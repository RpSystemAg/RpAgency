import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

function eventApi() {
  const listeners = new Set();
  return {
    addListener(listener) { listeners.add(listener); },
    removeListener(listener) { listeners.delete(listener); },
    async emit(...args) { for (const listener of [...listeners]) await listener(...args); },
  };
}

function createStorageArea() {
  const store = new Map();
  return {
    async get(keys) {
      if (keys == null) return Object.fromEntries(store);
      const out = {};
      const list = Array.isArray(keys) ? keys : typeof keys === "string" ? [keys] : Object.keys(keys || {});
      for (const key of list) if (store.has(key)) out[key] = store.get(key);
      return out;
    },
    async set(value) { for (const [key, item] of Object.entries(value || {})) store.set(key, item); },
    async remove(keys) { for (const key of (Array.isArray(keys) ? keys : [keys])) store.delete(key); },
    clearForTest() { store.clear(); },
  };
}

const local = createStorageArea();
const session = createStorageArea();
const noop = async () => undefined;
const tabRows = new Map();
const tabCalls = [];
let failingActivationTabId = 0;

function resetTabs({ targetActive = false } = {}) {
  tabRows.clear();
  tabRows.set(10, { id: 10, windowId: 7, url: "https://operator.test/", title: "Operator", active: !targetActive });
  tabRows.set(20, { id: 20, windowId: 7, url: "https://owned.test/", title: "Owned", active: targetActive });
  tabRows.set(30, { id: 30, windowId: 7, url: "https://newer-choice.test/", title: "Newer choice", active: false });
  tabCalls.length = 0;
  failingActivationTabId = 0;
  local.clearForTest();
  session.clearForTest();
}

globalThis.chrome = {
  runtime: {
    onInstalled: eventApi(), onStartup: eventApi(), onMessage: eventApi(), onConnect: eventApi(),
    getURL: (path) => `chrome-extension://test/${path}`,
  },
  alarms: { onAlarm: eventApi(), create: noop, clear: async () => true, get: async () => null },
  tabs: {
    onCreated: eventApi(), onReplaced: eventApi(), onRemoved: eventApi(), onActivated: eventApi(), onUpdated: eventApi(),
    async get(id) {
      const numeric = Number(id);
      tabCalls.push(`get:${numeric}`);
      const row = tabRows.get(numeric);
      if (!row) throw new Error("tab_missing");
      return { ...row };
    },
    async query(query = {}) {
      tabCalls.push(`query:${Number(query.windowId || 0)}:${query.active === true ? "active" : "all"}`);
      return [...tabRows.values()].filter((row) => (
        (!query.windowId || Number(row.windowId) === Number(query.windowId))
        && (query.active !== true || row.active)
      )).map((row) => ({ ...row }));
    },
    async update(id, props = {}) {
      const numeric = Number(id);
      tabCalls.push(`update:${numeric}:${props.active === true ? "active" : "other"}`);
      if (numeric === failingActivationTabId) throw Object.assign(new Error("injected_activation_failure"), { code: "INJECTED_ACTIVATION_FAILURE" });
      const row = tabRows.get(numeric);
      if (!row) throw new Error("tab_missing");
      if (props.active === true) {
        for (const candidate of tabRows.values()) if (candidate.windowId === row.windowId) candidate.active = false;
        row.active = true;
      }
      Object.assign(row, props);
      return { ...row };
    },
    create: async () => ({ id: 1, windowId: 7, url: "about:blank" }),
    remove: noop,
    captureVisibleTab: async () => "",
  },
  windows: {
    onRemoved: eventApi(), onFocusChanged: eventApi(), getAll: async () => [],
    get: async () => ({ id: 7, tabs: [...tabRows.values()].map((row) => ({ ...row })) }),
    create: async () => ({ id: 7, tabs: [] }), update: noop, remove: noop, WINDOW_ID_NONE: -1,
  },
  debugger: { onDetach: eventApi(), onEvent: eventApi(), getTargets: async () => [], attach: noop, detach: noop, sendCommand: noop },
  storage: { local, session },
  action: { setBadgeText: noop, setBadgeBackgroundColor: noop },
  scripting: { executeScript: async () => [] },
  notifications: { create: noop },
};

const { __test } = await import(`../service-worker.js?native-foreground-lease=${Date.now()}`);

async function registerOwnedTarget() {
  await chrome.storage.local.set({
    prstudioTabRegistry: {
      "20": {
        tabId: 20,
        windowId: 7,
        taskId: "task-native-lease",
        laneId: "lane-native-lease",
        expectedOrigin: "https://owned.test",
        url: "https://owned.test/",
        title: "Owned",
        owner: "prstudio-agent",
        ownershipNonce: "owned-native-lease-nonce",
        provisional: false,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      },
    },
  });
}

function activeTabId() {
  return Number([...tabRows.values()].find((row) => row.active)?.id || 0);
}

test("foreground lease rejects an unowned tab before any activation", async () => {
  resetTabs();
  await assert.rejects(
    () => __test.withOwnedTabForeground(20, async () => "must-not-run", "unit_unowned"),
    (error) => error?.code === "technical_tab_not_controlled",
  );
  assert.equal(tabCalls.some((call) => call.startsWith("update:")), false, JSON.stringify(tabCalls));
});

test("foreground lease activates only the owned tab for the whole operation and restores the prior tab", async () => {
  resetTabs();
  await registerOwnedTarget();
  const result = await __test.withOwnedTabForeground(20, async (lease) => {
    tabCalls.push("operation:start");
    assert.equal(activeTabId(), 20);
    assert.equal(lease.activated, true);
    assert.equal(lease.previousActiveTabId, 10);
    await Promise.resolve();
    assert.equal(activeTabId(), 20);
    tabCalls.push("operation:end");
    return { ok: true };
  }, "unit_native_click");

  assert.deepEqual(result, { ok: true });
  assert.equal(activeTabId(), 10);
  const ownershipRead = tabCalls.indexOf("get:20");
  const activation = tabCalls.indexOf("update:20:active");
  const operationStart = tabCalls.indexOf("operation:start");
  const operationEnd = tabCalls.indexOf("operation:end");
  const restoration = tabCalls.lastIndexOf("update:10:active");
  assert.ok(ownershipRead >= 0 && ownershipRead < activation, JSON.stringify(tabCalls));
  assert.ok(activation < operationStart && operationStart < operationEnd && operationEnd < restoration, JSON.stringify(tabCalls));
});

test("foreground restoration is best-effort and never replaces the operation result or error", async () => {
  resetTabs();
  await registerOwnedTarget();
  failingActivationTabId = 10;
  const value = await __test.withOwnedTabForeground(20, async () => "operation-result", "unit_restore_failure");
  assert.equal(value, "operation-result");
  assert.equal(activeTabId(), 20);

  resetTabs();
  await registerOwnedTarget();
  const expected = Object.assign(new Error("operation_failed"), { code: "EXPECTED_OPERATION_FAILURE" });
  await assert.rejects(
    () => __test.withOwnedTabForeground(20, async () => { throw expected; }, "unit_operation_failure"),
    (error) => error === expected,
  );
  assert.equal(activeTabId(), 10);
});

test("foreground lease does not overwrite a newer operator tab choice", async () => {
  resetTabs();
  await registerOwnedTarget();
  await __test.withOwnedTabForeground(20, async () => {
    assert.equal(activeTabId(), 20);
    await chrome.tabs.update(30, { active: true });
    assert.equal(activeTabId(), 30);
  }, "unit_operator_switch");
  assert.equal(activeTabId(), 30);
  assert.equal(tabCalls.filter((call) => call === "update:10:active").length, 0, JSON.stringify(tabCalls));
});

test("already-active owned tabs do not cause redundant activation or restoration", async () => {
  resetTabs({ targetActive: true });
  await registerOwnedTarget();
  await __test.withOwnedTabForeground(20, async (lease) => {
    assert.equal(lease.activated, false);
    assert.equal(activeTabId(), 20);
  }, "unit_already_active");
  assert.equal(tabCalls.some((call) => call.startsWith("update:")), false, JSON.stringify(tabCalls));
});

test("native element, direct input, scroll, progressive screenshot scroll and drag paths hold the foreground lease", async () => {
  const worker = await readFile(new URL("../service-worker.js", import.meta.url), "utf8");
  assert.match(worker, /async function runNativeElementAction\([\s\S]*?return withOwnedTabForeground\([\s\S]*?runNativeElementActionForeground/);
  assert.match(worker, /case "native_input":[\s\S]*?return withOwnedTabForeground\(tabId/);
  assert.match(worker, /case "scroll":[\s\S]*?return withOwnedTabForeground\(tabId/);
  assert.match(worker, /async function progressiveScroll\([\s\S]*?return withOwnedTabForeground\([\s\S]*?progressiveScrollForeground/);
  assert.match(worker, /action === "playwright_drag_and_drop"[\s\S]*?return withOwnedTabForeground\(tabId/);
});
