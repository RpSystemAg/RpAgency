import assert from "node:assert/strict";
import test from "node:test";
import { classifyStepEvidence } from "../lib/effect-verification.js";

test("owned browser_open with URL readback is verified on the first result", () => {
  const verdict = classifyStepEvidence(
    { type: "open_tab", url: "https://example.test/" },
    { created: true, ownedBeforeNavigation: true, url: "https://example.test/", domEvidence: { readyState: "complete", href: "https://example.test/", hasDocumentElement: true, bodyLength: 42 } },
    { actualUrl: "https://example.test/", urlMatched: true },
  );
  assert.deepEqual(verdict, { applicationAccepted: true, verificationStrength: "observed_ui_state" });
});

test("click is verified only from an observed post-dispatch URL, DOM or popup effect", () => {
  const observed = classifyStepEvidence({ type: "click" }, { effectEvidence: { observed: true, strength: "observed_ui_state" } });
  const unknown = classifyStepEvidence({ type: "click" }, { effectEvidence: { observed: false, reason: "effect_not_observed" } });
  assert.equal(observed.applicationAccepted, true);
  assert.equal(unknown.applicationAccepted, null);
  assert.equal(unknown.verificationStrength, "transport_or_ui_dispatch");
});

test("executor readback aliases are authoritative and negative evidence cannot be promoted", () => {
  assert.equal(classifyStepEvidence({ type: "fill" }, { application_effect_verified: true }).applicationAccepted, true);
  assert.equal(classifyStepEvidence({ type: "fill" }, { application_effect_verified: false }).applicationAccepted, false);
  assert.equal(classifyStepEvidence({ type: "fill" }, { application_effect_verified: null }).applicationAccepted, null);
});

test("close, navigation and screenshots require concrete readback evidence", () => {
  assert.equal(classifyStepEvidence({ type: "close_tab" }, { closed: true }, { targetAbsent: true }).applicationAccepted, true);
  assert.equal(classifyStepEvidence({ type: "navigate" }, { url: "https://wrong.test" }, { actualUrl: "https://wrong.test", urlMatched: false }).applicationAccepted, false);
  assert.equal(classifyStepEvidence({ type: "screenshot" }, { artifact: { sha256: "a".repeat(64) } }).applicationAccepted, true);
});
