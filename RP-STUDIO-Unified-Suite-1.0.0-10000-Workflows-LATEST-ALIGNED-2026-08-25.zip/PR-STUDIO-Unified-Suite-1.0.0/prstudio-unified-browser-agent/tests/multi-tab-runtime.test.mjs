import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { actionToSteps } from '../lib/protocol.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const worker = fs.readFileSync(path.join(here, '..', 'service-worker.js'), 'utf8');

function functionSource(name, nextName) {
  const start = worker.indexOf(`async function ${name}`);
  assert.ok(start >= 0, `missing ${name}`);
  const end = nextName ? worker.indexOf(`\nasync function ${nextName}`, start + 1) : -1;
  return worker.slice(start, end > start ? end : undefined);
}

test('new tab ownership commits affinity only after navigation and never requires eager CDP', () => {
  const source = functionSource('createOwnedAgentTab', 'registerAdoptedTab');
  const navigateAt = source.indexOf('await chrome.tabs.update(tabId, { url, active: false })');
  const bindAt = source.indexOf('await bindTabAffinity(state, tabId');
  assert.ok(navigateAt > 0);
  assert.ok(bindAt > navigateAt, 'current-tab affinity must be committed only after target navigation');
  assert.doesNotMatch(source, /await attachDebugger\(tabId\)/, 'opening a tab must not depend on CDP attach');
  assert.match(source, /previousStateTabId/);
  assert.match(source, /state\.tabId = previousStateTabId/);
});

test('resident agent recovers a valid tab after failed open or close', () => {
  const source = functionSource('executeBrowserKingTool', null);
  assert.match(worker, /async function recoverBrowserKingStateTab/);
  assert.match(source, /recoverBrowserKingStateTab\(state, previousTabId\)/);
  assert.match(source, /step\.type === "close_tab"/);
  assert.match(source, /browserTabsOperation === "activate"/);
  assert.match(source, /ownedTab\(Number\(result\.tabId\)\)/);
});

test('list-pages protocol can activate an explicit owned tab', () => {
  assert.deepEqual(actionToSteps('playwright_list_pages', { tab_id: 77, activate: true }), [
    { type: 'list_tabs', tabId: 77, activate: true },
  ]);
});

test('MV3 stale debugger attachments have a bounded reclaim path', () => {
  const source = functionSource('acquireDebuggerOwnership', 'attachDebuggerIfNeeded');
  assert.match(source, /service_worker_stale_debugger_reclaim/);
  assert.match(source, /chrome\.debugger\.detach\(\{ tabId: id \}\)/);
  assert.match(source, /cdp_target_busy_unowned/);
});


test('not-owned tab failures point to adoption without rebinding the lane', () => {
  const assertSource = functionSource('assertOwnedTab', 'listOwnedTabs');
  const resolveSource = functionSource('resolveTabId', 'assertTargetBinding');
  assert.match(assertSource, /recommendedNextAction/);
  assert.match(assertSource, /browser_adopt_tabs/);
  assert.match(assertSource, /doNotRebindContext: true/);
  assert.match(resolveSource, /explicit_tab_not_owned/);
  assert.match(resolveSource, /explicit_tab_auto_adoption/);
  assert.match(resolveSource, /registerAdoptedTab\(explicit/);
  assert.match(resolveSource, /browser_adopt_tabs/);
  const agentSource = functionSource('executeBrowserKingTool', null);
  assert.match(agentSource, /case "browser_adopt_tabs"/);
  assert.match(agentSource, /type: "adopt_tabs"/);
});

test('new tab open never converts about:blank into a non-provisional owned record', () => {
  const source = functionSource('createOwnedAgentTab', 'registerAdoptedTab');
  assert.doesNotMatch(source, /waitForTab\([^\n]+\)\.catch\(\(\) => \{\}\)/, 'readiness failure must not be swallowed');
  assert.match(source, /const committedHttp = \/\^https\?:\/i\.test\(committedUrl\)/);
  assert.match(source, /const provisional = !committedHttp/);
  assert.match(source, /agent_tab_navigation_not_committed/);
  assert.doesNotMatch(source, /provisional:\s*false,\s*\n\s*url:\s*String\(loaded\?\.url \|\| url\)/);
});
