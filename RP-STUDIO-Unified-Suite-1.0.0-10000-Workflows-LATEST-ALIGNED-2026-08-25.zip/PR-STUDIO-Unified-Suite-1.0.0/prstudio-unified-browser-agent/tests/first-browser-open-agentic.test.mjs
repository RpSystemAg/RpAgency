import assert from "node:assert/strict";
import test from "node:test";

const TARGET_URL = "https://first-command.example.test/dashboard";
const TARGET_TITLE = "First command dashboard";
const LANE_ID = "lane-first-browser-open";
const TASK_ID = "task-first-browser-open";

function deferred() {
  let resolve;
  let reject;
  const promise = new Promise((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

function eventApi() {
  const listeners = new Set();
  return {
    addListener(listener) { listeners.add(listener); },
    removeListener(listener) { listeners.delete(listener); },
    async emit(...args) {
      for (const listener of [...listeners]) await listener(...args);
    },
    get size() { return listeners.size; },
  };
}

function clone(value) {
  return value === undefined ? undefined : structuredClone(value);
}

function createStorageArea(initial = {}, onSet = () => {}) {
  const store = new Map(Object.entries(initial).map(([key, value]) => [key, clone(value)]));
  return {
    async get(keys) {
      if (keys == null) return clone(Object.fromEntries(store));
      const out = {};
      if (typeof keys === "string") {
        if (store.has(keys)) out[keys] = clone(store.get(keys));
        return out;
      }
      if (Array.isArray(keys)) {
        for (const key of keys) if (store.has(key)) out[key] = clone(store.get(key));
        return out;
      }
      for (const [key, fallback] of Object.entries(keys || {})) {
        out[key] = store.has(key) ? clone(store.get(key)) : clone(fallback);
      }
      return out;
    },
    async set(values) {
      for (const [key, value] of Object.entries(values || {})) store.set(key, clone(value));
      onSet(clone(values || {}));
    },
    async remove(keys) {
      for (const key of (Array.isArray(keys) ? keys : [keys])) store.delete(key);
    },
    async setAccessLevel() {},
  };
}

function jsonResponse(url, body, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    redirected: false,
    url,
    headers: { get: () => null },
    async json() { return clone(body); },
  };
}

function abortError() {
  const error = new Error("request aborted");
  error.name = "AbortError";
  return error;
}

function createAgenticHarness() {
  const operations = [];
  const apiCalls = [];
  const checkpoints = [];
  const failedTasks = [];
  const detachedTabIds = [];
  const attachedTabIds = [];
  const foreignAttached = new Set([70]);
  const runtimeAttached = new Set();
  const attachRaceBusyIds = new Set();
  const tabs = new Map([
    [70, { id: 70, windowId: 9, active: true, status: "complete", url: "https://operator.example.test/private", title: "Operator tab" }],
  ]);
  const tabEvents = {
    onCreated: eventApi(),
    onReplaced: eventApi(),
    onRemoved: eventApi(),
    onActivated: eventApi(),
    onUpdated: eventApi(),
  };
  const reconcileEntered = deferred();
  const releaseReconcile = deferred();
  const taskCompleted = deferred();
  let reconcileQueryCalls = 0;
  let nextTaskCalls = 0;
  let nextTabId = 101;
  let workerTestApi = null;
  let navigationClaim = null;
  let windowCreateCalls = 0;

  const config = {
    apiBase: "https://control.example.test/wp-json/prstudio-unified/v1",
    siteUrl: "https://control.example.test",
    token: "test-token",
    authExpired: false,
  };
  const local = createStorageArea({
    prstudioConfig: config,
    prstudioTabRegistry: {},
    prstudioTabAffinity: {},
    prstudioRuntimeSessions: {},
    prstudioLocalSchedules: [],
  }, (values) => {
    const registry = values.prstudioTabRegistry;
    const first = registry?.["101"];
    if (first?.provisional && first.url === TARGET_URL) operations.push("ownership:101");
  });
  const session = createStorageArea();

  const chrome = {
    runtime: {
      onInstalled: eventApi(),
      onStartup: eventApi(),
      onMessage: eventApi(),
      onConnect: eventApi(),
      getURL: (path) => `chrome-extension://agent-test/${path}`,
      getPlatformInfo: async () => ({ os: "win", arch: "x86-64" }),
      sendMessage: async () => undefined,
    },
    alarms: {
      onAlarm: eventApi(),
      async create() {},
      async clear() { return true; },
      async get() { return null; },
    },
    tabs: {
      ...tabEvents,
      async query(query = {}) {
        if (Object.keys(query).length === 0) {
          reconcileQueryCalls += 1;
          reconcileEntered.resolve();
          await releaseReconcile.promise;
        }
        let rows = [...tabs.values()];
        if (query.windowId != null) rows = rows.filter((tab) => Number(tab.windowId) === Number(query.windowId));
        if (query.active != null) rows = rows.filter((tab) => Boolean(tab.active) === Boolean(query.active));
        return clone(rows);
      },
      async get(tabId) {
        const tab = tabs.get(Number(tabId));
        if (!tab) throw new Error(`tab_missing:${tabId}`);
        return clone(tab);
      },
      async create(properties = {}) {
        const id = nextTabId++;
        const tab = {
          id,
          windowId: Number(properties.windowId || 9),
          active: Boolean(properties.active),
          status: "loading",
          url: String(properties.url || "about:blank"),
          pendingUrl: "",
          title: "",
        };
        tabs.set(id, tab);
        operations.push(`create:${id}:${tab.url}`);
        await tabEvents.onCreated.emit(clone(tab));
        return clone(tab);
      },
      async update(tabId, patch = {}) {
        const id = Number(tabId);
        const current = tabs.get(id);
        if (!current) throw new Error(`tab_missing:${id}`);
        if (patch.url) {
          const registry = (await local.get("prstudioTabRegistry")).prstudioTabRegistry || {};
          navigationClaim = clone(registry[String(id)] || null);
          operations.push(`navigate:${id}:${patch.url}`);
        }
        const next = {
          ...current,
          ...patch,
          ...(patch.url ? { status: "complete", pendingUrl: "", title: TARGET_TITLE } : {}),
        };
        tabs.set(id, next);
        await tabEvents.onUpdated.emit(id, patch.url ? { url: next.url, status: "complete" } : clone(patch), clone(next));
        return clone(next);
      },
      async remove(tabId) {
        const id = Number(tabId);
        tabs.delete(id);
        operations.push(`remove:${id}`);
      },
      async reload(tabId) { return clone(tabs.get(Number(tabId))); },
      async move(tabId, moveProperties) {
        const id = Number(tabId);
        const next = { ...tabs.get(id), windowId: Number(moveProperties.windowId) };
        tabs.set(id, next);
        return clone(next);
      },
      async group() { return 61; },
      async captureVisibleTab() { return ""; },
      async sendMessage() { return undefined; },
    },
    windows: {
      onRemoved: eventApi(),
      onFocusChanged: eventApi(),
      WINDOW_ID_NONE: -1,
      async getAll() {
        return [{ id: 9, type: "normal", focused: true, tabs: clone([...tabs.values()]) }];
      },
      async get(windowId) {
        if (Number(windowId) !== 9) throw new Error(`window_missing:${windowId}`);
        return { id: 9, type: "normal", focused: true, tabs: clone([...tabs.values()].filter((tab) => tab.windowId === 9)) };
      },
      async create() { windowCreateCalls += 1; return { id: 99, type: "normal", tabs: [] }; },
      async update(windowId) { return { id: Number(windowId), type: "normal" }; },
      async remove() {},
    },
    tabGroups: {
      async get() { throw new Error("group_missing"); },
      async update(groupId, patch) { return { id: Number(groupId), ...patch }; },
    },
    debugger: {
      onDetach: eventApi(),
      onEvent: eventApi(),
      async getTargets() {
        return [
          ...[...foreignAttached].map((tabId) => ({ tabId, attached: true })),
          ...[...runtimeAttached].filter((tabId) => !foreignAttached.has(tabId)).map((tabId) => ({ tabId, attached: true })),
        ];
      },
      async attach({ tabId }) {
        const id = Number(tabId);
        attachedTabIds.push(id);
        operations.push(`attach:${id}`);
        if (attachRaceBusyIds.has(id)) {
          foreignAttached.add(id);
          throw new Error("Another debugger is already attached to the tab");
        }
        if (foreignAttached.has(id)) throw new Error("Another debugger is already attached to the tab");
        runtimeAttached.add(id);
      },
      async detach({ tabId }) {
        const id = Number(tabId);
        detachedTabIds.push(id);
        operations.push(`detach:${id}`);
        runtimeAttached.delete(id);
      },
      async sendCommand(_target, method) {
        operations.push(`cdp:${method}`);
        return {};
      },
    },
    storage: { local, session },
    scripting: {
      async executeScript({ target } = {}) {
        const tab = tabs.get(Number(target?.tabId || 0));
        if (!tab) return [];
        return [{ result: {
          readyState: "complete",
          href: tab.url,
          hasDocumentElement: true,
          bodyLength: 321,
        } }];
      },
    },
    action: { async setBadgeText() {}, async setBadgeBackgroundColor() {} },
    sidePanel: { async setPanelBehavior() {} },
    notifications: { async create() {}, async clear() { return true; } },
    system: { display: { async getInfo() { return []; } } },
  };

  async function fetch(input, options = {}) {
    const url = String(input);
    const parsed = new URL(url);
    const path = `${parsed.pathname}${parsed.search}`;
    const body = options.body ? JSON.parse(options.body) : null;
    apiCalls.push({ method: options.method || "GET", path, body });

    if (parsed.pathname.endsWith("/device/heartbeat")) return jsonResponse(url, { ok: true });
    if (parsed.pathname.endsWith("/logs")) return jsonResponse(url, { ok: true });
    if (parsed.pathname.endsWith("/tasks/next")) {
      nextTaskCalls += 1;
      if (nextTaskCalls === 1) {
        return jsonResponse(url, {
          wait_supported: true,
          wait_mode: "immediate",
          waited_ms: 0,
          task: {
            task_uuid: TASK_ID,
            lease_token: "lease-first-open",
            status: "leased",
            action: "playwright_new_page",
            arguments: { url: TARGET_URL, wait_until: "interactive", _prstudio_lane_id: LANE_ID },
            step_index: 0,
            checkpoint: { last_completed_step: -1 },
          },
        });
      }
      return new Promise((resolve, reject) => {
        if (options.signal?.aborted) { reject(abortError()); return; }
        options.signal?.addEventListener("abort", () => reject(abortError()), { once: true });
      });
    }
    if (parsed.pathname.endsWith(`/tasks/${TASK_ID}/running`)) return jsonResponse(url, { ok: true });
    if (parsed.pathname.endsWith(`/tasks/${TASK_ID}/heartbeat`)) return jsonResponse(url, { ok: true });
    if (parsed.pathname.endsWith(`/tasks/${TASK_ID}/checkpoint`)) {
      checkpoints.push(clone(body));
      return jsonResponse(url, { ok: true });
    }
    if (parsed.pathname.endsWith(`/tasks/${TASK_ID}/complete`)) {
      taskCompleted.resolve(clone(body));
      queueMicrotask(() => { workerTestApi?.stopPolling("agentic_test_complete", 2_000).catch(() => {}); });
      return jsonResponse(url, { ok: true });
    }
    if (parsed.pathname.endsWith(`/tasks/${TASK_ID}/fail`)) {
      failedTasks.push(clone(body));
      taskCompleted.reject(new Error(`first browser_open failed: ${JSON.stringify(body)}`));
      return jsonResponse(url, { ok: true });
    }
    throw new Error(`unexpected API prerequisite: ${options.method || "GET"} ${path}`);
  }

  return {
    chrome,
    fetch,
    operations,
    apiCalls,
    checkpoints,
    failedTasks,
    detachedTabIds,
    attachedTabIds,
    foreignAttached,
    attachRaceBusyIds,
    tabs,
    local,
    reconcileEntered,
    releaseReconcile,
    taskCompleted,
    setWorkerTestApi(value) { workerTestApi = value; },
    addTab(tab) { tabs.set(Number(tab.id), clone(tab)); },
    get navigationClaim() { return clone(navigationClaim); },
    get reconcileQueryCalls() { return reconcileQueryCalls; },
    get nextTaskCalls() { return nextTaskCalls; },
    get windowCreateCalls() { return windowCreateCalls; },
  };
}

async function within(promise, timeoutMs, label) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} timed out`)), timeoutMs); }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

const harness = createAgenticHarness();
globalThis.chrome = harness.chrome;
globalThis.fetch = harness.fetch;
const { __test } = await import(`../service-worker.js?first-browser-open-agentic=${Date.now()}`);
harness.setWorkerTestApi(__test);

test("the first agentic browser_open is startup-single-flight, owned before navigation, and returns live URL/title/DOM evidence without a context prerequisite", async () => {
  await within(harness.reconcileEntered.promise, 2_000, "worker reconciliation barrier");
  assert.equal(chrome.runtime.onStartup.size, 1);

  // Reproduce two MV3 wake sources in the same incarnation while recovery is
  // still in flight. They must share one recovery barrier and one polling lane.
  const duplicateStartup = chrome.runtime.onStartup.emit();
  await Promise.resolve();
  assert.equal(harness.reconcileQueryCalls, 1, "concurrent startup created a second ownership reconciliation");
  assert.equal(harness.nextTaskCalls, 0, "polling crossed the startup recovery barrier");
  harness.releaseReconcile.resolve();
  await duplicateStartup;

  const completion = await within(harness.taskCompleted.promise, 4_000, "first browser_open completion");
  await __test.stopPolling("agentic_test_assertions", 2_000);

  assert.equal(harness.reconcileQueryCalls, 1, "MV3 startup recovery was not single-flight");
  assert.equal(harness.nextTaskCalls, 1, "more than one polling lane claimed the first task");
  assert.equal(harness.windowCreateCalls, 0, "browser_open incorrectly required a synthetic browser/context window");
  assert.deepEqual(harness.failedTasks, []);
  assert.equal(harness.checkpoints.length, 1);

  const result = harness.checkpoints[0].result;
  assert.equal(result.tabId, 101);
  assert.equal(result.url, TARGET_URL);
  assert.equal(result.title, TARGET_TITLE);
  assert.deepEqual(result.domEvidence, {
    readyState: "complete",
    href: TARGET_URL,
    hasDocumentElement: true,
    bodyLength: 321,
  });
  assert.equal(result.created, true);
  assert.equal(result.ownedBeforeNavigation, true);
  assert.equal(result.laneId, LANE_ID);
  assert.equal(result.verified, true);
  assert.equal(completion.result.url, TARGET_URL);
  assert.deepEqual(completion.result.domEvidence, result.domEvidence);

  assert.deepEqual(harness.navigationClaim && {
    owner: harness.navigationClaim.owner,
    provisional: harness.navigationClaim.provisional,
    url: harness.navigationClaim.url,
    taskId: harness.navigationClaim.taskId,
    laneId: harness.navigationClaim.laneId,
    hasNonce: Boolean(harness.navigationClaim.ownershipNonce),
  }, {
    owner: "prstudio-agent",
    provisional: true,
    url: TARGET_URL,
    taskId: TASK_ID,
    laneId: LANE_ID,
    hasNonce: true,
  });

  const createIndex = harness.operations.indexOf("create:101:about:blank");
  const ownershipIndex = harness.operations.indexOf("ownership:101");
  const attachIndex = harness.operations.indexOf("attach:101");
  const navigateIndex = harness.operations.indexOf(`navigate:101:${TARGET_URL}`);
  assert.ok(createIndex >= 0 && createIndex < ownershipIndex, `claim did not follow about:blank creation: ${JSON.stringify(harness.operations)}`);
  assert.ok(ownershipIndex < navigateIndex, `required order is claim -> navigate: ${JSON.stringify(harness.operations)}`);
  assert.equal(attachIndex, -1, `browser_open must not depend on eager debugger attach: ${JSON.stringify(harness.operations)}`);

  assert.ok(!harness.detachedTabIds.includes(101), "browser_open detached a debugger it never needed to acquire");
  assert.ok(!harness.detachedTabIds.includes(70), "startup/open detached the operator's foreign debugger");
});

test("foreign debugger targets are rejected before command dispatch and are never detached, including the attach race", async () => {
  assert.equal(typeof __test.attachDebuggerIfNeeded, "function", "missing debugger ownership regression hook");

  harness.addTab({ id: 201, windowId: 9, active: false, status: "complete", url: "https://busy.example.test/", title: "Busy" });
  await __test.registerOwnedTab(201, { taskId: "busy-preflight", laneId: LANE_ID, url: "https://busy.example.test/" });
  harness.foreignAttached.add(201);
  const attachCallsBeforePreflight = harness.attachedTabIds.length;
  const detachCallsBeforePreflight = harness.detachedTabIds.length;
  await assert.rejects(
    () => __test.attachDebuggerIfNeeded(201),
    (error) => error?.code === "cdp_target_busy_unowned",
  );
  assert.equal(harness.attachedTabIds.length, attachCallsBeforePreflight, "preflight busy target still attempted attach");
  assert.equal(harness.detachedTabIds.length, detachCallsBeforePreflight, "preflight busy target was detached despite missing local ownership");

  harness.addTab({ id: 202, windowId: 9, active: false, status: "complete", url: "https://race.example.test/", title: "Attach race" });
  await __test.registerOwnedTab(202, { taskId: "busy-race", laneId: LANE_ID, url: "https://race.example.test/" });
  harness.attachRaceBusyIds.add(202);
  const detachCallsBeforeRace = harness.detachedTabIds.length;
  await assert.rejects(
    () => __test.attachDebuggerIfNeeded(202),
    (error) => error?.code === "cdp_target_busy_unowned",
  );
  assert.equal(harness.attachedTabIds.at(-1), 202, "attach race was not exercised");
  assert.equal(harness.detachedTabIds.length, detachCallsBeforeRace, "attach race detached a debugger that this worker never acquired");
  assert.ok(!harness.detachedTabIds.includes(201) && !harness.detachedTabIds.includes(202));
});
