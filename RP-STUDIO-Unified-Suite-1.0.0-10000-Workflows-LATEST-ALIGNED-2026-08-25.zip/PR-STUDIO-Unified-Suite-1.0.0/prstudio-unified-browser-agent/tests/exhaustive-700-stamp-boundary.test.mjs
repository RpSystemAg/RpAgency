import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import {
  approvedStampedMutation,
  normalizeStampedText,
} from '../../.github/scripts/exhaustive-700-matrix.mjs';

const SHA = '0123456789abcdef0123456789abcdef01234567';
const HASH_A = 'a'.repeat(64);
const HASH_B = 'b'.repeat(64);
const EXPECTED_HASHES = { contract: HASH_A, protocol: HASH_B, timestamp: '2026-08-24T00:00:00Z' };
const ROOT = resolve(fileURLToPath(new URL('../..', import.meta.url)));

function bytes(value) {
  return Buffer.from(value, 'utf8');
}

test('Browser BUILD-INFO accepts only the exact deterministic identity stamp', () => {
  const source = JSON.stringify({
    version: '1.0.0', source_commit: 'UNSTAMPED', build_id: 'prstudio-browser-1.0.0+unbound',
    built_at_utc: 'UNSTAMPED', control_contract_sha256: 'UNSTAMPED', control_protocol_sha256: 'UNSTAMPED',
    capability_contract_sha256: HASH_A,
  }, null, 2) + '\n';
  const stamped = JSON.stringify({
    version: '1.0.0', source_commit: SHA, build_id: `prstudio-browser-1.0.0+git.${SHA.slice(0, 12)}`,
    built_at_utc: '2026-08-24T00:00:00Z', control_contract_sha256: HASH_A, control_protocol_sha256: HASH_B,
    capability_contract_sha256: HASH_A,
  }, null, 2) + '\n';
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/BUILD-INFO.json', bytes(source), bytes(stamped), SHA, EXPECTED_HASHES), true);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/BUILD-INFO.json', bytes(source), bytes(stamped.replace(HASH_A, HASH_B)), SHA, EXPECTED_HASHES), false);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/BUILD-INFO.json', bytes(source), bytes(stamped.replace('2026-08-24T00:00:00Z', '2026-08-24T00:00:01Z')), SHA, EXPECTED_HASHES), false);
  const duplicate = stamped.replace('"control_contract_sha256":', `"control_contract_sha256": "${HASH_A}", "control_contract_sha256":`);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/BUILD-INFO.json', bytes(source), bytes(duplicate), SHA, EXPECTED_HASHES), false);
  assert.equal(approvedStampedMutation('unrelated.json', bytes(source), bytes(stamped), SHA), false);
});

test('Control BUILD-INFO rejects a valid-looking stamp bound to another commit', () => {
  const source = JSON.stringify({
    version: '1.0.0', source_commit: 'UNSTAMPED', build_id: 'prstudio-control-1.0.0+unbound',
    built_at_utc: 'UNSTAMPED', contract_file_sha256: 'UNSTAMPED', protocol_file_sha256: 'UNSTAMPED',
  }, null, 2) + '\n';
  const other = 'f'.repeat(40);
  const stamped = JSON.stringify({
    version: '1.0.0', source_commit: other, build_id: `prstudio-control-1.0.0+git.${other.slice(0, 12)}`,
    built_at_utc: '2026-08-24T00:00:00Z', contract_file_sha256: HASH_A, protocol_file_sha256: HASH_B,
  }, null, 2) + '\n';
  assert.equal(approvedStampedMutation('prstudio-unified-control/BUILD-INFO.json', bytes(source), bytes(stamped), SHA, EXPECTED_HASHES), false);
});

test('service-worker is never an approved stamp mutation', () => {
  const source = 'const status = {\n    sourceSha: EXECUTOR_SOURCE_SHA,\n    ready: true,\n};\n';
  const changed = source.replace('EXECUTOR_SOURCE_SHA', `"${SHA}"`);
  assert.equal(normalizeStampedText('prstudio-unified-browser-agent/service-worker.js', changed), changed);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/service-worker.js', bytes(source), bytes(changed), SHA), false);
});

test('executor metadata stamp rejects residual placeholders and unrelated edits', () => {
  const source = 'export const EXECUTOR_SOURCE_SHA = "UNSTAMPED";\nexport const EXECUTOR_BUILD_TIMESTAMP = "UNSTAMPED";\nexport const EXECUTOR_BUILD_ID = `prstudio-browser-${SUITE_VERSION}+unbound`;\nexport const KEEP = true;\n';
  const stamped = `export const EXECUTOR_SOURCE_SHA = "${SHA}";\nexport const EXECUTOR_BUILD_TIMESTAMP = "2026-08-24T00:00:00Z";\nexport const EXECUTOR_BUILD_ID = "prstudio-browser-1.0.0+git.${SHA.slice(0, 12)}";\nexport const KEEP = true;\n`;
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/lib/executor-meta.js', bytes(source), bytes(stamped), SHA), true);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/lib/executor-meta.js', bytes(source), bytes(stamped.replace('2026-08-24T00:00:00Z', 'not-a-time')), SHA), false);
  assert.equal(approvedStampedMutation('prstudio-unified-browser-agent/lib/executor-meta.js', bytes(source), bytes(stamped.replace('KEEP = true', 'KEEP = false')), SHA), false);
});

test('runtime source identity has one immutable import binding and declared hash placeholders', () => {
  const worker = readFileSync(resolve(ROOT, 'prstudio-unified-browser-agent/service-worker.js'), 'utf8');
  const buildInfo = JSON.parse(readFileSync(resolve(ROOT, 'prstudio-unified-browser-agent/BUILD-INFO.json'), 'utf8'));
  assert.equal((worker.match(/\bEXECUTOR_SOURCE_SHA\b/g) || []).length, 2, 'one import plus one runtime binding');
  assert.equal((worker.match(/^    sourceSha: EXECUTOR_SOURCE_SHA,$/gm) || []).length, 1);
  assert.doesNotMatch(worker, /^    sourceSha: "[0-9a-f]{40}",$/m);
  assert.equal(Object.hasOwn(buildInfo, 'control_contract_sha256'), true);
  assert.equal(Object.hasOwn(buildInfo, 'control_protocol_sha256'), true);
});
