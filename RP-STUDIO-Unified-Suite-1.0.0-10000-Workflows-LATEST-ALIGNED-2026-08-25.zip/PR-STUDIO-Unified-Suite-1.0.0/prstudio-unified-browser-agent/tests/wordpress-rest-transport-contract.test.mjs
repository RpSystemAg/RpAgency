import test from "node:test";
import assert from "node:assert/strict";
import {
  buildApiUrl,
  buildWordPressRestCandidates,
  discoverPairingEndpoint,
  installWordPressRestTransport,
  normalizeWordPressSiteBase,
  pairOptionsSupportsPost,
  repairConcatenatedPlainRestUrl,
  restIndexSupportsPairRoute,
  wordpressApiRootFromLinkHeader,
} from "../lib/wordpress-rest-transport.js";

const REST_NS = "prstudio-unified/v1";
const PAIR_ROUTE = "/prstudio-unified/v1/pair";

function fakeHeaders(values = {}) {
  const source = typeof values === "string" ? { "content-type": values } : values;
  const normalized = new Map(Object.entries(source).map(([name, value]) => [String(name).toLowerCase(), String(value)]));
  return { get(name) { return normalized.get(String(name).toLowerCase()) ?? null; } };
}

function response(url, { status = 200, contentType = "application/json; charset=utf-8", body = {}, redirected = false, headers = {} } = {}) {
  return {
    url,
    status,
    statusText: status === 200 ? "OK" : "Error",
    ok: status >= 200 && status < 300,
    redirected,
    headers: fakeHeaders({ "content-type": contentType, ...headers }),
    async json() {
      if (body instanceof Error) throw body;
      return body;
    },
  };
}

function discoveryHead(url, apiRoot) {
  return response(url, {
    contentType: "text/html; charset=utf-8",
    headers: { link: `<${apiRoot}>; rel="https://api.w.org/"` },
  });
}

function pairOptions(url, methods = ["POST"]) {
  return response(url, {
    headers: { allow: methods.join(", ") },
    body: { namespace: REST_NS, methods, endpoints: [{ methods }] },
  });
}

function restIndex(url, mode = "pretty") {
  return response(url, {
    body: {
      name: "WordPress",
      namespaces: ["wp/v2", REST_NS],
      routes: { [PAIR_ROUTE]: { namespace: REST_NS, methods: ["POST"] } },
      _test_mode: mode,
    },
  });
}

function eventApi() {
  const listeners = [];
  return {
    addListener(listener) { listeners.push(listener); },
    emit(message) { for (const listener of listeners) listener(message, {}, () => {}); },
  };
}

for (const [site, pretty, plain] of [
  ["https://example.com", "https://example.com/wp-json/prstudio-unified/v1/pair", "https://example.com/?rest_route=%2Fprstudio-unified%2Fv1%2Fpair"],
  ["https://example.com/", "https://example.com/wp-json/prstudio-unified/v1/pair", "https://example.com/?rest_route=%2Fprstudio-unified%2Fv1%2Fpair"],
  ["https://example.com/wordpress", "https://example.com/wordpress/wp-json/prstudio-unified/v1/pair", "https://example.com/wordpress/?rest_route=%2Fprstudio-unified%2Fv1%2Fpair"],
  ["https://example.com/wordpress/", "https://example.com/wordpress/wp-json/prstudio-unified/v1/pair", "https://example.com/wordpress/?rest_route=%2Fprstudio-unified%2Fv1%2Fpair"],
  ["http://127.0.0.1:8082", "http://127.0.0.1:8082/wp-json/prstudio-unified/v1/pair", "http://127.0.0.1:8082/?rest_route=%2Fprstudio-unified%2Fv1%2Fpair"],
]) {
  test(`REST candidates preserve WordPress installation root: ${site}`, () => {
    const actual = buildWordPressRestCandidates(site);
    assert.equal(actual.pretty.pairUrl, pretty);
    assert.equal(actual.plain.pairUrl, plain);
    assert.equal(new URL(actual.pretty.pairUrl).origin, new URL(site).origin);
    assert.equal(new URL(actual.plain.pairUrl).origin, new URL(site).origin);
  });
}

test("site query and fragment cannot contaminate REST discovery", () => {
  const base = normalizeWordPressSiteBase("https://example.com/wordpress/?preview=1#frag");
  assert.equal(base.href, "https://example.com/wordpress/");
  const candidates = buildWordPressRestCandidates("https://example.com/wordpress/?preview=1#frag");
  assert.equal(candidates.pretty.indexUrl, "https://example.com/wordpress/wp-json/");
  assert.equal(candidates.plain.indexUrl, "https://example.com/wordpress/?rest_route=%2F");
});

test("non-loopback cleartext pairing fails closed", () => {
  assert.throws(() => normalizeWordPressSiteBase("http://example.com"), (error) => error?.code === "pairing_https_required");
});

test("site URL userinfo fails closed", () => {
  assert.throws(() => normalizeWordPressSiteBase("https://user:pass@example.com/wordpress"), (error) => error?.code === "site_credentials_forbidden");
});

test("malformed site URL fails closed", () => {
  assert.throws(() => normalizeWordPressSiteBase("not a site"), (error) => error?.code === "site_url_invalid");
});

test("REST index recognizes namespace and route forms", () => {
  assert.equal(restIndexSupportsPairRoute({ namespaces: [REST_NS] }), true);
  assert.equal(restIndexSupportsPairRoute({ routes: { [PAIR_ROUTE]: {} } }), true);
  assert.equal(restIndexSupportsPairRoute({ namespaces: ["wp/v2"], routes: {} }), false);
  assert.equal(restIndexSupportsPairRoute("html"), false);
});

test("official WordPress discovery Link selects a same-origin custom REST prefix", () => {
  const root = wordpressApiRootFromLinkHeader(
    '<https://example.com/custom-rest/>; rel="https://api.w.org/", <https://example.com/feed/>; rel="alternate"',
    "https://example.com",
  );
  assert.equal(root?.href, "https://example.com/custom-rest/");
  assert.throws(
    () => wordpressApiRootFromLinkHeader('<https://evil.example/wp-json/>; rel="https://api.w.org/"', "https://example.com"),
    (error) => error?.code === "pairing_api_origin_mismatch",
  );
});

test("pair OPTIONS must advertise POST through Allow or endpoint schema", () => {
  assert.equal(pairOptionsSupportsPost({ endpoints: [{ methods: ["POST"] }] }), true);
  assert.equal(pairOptionsSupportsPost({ methods: { GET: true, POST: true } }), true);
  assert.equal(pairOptionsSupportsPost({}, "GET, POST, OPTIONS"), true);
  assert.equal(pairOptionsSupportsPost({ endpoints: [{ methods: ["GET"] }] }, "GET, OPTIONS"), false);
});

for (const [apiBase, relative, expected] of [
  ["https://example.com/wp-json/prstudio-unified/v1", "/device/heartbeat", "https://example.com/wp-json/prstudio-unified/v1/device/heartbeat"],
  ["https://example.com/wp-json/prstudio-unified/v1/", "tasks/next", "https://example.com/wp-json/prstudio-unified/v1/tasks/next"],
  ["https://example.com/wp-json/prstudio-unified/v1", "/tasks/task-1/running", "https://example.com/wp-json/prstudio-unified/v1/tasks/task-1/running"],
  ["https://example.com/?rest_route=/prstudio-unified/v1", "/device/heartbeat", "https://example.com/?rest_route=%2Fprstudio-unified%2Fv1%2Fdevice%2Fheartbeat"],
  ["https://example.com/?rest_route=/prstudio-unified/v1", "/tasks/next", "https://example.com/?rest_route=%2Fprstudio-unified%2Fv1%2Ftasks%2Fnext"],
  ["https://example.com/wordpress/?rest_route=/prstudio-unified/v1", "/tasks/task-1/checkpoint", "https://example.com/wordpress/?rest_route=%2Fprstudio-unified%2Fv1%2Ftasks%2Ftask-1%2Fcheckpoint"],
  ["https://example.com/wordpress/?rest_route=/prstudio-unified/v1", "/tasks/task-1/complete", "https://example.com/wordpress/?rest_route=%2Fprstudio-unified%2Fv1%2Ftasks%2Ftask-1%2Fcomplete"],
  ["https://example.com/wordpress/?rest_route=/prstudio-unified/v1", "/logs", "https://example.com/wordpress/?rest_route=%2Fprstudio-unified%2Fv1%2Flogs"],
]) {
  test(`server-authoritative api_base composes ${relative}`, () => {
    const actual = buildApiUrl(apiBase, relative);
    assert.equal(actual.href, expected);
    assert.equal(actual.origin, new URL(apiBase).origin);
  });
}

test("api_base query transport preserves real query parameters", () => {
  const actual = buildApiUrl("https://example.com/?rest_route=/prstudio-unified/v1", "/tasks/next?wait=20&device=abc");
  assert.equal(actual.searchParams.get("rest_route"), "/prstudio-unified/v1/tasks/next");
  assert.equal(actual.searchParams.get("wait"), "20");
  assert.equal(actual.searchParams.get("device"), "abc");
});

test("api_base with embedded credentials fails closed", () => {
  assert.throws(() => buildApiUrl("https://user:pass@example.com/?rest_route=/prstudio-unified/v1", "/status"), (error) => error?.code === "api_credentials_forbidden");
});

test("absolute relative route is rejected rather than changing origin", () => {
  assert.throws(() => buildApiUrl("https://example.com/?rest_route=/prstudio-unified/v1", "https://evil.example/tasks/next"), (error) => error?.code === "api_relative_route_invalid");
});

test("legacy concatenation repair separates wait query from rest_route", () => {
  const actual = repairConcatenatedPlainRestUrl("http://127.0.0.1:8082/?rest_route=/prstudio-unified/v1/tasks/next?wait=20&lease=abc");
  assert.equal(actual.searchParams.get("rest_route"), "/prstudio-unified/v1/tasks/next");
  assert.equal(actual.searchParams.get("wait"), "20");
  assert.equal(actual.searchParams.get("lease"), "abc");
});

test("official HEAD discovery and exact-route OPTIONS are non-mutating and authoritative", async () => {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), init });
    if (init.method === "HEAD") return discoveryHead(String(url), "https://example.com/wordpress/custom-rest/");
    if (init.method === "OPTIONS") return pairOptions(String(url));
    throw new Error(`unexpected method ${init.method}`);
  };
  const found = await discoverPairingEndpoint(fetchImpl, "https://example.com/wordpress");
  assert.equal(found.mode, "link");
  assert.equal(found.pairUrl, "https://example.com/wordpress/custom-rest/prstudio-unified/v1/pair");
  assert.deepEqual(calls.map((call) => call.init.method), ["HEAD", "OPTIONS"]);
  assert.ok(calls.every((call) => call.init.body === undefined));
});

test("plain-permalink Link composes the exact pair route without a REST-index GET", async () => {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), init });
    if (init.method === "HEAD") return discoveryHead(String(url), "http://127.0.0.1:8082/?rest_route=/");
    if (init.method === "OPTIONS") return pairOptions(String(url));
    throw new Error(`unexpected method ${init.method}`);
  };
  const found = await discoverPairingEndpoint(fetchImpl, "http://127.0.0.1:8082");
  assert.equal(found.mode, "link");
  assert.equal(new URL(found.pairUrl).searchParams.get("rest_route"), PAIR_ROUTE);
  assert.equal(calls.length, 2);
  assert.deepEqual(calls.map((call) => call.init.method), ["HEAD", "OPTIONS"]);
  assert.ok(calls.every((call) => call.init.body === undefined));
});

test("missing Link falls back to exact standard OPTIONS probes and fails closed", async () => {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), init });
    if (init.method === "HEAD") return response(String(url), { contentType: "text/html", headers: {} });
    return response(String(url), { status: 404, body: { code: "rest_no_route" } });
  };
  await assert.rejects(() => discoverPairingEndpoint(fetchImpl, "https://example.com"), (error) => error?.code === "pairing_rest_route_unavailable");
  assert.deepEqual(calls.map((call) => call.init.method), ["HEAD", "OPTIONS", "OPTIONS"]);
});

test("cross-origin REST discovery redirect fails closed", async () => {
  const fetchImpl = async (url, init = {}) => init.method === "HEAD"
    ? discoveryHead(String(url), "https://example.com/wp-json/")
    : response("https://evil.example/wp-json/prstudio-unified/v1/pair", { redirected: true, body: { methods: ["POST"] } });
  await assert.rejects(() => discoverPairingEndpoint(fetchImpl, "https://example.com"), (error) => error?.code === "pairing_redirect_forbidden");
});

test("OPTIONS route without POST never authorizes the pairing mutation", async () => {
  const fetchImpl = async (url, init = {}) => init.method === "HEAD"
    ? discoveryHead(String(url), "https://example.com/wp-json/")
    : pairOptions(String(url), ["GET"]);
  await assert.rejects(() => discoverPairingEndpoint(fetchImpl, "https://example.com"), (error) => error?.code === "pairing_rest_route_unavailable");
});

test("transport performs one pairing POST only after secret-free HEAD and OPTIONS discovery", async () => {
  const calls = [];
  const secret = "PAIR-CODE-SHOULD-NOT-LEAK";
  const onMessage = eventApi();
  const scope = {
    chrome: { runtime: { onMessage } },
    fetch: async (url, init = {}) => {
      calls.push({ url: String(url), init: { ...init } });
      const href = String(url);
      if (init.method === "HEAD") return discoveryHead(href, "http://127.0.0.1:8082/?rest_route=/");
      if (init.method === "OPTIONS") return pairOptions(href);
      if (init.method === "POST") return response(href, { body: { device_id: "device-1", token: "token-1", api_base: "http://127.0.0.1:8082/?rest_route=/prstudio-unified/v1" } });
      throw new Error(`unexpected method ${init.method}`);
    },
  };
  installWordPressRestTransport(scope);
  onMessage.emit({ type: "pair", siteUrl: "http://127.0.0.1:8082", code: secret });
  const result = await scope.fetch("http://127.0.0.1:8082/wp-json/prstudio-unified/v1/pair", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code: secret, name: "Agent" }),
  });
  assert.equal(result.ok, true);
  const discovery = calls.filter((call) => ["HEAD", "OPTIONS"].includes(call.init.method));
  const posts = calls.filter((call) => call.init.method === "POST");
  assert.deepEqual(discovery.map((call) => call.init.method), ["HEAD", "OPTIONS"]);
  assert.equal(posts.length, 1);
  assert.equal(new URL(posts[0].url).searchParams.get("rest_route"), PAIR_ROUTE);
  assert.ok(discovery.every((call) => call.init.body === undefined));
  assert.ok(discovery.every((call) => !call.url.includes(secret) && !JSON.stringify(call.init).includes(secret)));
});

test("authoritative JSON 403 pairing response never triggers a second POST", async () => {
  const calls = [];
  const scope = {
    chrome: { runtime: { onMessage: eventApi() } },
    fetch: async (url, init = {}) => {
      calls.push({ url: String(url), init });
      if (init.method === "HEAD") return discoveryHead(String(url), "https://example.com/wp-json/");
      if (init.method === "OPTIONS") return pairOptions(String(url));
      return response(String(url), { status: 403, body: { code: "pairing_code_invalid", message: "invalid" } });
    },
  };
  installWordPressRestTransport(scope);
  const result = await scope.fetch("https://example.com/wp-json/prstudio-unified/v1/pair", { method: "POST", body: "{}" });
  assert.equal(result.status, 403);
  assert.equal(calls.filter((call) => call.init.method === "POST").length, 1);
});

test("authoritative JSON 409 pairing response never triggers a second POST", async () => {
  const calls = [];
  const scope = {
    chrome: { runtime: { onMessage: eventApi() } },
    fetch: async (url, init = {}) => {
      calls.push({ url: String(url), init });
      if (init.method === "HEAD") return discoveryHead(String(url), "https://example.com/wp-json/");
      if (init.method === "OPTIONS") return pairOptions(String(url));
      return response(String(url), { status: 409, body: { code: "pairing_contract_mismatch" } });
    },
  };
  installWordPressRestTransport(scope);
  const result = await scope.fetch("https://example.com/wp-json/prstudio-unified/v1/pair", { method: "POST", body: "{}" });
  assert.equal(result.status, 409);
  assert.equal(calls.filter((call) => call.init.method === "POST").length, 1);
});

test("HTML 200 pairing response is rejected as non-JSON", async () => {
  const scope = {
    chrome: { runtime: { onMessage: eventApi() } },
    fetch: async (url, init = {}) => {
      if (init.method === "HEAD") return discoveryHead(String(url), "https://example.com/wp-json/");
      if (init.method === "OPTIONS") return pairOptions(String(url));
      return response(String(url), { contentType: "text/html", body: new Error("html") });
    },
  };
  installWordPressRestTransport(scope);
  await assert.rejects(
    () => scope.fetch("https://example.com/wp-json/prstudio-unified/v1/pair", { method: "POST", body: "{}" }),
    (error) => error?.code === "pairing_response_not_json",
  );
});

test("cross-origin pairing final URL is rejected", async () => {
  const scope = {
    chrome: { runtime: { onMessage: eventApi() } },
    fetch: async (url, init = {}) => {
      if (init.method === "HEAD") return discoveryHead(String(url), "https://example.com/wp-json/");
      if (init.method === "OPTIONS") return pairOptions(String(url));
      return response("https://evil.example/pair", { redirected: true, body: {} });
    },
  };
  installWordPressRestTransport(scope);
  await assert.rejects(
    () => scope.fetch("https://example.com/wp-json/prstudio-unified/v1/pair", { method: "POST", body: "{}" }),
    (error) => error?.code === "pairing_redirect_forbidden",
  );
});

test("plain api_base long-poll query is repaired at production transport boundary", async () => {
  const calls = [];
  const scope = {
    chrome: { runtime: { onMessage: eventApi() } },
    fetch: async (url, init = {}) => { calls.push({ url: String(url), init }); return response(String(url), { body: {} }); },
  };
  installWordPressRestTransport(scope);
  await scope.fetch("https://example.com/?rest_route=/prstudio-unified/v1/tasks/next?wait=20&device=device-1", { method: "GET" });
  assert.equal(calls.length, 1);
  const actual = new URL(calls[0].url);
  assert.equal(actual.searchParams.get("rest_route"), "/prstudio-unified/v1/tasks/next");
  assert.equal(actual.searchParams.get("wait"), "20");
  assert.equal(actual.searchParams.get("device"), "device-1");
});
