/**
 * Observable browser parity contract — exactly 50 independently named cases.
 *
 * This suite compares public, user-visible browser semantics rather than any
 * proprietary implementation. Every behavioral case calls production code.
 * The final case also proves that the same extension is exercised by the real
 * Chrome/WordPress E2E, with page-state and artifact oracles, so a mock-only
 * implementation cannot satisfy the release contract.
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { classifyStepEvidence } from "../lib/effect-verification.js";
import {
  dragSequence,
  keyboardSequence,
  parseKeyChord,
  pointerSequence,
} from "../lib/native-input.js";
import { actionToSteps } from "../lib/protocol.js";
import {
  canFreshRestart,
  isRetrySafeFailure,
} from "../lib/remote-recovery.js";
import {
  buildScreenshotCandidates,
  canCaptureBackgroundTab,
} from "../lib/screenshot-candidates.js";
import {
  migrateTabReplacementState,
  provisionalOwnershipState,
  tabBindingCompatibility,
} from "../lib/tab-ownership.js";
import { parseUserUrl } from "../lib/url-input.js";

const readRepositoryFile = (relative) => readFileSync(new URL(`../../${relative}`, import.meta.url), "utf8");

function oneStep(action, args = {}) {
  const steps = actionToSteps(action, args);
  assert.equal(steps.length, 1, `${action} must resolve on its first call without discovery`);
  return steps[0];
}

function mouseTypes(commands) {
  return commands.map((command) => command.params.type);
}

const PARITY_CASES = [
  {
    name: "01/50 open creates one controlled tab on the first call",
    run() {
      const step = oneStep("playwright_new_page", { url: "https://example.test/start", wait_until: "complete" });
      assert.deepEqual(step, {
        type: "open_tab",
        url: "https://example.test/start",
        expectedOrigin: "",
        waitUntil: "complete",
      });
    },
  },
  {
    name: "02/50 human bare-host input is normalized to HTTPS without a trial navigation",
    run() {
      const parsed = parseUserUrl("example.test/path?q=1");
      assert.equal(parsed?.coerced, true);
      assert.equal(parsed?.url.href, "https://example.test/path?q=1");
    },
  },
  {
    name: "03/50 navigate reuses the explicitly controlled tab",
    run() {
      const step = oneStep("playwright_goto", { tab_id: 17, url: "https://example.test/next", wait_until: "complete" });
      assert.equal(step.type, "navigate");
      assert.equal(step.tabId, 17);
      assert.equal(step.url, "https://example.test/next");
      assert.equal(step.waitUntil, "complete");
    },
  },
  {
    name: "04/50 navigate without a tab becomes one deterministic ensure-page operation",
    run() {
      const step = oneStep("playwright_goto", { url: "https://example.test/direct" });
      assert.equal(step.type, "ensure_page");
      assert.equal(step.url, "https://example.test/direct");
      assert.equal(step.expectedUrl, "https://example.test/direct");
    },
  },
  {
    name: "05/50 page snapshot requests the interactive semantic surface",
    run() {
      const step = oneStep("playwright_locator_snapshot", { tab_id: 17, selector: "main" });
      assert.deepEqual({ type: step.type, tabId: step.tabId, selector: step.selector, includeInteractive: step.includeInteractive }, {
        type: "page_snapshot", tabId: 17, selector: "main", includeInteractive: true,
      });
    },
  },
  {
    name: "06/50 DOM snapshot targets the requested controlled tab",
    run() {
      assert.deepEqual(oneStep("playwright_dom_snapshot", { tab_id: 17 }), { type: "dom_snapshot", tabId: 17 });
    },
  },
  {
    name: "07/50 accessibility snapshot targets the requested controlled tab",
    run() {
      assert.deepEqual(oneStep("playwright_accessibility_snapshot", { tab_id: 17 }), { type: "accessibility_snapshot", tabId: 17 });
    },
  },
  {
    name: "08/50 viewport screenshot preserves format and quality",
    run() {
      const step = oneStep("playwright_screenshot_page", { tab_id: 17, format: "jpeg", quality: 73 });
      assert.deepEqual({ type: step.type, tabId: step.tabId, fullPage: step.fullPage, format: step.format, quality: step.quality }, {
        type: "screenshot", tabId: 17, fullPage: false, format: "jpeg", quality: 73,
      });
    },
  },
  {
    name: "09/50 full-page screenshot preserves the full-page intent",
    run() {
      const step = oneStep("playwright_screenshot_page", { tab_id: 17, full_page: true });
      assert.equal(step.type, "screenshot");
      assert.equal(step.fullPage, true);
      assert.equal(step.lazyLoad, true);
    },
  },
  {
    name: "10/50 element screenshot preserves the grounded selector",
    run() {
      const step = oneStep("playwright_screenshot_element", { tab_id: 17, selector: "#chart" });
      assert.equal(step.type, "screenshot_element");
      assert.equal(step.tabId, 17);
      assert.equal(step.selector, "#chart");
    },
  },
  {
    name: "11/50 selector click resolves directly to one click operation",
    run() {
      const step = oneStep("playwright_click", { tab_id: 17, selector: "#save" });
      assert.deepEqual({ type: step.type, tabId: step.tabId, selector: step.selector, button: step.button, clickCount: step.clickCount }, {
        type: "click", tabId: 17, selector: "#save", button: "left", clickCount: 1,
      });
    },
  },
  {
    name: "12/50 point click preserves exact visual coordinates",
    run() {
      const step = oneStep("playwright_click", { tab_id: 17, coordinates: { x: 321.5, y: 144.25 } });
      assert.deepEqual(step.coordinates, { x: 321.5, y: 144.25 });
      assert.equal(step.type, "click");
      assert.equal(step.clickCount, 1);
    },
  },
  {
    name: "13/50 double click remains one grounded action with count two",
    run() {
      const step = oneStep("playwright_double_click", { tab_id: 17, selector: ".row" });
      assert.equal(step.type, "click");
      assert.equal(step.clickCount, 2);
      assert.equal(step.selector, ".row");
    },
  },
  {
    name: "14/50 context click preserves the right mouse button",
    run() {
      const step = oneStep("playwright_click", { tab_id: 17, selector: ".menu", button: "right" });
      assert.equal(step.button, "right");
      assert.equal(step.clickCount, 1);
    },
  },
  {
    name: "15/50 hover preserves the same semantic target",
    run() {
      const step = oneStep("playwright_hover", { tab_id: 17, role: "button", name: "Details" });
      assert.deepEqual({ type: step.type, role: step.role, name: step.name }, { type: "hover", role: "button", name: "Details" });
    },
  },
  {
    name: "16/50 focus preserves the same labelled field",
    run() {
      const step = oneStep("playwright_focus", { tab_id: 17, label: "Email" });
      assert.deepEqual({ type: step.type, label: step.label }, { type: "focus", label: "Email" });
    },
  },
  {
    name: "17/50 blur preserves the same grounded field",
    run() {
      const step = oneStep("playwright_blur", { tab_id: 17, selector: "#email" });
      assert.deepEqual({ type: step.type, selector: step.selector }, { type: "blur", selector: "#email" });
    },
  },
  {
    name: "18/50 fill carries the replacement value unchanged",
    run() {
      const step = oneStep("playwright_fill", { tab_id: 17, label: "Email", value: "qa@example.test" });
      assert.deepEqual({ type: step.type, label: step.label, value: step.value }, {
        type: "fill", label: "Email", value: "qa@example.test",
      });
    },
  },
  {
    name: "19/50 type carries text unchanged and explicitly appends",
    run() {
      const step = oneStep("playwright_type", { tab_id: 17, selector: "#query", text: " enterprise" });
      assert.deepEqual({ type: step.type, selector: step.selector, value: step.value, append: step.append }, {
        type: "type_text", selector: "#query", value: " enterprise", append: true,
      });
    },
  },
  {
    name: "20/50 key press carries the requested key to the owned tab",
    run() {
      const step = oneStep("playwright_press", { tab_id: 17, selector: "#query", key: "Enter" });
      assert.deepEqual({ type: step.type, tabId: step.tabId, key: step.key }, { type: "press", tabId: 17, key: "Enter" });
    },
  },
  {
    name: "21/50 select option preserves the requested option value",
    run() {
      const step = oneStep("playwright_select_option", { tab_id: 17, selector: "#country", value: "IT" });
      assert.deepEqual({ type: step.type, selector: step.selector, value: step.value }, { type: "select", selector: "#country", value: "IT" });
    },
  },
  {
    name: "22/50 check requests the checked state explicitly",
    run() {
      const step = oneStep("playwright_check", { tab_id: 17, selector: "#terms" });
      assert.equal(step.type, "check");
      assert.equal(step.checked, true);
    },
  },
  {
    name: "23/50 uncheck requests the unchecked state explicitly",
    run() {
      const step = oneStep("playwright_uncheck", { tab_id: 17, selector: "#terms" });
      assert.equal(step.type, "check");
      assert.equal(step.checked, false);
    },
  },
  {
    name: "24/50 scroll preserves horizontal and vertical deltas",
    run() {
      const step = oneStep("playwright_scroll", { tab_id: 17, delta_x: 25, delta_y: 700 });
      assert.deepEqual({ type: step.type, x: step.x, y: step.y }, { type: "scroll", x: 25, y: 700 });
    },
  },
  {
    name: "25/50 tap resolves to a touch-pointer click",
    run() {
      const step = oneStep("playwright_tap", { tab_id: 17, coordinates: { x: 40, y: 80 } });
      assert.equal(step.type, "click");
      assert.equal(step.pointerType, "touch");
      assert.deepEqual(step.coordinates, { x: 40, y: 80 });
    },
  },
  {
    name: "26/50 native point click emits one trusted-browser CDP click sequence",
    run() {
      const commands = pointerSequence([{ type: "click", x: 48, y: 72 }]);
      assert.deepEqual(mouseTypes(commands), ["mouseMoved", "mousePressed", "mouseReleased"]);
      assert.deepEqual(commands.map((command) => [command.params.x, command.params.y]), [[48, 72], [48, 72], [48, 72]]);
      assert.deepEqual(commands.map((command) => command.method), Array(3).fill("Input.dispatchMouseEvent"));
    },
  },
  {
    name: "27/50 native drag is continuous from the exact start to exact end point",
    run() {
      const commands = dragSequence({ x: 10, y: 20 }, { x: 110, y: 220 }, { steps: 4 });
      assert.deepEqual(mouseTypes(commands), ["mouseMoved", "mousePressed", "mouseMoved", "mouseMoved", "mouseMoved", "mouseMoved", "mouseReleased"]);
      assert.deepEqual({ x: commands[0].params.x, y: commands[0].params.y }, { x: 10, y: 20 });
      assert.deepEqual({ x: commands.at(-1).params.x, y: commands.at(-1).params.y }, { x: 110, y: 220 });
    },
  },
  {
    name: "28/50 native wheel preserves point and signed deltas",
    run() {
      const [command] = pointerSequence([{ type: "wheel", x: 100, y: 200, deltaX: -4, deltaY: 360 }]);
      assert.equal(command.method, "Input.dispatchMouseEvent");
      assert.deepEqual(command.params, {
        type: "mouseWheel", x: 100, y: 200, deltaX: -4, deltaY: 360, modifiers: 0, pointerType: "mouse",
      });
    },
  },
  {
    name: "29/50 native touch starts and ends at the intended point",
    run() {
      const commands = pointerSequence([
        { type: "touchstart", x: 25, y: 35, id: 4 },
        { type: "touchend", x: 25, y: 35, id: 4 },
      ]);
      assert.deepEqual(commands.map((command) => command.method), ["Input.dispatchTouchEvent", "Input.dispatchTouchEvent"]);
      assert.equal(commands[0].params.type, "touchStart");
      assert.deepEqual(commands[0].params.touchPoints[0], { x: 25, y: 35, radiusX: 1, radiusY: 1, force: 1, id: 4 });
      assert.deepEqual(commands[1].params.touchPoints, []);
    },
  },
  {
    name: "30/50 native Enter press emits balanced key-down and key-up",
    run() {
      const commands = keyboardSequence(["Enter"]);
      assert.deepEqual(commands.map((command) => command.params.type), ["keyDown", "keyUp"]);
      assert.deepEqual(commands.map((command) => command.params.windowsVirtualKeyCode), [13, 13]);
    },
  },
  {
    name: "31/50 native Control-A chord preserves modifier and physical key code",
    run() {
      const chord = parseKeyChord("Ctrl+A");
      assert.deepEqual({ key: chord.key, code: chord.code, modifiers: chord.modifiers, windowsVirtualKeyCode: chord.windowsVirtualKeyCode }, {
        key: "A", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65,
      });
    },
  },
  {
    name: "32/50 native text insertion preserves Unicode exactly",
    run() {
      const [command] = keyboardSequence([{ type: "insert_text", text: "Caffè già pronto ✓" }]);
      assert.deepEqual(command, { method: "Input.insertText", params: { text: "Caffè già pronto ✓" }, delayMs: 0 });
    },
  },
  {
    name: "33/50 tab listing maps directly to the tab inventory operation",
    run() {
      assert.deepEqual(oneStep("playwright_list_pages", { tab_id: 17, activate: false }), { type: "list_tabs", tabId: 17, activate: false });
    },
  },
  {
    name: "34/50 close tab targets only the explicitly controlled tab",
    run() {
      assert.deepEqual(oneStep("playwright_close_page", { tab_id: 17 }), { type: "close_tab", tabId: 17 });
    },
  },
  {
    name: "35/50 reload targets the same controlled tab",
    run() {
      assert.deepEqual(oneStep("playwright_reload", { tab_id: 17 }), { type: "reload", tabId: 17 });
    },
  },
  {
    name: "36/50 back navigation keeps browser history direction",
    run() {
      assert.deepEqual(oneStep("playwright_go_back", { tab_id: 17 }), { type: "history", direction: "back", tabId: 17 });
    },
  },
  {
    name: "37/50 forward navigation keeps browser history direction",
    run() {
      assert.deepEqual(oneStep("playwright_go_forward", { tab_id: 17 }), { type: "history", direction: "forward", tabId: 17 });
    },
  },
  {
    name: "38/50 selector wait is bounded and preserves the semantic target",
    run() {
      const step = oneStep("playwright_wait_for_selector", { tab_id: 17, role: "button", name: "Continue", timeout: 999999 });
      assert.equal(step.type, "wait_selector");
      assert.equal(step.role, "button");
      assert.equal(step.name, "Continue");
      assert.equal(step.timeoutMs, 120000);
    },
  },
  {
    name: "39/50 URL wait preserves the requested URL pattern",
    run() {
      const step = oneStep("playwright_wait_for_url", { tab_id: 17, pattern: "https://example.test/done*", timeout: 8000 });
      assert.deepEqual({ type: step.type, tabId: step.tabId, url: step.url, timeoutMs: step.timeoutMs }, {
        type: "wait_url", tabId: 17, url: "https://example.test/done*", timeoutMs: 8000,
      });
    },
  },
  {
    name: "40/50 viewport emulation preserves width height scale and mobile mode",
    run() {
      const step = oneStep("playwright_set_viewport", { tab_id: 17, width: 390, height: 844, device_scale_factor: 3, mobile: true });
      assert.deepEqual(step, {
        type: "emulation", tabId: 17, command: "viewport",
        value: { width: 390, height: 844, deviceScaleFactor: 3, mobile: true },
      });
    },
  },
  {
    name: "41/50 foreground screenshot starts from the compositor and avoids blind renderer retries",
    run() {
      const candidates = buildScreenshotCandidates({ format: "png" });
      assert.equal(candidates[0].fromSurface, true);
      assert.equal(canCaptureBackgroundTab(candidates), false);
      assert.ok(candidates.every((candidate) => candidate.fromSurface === true));
    },
  },
  {
    name: "42/50 background screenshot starts from the renderer and retains its clip",
    run() {
      const clip = { x: 10, y: 20, width: 300, height: 180, scale: 2 };
      const candidates = buildScreenshotCandidates({ format: "png", clip, preferRenderer: true });
      assert.equal(candidates[0].fromSurface, false);
      assert.deepEqual(candidates[0].clip, clip);
      assert.equal(canCaptureBackgroundTab(candidates), true);
    },
  },
  {
    name: "43/50 screenshot success requires an independently hashable artifact",
    run() {
      const accepted = classifyStepEvidence({ type: "screenshot" }, { artifact: { sha256: "a".repeat(64) } });
      const missing = classifyStepEvidence({ type: "screenshot" }, { artifact: {} });
      assert.deepEqual(accepted, { applicationAccepted: true, verificationStrength: "artifact_integrity" });
      assert.deepEqual(missing, { applicationAccepted: false, verificationStrength: "artifact_integrity" });
    },
  },
  {
    name: "44/50 open success requires ownership before navigation plus live DOM evidence",
    run() {
      const accepted = classifyStepEvidence({ type: "open_tab" }, {
        created: true,
        ownedBeforeNavigation: true,
        domEvidence: { hasDocumentElement: true, readyState: "complete" },
      }, { urlMatched: true });
      const unowned = classifyStepEvidence({ type: "open_tab" }, {
        created: true,
        ownedBeforeNavigation: false,
        domEvidence: { hasDocumentElement: true, readyState: "complete" },
      }, { urlMatched: true });
      assert.equal(accepted.applicationAccepted, true);
      assert.equal(unowned.applicationAccepted, false);
      assert.equal(accepted.verificationStrength, "observed_ui_state");
    },
  },
  {
    name: "45/50 fill success is decided by post-input DOM readback",
    run() {
      const replaced = classifyStepEvidence({ type: "fill", value: "hello" }, { element: { valueLength: 99 }, after: { valueLength: 5 } });
      const mismatch = classifyStepEvidence({ type: "fill", value: "hello" }, { element: { valueLength: 99 }, after: { valueLength: 4 } });
      assert.equal(replaced.applicationAccepted, true);
      assert.equal(mismatch.applicationAccepted, false);
      assert.equal(replaced.verificationStrength, "dom_readback");
    },
  },
  {
    name: "46/50 click success stays unknown until a page effect is independently observed",
    run() {
      const accepted = classifyStepEvidence({ type: "click" }, { effectEvidence: { observed: true, strength: "url_or_dom_change" } });
      const unknown = classifyStepEvidence({ type: "click" }, { effectEvidence: { observed: false } });
      assert.deepEqual(accepted, { applicationAccepted: true, verificationStrength: "url_or_dom_change" });
      assert.deepEqual(unknown, { applicationAccepted: null, verificationStrength: "transport_or_ui_dispatch" });
    },
  },
  {
    name: "47/50 about-blank ownership is provisional only for a concrete pending HTTP target",
    run() {
      assert.deepEqual(provisionalOwnershipState(
        { id: 17, url: "about:blank", pendingUrl: "https://example.test/" },
        { provisional: true, url: "https://example.test/" },
      ), {
        committedUrl: "about:blank",
        candidateUrl: "https://example.test/",
        committedHttp: false,
        candidateHttp: true,
        provisional: true,
      });
    },
  },
  {
    name: "48/50 lane ownership survives task changes and tab replacement but rejects another lane",
    run() {
      const sameLane = tabBindingCompatibility(
        { laneId: "lane-a", taskId: "task-one" },
        { laneId: "lane-a", taskId: "task-two" },
      );
      const otherLane = tabBindingCompatibility(
        { laneId: "lane-a", taskId: "task-one" },
        { laneId: "lane-b", taskId: "task-two" },
      );
      assert.equal(sameLane.ok, true);
      assert.equal(sameLane.mode, "lane_task_rebind");
      assert.deepEqual({ ok: otherLane.ok, code: otherLane.code }, { ok: false, code: "tab_lane_conflict" });

      const migrated = migrateTabReplacementState({
        registry: { 17: { tabId: 17, laneId: "lane-a", taskId: "task-one", url: "https://example.test/" } },
        affinityTasks: { "task-one": { tabId: 17 } },
        lastTabId: 17,
        activeTask: { taskId: "task-one", tabId: 17 },
        runtimeSessions: {},
      }, { id: 18, windowId: 2, url: "https://example.test/", title: "Replacement" }, 17, 1234);
      assert.equal(migrated?.registry?.[18]?.laneId, "lane-a");
      assert.equal(migrated?.affinityTasks?.["task-one"]?.tabId, 18);
      assert.equal(migrated?.activeTask?.tabId, 18);
    },
  },
  {
    name: "49/50 recovery retries only pre-effect failures and never blindly replays an uncertain click",
    run() {
      const ownershipFailure = { code: "tab_ownership_missing" };
      assert.equal(isRetrySafeFailure({ type: "click" }, ownershipFailure), true);
      assert.equal(isRetrySafeFailure({ type: "click" }, { code: "network_after_dispatch" }), false);
      assert.equal(canFreshRestart({ checkpoint: { last_completed_step: -1, fresh_restart_count: 0 } }, { type: "click" }, ownershipFailure, 2), true);
      assert.equal(canFreshRestart({ checkpoint: { last_completed_step: 0, fresh_restart_count: 0 } }, { type: "click" }, ownershipFailure, 2), false);
    },
  },
  {
    name: "50/50 connector routes the first call directly, exposes no streaming viewer, and keeps real-Chrome effect oracles release-blocking",
    run() {
      const descriptor = JSON.parse(readRepositoryFile("RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json"));
      const requiredFastPaths = [
        "browser_open", "browser_navigate", "browser_snapshot", "browser_screenshot",
        "browser_click", "browser_fill", "browser_tabs", "browser_viewport",
      ];
      for (const tool of requiredFastPaths) assert.ok(descriptor.tool_names.includes(tool), `missing first-call tool ${tool}`);

      const instructions = readRepositoryFile("prstudio-unified-control/includes/class-prstudio-uc-agent-model.php");
      assert.match(instructions, /Fast paths: snapshot=browser_snapshot; screenshot-only=browser_screenshot; open=browser_open;/);
      assert.match(instructions, /call the requested tool directly and never add a context_open round-trip/);
      assert.match(instructions, /first stateful browser\/GSC call creates or reuses its OAuth-bound execution lane inside the server/);

      const mcp = readRepositoryFile("prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php");
      assert.match(mcp, /'resources'\s*=>\s*array\(\)/);
      assert.doesNotMatch(mcp, /openai\/outputTemplate|browser_viewer/);

      const realE2e = readRepositoryFile("tests/wordpress-remote-browser-e2e.mjs");
      assert.match(realE2e, /--load-extension=/);
      assert.match(realE2e, /\{ type: 'fill'.*\n[\s\S]{0,300}\{ type: 'click'/);
      assert.match(realE2e, /\{ type: 'screenshot' \}/);
      assert.match(realE2e, /real Chrome emitted the ordered trusted pointer\/click sequence/);
      assert.match(realE2e, /remote fill\/click\/scroll\/CDP mutation reached real page/);
      assert.match(realE2e, /Page\.captureScreenshot/);

      const workflow = readRepositoryFile(".github/workflows/unified-h24-control.yml");
      assert.match(workflow, /name: Real Chrome Browser Agent E2E/);
      assert.match(workflow, /node tests\/wordpress-remote-browser-e2e\.mjs/);
    },
  },
];

// Fail during module evaluation if an edit adds, drops or duplicates a case;
// this invariant does not add a 51st TAP test.
assert.equal(PARITY_CASES.length, 50, "the observable browser parity contract must contain exactly 50 cases");
assert.equal(new Set(PARITY_CASES.map((entry) => entry.name)).size, 50, "all parity case names must be unique");

for (const parityCase of PARITY_CASES) {
  test(`browser observable parity ${parityCase.name}`, parityCase.run);
}
