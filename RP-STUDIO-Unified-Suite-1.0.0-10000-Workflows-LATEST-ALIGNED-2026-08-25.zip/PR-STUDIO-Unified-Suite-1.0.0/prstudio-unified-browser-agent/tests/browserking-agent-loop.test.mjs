import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BROWSERKING_COMPAT_VERSION,
  BROWSERKING_UPSTREAM_REF,
  BROWSERKING_TOOL_SPECS,
  normalizeAgentConfig,
  runBrowserKingAgent,
} from '../browserking/agent-loop.js';
import { actionToSteps } from '../lib/protocol.js';

test('BrowserKing compatibility metadata and bounded tool surface are explicit', () => {
  assert.match(BROWSERKING_COMPAT_VERSION, /^1\.0\.62\.1-prstudio\./);
  assert.match(BROWSERKING_UPSTREAM_REF, /^[0-9a-f]{40}$/);
  const names = BROWSERKING_TOOL_SPECS.map((row) => row.function.name);
  assert.ok(names.includes('browser_snapshot'));
  assert.ok(names.includes('browser_click'));
  assert.ok(names.includes('browser_open'));
  assert.ok(names.includes('browser_adopt_tabs'));
  assert.ok(names.length <= 16, 'resident agent tool surface must stay small');
});

test('agent config is bounded and defaults to OpenAI-compatible endpoint', () => {
  const config = normalizeAgentConfig({ api_key: 'x', model: 'model', max_steps: 999, timeout_ms: 1 });
  assert.equal(config.provider, 'openai_compatible');
  assert.equal(config.baseUrl, 'https://api.openai.com/v1');
  assert.equal(config.maxSteps, 40);
  assert.equal(config.timeoutMs, 5000);
});

test('PR STUDIO protocol maps explicit BrowserKing prompt aliases to resident agent step', () => {
  for (const action of ['browserking_agent_prompt', 'browser_agent_prompt', 'agent_prompt']) {
    assert.deepEqual(actionToSteps(action, { prompt: 'Inspect this page' }), [
      { type: 'browserking_agent', prompt: 'Inspect this page', config: {} },
    ]);
  }
});

test('OpenAI-compatible agent loop executes tool calls then terminates on final answer', async () => {
  const originalFetch = globalThis.fetch;
  const requests = [];
  let call = 0;
  globalThis.fetch = async (url, init) => {
    requests.push({ url, body: JSON.parse(init.body) });
    call += 1;
    const payload = call === 1
      ? { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'browser_snapshot', arguments: '{}' } }] } }] }
      : { choices: [{ message: { role: 'assistant', content: 'Pagina verificata.', tool_calls: [] } }] };
    return new Response(JSON.stringify(payload), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  try {
    const tools = [];
    const result = await runBrowserKingAgent({
      prompt: 'Controlla la pagina',
      config: { apiKey: 'secret', model: 'test-model', maxSteps: 4 },
      executeTool: async (name, args) => { tools.push({ name, args }); return { ok: true, verified: true, tabId: 9 }; },
    });
    assert.equal(result.ok, true);
    assert.equal(result.verified, true);
    assert.equal(result.effectVerified, true);
    assert.equal(result.final, 'Pagina verificata.');
    assert.deepEqual(tools, [{ name: 'browser_snapshot', args: {} }]);
    assert.equal(requests.length, 2);
    assert.equal(requests[0].url, 'https://api.openai.com/v1/chat/completions');
    assert.ok(requests[1].body.messages.some((message) => message.role === 'tool'));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('Anthropic agent loop preserves tool_use/tool_result structure', async () => {
  const originalFetch = globalThis.fetch;
  let call = 0;
  const bodies = [];
  globalThis.fetch = async (_url, init) => {
    bodies.push(JSON.parse(init.body));
    call += 1;
    const payload = call === 1
      ? { content: [{ type: 'tool_use', id: 't1', name: 'browser_wait', input: { ms: 50 } }] }
      : { content: [{ type: 'text', text: 'Fatto.' }] };
    return new Response(JSON.stringify(payload), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  try {
    const result = await runBrowserKingAgent({
      prompt: 'Aspetta e rispondi',
      config: { provider: 'anthropic', baseUrl: 'https://api.anthropic.com/v1', apiKey: 'secret', model: 'claude-test', maxSteps: 3 },
      executeTool: async () => ({ ok: true, verified: true }),
    });
    assert.equal(result.ok, true);
    assert.equal(result.final, 'Fatto.');
    assert.equal(bodies.length, 2);
    const toolResultTurn = bodies[1].messages.find((message) => message.role === 'user' && Array.isArray(message.content));
    assert.equal(toolResultTurn.content[0].type, 'tool_result');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('resident BrowserKing surface supports explicit multi-tab targeting', () => {
  const byName = Object.fromEntries(BROWSERKING_TOOL_SPECS.map((row) => [row.function.name, row.function]));
  for (const name of [
    'browser_snapshot', 'browser_navigate', 'browser_find', 'browser_click', 'browser_fill',
    'browser_type', 'browser_press', 'browser_scroll', 'browser_extract', 'browser_screenshot',
  ]) {
    assert.ok(byName[name]?.parameters?.properties?.tab_id, `${name} must accept tab_id`);
  }
  assert.deepEqual(byName.browser_tabs.parameters.properties.operation.enum, ['list', 'open', 'activate', 'close']);
  assert.ok(byName.browser_adopt_tabs.parameters.properties.tab_ids);
  assert.ok(byName.browser_adopt_tabs.parameters.properties.origin);
});
