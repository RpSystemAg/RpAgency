import { BROWSERKING_CONFIG_KEY, publicBrowserKingConfig, saveBrowserKingConfig } from "./browserking/config.js";

const $ = (id) => document.getElementById(id);
const form = $("form");

async function load() {
  const raw = (await chrome.storage.local.get([BROWSERKING_CONFIG_KEY]))?.[BROWSERKING_CONFIG_KEY] || {};
  const view = await publicBrowserKingConfig(raw);
  $("provider").value = view.provider;
  $("baseUrl").value = view.baseUrl;
  $("model").value = view.model;
  $("maxSteps").value = view.maxSteps;
  $("maxTokens").value = view.maxTokens;
  $("timeoutMs").value = view.timeoutMs;
  $("apiKey").placeholder = view.apiKeyPresent ? "chiave già salvata — vuoto = mantieni" : "API key";
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const prior = (await chrome.storage.local.get([BROWSERKING_CONFIG_KEY]))?.[BROWSERKING_CONFIG_KEY] || {};
  const enteredKey = $("apiKey").value.trim();
  const saved = await saveBrowserKingConfig({
    provider: $("provider").value,
    baseUrl: $("baseUrl").value,
    model: $("model").value,
    apiKey: enteredKey || prior.apiKey || "",
    maxSteps: $("maxSteps").value,
    maxTokens: $("maxTokens").value,
    timeoutMs: $("timeoutMs").value,
  });
  $("apiKey").value = "";
  $("apiKey").placeholder = saved.apiKeyPresent ? "chiave già salvata — vuoto = mantieni" : "API key";
  $("status").textContent = saved.configured ? "Salvato — agent loop pronto" : "Salvato — manca modello o API key";
  setTimeout(() => { $("status").textContent = ""; }, 3000);
});

load();
