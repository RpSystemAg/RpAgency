# Browser engine provenance

PR STUDIO Browser 1.0.0 uses a **clean-room BrowserKing-compatible agent loop** for the optional `browserking_agent_prompt` execution mode. The public pairing panel, WordPress transport, execution lanes, task leases, checkpointing, verification and anti-crash behavior remain PR STUDIO code.

Reference implementation studied: `Mushisushi28/BrowserKing`, documented browser-extension version `1.0.62.1`; repository `git-hash.txt` at integration time: `1d6d6c2acadae08b5fc7c7aa4a1160d9eb0527c9`.

BrowserKing's README states an MIT license, and also states that BrowserKing is built on Anthropic's Claude for Chrome extension. This package therefore does **not** redistribute BrowserKing's compiled Claude-for-Chrome-derived bundles. It reimplements the documented provider/tool loop against PR STUDIO's already audited browser primitives. A product owner may replace this compatibility layer with a separately audited BrowserKing fork later without changing the PR STUDIO pairing or MCP contract.
