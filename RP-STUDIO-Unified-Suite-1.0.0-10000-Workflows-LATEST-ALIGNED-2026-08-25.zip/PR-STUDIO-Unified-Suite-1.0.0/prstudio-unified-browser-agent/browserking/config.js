import { normalizeAgentConfig, BROWSERKING_COMPAT_VERSION, BROWSERKING_UPSTREAM_REF } from "./agent-loop.js";

export const BROWSERKING_CONFIG_KEY = "prstudioBrowserKingConfig";

export async function loadBrowserKingConfig(overrides = {}) {
  const stored = await chrome.storage.local.get([BROWSERKING_CONFIG_KEY]);
  const local = stored?.[BROWSERKING_CONFIG_KEY] || {};
  return normalizeAgentConfig({ ...local, ...sanitizeOverrides(overrides) });
}

export async function saveBrowserKingConfig(input = {}) {
  const normalized = normalizeAgentConfig(input);
  const value = {
    provider: normalized.provider,
    baseUrl: normalized.baseUrl,
    apiKey: normalized.apiKey,
    model: normalized.model,
    maxSteps: normalized.maxSteps,
    maxTokens: normalized.maxTokens,
    timeoutMs: normalized.timeoutMs,
  };
  await chrome.storage.local.set({ [BROWSERKING_CONFIG_KEY]: value });
  return publicBrowserKingConfig(value);
}

export async function publicBrowserKingConfig(input = null) {
  let value = input;
  if (!value) value = (await chrome.storage.local.get([BROWSERKING_CONFIG_KEY]))?.[BROWSERKING_CONFIG_KEY] || {};
  const normalized = normalizeAgentConfig(value);
  return {
    configured: Boolean(normalized.apiKey && normalized.model),
    provider: normalized.provider,
    baseUrl: normalized.baseUrl,
    model: normalized.model,
    maxSteps: normalized.maxSteps,
    maxTokens: normalized.maxTokens,
    timeoutMs: normalized.timeoutMs,
    apiKeyPresent: Boolean(normalized.apiKey),
    version: BROWSERKING_COMPAT_VERSION,
    upstreamRef: BROWSERKING_UPSTREAM_REF,
  };
}

function sanitizeOverrides(input = {}) {
  const allowed = ["provider", "baseUrl", "base_url", "model", "maxSteps", "max_steps", "maxTokens", "max_tokens", "timeoutMs", "timeout_ms"];
  const out = {};
  for (const key of allowed) if (Object.prototype.hasOwnProperty.call(input, key)) out[key] = input[key];
  // Remote PR STUDIO tasks may select an already configured provider/model but
  // cannot inject an API key into logs/checkpoints or overwrite local secrets.
  return out;
}
