#!/usr/bin/env python3
import json, pathlib, re, sys
R=pathlib.Path(__file__).resolve().parents[1]
paths=[
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave1-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave2-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave3-2026-08-25.json',
 R/'prstudio-unified-control/workflows/wave4-enterprise-workflows-2026-08-25.json',
 R/'prstudio-unified-control/workflows/wave5-enterprise-workflows-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave6-consulting-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave7-web-engineering-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave8-productivity-growth-2026-08-25.json',
 R/'prstudio-unified-control/workflows/enterprise-workflows-wave9-enterprise-atlas-2026-08-25.json',
]
docs=[json.load(open(p,encoding='utf-8')) for p in paths]
expected=[300,300,300,380,600,299,200,299,7322]
errors=[]
if [d['workflow_count'] for d in docs]!=expected: errors.append(f'wave counts must be {expected}')
allw=[w for d in docs for w in d['workflows']]; ids=[w['id'] for w in allw]
if len(ids)!=10000 or len(set(ids))!=10000: errors.append(f'workflow IDs must be 10000/10000 unique, got {len(ids)}/{len(set(ids))}')
if not all(w['domain']=='browser_tab_control' for w in docs[0]['workflows'][:50]): errors.append('Wave1 first 50 must be browser tab-control procedures')
oldids=set()
for f in ['enterprise-workflows-wave1-2026-08-24.json','enterprise-workflows-wave2-2026-08-24.json']:
 oldids.update(w['id'] for w in json.load(open(R/'prstudio-unified-control/workflows'/f))['workflows'])
if set(w['id'] for w in docs[1]['workflows'])!=oldids: errors.append('Wave2 must preserve exactly all 300 original workflow IDs')
source_register=json.load(open(R/'docs/research/WAVE4-WAVE7-SOURCE-REGISTER-2026-08-25.json')); source_ids={r['id'] for r in source_register.get('sources',[]) if isinstance(r,dict) and r.get('id')}
caps=json.load(open(R/'prstudio-unified-control/capabilities/capability-registry.json'))['capabilities']; cmap={c['id']:c for c in caps}
contract_fields={'id','version','wave','domain','label','description','business_objective','triggers','intent_examples','negative_intent_examples','execution_mode','risk_class','browser_requirement','external_provider_requirements','input_schema','output_schema','preconditions','permissions','data_classification','phases','decision_gates','approval_gates','rollback','verification','measurement','failure_semantics','retry_policy','idempotency','audit_policy','observability','rate_limit','retention','i18n','source_references','legal_or_policy_constraints','completion_contract'}
for w in allw:
    if w.get('wave') in {1,3,4,5,6,7,8,9}:
        miss=contract_fields-set(w)
        if miss: errors.append(f"{w['id']}: missing contract fields {sorted(miss)[:4]}")
        missing_refs=[r for r in w.get('source_references',[]) if r not in source_ids]
        if missing_refs: errors.append(f"{w['id']}: unknown source references {missing_refs[:3]}")
    if not re.fullmatch(r'[a-z0-9_]+',w['id']): errors.append(f"{w['id']}: invalid slug")
    for p in w.get('phases',[]):
        kind=p.get('executor_kind')
        if kind=='capability':
            c=cmap.get(p.get('capability'))
            if not c: errors.append(f"{w['id']}/{p.get('id')}: unknown capability {p.get('capability')}"); continue
            src=c.get('source') or {}
            if p.get('route') and (src.get('route')!=p.get('route') or src.get('action')!=p.get('action')): errors.append(f"{w['id']}/{p.get('id')}: source mismatch")
        elif kind=='tool':
            if not p.get('tool'): errors.append(f"{w['id']}/{p.get('id')}: missing direct tool")
        else:
            errors.append(f"{w['id']}/{p.get('id')}: invalid executor kind {kind}")
if docs[3].get('assertions')!={'W4_A':180,'W4_B':180,'W4_C':20,'total':380}: errors.append('Wave4 split assertion mismatch')
if docs[4].get('assertions')!={'domains':30,'per_domain':20,'total':600}: errors.append('Wave5 split assertion mismatch')
if docs[5].get('capability_groups')!={'social-image':50,'commerce-image':50,'ux-cro':49,'exec-design':50,'social-content':50,'campaigns':50}: errors.append('Wave6 first 299 split mismatch')
if docs[6].get('assertions')!={'gutenberg_block_engineering':50,'html_web_platform':40,'javascript_engineering':40,'java_enterprise_engineering':35,'css_architecture':35,'total':200}: errors.append('Wave7 split assertion mismatch')
if docs[7].get('assertions',{}).get('total')!=299: errors.append('Wave8 second 299 total mismatch')
if docs[8].get('assertions')!={'domains':73,'per_domain':100,'cross_domain':22,'total':7322}: errors.append('Wave9 atlas split mismatch')
for w in allw:
 if 'security' in w.get('domain','') and w.get('wave') in {3,4,9}:
  raw=json.dumps(w).lower()
  if 'authorized' not in raw and 'defensive' not in raw: errors.append(f"{w['id']}: security authorization boundary missing")
index=json.load(open(R/'prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-25.json'))
if index.get('workflow_count')!=10000 or len(index.get('items',[]))!=10000: errors.append('index must enumerate all 10,000 workflows')
if index.get('waves')!={str(i):n for i,n in enumerate(expected,1)}: errors.append('index wave map mismatch')
if errors:
 print('FAIL enterprise workflow suite')
 for e in errors[:200]: print(' -',e)
 sys.exit(1)
print(f"PASS: 10000 unique canonical workflows; wave counts={expected}; phases={sum(d['phase_count'] for d in docs)}")
print('PASS: cumulative prompts preserved; original 300 IDs preserved; both 299-workflow batches present; Wave9 Enterprise Atlas=7322')
