import fs from 'node:fs';
const manifest=JSON.parse(fs.readFileSync(new URL('../prstudio-unified-browser-agent/manifest.json',import.meta.url),'utf8'));
const perms=new Set(manifest.permissions||[]);
for (const p of ['tabCapture','offscreen','contextMenus']) if (perms.has(p)) throw new Error(`removed Browser LIVE permission still present: ${p}`);
const panel=fs.readFileSync(new URL('../prstudio-unified-browser-agent/sidepanel.html',import.meta.url),'utf8');
for (const needle of ['Browser LIVE','WebRTC','liveStartButton','liveWebRtc']) if (panel.includes(needle)) throw new Error(`removed streaming UI remains: ${needle}`);
for (const f of ['offscreen-live.html','offscreen-live.js','lib/live-webrtc.js']) if (fs.existsSync(new URL(`../prstudio-unified-browser-agent/${f}`,import.meta.url))) throw new Error(`removed live runtime remains: ${f}`);
const controlReadme=fs.readFileSync(new URL('../prstudio-unified-control/README.md',import.meta.url),'utf8');
const browserReadme=fs.readFileSync(new URL('../prstudio-unified-browser-agent/README.md',import.meta.url),'utf8');
for (const text of [controlReadme,browserReadme]) {
  if (/captures the selected controlled tab|Il viewer LIVE usa|aggiunge esclusivamente i permessi Chrome/i.test(text)) throw new Error('removed streaming contract remains documented as active');
  if (!/nessun(?:o)? (?:viewer|streaming)|non espone risorse/i.test(text)) throw new Error('streaming removal is not documented');
}
console.log('OK embedded browser streaming/viewer surface removed');
