<?php
define('PRSTUDIO_UC_TESTING', true);

function sanitize_key($v){ return strtolower(preg_replace('/[^a-z0-9_-]+/i','',(string)$v)); }
class WP_Error {}
function is_wp_error($v){ return $v instanceof WP_Error; }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function absint($v){ return abs((int)$v); }
function esc_url_raw($v){ return (string)$v; }
function wp_json_encode($v,$flags=0){ return json_encode($v,$flags); }
function wp_generate_uuid4(){ return '11111111-2222-4333-8444-555555555555'; }
function url_to_postid($url){ return str_contains((string)$url,'known-product') ? 101 : 0; }
function get_post_type($id){ return 101 === (int)$id ? 'product' : null; }
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function get_post_field($field,$id){ return '<p>Primary keyword and secondary phrase.</p><a href="/related">Related</a>'; }
function get_permalink($id){ return 'https://example.test/product/known-product/'; }
function get_the_terms($id,$tax){ return [(object)['name'=>$tax==='product_cat'?'Category':'Brand']]; }
function get_post_modified_time(){ return '1700000000'; }
function get_posts($args=[]){ return [101]; }

$GLOBALS['seo_meta'] = [
  'rank_math_focus_keyword' => 'primary keyword, secondary phrase',
  'rank_math_title' => 'Primary Keyword Product',
  'rank_math_description' => 'Primary keyword product description.',
  'rank_math_canonical_url' => 'https://example.test/product/known-product/',
  'rank_math_robots' => [],
  'rank_math_seo_score' => '39',
  '_wp_attachment_image_alt' => 'Primary keyword product image',
];
function get_post_meta($id,$key,$single=true){ return $GLOBALS['seo_meta'][$key] ?? ''; }

final class Fake_Product {
  public function get_id(){ return 101; }
  public function get_name(){ return 'Primary Keyword Product'; }
  public function get_slug(){ return 'known-product'; }
  public function get_status(){ return 'publish'; }
  public function get_stock_quantity(){ return 3; }
  public function get_stock_status(){ return 'instock'; }
  public function get_image_id(){ return 501; }
  public function get_gallery_image_ids(){ return [502,503]; }
  public function get_sku(){ return 'SKU-101'; }
  public function get_description(){ return 'Primary keyword description with secondary phrase and useful product details.'; }
  public function get_short_description(){ return 'Primary keyword short description.'; }
}
function wc_get_product($id){ return 101 === (int)$id ? new Fake_Product() : null; }

final class PRSTUDIO_UC_Memory {
  public static array $missions=[];
  public static function mission(string $id, ?array $state=null): array {
    if (null !== $state) self::$missions[$id]=$state;
    return self::$missions[$id] ?? [];
  }
  public static function fingerprint($v): string { return hash('sha256', json_encode($v)); }
  public static function can_reuse($type,$id,$fp): bool { return false; }
  public static function lookup($type,$id): array { return []; }
  public static function remember($type,$id,$fp,$summary,$ttl=0): void {}
}

require_once __DIR__ . '/../prstudio-unified-control/includes/class-prstudio-uc-seo-autopilot.php';
require_once __DIR__ . '/../prstudio-unified-control/includes/class-prstudio-uc-product-audit.php';

function fail_now($message){ fwrite(STDERR, "FAIL: $message\n"); exit(1); }
function ok($condition,$message){ if(!$condition) fail_now($message); }
function call_private($class,$method,...$args){ $r=new ReflectionMethod($class,$method); $r->setAccessible(true); return $r->invoke(null,...$args); }

$spec = call_private(PRSTUDIO_UC_SEO_Autopilot::class,'build_or_merge_spec','report-1',[
  'scope_mode'=>'explicit',
  'entity_ids'=>[101,101],
  'entity_urls'=>['https://example.test/product/known-product/','https://example.test/product/missing/'],
  'source_report_id'=>'crawl.csv',
  'rank_math_target_score'=>100,
  'min_focus_keywords'=>4,
  'media_policy'=>'review_if_available',
  'strict_scope'=>true,
  'require_verified'=>true,
  'require_live_rank_math_score'=>true,
],[]);
ok($spec['scope_mode']==='explicit','explicit report scope must be preserved');
ok($spec['target_count']===2,'resolved ID plus unresolved report URL must both count in denominator');
ok($spec['entity_ids']===[101],'target IDs must be unique');
ok(count($spec['unresolved_urls'])===1,'unresolved source URLs must remain visible, never disappear');
ok($spec['requirements']['rank_math_target_score']===100,'Rank Math target must persist');
ok($spec['requirements']['min_focus_keywords']===4,'focus keyword target must persist');
call_private(PRSTUDIO_UC_SEO_Autopilot::class,'save_campaign_spec','report-1',$spec);

$acceptance = call_private(PRSTUDIO_UC_SEO_Autopilot::class,'completion_acceptance','report-1','product','101',[
  'remaining_issues'=>[], 'verified'=>true, 'media_decision'=>'kept_relevant', 'media_search_performed'=>true, 'media_candidates_found'=>3, 'rank_math_score_observed'=>39,
]);
ok($acceptance['ok']===false,'score 39 and two keywords must not close a score-100/four-keyword product');
$codes=array_column($acceptance['violations'],'code');
ok(in_array('rank_math_score_below_target',$codes,true),'stored Rank Math target violation required');
ok(in_array('focus_keyword_count_below_target',$codes,true),'focus keyword count violation required');
ok(in_array('live_rank_math_score_below_target',$codes,true),'live Rank Math target violation required');

$GLOBALS['seo_meta']['rank_math_seo_score']='100';
$GLOBALS['seo_meta']['rank_math_focus_keyword']='primary keyword, secondary phrase, use query, brand format query';
$acceptance = call_private(PRSTUDIO_UC_SEO_Autopilot::class,'completion_acceptance','report-1','product','101',[
  'remaining_issues'=>[], 'verified'=>true, 'media_decision'=>'kept_relevant', 'media_search_performed'=>true, 'media_candidates_found'=>3, 'rank_math_score_observed'=>100,
]);
ok($acceptance['ok']===true,'product meeting strict score/keyword/media/verification contract must close');

$audit = PRSTUDIO_UC_Product_Audit::execute(['id'=>101,'rank_math_target_score'=>100,'min_focus_keywords'=>4,'force'=>true]);
ok(is_array($audit),'product audit must return an array');
ok($audit['items'][0]['checks']['rank_math_score']['evidence']['score']===100.0,'audit must expose stored Rank Math score');
ok($audit['items'][0]['checks']['focus_keyword']['evidence']['count']===4,'audit must expose focus keyword count');
ok($audit['items'][0]['issue_count']===0,'target-aware audit should pass once criteria are met');

echo "PASS: report scope denominator + Rank Math/media acceptance are enforced\n";
