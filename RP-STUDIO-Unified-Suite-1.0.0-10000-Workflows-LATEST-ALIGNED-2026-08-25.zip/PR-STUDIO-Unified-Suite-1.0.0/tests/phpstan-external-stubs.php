<?php
/**
 * Static signatures for optional integrations that are runtime-guarded by the
 * plugin but are not part of WordPress or WooCommerce core stub packages.
 *
 * This file is read only by PHPStan through scanFiles. It is never loaded by
 * WordPress and must describe the public signatures actually invoked by the
 * production plugin.
 */

namespace {
	if ( ! function_exists( 'as_has_scheduled_action' ) ) {
		function as_has_scheduled_action( string $hook, array $args = array(), string $group = '' ): int|false {}
	}

	if ( ! function_exists( 'as_schedule_recurring_action' ) ) {
		function as_schedule_recurring_action( int $timestamp, int $interval_in_seconds, string $hook, array $args = array(), string $group = '', bool $unique = false, int $priority = 10 ): int {}
	}

	// ext-yaml may be loaded by the PHP binary that lints this scan file.
	if ( ! function_exists( 'yaml_parse' ) ) {
		function yaml_parse( string $input, int $pos = 0, int &$ndocs = 0, array $callbacks = array() ): mixed {}
	}

	if ( ! class_exists( 'WP_CLI', false ) ) {
		class WP_CLI {
			public static function add_command( string $name, callable|string|object $callable, array $args = array() ): void {}
			public static function log( string $message ): void {}
		}
	}

	if ( ! class_exists( 'WC_Customer_Query', false ) ) {
		class WC_Customer_Query {
			public function __construct( array $query = array() ) {}
			public function get_customers(): array {}
		}
	}
}

namespace Symfony\Component\Yaml {
	if ( ! class_exists( Yaml::class, false ) ) {
		final class Yaml {
			public static function parse( string $input, int $flags = 0 ): mixed {}
		}
	}
}

namespace AdTribes\PFP\Helpers {
	if ( ! class_exists( Product_Feed::class, false ) ) {
		final class Product_Feed {
			public int $id;
			public string $status;
			public string $title;
			public string $channel_hash;
			public string $file_format;
			public int $products_count;
			public string $last_updated;
			public string $refresh_interval;
			public string $legacy_project_hash;
			public string $file_name;
			public function set_props( array $properties ): void {}
			public function set_data_version( string $key, string $version ): void {}
			public function unregister_action(): void {}
			public function save(): int|false {}
			public function generate( string $context = 'manual' ): bool {}
			public function get_file_url(): string {}
			public function get_file_path(): string {}
		}
	}

	if ( ! class_exists( Product_Feed_Helper::class, false ) ) {
		final class Product_Feed_Helper {
			public static function get_product_feed( int $feed_id, string $context = 'view' ): Product_Feed|false {}
			public static function generate_legacy_project_hash(): string {}
		}
	}
}

namespace AdTribes\PFP\Classes {
	if ( ! class_exists( Product_Feed_Attributes::class, false ) ) {
		final class Product_Feed_Attributes {
			public static function instance(): self {}
			public function get_channels( string $country_name ): array {}
		}
	}
}

namespace LiteSpeed {
	if ( ! class_exists( Purge::class, false ) ) {
		final class Purge {
			public static function purge_all(): void {}
		}
	}
}
