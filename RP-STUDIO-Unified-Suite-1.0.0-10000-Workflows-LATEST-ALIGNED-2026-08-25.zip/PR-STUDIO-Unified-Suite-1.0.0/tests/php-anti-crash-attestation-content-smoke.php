<?php
declare(strict_types=1);

define('PRSTUDIO_UC_TESTING', true);
define('ABSPATH', __DIR__ . '/');
$root=sys_get_temp_dir().'/prstudio-attestation-content-'.getmypid().'-'.bin2hex(random_bytes(4));
define('PRSTUDIO_UC_DIR', rtrim($root,"/\\").'/');

$GLOBALS['attestation_options']=[];
function get_option($key,$default=false){return $GLOBALS['attestation_options'][$key]??$default;}
function update_option($key,$value,$autoload=null){$GLOBALS['attestation_options'][$key]=$value;return true;}
function wp_json_encode($value,$flags=0){return json_encode($value,$flags|JSON_THROW_ON_ERROR);}
function check(bool $condition,string $message):void{if(!$condition){fwrite(STDERR,"FAIL $message\n");exit(1);}fwrite(STDOUT,"PASS $message\n");}

foreach(['includes/orchestrator/domains','capabilities','contract'] as $directory){mkdir(PRSTUDIO_UC_DIR.$directory,0777,true);}
file_put_contents(PRSTUDIO_UC_DIR.'prstudio-unified-control.php','<?php // bootstrap');
file_put_contents(PRSTUDIO_UC_DIR.'capabilities/agency-capabilities.json','{}');
file_put_contents(PRSTUDIO_UC_DIR.'contract/capability-contract.json','{}');
$include=PRSTUDIO_UC_DIR.'includes/orchestrator/domains/example.php';
$before="<?php return 'AAAA';\n";
$after ="<?php return 'BBBB';\n";
check(strlen($before)===strlen($after),'fixture mutation preserves exact byte length');
file_put_contents($include,$before);
$originalMtime=time()-3600;
touch($include,$originalMtime);
clearstatcache(true,$include);
$originalSize=filesize($include);$storedMtime=filemtime($include);

require dirname(__DIR__).'/prstudio-unified-control/includes/class-prstudio-uc-anti-crash-attestation.php';
$stored=PRSTUDIO_UC_Anti_Crash_Attestation::store(['status'=>'passed','evidence_sha256'=>hash('sha256','evidence')],['scope'=>['wordpress']]);
check(($stored['stored']??false)===true,'content-bound attestation is stored');
$initialStatus=PRSTUDIO_UC_Anti_Crash_Attestation::status();
$initialReuse=PRSTUDIO_UC_Anti_Crash_Attestation::reusable('wordpress_content_transaction');
check(($initialReuse['reused']??false)===true,'unchanged include content permits scoped attestation reuse');

file_put_contents($include,$after);
touch($include,$originalMtime);
clearstatcache(true,$include);
check(filesize($include)===$originalSize&&filemtime($include)===$storedMtime,'mutation retains original size and mtime metadata');

// A new PHP request recomputes the memoized fingerprint. Resetting the private
// memo models that boundary without loading a second process.
$memo=new ReflectionProperty(PRSTUDIO_UC_Anti_Crash_Attestation::class,'fingerprint_memo');
$memo->setAccessible(true);$memo->setValue(null,null);
$changedStatus=PRSTUDIO_UC_Anti_Crash_Attestation::status();
$changedReuse=PRSTUDIO_UC_Anti_Crash_Attestation::reusable('wordpress_content_transaction');
check(($initialStatus['fingerprint']??'')!==($changedStatus['fingerprint']??''),'same-size same-mtime nested PHP mutation changes content fingerprint');
check(($changedReuse['reused']??true)===false,'content mutation invalidates the prior anti-crash attestation');

$remove=function(string $path)use(&$remove):void{
    if(is_dir($path)){foreach(scandir($path)?:[] as $entry){if($entry==='.'||$entry==='..')continue;$remove($path.DIRECTORY_SEPARATOR.$entry);}@rmdir($path);return;}
    @unlink($path);
};
$remove($root);
fwrite(STDOUT,"OK anti-crash attestation content fingerprint smoke\n");
