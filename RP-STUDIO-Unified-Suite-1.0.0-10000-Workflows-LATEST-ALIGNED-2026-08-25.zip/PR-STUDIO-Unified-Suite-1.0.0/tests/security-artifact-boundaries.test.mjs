import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import {
  BROWSER_PARITY_REQUIRED_CHECKS,
  REMOTE_E2E_REQUIRED_CHECKS,
  canonicalBrowserParityEvidence,
  canonicalRemoteE2EFailureEvidence,
  canonicalRemoteE2EEvidence,
  confinedArtifactRoot,
  decodeValidatedPngBase64,
  readBoundedJsonArtifact,
  sanitizeLogValue,
  validateRemoteE2EReceipt,
  validateRemoteE2EFailureEvidence,
  validateWindowsArtifactSourceMetadata,
  validateBrowserExtensionReport,
  writeBoundedJsonArtifact,
  writeBoundedPngArtifact,
} from '../.github/scripts/security-artifact-boundaries.mjs';

const extensionId = 'a'.repeat(32);

function validBrowserReport() {
  return {
    ok: true,
    base_url: 'http://127.0.0.1:8080',
    browser_version: 'Chrome/151.0.0.0',
    worker_url: `chrome-extension://${extensionId}/service-worker-bootstrap.js`,
    finished_at: '2026-08-24T08:00:00.000Z',
    checks: BROWSER_PARITY_REQUIRED_CHECKS.map((name) => (
      name === 'exact_mv3_worker_loaded' ? { name, ok: true, extension_id: extensionId } : { name, ok: true }
    )),
  };
}

test('log boundary removes line forging and terminal control characters', () => {
  const safe = sanitizeLogValue('remote\r\nPASS forged\u2028next\u001b[31m', 200);
  assert.equal(safe.includes('\r'), false);
  assert.equal(safe.includes('\n'), false);
  assert.equal(safe.includes('\u2028'), false);
  assert.equal(safe.includes('\u001b'), false);
  assert.ok(safe.includes('PASS forged'), 'sanitization preserves diagnostic content without forging a new entry');
});

test('JSON artifact boundary confines paths, validates exact bytes and binds canonical evidence', async () => {
  const root = await mkdtemp(join(tmpdir(), 'rpconnector-artifact-boundary-'));
  try {
    const report = validBrowserReport();
    const written = await writeBoundedJsonArtifact(root, 'browser-extension-e2e.json', report, { maxBytes: 200000 });
    const loaded = await readBoundedJsonArtifact(root, 'browser-extension-e2e.json', { maxBytes: 200000 });
    assert.equal(loaded.byteLength, written.byteLength);
    assert.equal(loaded.sha256, written.sha256);
    assert.equal(validateBrowserExtensionReport(loaded.value, report.base_url), true);

    const canonical = canonicalBrowserParityEvidence(loaded);
    assert.deepEqual(canonical.checks.map((row) => row.name), BROWSER_PARITY_REQUIRED_CHECKS);
    assert.ok(canonical.checks.every((row) => row.ok === true));
    await writeBoundedJsonArtifact(root, 'parity.json', canonical, { maxBytes: 200000 });
    assert.equal(JSON.parse(await readFile(join(root, 'parity.json'), 'utf8')).source_sha256, loaded.sha256);
    await writeBoundedJsonArtifact(root, 'parity.json', { ...canonical, schema_version: 2 }, { maxBytes: 200000 });
    assert.equal(JSON.parse(await readFile(join(root, 'parity.json'), 'utf8')).schema_version, 2);

    await assert.rejects(() => writeBoundedJsonArtifact(root, '../escape.json', report), /artifact_leaf_invalid/);
    await assert.rejects(() => readBoundedJsonArtifact(root, '../escape.json'), /artifact_leaf_invalid/);
    await assert.rejects(() => writeBoundedJsonArtifact(root, 'oversize.json', { value: 'x'.repeat(5000) }, { maxBytes: 100 }), /artifact_bytes_out_of_bounds/);

    await writeFile(join(root, 'oversize-source.json'), JSON.stringify({ value: 'x'.repeat(5000) }));
    await assert.rejects(() => readBoundedJsonArtifact(root, 'oversize-source.json', { maxBytes: 100 }), /artifact_source_invalid/);
    assert.equal(confinedArtifactRoot(root, join(root, 'nested')), join(root, 'nested'));
    assert.throws(() => confinedArtifactRoot(root, join(root, '..', 'escape')), /artifact_root_outside_allowed_tree/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('JSON artifact reader rejects a symlink/reparse leaf on every supported platform', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'rpconnector-artifact-symlink-'));
  try {
    const target = join(root, 'real.json');
    const link = join(root, 'linked.json');
    await writeFile(target, '{"ok":true}\n');
    try {
      await symlink(target, link, 'file');
    } catch (error) {
      if (['EPERM', 'EACCES', 'UNKNOWN'].includes(error?.code)) {
        t.skip(`symlink creation unavailable: ${error.code}`);
        return;
      }
      throw error;
    }
    await assert.rejects(() => readBoundedJsonArtifact(root, 'linked.json'), /ELOOP|reparse|symlink/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('Windows artifact source predicate rejects reparse leaves and identity swaps', () => {
  const metadata = ({ file = true, symlinkLeaf = false, dev = 12, ino = 34 } = {}) => ({
    dev,
    ino,
    isFile: () => file,
    isSymbolicLink: () => symlinkLeaf,
  });
  assert.equal(validateWindowsArtifactSourceMetadata(metadata(), metadata()), true);
  assert.throws(() => validateWindowsArtifactSourceMetadata(metadata({ symlinkLeaf: true }), metadata()), /reparse_or_symlink/);
  assert.throws(() => validateWindowsArtifactSourceMetadata(metadata(), metadata({ ino: 35 })), /identity_changed/);
  assert.throws(() => validateWindowsArtifactSourceMetadata(metadata(), metadata({ file: false })), /not_regular/);
  assert.throws(() => validateWindowsArtifactSourceMetadata(metadata({ ino: 0 }), metadata({ ino: 0 })), /identity_changed/);
});

test('CDP screenshot boundary accepts only bounded structurally valid canonical PNG bytes', async () => {
  const root = await mkdtemp(join(tmpdir(), 'rpconnector-png-boundary-'));
  try {
    const encoded = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
    const png = decodeValidatedPngBase64(encoded, { maxBytes: 10000, maxPixels: 100 });
    await writeBoundedPngArtifact(root, 'screen.png', png, { maxBytes: 10000 });
    assert.deepEqual(await readFile(join(root, 'screen.png')), png);
    assert.throws(() => decodeValidatedPngBase64(`${encoded.slice(0, -4)}AAAA`, { maxBytes: 10000 }), /png_iend/);
    assert.throws(() => decodeValidatedPngBase64('not-base64-data!', { maxBytes: 10000 }), /png_base64/);
    await assert.rejects(() => writeBoundedPngArtifact(root, '../escape.png', png), /artifact_leaf_invalid/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test('browser evidence validator rejects remote identity and failed-check tampering', () => {
  const wrongWorker = validBrowserReport();
  wrongWorker.worker_url = 'https://attacker.invalid/payload.js';
  assert.throws(() => validateBrowserExtensionReport(wrongWorker, wrongWorker.base_url), /worker_url_invalid/);

  const failedCheck = validBrowserReport();
  failedCheck.checks[1].ok = false;
  assert.throws(() => validateBrowserExtensionReport(failedCheck, failedCheck.base_url), /check_row_invalid/);

  const wrongOrigin = validBrowserReport();
  assert.throws(() => validateBrowserExtensionReport(wrongOrigin, 'http://127.0.0.1:9999'), /base_url_mismatch/);
});

test('remote E2E evidence is canonical, bounded and strips untrusted task details', () => {
  const required = REMOTE_E2E_REQUIRED_CHECKS.map((name) => ({ name, ok: true }));
  const source = {
    ok: true,
    tasks: Array.from({ length: 5 }, (_, index) => ({ task_uuid: `task-${index}`, status: 'completed', result: { secret: 'must-not-persist' } })),
    checks: [...required, ...Array.from({ length: 20 - required.length }, (_, index) => ({ name: `supplemental-${index}`, ok: true }))],
    error: null,
  };
  const canonical = canonicalRemoteE2EEvidence(source);
  assert.deepEqual(canonical, {
    schema_version: '1.0.0',
    ok: true,
    task_count: 5,
    completed_task_count: 5,
    check_count: 20,
    passed_check_count: 20,
    error_present: false,
    required_checks: [...REMOTE_E2E_REQUIRED_CHECKS],
    receipt_algorithm: 'sha256',
    receipt_sha256: canonical.receipt_sha256,
  });
  assert.match(canonical.receipt_sha256, /^[a-f0-9]{64}$/);
  assert.equal(validateRemoteE2EReceipt(canonical), true);
  assert.equal(JSON.stringify(canonical).includes('must-not-persist'), false);
  assert.throws(() => canonicalRemoteE2EEvidence({ ...source, checks: [...source.checks, required[0]] }), /required_check_invalid/);
  assert.throws(() => validateRemoteE2EReceipt({ ...canonical, receipt_sha256: '0'.repeat(64) }), /hash_invalid/);
  assert.throws(() => validateRemoteE2EReceipt({ ...canonical, check_count: 21, passed_check_count: 21 }), /hash_mismatch/);
  const forgedIdentity = { ...canonical, required_checks: canonical.required_checks.map((name, index) => index === 0 ? 'forged check' : name) };
  assert.throws(() => validateRemoteE2EReceipt(forgedIdentity), /required_checks_invalid/);
  assert.throws(() => canonicalRemoteE2EEvidence({ tasks: [], checks: new Array(513).fill({ ok: true }) }), /checks_invalid/);
  assert.throws(() => canonicalRemoteE2EEvidence(null), /evidence_invalid/);
});

test('remote E2E failure evidence is hashed, diagnostic and contains no untrusted payload', () => {
  const source = {
    ok: false,
    tasks: [{ task_uuid: 'secret-task-id', status: 'completed', result: { token: 'must-not-persist' } }],
    checks: [
      { name: REMOTE_E2E_REQUIRED_CHECKS[0], ok: true, detail: { password: 'must-not-persist' } },
      { name: 'restart health', ok: false, detail: { authorization: 'Bearer must-not-persist' } },
    ],
  };
  const error = new Error('mv3_worker_missing:https://user:password@attacker.invalid/?token=must-not-persist');
  error.stack = `Error: secret\n    at file:///workspace/tests/wordpress-remote-browser-e2e.mjs:404:9\nBearer must-not-persist`;
  const diagnostic = canonicalRemoteE2EFailureEvidence(source, error);
  assert.equal(validateRemoteE2EFailureEvidence(diagnostic), true);
  assert.equal(diagnostic.ok, false);
  assert.equal(diagnostic.failure_code, 'mv3_worker_missing');
  assert.equal(diagnostic.failure_line, 404);
  assert.equal(diagnostic.last_passed_check, REMOTE_E2E_REQUIRED_CHECKS[0]);
  assert.equal(diagnostic.failed_check, 'restart health');
  assert.equal(diagnostic.required_checks_passed.length, 1);
  assert.equal(JSON.stringify(diagnostic).includes('must-not-persist'), false);
  assert.equal(JSON.stringify(diagnostic).includes('attacker.invalid'), false);
  assert.throws(() => validateRemoteE2EFailureEvidence({ ...diagnostic, diagnostic_sha256: '0'.repeat(64) }), /hash_invalid/);
  assert.throws(() => validateRemoteE2EFailureEvidence({ ...diagnostic, task_count: 2 }), /hash_mismatch/);
});

test('remote WordPress E2E follows Chrome MV3 terminate-then-status-event restart semantics', async () => {
  const source = await readFile(new URL('./wordpress-remote-browser-e2e.mjs', import.meta.url), 'utf8');
  assert.match(source, /Target\.closeTarget/);
  assert.match(source, /waitTargetGone\(cdp, oldWorkerId\)/);
  assert.match(source, /const \[restartedWorker, restartStatus\] = await Promise\.all/);
  assert.match(source, /chrome\.runtime\.sendMessage\(\{type:'status'\}\)/);
  assert.match(source, /restartStatus\?\.paired === true && restartStatus\?\.deviceId === deviceId/);
  assert.match(source, /workerTarget\.targetId !== oldWorkerId/);
  assert.doesNotMatch(source, /chrome\.runtime\.reload/);
});
