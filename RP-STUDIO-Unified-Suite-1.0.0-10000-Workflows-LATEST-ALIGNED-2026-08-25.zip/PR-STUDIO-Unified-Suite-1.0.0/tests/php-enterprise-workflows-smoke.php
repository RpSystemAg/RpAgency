<?php
define('PRSTUDIO_UC_TESTING', true);
if(!defined('PRSTUDIO_UC_DIR')) define('PRSTUDIO_UC_DIR', dirname(__DIR__).'/prstudio-unified-control/');
function sanitize_key($v){ return strtolower(preg_replace('/[^a-z0-9_-]+/i','',(string)$v)); }
function remove_accents($v){ return (string)$v; }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function absint($v){ return abs((int)$v); }
function wp_json_encode($v,$flags=0){ return json_encode($v,$flags); }
function is_wp_error($v){ return false; }
require_once PRSTUDIO_UC_DIR.'includes/class-prstudio-uc-capability-registry.php';
require_once PRSTUDIO_UC_DIR.'includes/class-prstudio-uc-enterprise-workflows.php';
function ok($v,$m){ if(!$v){fwrite(STDERR,"FAIL: $m\n");exit(1);} }
$c=PRSTUDIO_UC_Enterprise_Workflows::catalog(['limit'=>5,'offset'=>0]);
ok($c['workflow_count']===10000,'catalog must expose 10000 workflows');
ok($c['phase_count']===40715,'catalog must expose exactly 40715 grounded phases');
ok(($c['waves'][1]??0)===300 && ($c['waves'][2]??0)===300 && ($c['waves'][3]??0)===300 && ($c['waves'][4]??0)===380 && ($c['waves'][5]??0)===600 && ($c['waves'][6]??0)===299 && ($c['waves'][7]??0)===200 && ($c['waves'][8]??0)===299 && ($c['waves'][9]??0)===7322,'wave counts must match 300/300/300/380/600/299/200/299/7322');
$s=PRSTUDIO_UC_Enterprise_Workflows::search('autopilot state convergence',['limit'=>3,'offset'=>0]);
ok($s['count']>0,'semantic workflow search must return results');
ok($s['items'][0]['id']==='seo_autopilot_state_convergence_enterprise','Autopilot incident must route to the dedicated workflow first');
$d=PRSTUDIO_UC_Enterprise_Workflows::describe('seo_autopilot_state_convergence_enterprise');
ok(!empty($d['ok']) && count($d['workflow']['phases'])===6,'dedicated workflow must be describable and have six bounded phases');
$v=PRSTUDIO_UC_Enterprise_Workflows::validate();
ok(!empty($v['ok']) && $v['workflows_checked']===10000 && $v['phases_checked']===40715,'registry validation must cover every workflow/phase exactly');
$page2=PRSTUDIO_UC_Enterprise_Workflows::catalog(['wave'=>7,'limit'=>25,'offset'=>25]);
ok($page2['returned']===25 && $page2['matched']===200 && $page2['offset']===25 && !empty($page2['has_more']),'Wave7 catalog pagination must expose the entire wave');
$compile=PRSTUDIO_UC_Enterprise_Workflows::compile('seo_autopilot_state_convergence_enterprise',[]);
ok(count($compile['phases'])===6,'workflow compiler must retain bounded state-machine phases');
echo "PASS: enterprise workflow registry/search/describe/compile/validate = 10000 workflows\n";
