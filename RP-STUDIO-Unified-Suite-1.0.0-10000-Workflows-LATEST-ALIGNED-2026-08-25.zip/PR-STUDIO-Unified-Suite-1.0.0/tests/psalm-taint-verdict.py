#!/usr/bin/env python3
"""Turn Psalm's JSON output into a security-only fail-closed verdict.

Psalm 6 emits regular type findings together with taint findings when
--taint-analysis is enabled. PHPStan owns the type gate; this parser owns only
Psalm's security dataflow signal. Engine/config crashes always fail.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

ENGINE_PATTERN = re.compile(
    r"(?:Fatal error|Uncaught|ConfigException|InvalidArgumentException|cannot load|could not load)",
    re.I,
)


def engine_failed(stderr: str) -> bool:
    return bool(ENGINE_PATTERN.search(stderr))


def security_findings(payload: object) -> list[dict]:
    if not isinstance(payload, list):
        raise TypeError("Psalm JSON result is not an issue list")
    return [
        issue for issue in payload
        if isinstance(issue, dict) and "Tainted" in str(issue.get("type", ""))
    ]


def full_surface_self_test() -> int:
    clean = [{"type": "InvalidReturnType"}]
    tainted = clean + [{"type": "TaintedHtml", "message": "source reaches sink"}]
    if security_findings(clean):
        raise RuntimeError("Psalm taint oracle classified a type-only finding as tainted")
    if len(security_findings(tainted)) != 1:
        raise RuntimeError("Psalm taint oracle did not isolate the tainted path")
    if not engine_failed("ConfigException: invalid taint configuration") or engine_failed("analysis complete"):
        raise RuntimeError("Psalm engine diagnostic oracle diverged")
    try:
        security_findings({"type": "TaintedHtml"})
    except TypeError:
        pass
    else:
        raise RuntimeError("Psalm taint oracle accepted a non-list result")
    print("PASS Psalm taint verdict internal self-test")
    return 0


def main() -> int:
    if os.environ.get("PRSTUDIO_FULL_SURFACE_EXECUTION") == "1" and len(sys.argv) == 1:
        return full_surface_self_test()

    out = Path("/tmp/psalm-taint.json")
    err = Path("/tmp/psalm-taint.stderr")
    code_file = Path("/tmp/psalm-taint.exit")
    if not out.is_file() or not code_file.is_file():
        raise SystemExit("PSALM-TAINT-01 missing Psalm result/exit artifacts")

    stderr = err.read_text(encoding="utf-8", errors="replace") if err.is_file() else ""
    if engine_failed(stderr):
        print(stderr[-12000:], file=sys.stderr)
        raise SystemExit("PSALM-TAINT-02 Psalm engine/configuration failed")
    try:
        payload = json.loads(out.read_text(encoding="utf-8", errors="strict") or "[]")
        security = security_findings(payload)
    except (json.JSONDecodeError, UnicodeError) as exc:
        print(stderr[-12000:], file=sys.stderr)
        raise SystemExit(f"PSALM-TAINT-03 invalid JSON result: {exc}") from exc
    except TypeError as exc:
        raise SystemExit(f"PSALM-TAINT-04 {exc}") from exc

    print(f"PSALM TAINT VERDICT: all_findings={len(payload)} taint_findings={len(security)} exit={code_file.read_text().strip()}")
    for issue in security:
        print(json.dumps({
            "type": issue.get("type"),
            "message": issue.get("message"),
            "file": issue.get("file_name"),
            "line": issue.get("line_from"),
        }, ensure_ascii=False))
    if security:
        raise SystemExit("PSALM-TAINT-05 unreviewed taint path(s) reached a security sink")
    print("PASS Psalm found no source-to-security-sink path under the configured WordPress/MCP taint model")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
