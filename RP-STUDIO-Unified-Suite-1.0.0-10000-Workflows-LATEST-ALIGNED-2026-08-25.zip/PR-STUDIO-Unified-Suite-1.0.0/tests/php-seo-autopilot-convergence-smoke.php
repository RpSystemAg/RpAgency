<?php
define('PRSTUDIO_UC_TESTING', true);
function sanitize_key($v){ return strtolower(preg_replace('/[^a-z0-9_-]+/i','',(string)$v)); }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function absint($v){ return abs((int)$v); }
function wp_json_encode($v,$flags=0){ return json_encode($v,$flags); }
$GLOBALS['modified_ts']=time()-60;
$GLOBALS['seo_meta']=['rank_math_seo_score'=>'80','rank_math_focus_keyword'=>'alpha,beta,gamma,delta'];
function get_post_modified_time(){ return (string)$GLOBALS['modified_ts']; }
function get_post_meta($id,$key,$single=true){ return $GLOBALS['seo_meta'][$key]??''; }
final class Fake_Product_Convergence {
 public function get_id(){return 101;} public function get_name(){return 'Product';} public function get_slug(){return 'product';}
 public function get_status(){return 'publish';} public function get_stock_quantity(){return 2;} public function get_stock_status(){return 'instock';}
 public function get_image_id(){return 501;} public function get_gallery_image_ids(){return [502];}
}
function wc_get_product($id){ return (int)$id===101?new Fake_Product_Convergence():null; }
final class PRSTUDIO_UC_Memory { public static function fingerprint($v):string{return hash('sha256',json_encode($v));} public static function mission(string $id,?array $state=null):array{return [];} }
final class PRSTUDIO_UC_Interventions {
 const APPLIED='applied';
 public static string $key='seo_autopilot_pass';
 public static string $applied='';
 public static function normalize_entity(string $type,$id):string{return sanitize_key($type).':'.trim((string)$id);}
 public static function filter_new(array $findings,bool $include=false):array{
   $rows=[]; foreach($findings as $f){ if(($f['intervention_key']??'')===self::$key){$rows[]=['entity_key'=>$f['entity_key'],'intervention_key'=>self::$key,'state'=>'applied','applied_gmt'=>self::$applied];}}
   return ['findings'=>$findings,'already_settled_count'=>count($rows),'already_settled'=>$rows];
 }
}
PRSTUDIO_UC_Interventions::$applied=gmdate('Y-m-d H:i:s',time()-30);
require_once __DIR__.'/../prstudio-unified-control/includes/class-prstudio-uc-seo-autopilot.php';
function ok($v,$m){if(!$v){fwrite(STDERR,"FAIL: $m\n");exit(1);}}
function priv($m,...$args){$r=new ReflectionMethod(PRSTUDIO_UC_SEO_Autopilot::class,$m);$r->setAccessible(true);return $r->invoke(null,...$args);}
$req=priv('normalized_requirements',[],[]);
ok(($req['rotation_cooldown_days']??0)===120,'rotation cooldown must default to 120 days');
$row=['entity_type'=>'product','entity_id'=>'101','entity_key'=>'product:101','status'=>'PENDING'];
$c=priv('convergence_candidate',$row,$req);
ok(!empty($c['ok']) && ($c['settlement']['intervention_key']??'')==='seo_autopilot_pass','canonical Autopilot pass + unchanged product must be safely backfillable');
$strict=$req;$strict['require_live_rank_math_score']=true;
$c=priv('convergence_candidate',$row,$strict);
ok(empty($c['ok']) && ($c['reason']??'')==='live_rank_math_editor_evidence_required','historical backfill must not fabricate live Rank Math editor evidence');
PRSTUDIO_UC_Interventions::$key='seo_rotation_cooldown'; PRSTUDIO_UC_Interventions::$applied=gmdate('Y-m-d H:i:s',time()-86400*30); $GLOBALS['modified_ts']=time()-86400*31;
$c=priv('convergence_candidate',$row,$req);
ok(!empty($c['ok']),'manual SEO cooldown inside 120 days + unchanged product must be eligible for safe campaign convergence');
PRSTUDIO_UC_Interventions::$applied=gmdate('Y-m-d H:i:s',time()-86400*121);$GLOBALS['modified_ts']=time()-86400*122;
$c=priv('convergence_candidate',$row,$req);
ok(empty($c['ok']) && ($c['reason']??'')==='rotation_cooldown_expired','expired manual cooldown must return product to normal rotation');
$src=file_get_contents(__DIR__.'/../prstudio-unified-control/includes/class-prstudio-uc-seo-autopilot.php');
ok(str_contains($src,'self::reconcile( $campaign_id )'),'mcp_next path must reconcile campaign state before claiming by default');
ok(str_contains($src,"'seo_rotation_cooldown'"),'Autopilot must understand the historical rotation key');
echo "PASS: SEO Autopilot convergence, 120-day rotation, fingerprint drift and no-fabricated-live-evidence rules\n";
