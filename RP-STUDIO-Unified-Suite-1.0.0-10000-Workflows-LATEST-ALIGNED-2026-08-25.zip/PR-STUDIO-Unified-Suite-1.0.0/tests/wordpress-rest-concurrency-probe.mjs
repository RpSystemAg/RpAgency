import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import {
  CAPABILITY_CONTRACT_SHA256,
  EXECUTOR_BUILD_ID,
  EXECUTOR_BUILD_TIMESTAMP,
  EXECUTOR_PROTOCOL_VERSION,
  GSC_DIMENSION_SESSION_VERSION,
  SUITE_VERSION,
} from '../prstudio-unified-browser-agent/lib/executor-meta.js';
import { RUNTIME_CONTRACT_ACTIONS } from '../prstudio-unified-browser-agent/lib/runtime-capabilities.js';
import { buildApiUrl } from '../prstudio-unified-browser-agent/lib/wordpress-rest-transport.js';

const wpUrl = String(process.env.WP_URL || '').replace(/\/+$/, '');
const wpPath = String(process.env.WP_PATH || process.env.RP_WP_PATH || '');
const wpCli = String(process.env.WP_CLI || '/tmp/wp-cli.phar');
const pairBudgetMs = 5_000;

assert.match(wpUrl, /^http:\/\/127\.0\.0\.1:\d+$/, 'probe is confined to the loopback WordPress fixture');
assert.ok(wpPath.startsWith('/tmp/') && !wpPath.includes('\0'), 'WordPress fixture path must be an explicit /tmp path');

function wpEval(program) {
  const result = spawnSync('php', [wpCli, 'eval', program, `--path=${wpPath}`], {
    encoding: 'utf8',
    timeout: 15_000,
  });
  if (result.status !== 0) {
    throw new Error(`wp_eval_failed:${String(result.stderr || result.stdout || '').slice(0, 1000)}`);
  }
  return String(result.stdout || '').trim();
}

const capabilities = {
  executorProtocolVersion: EXECUTOR_PROTOCOL_VERSION,
  runtimeOperationCount: RUNTIME_CONTRACT_ACTIONS.length,
  wordpressCapabilityCatalog: false,
  capabilityHash: CAPABILITY_CONTRACT_SHA256,
  gscDimensionSessionVersion: GSC_DIMENSION_SESSION_VERSION,
  agentBuild: EXECUTOR_BUILD_ID,
  buildTimestamp: EXECUTOR_BUILD_TIMESTAMP,
  suiteVersion: SUITE_VERSION,
};

async function pair(name) {
  const code = wpEval('echo PRSTUDIO_UC_Auth::create_pairing_code();');
  assert.match(code, /^[A-Z0-9_-]{4,}$/, 'WordPress returned a bounded pairing code');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('pair_budget_exceeded'), pairBudgetMs);
  try {
    const endpoint = new URL(wpUrl);
    endpoint.searchParams.set('rest_route', '/prstudio-unified/v1/pair');
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, name, capabilities }),
      cache: 'no-store',
      credentials: 'omit',
      redirect: 'error',
      signal: controller.signal,
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(`pair_http_${response.status}:${String(payload?.code || '')}`);
    assert.match(String(payload?.device_id || ''), /^[A-Za-z0-9_-]{8,191}$/);
    assert.ok(String(payload?.token || '').length >= 16);
    assert.equal(new URL(String(payload?.api_base || '')).origin, new URL(wpUrl).origin);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

const devices = [];
const longPollController = new AbortController();
try {
  const waitingDevice = await pair('CI concurrency waiting device');
  devices.push(String(waitingDevice.device_id));
  const longPollUrl = buildApiUrl(waitingDevice.api_base, '/tasks/next?wait=20');
  let longPollSettled = false;
  const longPoll = fetch(longPollUrl, {
    headers: { Authorization: `Bearer ${waitingDevice.token}`, Accept: 'application/json' },
    cache: 'no-store',
    credentials: 'omit',
    redirect: 'error',
    signal: longPollController.signal,
  }).then(
    (response) => ({ response }),
    (error) => ({ error }),
  ).finally(() => { longPollSettled = true; });
  await new Promise((resolvePromise) => setTimeout(resolvePromise, 350));
  assert.equal(longPollSettled, false, 'first authenticated task request is actively held as a long-poll');

  const started = performance.now();
  const concurrentDevice = await pair('CI concurrency independent device');
  const elapsedMs = performance.now() - started;
  devices.push(String(concurrentDevice.device_id));
  assert.ok(elapsedMs < pairBudgetMs, `independent pairing exceeded ${pairBudgetMs}ms while long-poll was held: ${elapsedMs.toFixed(1)}ms`);

  longPollController.abort();
  const outcome = await longPoll;
  if (outcome.error && outcome.error.name !== 'AbortError') throw outcome.error;
  console.log(`PASS WordPress REST concurrency: pairing_ms=${elapsedMs.toFixed(1)} budget_ms=${pairBudgetMs} held_long_poll=true`);
} finally {
  longPollController.abort();
  for (const deviceId of devices) {
    wpEval(`if (!PRSTUDIO_UC_Store::revoke_device(${JSON.stringify(deviceId)})) { exit(1); }`);
  }
}
