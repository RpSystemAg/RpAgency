#!/usr/bin/env python3
"""Regression proof that the live rigorous audit stays fail-closed."""
from __future__ import annotations

import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIT = runpy.run_path(str(ROOT / "tests/rigorous-audit-controller.py"))

module_refs = AUDIT["local_module_refs"]
assert module_refs("import value from './real.js';") == ["./real.js"]
assert module_refs("await import('../dynamic.mjs');") == ["../dynamic.mjs"]
assert module_refs("new URL('../../fixture', import.meta.url)") == []

index = AUDIT["php_executor_index"]()
exists = AUDIT["executor_target_exists"]
assert exists("PRSTUDIO_UC_Business_Intelligence::goal_registry", index)
assert exists("PRSTUDIO_UC_Business_Intelligence::outcome_tracker", index)
assert not exists("PRSTUDIO_UC_Business_Intelligence::missing_mutator", index)
assert not exists("Missing_Class::execute", index)
assert not exists("not-a-callable", index)

research, ledger, source = AUDIT["research_ledger"]()
assert source in {"live_in_memory", "persisted_release_ledger"}
assert research.get("pass_count") == 5
assert ledger.get("prstudio-unified-browser-agent/service-worker.js")

summary, _, tools = AUDIT["generate"]()
assert summary["hard_failure_count"] == 0, summary["hard_failures"]
capabilities = {row["id"]: row for row in tools if row["kind"] == "capability"}
for capability_id in ("business.goal.registry", "business.outcome.track"):
    assert capabilities[capability_id]["checks"]["executor_target_exists"] is True

print("RIGOROUS_AUDIT_REGRESSION: PASS")
