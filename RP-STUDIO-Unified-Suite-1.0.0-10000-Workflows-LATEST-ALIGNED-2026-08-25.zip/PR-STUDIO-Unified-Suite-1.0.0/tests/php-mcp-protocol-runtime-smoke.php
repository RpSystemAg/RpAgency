<?php
declare(strict_types=1);
define('PRSTUDIO_UC_TESTING', true);

final class WP_Error { public function __construct(private string $code='',private string $message='',private $data=null){} public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} public function get_error_data(){return $this->data;} }
function is_wp_error($v){return $v instanceof WP_Error;}
function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function sanitize_key($v){return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v));}
function esc_url_raw($v){return (string)$v;}
function wp_json_encode($v,$flags=0,$depth=512){return json_encode($v,$flags,$depth);}
function wp_salt($scheme='auth'){return 'mcp-protocol-test-'.$scheme;}
function get_option($k,$d=false){global $opts;return $opts[$k]??$d;}
function update_option($k,$v,$autoload=null){global $opts;$opts[$k]=$v;return true;}
$opts=[];

final class WP_REST_Request {
    public function __construct(private string $method, private $payload, private string $protocol='2025-06-18', private array $headers=[]){}
    public function get_header($name){$key=strtolower((string)$name);if($key==='mcp-protocol-version')return $this->protocol;return (string)($this->headers[$key]??'');}
    public function get_method(){return $this->method;}
    public function get_body(){return json_encode($this->payload);}
    public function get_json_params(){return $this->payload;}
    public function get_params(){return is_array($this->payload)?$this->payload:[];}
}
final class WP_REST_Response {
    private array $headers=[];
    public function __construct(private $data=null, private int $status=200){}
    public function header($k,$v){$this->headers[$k]=$v;}
    public function get_data(){return $this->data;}
    public function get_status(){return $this->status;}
    public function get_headers(){return $this->headers;}
}
final class PRSTUDIO_UC_MCP_Auth_V5 {
    public static function permission($write=false){return ['client_id'=>'client'];}
    public static function protected_resource_metadata_url(){return 'https://example.test/.well-known/oauth-protected-resource';}
    public static function mcp_url(){return 'https://example.test/mcp';}
    public static function bearer_token_from_request(){return 'token';}
    public static function verify_access_token($token,$write){return ['client_id'=>'client'];}
    public static function status(){return ['authenticated'=>true,'client_id'=>'client'];}
}
final class PRSTUDIO_UC_Memory {
    public static bool $throwOnRedact=false;
    public static function redact($value){if(self::$throwOnRedact)throw new RuntimeException('post-processing fault injection');return $value;}
}
final class PRSTUDIO_UC_Store {
    public static array $cancelledJobs=[]; public static array $cancelledTasks=[]; public static array $tasks=[]; public static array $events=[]; public static array $requeued=[];
    public static function get_job($id){return ['job_uuid'=>$id,'owner_client_id'=>'client','status'=>'RUNNING'];}
    public static function cancel_job($id,$reason='cancelled'){self::$cancelledJobs[$id]=$reason;return ['job_uuid'=>$id,'status'=>'CANCELLED'];}
    public static function get_task($id){return self::$tasks[$id]??null;}
    public static function cancel($id){if(!isset(self::$tasks[$id]))return null;self::$tasks[$id]['status']='cancelled';return self::$tasks[$id];}
    public static function release_lease_for_requeue($id,$reason){if(!isset(self::$tasks[$id]))return null;self::$tasks[$id]['status']='queued';self::$requeued[$id]=$reason;return self::$tasks[$id];}
    public static function event($id,$type,$payload=[]){self::$events[]=[$id,$type,$payload];}
}
final class PRSTUDIO_UC_Job_Engine {
    public static function cancel_browser_task($id,$device='',$error=[]){PRSTUDIO_UC_Store::$cancelledTasks[$id]=$error;return ['task_uuid'=>$id,'status'=>'cancelled'];}
}
final class PRSTUDIO_UC_State_Machine { public static function is_terminal($status){return in_array($status,['completed','failed','cancelled'],true);} }

require dirname(__DIR__).'/prstudio-unified-control/includes/class-prstudio-uc-turn.php';
require dirname(__DIR__).'/prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php';
function ok($c,$m){if(!$c){fwrite(STDERR,"FAIL $m\n");exit(1);}fwrite(STDOUT,"PASS $m\n");}
function modern_rpc(int $id,string $method,array $params=[]): array {
    $params['_meta']=[
        'io.modelcontextprotocol/protocolVersion'=>'2026-07-28',
        'io.modelcontextprotocol/clientCapabilities'=>[],
        'io.modelcontextprotocol/clientInfo'=>['name'=>'prstudio-test','version'=>'1.0.0'],
    ];
    return ['jsonrpc'=>'2.0','id'=>$id,'method'=>$method,'params'=>$params];
}

$batch=[['jsonrpc'=>'2.0','id'=>1,'method'=>'ping'],['jsonrpc'=>'2.0','id'=>2,'method'=>'ping']];
$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',$batch,'2025-06-18'));
ok($r->get_status()===400&&($r->get_data()['error']['code']??null)===-32600,'MCP 2025-06-18 rejects removed JSON-RPC batching');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',$batch,'2025-03-26'));
ok($r->get_status()===200&&is_array($r->get_data())&&count($r->get_data())===2,'legacy 2025-03-26 compatibility can still process bounded batches');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',['jsonrpc'=>'2.0','id'=>3,'method'=>'ping'],'2025-06-18'));
$data=$r->get_data();
ok($r->get_status()===200&&isset($data['result'])&&is_object($data['result']),'MCP ping returns a prompt empty response object');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',modern_rpc(31,'server/discover'),'2026-07-28',['mcp-method'=>'server/discover']));
$data=$r->get_data();
ok($r->get_status()===200&&($data['result']['ttlMs']??0)===300000&&($data['result']['cacheScope']??'')==='private'&&in_array('2026-07-28',(array)($data['result']['supportedVersions']??[]),true),'MCP 2026 server/discover returns stateless discovery plus private cache hints');
ok(($data['result']['resultType']??'')==='complete','MCP 2026 results carry the required complete resultType');
ok(($data['result']['_meta']['io.modelcontextprotocol/serverInfo']['version']??'')==='1.0.0','MCP 2026 result metadata carries serverInfo in _meta');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',modern_rpc(32,'initialize',['protocolVersion'=>'2026-07-28']),'2026-07-28',['mcp-method'=>'initialize']));
$data=$r->get_data();
ok($r->get_status()===404&&($data['error']['code']??null)===-32601,'MCP 2026 rejects legacy initialize handshake with method-not-found HTTP semantics');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',modern_rpc(33,'ping'),'2026-07-28',['mcp-method'=>'tools/list']));
$data=$r->get_data();
ok($r->get_status()===400&&($data['error']['code']??null)===-32020,'MCP 2026 enforces Mcp-Method request binding');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',['jsonrpc'=>'2.0','id'=>34,'method'=>'ping','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2025-06-18','io.modelcontextprotocol/clientCapabilities'=>[]]]],'2026-07-28',['mcp-method'=>'ping']));
$data=$r->get_data();
ok($r->get_status()===400&&($data['error']['code']??null)===-32020,'MCP 2026 rejects header/body protocol-version mismatch');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',['jsonrpc'=>'2.0','id'=>35,'method'=>'ping','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28']]],'2026-07-28',['mcp-method'=>'ping']));
$data=$r->get_data();
ok($r->get_status()===400&&($data['error']['code']??null)===-32602,'MCP 2026 requires per-request client capabilities metadata');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',modern_rpc(36,'future/method'),'2026-07-28',['mcp-method'=>'future/method']));
$data=$r->get_data();
ok($r->get_status()===404&&($data['error']['code']??null)===-32601,'MCP 2026 maps an unknown method to HTTP 404 plus JSON-RPC method-not-found');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',modern_rpc(37,'ping'),'2099-01-01',['mcp-method'=>'ping']));
$data=$r->get_data();
ok($r->get_status()===400&&($data['error']['code']??null)===-32022&&($data['error']['data']['requested']??'')==='2099-01-01'&&in_array('2026-07-28',(array)($data['error']['data']['supported']??[]),true),'MCP 2026 rejects unsupported protocol versions with supported/requested evidence');

$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('GET',modern_rpc(38,'ping'),'2026-07-28',['mcp-method'=>'ping']));
ok($r->get_status()===405&&($r->get_headers()['Allow']??'')==='POST','MCP 2026 rejects GET on the stateless endpoint');
$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('DELETE',modern_rpc(39,'ping'),'2026-07-28',['mcp-method'=>'ping']));
ok($r->get_status()===405,'MCP 2026 rejects DELETE on the stateless endpoint');

$owner=hash_hmac('sha256','client',wp_salt('auth').'|prstudio-mcp-task-owner');
$requestKey=hash_hmac('sha256','42',$owner.'|prstudio-mcp-request');
$job=str_repeat('a',32);$task=str_repeat('b',32);
$opts['prstudio_mcp_v5_task_owners']=[
  $job=>['owner'=>$owner,'type'=>'job','request_key'=>$requestKey,'updated_at'=>time()],
  $task=>['owner'=>$owner,'type'=>'browser_task','request_key'=>$requestKey,'updated_at'=>time()],
];
$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',['jsonrpc'=>'2.0','method'=>'notifications/cancelled','params'=>['requestId'=>42,'reason'=>'client timeout']],'2025-06-18'));
ok($r->get_status()===204,'MCP cancellation notification is notification-only');
ok(isset(PRSTUDIO_UC_Store::$cancelledJobs[$job])&&isset(PRSTUDIO_UC_Store::$cancelledTasks[$task])&&((PRSTUDIO_UC_Store::$cancelledTasks[$task]['code']??'')==='mcp_request_cancelled'),'MCP cancellation propagates through parent-aware Browser task cancellation');

// Explicit queue control is owner-bound too: knowing another OAuth client's
// task UUID must not be enough to cancel or requeue it.
$task2=str_repeat('c',32);$unmapped=str_repeat('d',32);
PRSTUDIO_UC_Store::$tasks[$task]=['task_uuid'=>$task,'status'=>'queued','attempt_count'=>0];
PRSTUDIO_UC_Store::$tasks[$task2]=['task_uuid'=>$task2,'status'=>'leased','attempt_count'=>2];
PRSTUDIO_UC_Store::$tasks[$unmapped]=['task_uuid'=>$unmapped,'status'=>'queued','attempt_count'=>0];
$opts['prstudio_mcp_v5_task_owners'][$task2]=['owner'=>$owner,'type'=>'browser_task','request_key'=>$requestKey,'updated_at'=>time()];
$control=new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class,'control_browser_task');$control->setAccessible(true);
$foreign=$control->invoke(null,['task_id'=>$task,'action'=>'cancel'],['client_id'=>'other-client']);
ok(is_wp_error($foreign)&&$foreign->get_error_code()==='browser_task_not_found'&&(PRSTUDIO_UC_Store::$tasks[$task]['status']??'')==='queued','foreign OAuth client cannot cancel an owned browser task');
$legacy=$control->invoke(null,['task_id'=>$unmapped,'action'=>'cancel'],['client_id'=>'client']);
ok(is_wp_error($legacy)&&$legacy->get_error_code()==='browser_task_not_found'&&(PRSTUDIO_UC_Store::$tasks[$unmapped]['status']??'')==='queued','unmapped legacy browser task fails closed instead of being claimed by UUID');
$ownedCancel=$control->invoke(null,['task_id'=>$task,'action'=>'cancel','reason'=>'operator cancel'],['client_id'=>'client']);
ok(!is_wp_error($ownedCancel)&&($ownedCancel['status']??'')==='cancelled'&&(PRSTUDIO_UC_Store::$tasks[$task]['status']??'')==='cancelled','owning OAuth client can cancel its browser task');
$ownedRequeue=$control->invoke(null,['task_id'=>$task2,'action'=>'requeue','reason'=>'lease recovery'],['client_id'=>'client']);
ok(!is_wp_error($ownedRequeue)&&($ownedRequeue['status']??'')==='queued'&&($ownedRequeue['attempt_count']??0)===2&&isset(PRSTUDIO_UC_Store::$requeued[$task2]),'owning OAuth client can requeue while preserving attempt evidence');

// Fault-inject the first post-dispatch stage. The executor completes, then
// response redaction throws: this must still be a typed tools/call result and
// never escape as an uncaught Error/ExceptionGroup at the transport boundary.
PRSTUDIO_UC_Memory::$throwOnRedact=true;
$r=PRSTUDIO_UC_MCP_V5::handle(new WP_REST_Request('POST',[
    'jsonrpc'=>'2.0',
    'id'=>50,
    'method'=>'tools/call',
    'params'=>['name'=>'prstudio_health','arguments'=>[]],
],'2025-06-18'));
PRSTUDIO_UC_Memory::$throwOnRedact=false;
$data=$r->get_data();
$postProcess=$data['result']['structuredContent']??[];
ok(
    $r->get_status()===200
    &&($data['result']['isError']??false)===true
    &&($postProcess['status']??'')==='technical_error'
    &&($postProcess['terminal']??false)===true
    &&($postProcess['error']['code']??'')==='prstudio_tool_exception'
    &&($postProcess['error']['details']['exception_class']??'')===RuntimeException::class,
    'tools/call catches response post-processing exceptions and returns a typed terminal MCP error'
);

fwrite(STDOUT,"OK MCP protocol runtime smoke\n");
