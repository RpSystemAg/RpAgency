<?php
declare(strict_types=1);

define( 'PRSTUDIO_UC_TESTING', true );
$root = sys_get_temp_dir() . '/prstudio-business-crud-' . bin2hex( random_bytes( 8 ) );

final class WP_Error {
    public function __construct( private string $code = '', private string $message = '', private array $data = array() ) {}
    public function get_error_code(): string { return $this->code; }
}
function is_wp_error( $value ): bool { return $value instanceof WP_Error; }
function sanitize_text_field( $value ): string { return trim( strip_tags( (string) $value ) ); }
function wp_mkdir_p( string $directory ): bool { return is_dir( $directory ) || mkdir( $directory, 0750, true ); }

final class PRSTUDIO_UC_Memory {
    public static function site_dir(): string {
        global $root;
        wp_mkdir_p( $root );
        return $root;
    }
    public static function redact( $value ) { return $value; }
}

function check_business( bool $condition, string $message ): void {
    if ( ! $condition ) {
        fwrite( STDERR, "FAIL {$message}\n" );
        exit( 1 );
    }
}
function error_code( $value ): string { return is_wp_error( $value ) ? $value->get_error_code() : ''; }
function cleanup_business( string $directory ): void {
    if ( ! is_dir( $directory ) ) { return; }
    $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $directory, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
    foreach ( $iterator as $entry ) { $entry->isDir() ? rmdir( $entry->getPathname() ) : unlink( $entry->getPathname() ); }
    rmdir( $directory );
}

require dirname( __DIR__ ) . '/prstudio-unified-control/includes/class-prstudio-uc-business-intelligence.php';

$goal = array(
    'operation'      => 'upsert',
    'goal_id'        => 'growth-2026',
    'title'          => 'Grow qualified revenue',
    'metric'         => 'qualified_revenue',
    'baseline_value' => 100.0,
    'target_value'   => 160.0,
    'constraints'    => array( 'margin >= 30%' ),
);
$created = PRSTUDIO_UC_Business_Intelligence::goal_registry( $goal );
check_business( ! is_wp_error( $created ) && true === $created['created'] && true === $created['changed'], 'goal create persists' );
$state_path = $root . '/business-intelligence-v1.json';
check_business( is_file( $state_path ), 'goal create writes durable state' );
$before_replay = file_get_contents( $state_path );
$replayed = PRSTUDIO_UC_Business_Intelligence::goal_registry( $goal );
$after_replay = file_get_contents( $state_path );
check_business( false === $replayed['created'] && false === $replayed['changed'] && $before_replay === $after_replay, 'goal replay is idempotent and performs no write' );
$read = PRSTUDIO_UC_Business_Intelligence::goal_registry( array( 'operation' => 'get', 'goal_id' => 'growth-2026' ) );
check_business( 'Grow qualified revenue' === $read['goal']['title'], 'goal independent readback matches persisted content' );
$evaluated = PRSTUDIO_UC_Business_Intelligence::goal_registry( array( 'operation' => 'evaluate', 'goal_id' => 'growth-2026', 'current_value' => 130 ) );
check_business( 0.5 === $evaluated['progress_ratio'] && false === $evaluated['achieved'], 'goal evaluation is deterministic' );
$removed = PRSTUDIO_UC_Business_Intelligence::goal_registry( array( 'operation' => 'remove', 'goal_id' => 'growth-2026' ) );
check_business( true === $removed['removed'], 'goal remove mutates durable state' );
$missing = PRSTUDIO_UC_Business_Intelligence::goal_registry( array( 'operation' => 'get', 'goal_id' => 'growth-2026' ) );
check_business( 'business_goal_not_found' === error_code( $missing ), 'goal deletion has independent negative readback' );
$remove_replay = PRSTUDIO_UC_Business_Intelligence::goal_registry( array( 'operation' => 'remove', 'goal_id' => 'growth-2026' ) );
check_business( false === $remove_replay['removed'] && false === $remove_replay['changed'], 'goal removal replay is idempotent' );

$outcome = array(
    'operation'        => 'record',
    'outcome_id'       => 'outcome-growth-2026',
    'goal_id'          => 'growth-2026',
    'intervention'     => 'Publish a measured acquisition campaign',
    'metric'           => 'qualified_revenue',
    'baseline_value'   => 100,
    'measured_value'   => 127.5,
    'window_start_gmt' => '2026-08-01T00:00:00Z',
    'window_end_gmt'   => '2026-08-24T00:00:00Z',
);
$recorded = PRSTUDIO_UC_Business_Intelligence::outcome_tracker( $outcome );
check_business( true === $recorded['created'] && 27.5 === $recorded['outcome']['delta'], 'outcome record persists measured delta' );
$outcome_before = file_get_contents( $state_path );
$outcome_replay = PRSTUDIO_UC_Business_Intelligence::outcome_tracker( $outcome );
check_business( true === $outcome_replay['replayed'] && false === $outcome_replay['changed'] && $outcome_before === file_get_contents( $state_path ), 'outcome replay is idempotent and performs no write' );
$outcome_read = PRSTUDIO_UC_Business_Intelligence::outcome_tracker( array( 'operation' => 'get', 'outcome_id' => 'outcome-growth-2026' ) );
check_business( 127.5 === $outcome_read['outcome']['measured_value'], 'outcome independent readback matches persisted content' );
$conflict = $outcome;
$conflict['measured_value'] = 999;
check_business( 'business_outcome_id_conflict' === error_code( PRSTUDIO_UC_Business_Intelligence::outcome_tracker( $conflict ) ), 'outcome immutable id rejects conflicting replay' );
$outcome_removed = PRSTUDIO_UC_Business_Intelligence::outcome_tracker( array( 'operation' => 'remove', 'outcome_id' => 'outcome-growth-2026' ) );
check_business( true === $outcome_removed['removed'], 'outcome remove mutates durable state' );
check_business( 'business_outcome_not_found' === error_code( PRSTUDIO_UC_Business_Intelligence::outcome_tracker( array( 'operation' => 'get', 'outcome_id' => 'outcome-growth-2026' ) ) ), 'outcome deletion has independent negative readback' );
check_business( 'business_outcome_window_invalid' === error_code( PRSTUDIO_UC_Business_Intelligence::outcome_tracker( array_merge( $outcome, array( 'outcome_id' => 'bad-window', 'window_end_gmt' => '2026-07-01T00:00:00Z' ) ) ) ), 'invalid outcome window fails before persistence' );

$neutral_experiment = PRSTUDIO_UC_Business_Intelligence::causal_experiment_evaluator( array(
    'control' => array( 'exposures' => 1000, 'conversions' => 100 ),
    'variant' => array( 'exposures' => 1000, 'conversions' => 100 ),
) );
check_business( ! is_wp_error( $neutral_experiment ) && 1.0 === $neutral_experiment['p_value'] && 'inconclusive' === $neutral_experiment['decision'], 'causal evaluator returns a stable neutral probability' );

$winning_experiment = PRSTUDIO_UC_Business_Intelligence::causal_experiment_evaluator( array(
    'control'        => array( 'exposures' => 1000, 'conversions' => 100 ),
    'variant'        => array( 'exposures' => 1000, 'conversions' => 180 ),
    'minimum_effect' => 0.01,
) );
check_business( ! is_wp_error( $winning_experiment ) && $winning_experiment['p_value'] < 0.00001 && 'variant' === $winning_experiment['decision'], 'causal evaluator detects a material statistically significant winner' );

$guardrail_experiment = PRSTUDIO_UC_Business_Intelligence::causal_experiment_evaluator( array(
    'control'    => array( 'exposures' => 1000, 'conversions' => 100 ),
    'variant'    => array( 'exposures' => 1000, 'conversions' => 180 ),
    'guardrails' => array( array( 'metric' => 'refund_rate', 'value' => 0.2, 'max' => 0.1 ) ),
) );
check_business( ! is_wp_error( $guardrail_experiment ) && 'guardrail_failed' === $guardrail_experiment['decision'] && false === $guardrail_experiment['guardrails'][0]['ok'], 'causal evaluator gives failing guardrails precedence over a winner' );
check_business( 'experiment_exposures_required' === error_code( PRSTUDIO_UC_Business_Intelligence::causal_experiment_evaluator( array( 'control' => array(), 'variant' => array() ) ) ), 'causal evaluator rejects empty samples' );

cleanup_business( $root );
echo "PASS business intelligence CRUD smoke: durable create/read/evaluate/delete/replay/conflict paths\n";
