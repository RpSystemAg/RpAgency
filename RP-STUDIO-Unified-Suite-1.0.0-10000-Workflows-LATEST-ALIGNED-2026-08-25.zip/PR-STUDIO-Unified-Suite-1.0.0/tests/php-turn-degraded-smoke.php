<?php
declare(strict_types=1);
define('PRSTUDIO_UC_TESTING',true);
function is_wp_error($value): bool { return false; }
function wp_cache_get($key,$group=''){return false;} function wp_cache_set($key,$value,$group='',$ttl=0){return true;}
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-turn.php';
if(!PRSTUDIO_UC_Turn::is_terminal('degraded')){fwrite(STDERR,"FAIL: degraded is not terminal\n");exit(1);}
$next=['tool'=>'browser_snapshot','arguments'=>['tab_id'=>7]];
$turn=PRSTUDIO_UC_Turn::degraded(['tabId'=>7],$next,['effect_verified'=>false]);
if(($turn['status']??'')!=='degraded'||empty($turn['terminal'])||empty($turn['executed'])||!empty($turn['verified'])||($turn['next_action']??[])!==$next){fwrite(STDERR,"FAIL: degraded turn shape\n");exit(1);}
$normalized=PRSTUDIO_UC_Turn::normalize($turn,'corr_'.str_repeat('a',32),'browser_open',1);
if($normalized!==$turn){fwrite(STDERR,"FAIL: degraded turn changed during normalization\n");exit(1);}
echo "PASS: degraded terminal turn preserves machine-readable verification continuation\n";
