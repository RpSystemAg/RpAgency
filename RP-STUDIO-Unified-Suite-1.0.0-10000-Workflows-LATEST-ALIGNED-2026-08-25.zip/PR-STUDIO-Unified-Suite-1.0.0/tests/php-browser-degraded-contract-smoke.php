<?php
declare(strict_types=1);
define('ABSPATH', __DIR__ . '/');
function sanitize_text_field($value): string { return trim((string)$value); }
final class PRSTUDIO_UC_State_Machine {
    public const COMPLETED='completed'; public const CANCELLED='cancelled'; public const EXPIRED='expired'; public const FAILED='failed';
    public static function is_terminal(string $status): bool { return in_array($status,[self::COMPLETED,self::CANCELLED,self::EXPIRED,self::FAILED],true); }
}
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-bridge.php';
function check_bridge(bool $ok,string $message): void { if(!$ok){fwrite(STDERR,"FAIL: $message\n");exit(1);} echo "PASS: $message\n"; }
$method=new ReflectionMethod(PRSTUDIO_UC_Bridge::class,'task_response');$method->setAccessible(true);
$lane='lane_'.str_repeat('a',32);
$degraded=$method->invoke(null,[
    'task_uuid'=>'task-1','status'=>'completed','arguments'=>['_prstudio_lane_id'=>$lane,'correlation_id'=>'corr_'.str_repeat('b',32)],
    'result'=>['tabId'=>77,'url'=>'https://example.test/'],'verification'=>['ok'=>false,'reason'=>'browser_effect_not_verified'],'error'=>[],
]);
check_bridge($degraded['ok']===true&&$degraded['status']==='degraded'&&$degraded['executed']===true,'executed unverified task is degraded success, never technical error');
check_bridge($degraded['error']===[]&&($degraded['verification_warning']['code']??'')==='browser_effect_unverified','verification uncertainty is a warning');
check_bridge(($degraded['next_action']['tool']??'')==='browser_snapshot'&&($degraded['next_action']['arguments']['tab_id']??0)===77,'degraded result carries exact same-tab verification action');
check_bridge(($degraded['next_action']['arguments']['lane_handle']??'')===$lane,'verification continuation preserves execution lane');
$verified=$method->invoke(null,['task_uuid'=>'task-2','status'=>'completed','arguments'=>[],'result'=>['tabId'=>78],'verification'=>['ok'=>true],'error'=>[]]);
check_bridge($verified['ok']===true&&$verified['status']==='completed'&&$verified['next_action']===null,'verified task remains terminal completed');
$failed=$method->invoke(null,['task_uuid'=>'task-3','status'=>'failed','arguments'=>[],'result'=>[],'verification'=>[],'error'=>[]]);
check_bridge($failed['ok']===false&&($failed['error']['code']??'')==='browser_task_failed','real execution failure remains an error');
