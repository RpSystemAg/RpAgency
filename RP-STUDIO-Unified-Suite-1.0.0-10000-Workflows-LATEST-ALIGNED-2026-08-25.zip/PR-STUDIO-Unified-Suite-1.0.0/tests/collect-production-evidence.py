#!/usr/bin/env python3
"""Collect external production evidence from GitHub Actions for one exact SHA.

The collector rejects cross-SHA evidence, unsuccessful/in-progress runs, duplicate
receipt filenames, unsafe ZIP paths and artifact name mismatches. It is intended
to run immediately before production-readiness-certifier.py in release CI.

A bare invocation runs a deterministic self-test of the collector using real ZIP
and filesystem operations. It does not claim or manufacture production evidence.
Production collection is requested by passing CLI arguments, as release CI does.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import shutil
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCES = ROOT / "quality" / "production-evidence-sources.json"
DEFAULT_OUT = ROOT / "evidence" / "production"
API = os.environ.get("GITHUB_API_URL", "https://api.github.com").rstrip("/")


def request_json(url: str, token: str) -> Any:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "RPConnector-Production-Evidence/1",
        },
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.loads(response.read().decode("utf-8"))


def request_bytes(url: str, token: str) -> bytes:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "RPConnector-Production-Evidence/1",
        },
    )
    with urllib.request.urlopen(request, timeout=120) as response:
        return response.read()


def safe_extract(data: bytes, destination: Path) -> list[Path]:
    extracted: list[Path] = []
    root = destination.resolve()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            if name.endswith("/"):
                continue
            if name.startswith("/") or ".." in Path(name).parts:
                raise RuntimeError(f"unsafe artifact path: {name}")
            target = (destination / name).resolve()
            if root != target and root not in target.parents:
                raise RuntimeError(f"artifact escapes destination: {name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("wb") as sink:
                shutil.copyfileobj(source, sink)
            extracted.append(target)
    return extracted


def find_successful_run(repository: str, workflow: str, commit: str, token: str) -> dict[str, Any] | None:
    encoded = urllib.parse.quote(workflow, safe="")
    query = urllib.parse.urlencode({"head_sha": commit, "status": "completed", "per_page": 100})
    data = request_json(f"{API}/repos/{repository}/actions/workflows/{encoded}/runs?{query}", token)
    runs = data.get("workflow_runs", []) if isinstance(data, dict) else []
    candidates = [
        run for run in runs
        if run.get("head_sha") == commit
        and run.get("status") == "completed"
        and run.get("conclusion") == "success"
    ]
    candidates.sort(key=lambda run: (str(run.get("updated_at", "")), int(run.get("id", 0))), reverse=True)
    return candidates[0] if candidates else None


def find_artifact(repository: str, run_id: int, prefix: str, commit: str, token: str) -> dict[str, Any] | None:
    data = request_json(f"{API}/repos/{repository}/actions/runs/{run_id}/artifacts?per_page=100", token)
    artifacts = data.get("artifacts", []) if isinstance(data, dict) else []
    expected = prefix + commit
    matches = [
        artifact for artifact in artifacts
        if artifact.get("name") == expected and artifact.get("expired") is not True
    ]
    matches.sort(key=lambda artifact: int(artifact.get("id", 0)), reverse=True)
    return matches[0] if matches else None


def receipt_commit(path: Path) -> str:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"invalid JSON receipt {path.name}: {exc}") from exc
    return str(value.get("commit_sha", "")) if isinstance(value, dict) else ""


def make_zip(entries: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in entries.items():
            archive.writestr(name, payload)
    return buffer.getvalue()


def self_test() -> int:
    failures: list[str] = []
    commit = "a" * 40

    try:
        config = json.loads(DEFAULT_SOURCES.read_text(encoding="utf-8"))
        sources = config.get("sources", [])
        if not isinstance(sources, list) or not sources:
            failures.append("production evidence sources are empty")
        claimed: set[str] = set()
        for source in sources:
            required = source.get("required_files", []) if isinstance(source, dict) else []
            if not source.get("id") or not source.get("workflow") or not source.get("artifact_name_prefix") or not required:
                failures.append(f"invalid production evidence source: {source!r}")
                continue
            duplicate = claimed.intersection(str(item) for item in required)
            if duplicate:
                failures.append(f"duplicate required evidence names: {sorted(duplicate)}")
            claimed.update(str(item) for item in required)
    except Exception as exc:
        failures.append(f"sources configuration could not be validated: {type(exc).__name__}: {exc}")

    with tempfile.TemporaryDirectory(prefix="rp-evidence-collector-self-test-") as tmp_name:
        temp = Path(tmp_name)
        valid = make_zip({"nested/receipt.json": json.dumps({"commit_sha": commit}).encode("utf-8")})
        try:
            extracted = safe_extract(valid, temp / "valid")
            if len(extracted) != 1 or receipt_commit(extracted[0]) != commit:
                failures.append("valid ZIP/receipt extraction did not preserve commit binding")
        except Exception as exc:
            failures.append(f"valid ZIP extraction failed: {type(exc).__name__}: {exc}")

        unsafe = make_zip({"../escape.json": b"{}"})
        try:
            safe_extract(unsafe, temp / "unsafe")
            failures.append("path-traversal ZIP was accepted")
        except RuntimeError as exc:
            if "unsafe artifact path" not in str(exc):
                failures.append(f"unexpected traversal rejection: {exc}")

        invalid_receipt = temp / "invalid.json"
        invalid_receipt.write_text("{not-json", encoding="utf-8")
        try:
            receipt_commit(invalid_receipt)
            failures.append("invalid JSON receipt was accepted")
        except RuntimeError:
            pass

    query = urllib.parse.urlencode({"head_sha": commit, "status": "completed", "per_page": 100})
    if f"head_sha={commit}" not in query or "status=completed" not in query:
        failures.append(f"workflow query encoding is invalid: {query}")

    print("PRODUCTION EVIDENCE COLLECTOR SELF-TEST")
    if failures:
        for failure in failures:
            print(f"FAIL {failure}")
        return 1
    print("PASS sources_configuration")
    print("PASS safe_zip_extraction")
    print("PASS traversal_rejection")
    print("PASS receipt_commit_binding")
    print("PASS exact_sha_query_encoding")
    print("SELF_TEST production_evidence_claimed=false")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", default=os.environ.get("GITHUB_REPOSITORY", ""))
    parser.add_argument("--commit", default=os.environ.get("GITHUB_SHA", ""))
    parser.add_argument("--token", default=os.environ.get("GITHUB_TOKEN", ""))
    parser.add_argument("--sources", default=str(DEFAULT_SOURCES))
    parser.add_argument("--output", default=str(DEFAULT_OUT))
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    if len(sys.argv) == 1:
        return self_test()

    repository = args.repository.strip()
    commit = args.commit.strip()
    token = args.token.strip()
    if "/" not in repository:
        raise SystemExit("repository owner/name is required")
    if len(commit) != 40 or any(ch not in "0123456789abcdefABCDEF" for ch in commit):
        raise SystemExit("exact 40-hex commit is required")
    if not token:
        raise SystemExit("GITHUB_TOKEN/actions:read is required")

    sources_path = Path(args.sources)
    if not sources_path.is_absolute():
        sources_path = ROOT / sources_path
    output = Path(args.output)
    if not output.is_absolute():
        output = ROOT / output
    output.mkdir(parents=True, exist_ok=True)
    config = json.loads(sources_path.read_text(encoding="utf-8"))

    failures: list[str] = []
    collected: list[dict[str, Any]] = []
    claimed_names: set[str] = set()

    for source in config.get("sources", []):
        source_id = str(source.get("id", ""))
        workflow = str(source.get("workflow", ""))
        prefix = str(source.get("artifact_name_prefix", ""))
        required_files = [str(name) for name in source.get("required_files", [])]
        if not source_id or not workflow or not prefix or not required_files:
            failures.append(f"invalid evidence source definition: {source!r}")
            continue
        duplicate = claimed_names.intersection(required_files)
        if duplicate:
            failures.append(f"{source_id}: duplicate required filenames across sources: {sorted(duplicate)}")
            continue
        claimed_names.update(required_files)

        try:
            run = find_successful_run(repository, workflow, commit, token)
            if not run:
                failures.append(f"{source_id}: no successful completed {workflow} run for exact SHA {commit}")
                continue
            run_id = int(run["id"])
            artifact = find_artifact(repository, run_id, prefix, commit, token)
            if not artifact:
                failures.append(f"{source_id}: expected artifact {prefix}{commit!s} not found on run {run_id}")
                continue
            artifact_id = int(artifact["id"])
            archive = request_bytes(f"{API}/repos/{repository}/actions/artifacts/{artifact_id}/zip", token)
            temp = output / f".incoming-{source_id}-{artifact_id}"
            if temp.exists():
                shutil.rmtree(temp)
            temp.mkdir(parents=True)
            extracted = safe_extract(archive, temp)
            by_name: dict[str, Path] = {}
            for path in extracted:
                name = path.name
                if name in by_name:
                    raise RuntimeError(f"artifact contains duplicate basename {name}")
                by_name[name] = path
            missing = [name for name in required_files if name not in by_name]
            if missing:
                raise RuntimeError(f"artifact missing required files: {missing}")

            for name in required_files:
                source_path = by_name[name]
                target = output / name
                if target.exists():
                    raise RuntimeError(f"refusing to overwrite existing evidence file {target}")
                if name.endswith(".json") and name != "wordpress-lifecycle-details.json":
                    bound = receipt_commit(source_path)
                    if bound and bound != commit:
                        raise RuntimeError(f"{name} commit_sha={bound!r} != exact release SHA {commit!r}")
                shutil.copy2(source_path, target)
            shutil.rmtree(temp)
            collected.append({
                "source": source_id,
                "workflow": workflow,
                "run_id": run_id,
                "run_url": run.get("html_url"),
                "artifact_id": artifact_id,
                "artifact_name": artifact.get("name"),
                "files": required_files,
            })
        except Exception as exc:
            failures.append(f"{source_id}: {type(exc).__name__}: {exc}")

    manifest = {
        "schema_version": 1,
        "repository": repository,
        "commit_sha": commit,
        "sources_file": str(sources_path),
        "collected": collected,
        "failures": failures,
    }
    manifest_path = output / "collected-evidence-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print("PRODUCTION EVIDENCE COLLECTION")
    print(f"repository={repository} commit={commit}")
    for item in collected:
        print(f"PASS {item['source']} run={item['run_id']} artifact={item['artifact_name']}")
    for failure in failures:
        print(f"FAIL {failure}")
    print(f"manifest={manifest_path}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
