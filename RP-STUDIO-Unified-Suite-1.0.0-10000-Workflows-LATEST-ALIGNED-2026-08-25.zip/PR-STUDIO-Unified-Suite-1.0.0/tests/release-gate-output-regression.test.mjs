import assert from 'node:assert/strict';
import test from 'node:test';

import { outputHasBlockingMarker, strictCompletionIsBlocked } from './validate-release.mjs';

test('incomplete and TAP-negative output is blocking without case loopholes', () => {
  for (const sample of [
    'failed after recovery',
    'SKIP dependency unavailable',
    'ToDo coverage remains',
    'state=pEnDiNg',
    'not ok 2 - contract',
    'ok 3 - conditional # sKiP dependency',
    '# todo 4',
    'ℹ skipped 1',
  ]) assert.equal(outputHasBlockingMarker(sample), true, sample);
});

test('successful TAP summaries and titles remain successful', () => {
  for (const sample of [
    'PASS invariant',
    'fail-closed policy text',
    'failure handling is enabled',
    'PASS procedural skill records failed path',
    'OK pending-url remains provisional',
    '# fail 0',
    '# skipped 0',
    'ℹ todo 0',
    'Summary: 42 passed, 0 skipped, 0 failed.',
    '"failed": 0, "skipped": [], "pending": false, "todo": null',
    '# Subtest: pending-url ownership remains provisional',
    'ok 1 - pending-url ownership remains provisional',
  ]) assert.equal(outputHasBlockingMarker(sample), false, sample);
  assert.equal(outputHasBlockingMarker('Summary: 41 passed, 1 skipped, 0 failed.'), true);
  assert.equal(outputHasBlockingMarker('PASS state=PENDING'), true);
});

test('strict completion rejects every incomplete result status', () => {
  assert.equal(strictCompletionIsBlocked({ FAIL: 0, SKIP: 1 }, [], true), true);
  assert.equal(strictCompletionIsBlocked({ FAIL: 0, SKIP: 0, TODO: 1 }, [], true), true);
  assert.equal(strictCompletionIsBlocked({ FAIL: 0, SKIP: 0, PENDING: 1 }, [], true), true);
  assert.equal(strictCompletionIsBlocked({ FAIL: 0, SKIP: 0 }, [], true), false);
  assert.equal(strictCompletionIsBlocked({ FAIL: 0, SKIP: 1 }, [], false), false);
});
