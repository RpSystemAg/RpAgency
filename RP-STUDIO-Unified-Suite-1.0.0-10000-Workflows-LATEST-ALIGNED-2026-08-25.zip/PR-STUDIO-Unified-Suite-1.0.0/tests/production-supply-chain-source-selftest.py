#!/usr/bin/env python3
"""Negative/positive fixtures for executable-download supply-chain gating."""
from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tests" / "production-supply-chain-source.py"
SPEC = importlib.util.spec_from_file_location("production_supply_chain_source", SOURCE)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)

HASH = "b" * 128
unsafe = """
jobs:
  test:
    steps:
      - run: |
          curl --fail --location https://example.invalid/tool.phar -o /tmp/tool.phar
          php /tmp/tool.phar --info
"""
unsafe_findings = MODULE.executable_download_findings(unsafe, "unsafe.yml")
assert len(unsafe_findings) == 1, unsafe_findings
assert "before a pinned checksum" in unsafe_findings[0]["reason"]

pipe_to_shell = "curl --fail https://example.invalid/install.sh | bash"
pipe_findings = MODULE.executable_download_findings(pipe_to_shell, "pipe.yml")
assert len(pipe_findings) == 1, pipe_findings
assert "piped directly" in pipe_findings[0]["reason"]

safe = f"""
jobs:
  test:
    steps:
      - run: |
          curl --fail --location https://example.invalid/tool.phar -o /tmp/tool.phar
          echo '{HASH}  /tmp/tool.phar' | sha512sum --check --strict
          php /tmp/tool.phar --info
"""
assert MODULE.executable_download_findings(safe, "safe.yml") == []

copied_unsafe = """
cp "$(command -v wp)" /tmp/wp-cli.phar
php /tmp/wp-cli.phar --info
"""
assert MODULE.executable_download_findings(copied_unsafe, "copied.yml"), "unverified provisioned PHAR was accepted"

copied_safe = f"""
cp "$(command -v wp)" /tmp/wp-cli.phar
echo '{HASH}  /tmp/wp-cli.phar' | sha512sum --check --strict
php /tmp/wp-cli.phar --info
"""
assert MODULE.executable_download_findings(copied_safe, "copied-safe.yml") == []

late_verification = f"""
curl --fail https://example.invalid/tool.phar -o /tmp/tool.phar
php /tmp/tool.phar --info
echo '{HASH}  /tmp/tool.phar' | sha512sum --check --strict
"""
assert MODULE.executable_download_findings(late_verification, "late.yml"), "verification after execution was accepted"

secret_outside_environment = """
jobs:
  unsafe:
    runs-on: ubuntu-latest
    steps:
      - run: consume '${{ secrets.PRIVATE_KEY }}'
"""
outside_findings = MODULE.workflow_secret_environment_findings(secret_outside_environment, "unsafe-secret.yml")
assert len(outside_findings) == 1, outside_findings
assert outside_findings[0]["job"] == "unsafe"

secret_in_environment = """
jobs:
  safe:
    environment: governance-attestation
    runs-on: ubuntu-latest
    steps:
      - run: consume '${{ secrets.PRIVATE_KEY }}'
"""
assert MODULE.workflow_secret_environment_findings(secret_in_environment, "safe-secret.yml") == []

comment_is_not_a_secret_consumer = """
jobs:
  safe:
    runs-on: ubuntu-latest
    # never consume ${{ secrets.PRIVATE_KEY }} here
    steps:
      - run: echo safe
"""
assert MODULE.workflow_secret_environment_findings(comment_is_not_a_secret_consumer, "comment.yml") == []

print("PRODUCTION_SUPPLY_CHAIN_SOURCE_SELFTEST: PASS")
