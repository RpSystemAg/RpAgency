<?php
declare(strict_types=1);

namespace LiteSpeed {
    // Simulates an older LiteSpeed build where the class exists without purge_all().
    final class Purge {}
}

namespace {
    define( 'ABSPATH', __DIR__ . '/' );
    define( 'PRSTUDIO_UC_TESTING', true );

    function add_action( string $hook, $callback, int $priority = 10, int $accepted_args = 1 ): void {}
    function add_filter( string $hook, $callback, int $priority = 10, int $accepted_args = 1 ): void {}
    function esc_url_raw( string $url ): string { return $url; }

    function check_integration_compat( bool $condition, string $message ): void {
        if ( ! $condition ) {
            fwrite( STDERR, "FAIL {$message}\n" );
            exit( 1 );
        }
    }

    require dirname( __DIR__ ) . '/prstudio-unified-control/includes/class-wpaib-adtribes.php';
    require dirname( __DIR__ ) . '/prstudio-unified-control/includes/class-wpaib-rest.php';
    require dirname( __DIR__ ) . '/prstudio-unified-control/includes/class-prstudio-uc-seo-intelligence.php';

    $optional_feed_call = new \ReflectionMethod( 'WPAIB_AdTribes', 'optional_feed_call' );
    $legacy_feed = new \stdClass();
    check_integration_compat(
        false === $optional_feed_call->invoke( null, $legacy_feed, 'set_data_version', array( 'feed_rules', '13.4.6' ) ),
        'older AdTribes feed without optional methods degrades without a fatal error'
    );

    $modern_feed = new class() {
        public array $calls = array();
        public function set_data_version( string $key, string $version ): void { $this->calls[] = array( $key, $version ); }
    };
    check_integration_compat(
        true === $optional_feed_call->invoke( null, $modern_feed, 'set_data_version', array( 'feed_rules', '13.4.6' ) )
        && array( array( 'feed_rules', '13.4.6' ) ) === $modern_feed->calls,
        'current AdTribes optional method is invoked with its exact arguments'
    );

    $flush_caches = new \ReflectionMethod( 'WPAIB_REST', 'flush_caches_native' );
    $cache_result = $flush_caches->invoke( null, 'flush_page_cache', array( 'urls' => array() ) );
    check_integration_compat(
        is_array( $cache_result ) && ! in_array( 'litespeed', $cache_result['providers_executed'], true ),
        'older LiteSpeed class without purge_all is skipped without a fatal error'
    );

    $source_rows = array();
    for ( $index = 0; $index < 6000; $index++ ) {
        $source_rows[] = array( 'query' => 'query-' . $index, 'clicks' => $index );
    }
    $flatten = new \ReflectionMethod( 'PRSTUDIO_UC_SEO_Intelligence', 'flatten_gsc_rows' );
    $bounded = $flatten->invoke( null, array( 'google_data' => array( 'rows' => $source_rows ) ) );
    check_integration_compat(
        is_array( $bounded ) && 5000 === count( $bounded ) && 'query-4999' === $bounded[4999]['query'],
        'SEO GSC flattening stops exactly at its 5,000-row bound'
    );

    echo "PASS optional-integration compatibility and SEO boundedness smoke: 4 assertions\n";
}
