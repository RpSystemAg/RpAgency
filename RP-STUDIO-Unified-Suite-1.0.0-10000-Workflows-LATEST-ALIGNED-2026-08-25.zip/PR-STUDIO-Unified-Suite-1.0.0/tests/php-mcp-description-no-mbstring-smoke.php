<?php
declare(strict_types=1);

define( 'PRSTUDIO_UC_TESTING', true );

function wp_json_encode( $value, int $flags = 0, int $depth = 512 ) {
    return json_encode( $value, $flags, $depth );
}

require dirname( __DIR__ ) . '/prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php';

/** @param mixed $condition */
function no_mb_check( $condition, string $message ): void {
    if ( ! $condition ) { fwrite( STDERR, "FAIL {$message}\n" ); exit( 1 ); }
    fwrite( STDOUT, "PASS {$message}\n" );
}

function no_mb_length( string $value ): int {
    $count = preg_match_all( '/./us', $value, $matches );
    if ( false === $count ) { fwrite( STDERR, "FAIL output is not valid UTF-8\n" ); exit( 1 ); }
    return $count;
}

$compact = new ReflectionMethod( PRSTUDIO_UC_MCP_V5::class, 'compact_description' );
$short = 'Analizza qualità, accessibilità e stabilità 🚀 senza perdere dettagli.';
no_mb_check( $compact->invoke( null, $short ) === $short, 'short UTF-8 description is unchanged without mbstring' );

$word_bounded = str_repeat( 'è', 170 ) . ' limite ' . str_repeat( '🚀', 30 );
$word_result = (string) $compact->invoke( null, $word_bounded );
no_mb_check( 1 === preg_match( '//u', $word_result ), 'word-bounded result remains valid UTF-8' );
no_mb_check( no_mb_length( $word_result ) <= 180, 'word-bounded result respects the 180-code-point ceiling' );
no_mb_check( str_ends_with( $word_result, '.' ), 'truncated word-bounded result has terminal punctuation' );

$unbroken = str_repeat( '漢', 220 );
$unbroken_result = (string) $compact->invoke( null, $unbroken );
no_mb_check( 1 === preg_match( '//u', $unbroken_result ), 'unbroken multibyte result is never cut inside a code point' );
no_mb_check( 180 === no_mb_length( $unbroken_result ), 'unbroken multibyte result uses the exact descriptor ceiling' );

// clean_result used to call mb_substr only when the response crossed 180 KB,
// so ordinary no-mbstring probes could never reproduce the production crash.
$clean = new ReflectionMethod( PRSTUDIO_UC_MCP_V5::class, 'clean_result' );
$large_payload = array( 'payload' => str_repeat( "é🚀漢", 25000 ) );
$cleaned = $clean->invoke( null, $large_payload );
no_mb_check( is_array( $cleaned ) && true === ( $cleaned['truncated'] ?? false ), 'oversized MCP result is truncated under php -n without mbstring' );
no_mb_check( (int) ( $cleaned['original_bytes'] ?? 0 ) > 180000, 'regression fixture exercises the real result-size branch' );
no_mb_check( is_string( $cleaned['preview'] ?? null ) && strlen( $cleaned['preview'] ) <= 160000, 'oversized preview respects its byte budget' );
no_mb_check( 1 === preg_match( '//u', (string) $cleaned['preview'] ), 'oversized preview remains valid UTF-8 at a multibyte boundary' );
no_mb_check( false !== json_encode( $cleaned, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), 'truncated MCP wrapper remains JSON serializable' );

fwrite( STDOUT, "OK MCP description portability without mbstring\n" );
