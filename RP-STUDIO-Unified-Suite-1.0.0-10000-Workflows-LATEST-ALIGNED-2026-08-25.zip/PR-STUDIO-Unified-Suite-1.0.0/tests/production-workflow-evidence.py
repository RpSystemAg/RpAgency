#!/usr/bin/env python3
"""Normalize exact-SHA GitHub Actions workflow/job results into production receipts.

A workflow conclusion alone is not sufficient. Every configured selector must
match the expected minimum number of jobs and every matched job must conclude
successfully. Receipt timestamps are inherited from the source runs so stale
workflow evidence cannot be made fresh merely by regenerating the receipt.
Collected release artifacts can additionally be required and independently
rehash-validated before becoming part of a receipt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "quality" / "production-workflow-gates.json"
OUT = ROOT / "evidence" / "production"
API = os.environ.get("GITHUB_API_URL", "https://api.github.com").rstrip("/")


def request_json(url: str, token: str) -> Any:
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "RPConnector-Workflow-Evidence/1",
        },
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.loads(response.read().decode("utf-8"))


def successful_run(repository: str, workflow: str, commit: str, token: str) -> dict[str, Any] | None:
    encoded = urllib.parse.quote(workflow, safe="")
    query = urllib.parse.urlencode({"head_sha": commit, "status": "completed", "per_page": 100})
    payload = request_json(f"{API}/repos/{repository}/actions/workflows/{encoded}/runs?{query}", token)
    runs = payload.get("workflow_runs", []) if isinstance(payload, dict) else []
    matches = [
        run for run in runs
        if run.get("head_sha") == commit
        and run.get("status") == "completed"
        and run.get("conclusion") == "success"
    ]
    matches.sort(key=lambda run: (str(run.get("updated_at", "")), int(run.get("id", 0))), reverse=True)
    return matches[0] if matches else None


def run_jobs(repository: str, run_id: int, token: str) -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []
    page = 1
    while True:
        payload = request_json(f"{API}/repos/{repository}/actions/runs/{run_id}/jobs?per_page=100&page={page}", token)
        batch = payload.get("jobs", []) if isinstance(payload, dict) else []
        jobs.extend(batch)
        if len(batch) < 100:
            break
        page += 1
        if page > 20:
            raise RuntimeError(f"run {run_id}: excessive job pagination")
    return jobs


def parse_time(value: str) -> datetime:
    value = value.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        raise ValueError("timezone missing")
    return dt.astimezone(timezone.utc)


def z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_sbom(path: Path) -> list[str]:
    errors: list[str] = []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [f"{path.name}: invalid JSON: {exc}"]
    if value.get("bomFormat") != "CycloneDX" or value.get("specVersion") != "1.6":
        errors.append(f"{path.name}: expected CycloneDX 1.6")
    components = value.get("components")
    if not isinstance(components, list) or len(components) < 3:
        errors.append(f"{path.name}: components are missing/incomplete")
        return errors
    file_components = [component for component in components if isinstance(component, dict) and component.get("type") == "file"]
    if not file_components:
        errors.append(f"{path.name}: no shipped file components")
    for component in file_components:
        hashes = component.get("hashes")
        if not isinstance(hashes, list) or not any(
            item.get("alg") == "SHA-256"
            and isinstance(item.get("content"), str)
            and len(item.get("content")) == 64
            for item in hashes if isinstance(item, dict)
        ):
            errors.append(f"{path.name}: file component {component.get('bom-ref')} lacks SHA-256")
            break
    return errors


def validate_supply_source(path: Path) -> list[str]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return [f"{path.name}: invalid JSON: {exc}"]
    checks = value.get("checks") if isinstance(value.get("checks"), dict) else {}
    errors = []
    for check_id in ("github_actions_commit_pinned", "dependencies_locked"):
        if checks.get(check_id, {}).get("ok") is not True:
            errors.append(f"{path.name}: {check_id} is not ok=true")
    return errors


def parse_checksum_manifest(path: Path) -> tuple[dict[str, str], list[str]]:
    entries: dict[str, str] = {}
    errors: list[str] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{64})\s+[* ]?(.+)", line.strip())
        if not match:
            errors.append(f"{path.name}:{line_no}: invalid sha256sum line")
            continue
        digest = match.group(1).lower()
        name = Path(match.group(2).strip()).name
        if name in entries and entries[name] != digest:
            errors.append(f"{path.name}:{line_no}: duplicate conflicting checksum for {name}")
        entries[name] = digest
    return entries, errors


def validate_local_artifacts(gate: dict[str, Any]) -> tuple[list[dict[str, str]], list[str], dict[str, Any]]:
    required = [str(name) for name in gate.get("required_local_artifacts", [])]
    artifacts: list[dict[str, str]] = []
    errors: list[str] = []
    details: dict[str, Any] = {"required": required, "files": {}}
    for name in required:
        path = OUT / name
        if not path.is_file():
            errors.append(f"required collected artifact missing: {name}")
            details["files"][name] = {"exists": False}
            continue
        digest = sha256(path)
        artifacts.append({"path": str(path.relative_to(ROOT)), "sha256": digest})
        details["files"][name] = {"exists": True, "bytes": path.stat().st_size, "sha256": digest}
        if name == "sbom.cdx.json":
            sbom_errors = validate_sbom(path)
            errors.extend(sbom_errors)
            details["files"][name]["validation_errors"] = sbom_errors
        elif name == "supply-chain-source.json":
            source_errors = validate_supply_source(path)
            errors.extend(source_errors)
            details["files"][name]["validation_errors"] = source_errors

    checksum_name = str(gate.get("checksum_manifest", "")).strip()
    if checksum_name:
        checksum_path = OUT / checksum_name
        if not checksum_path.is_file():
            errors.append(f"checksum manifest missing: {checksum_name}")
        else:
            entries, checksum_errors = parse_checksum_manifest(checksum_path)
            errors.extend(checksum_errors)
            verification: dict[str, Any] = {}
            for name in required:
                if name == checksum_name:
                    continue
                path = OUT / name
                expected = entries.get(name)
                actual = sha256(path) if path.is_file() else None
                ok = bool(expected and actual and expected == actual)
                verification[name] = {"expected": expected, "actual": actual, "ok": ok}
                if not ok:
                    errors.append(f"checksum manifest does not verify collected artifact {name}")
            details["checksum_verification"] = verification
    return artifacts, errors, details


def full_surface_self_test() -> int:
    digest = "a" * 64
    with tempfile.TemporaryDirectory(prefix="prstudio-workflow-selftest-") as raw:
        directory = Path(raw)
        sbom = directory / "sbom.cdx.json"
        sbom.write_text(json.dumps({
            "bomFormat": "CycloneDX",
            "specVersion": "1.6",
            "components": [
                {"type": "file", "bom-ref": "file:a", "hashes": [{"alg": "SHA-256", "content": digest}]},
                {"type": "library", "bom-ref": "library:b"},
                {"type": "application", "bom-ref": "application:c"},
            ],
        }), encoding="utf-8")
        if validate_sbom(sbom):
            raise RuntimeError("valid CycloneDX evidence was rejected")
        source = directory / "supply-chain-source.json"
        source.write_text(json.dumps({"checks": {
            "github_actions_commit_pinned": {"ok": True},
            "dependencies_locked": {"ok": True},
        }}), encoding="utf-8")
        if validate_supply_source(source):
            raise RuntimeError("valid supply-chain source evidence was rejected")
        sums = directory / "SHA256SUMS"
        sums.write_text(f"{digest}  artifact.zip\n", encoding="utf-8")
        entries, errors = parse_checksum_manifest(sums)
        if errors or entries.get("artifact.zip") != digest:
            raise RuntimeError("checksum manifest parser rejected a valid record")
        sums.write_text(f"{digest}  artifact.zip\n{'b' * 64}  artifact.zip\n", encoding="utf-8")
        _, conflicting = parse_checksum_manifest(sums)
        if not conflicting:
            raise RuntimeError("checksum manifest parser accepted a conflicting duplicate")
    print("PASS production workflow evidence internal self-test")
    return 0


def main() -> int:
    if os.environ.get("PRSTUDIO_FULL_SURFACE_EXECUTION") == "1" and len(sys.argv) == 1:
        return full_surface_self_test()
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", default=os.environ.get("GITHUB_REPOSITORY", ""))
    parser.add_argument("--commit", default=os.environ.get("GITHUB_SHA", ""))
    parser.add_argument("--token", default=os.environ.get("GITHUB_TOKEN", ""))
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    repository = args.repository.strip()
    commit = args.commit.strip()
    token = args.token.strip()
    if "/" not in repository:
        raise SystemExit("repository owner/name is required")
    if len(commit) != 40 or any(ch not in "0123456789abcdefABCDEF" for ch in commit):
        raise SystemExit("exact 40-hex commit is required")
    if not token:
        raise SystemExit("GITHUB_TOKEN/actions:read is required")

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = ROOT / config_path
    config = json.loads(config_path.read_text(encoding="utf-8"))
    OUT.mkdir(parents=True, exist_ok=True)

    run_cache: dict[str, tuple[dict[str, Any] | None, list[dict[str, Any]]]] = {}
    global_failures: list[str] = []

    def load_workflow(workflow: str) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
        if workflow in run_cache:
            return run_cache[workflow]
        run = successful_run(repository, workflow, commit, token)
        jobs = run_jobs(repository, int(run["id"]), token) if run else []
        run_cache[workflow] = (run, jobs)
        return run, jobs

    for gate_id, gate in config.get("gates", {}).items():
        receipt_name = str(gate.get("receipt", f"{gate_id.replace('_', '-')}.json"))
        checks: list[dict[str, Any]] = []
        gate_runs: dict[int, dict[str, Any]] = {}
        gate_errors: list[str] = []

        for check_id, check_definition in gate.get("checks", {}).items():
            requirements = check_definition.get("requirements", [])
            requirement_evidence: list[dict[str, Any]] = []
            check_ok = bool(requirements)
            if not requirements:
                check_ok = False
                gate_errors.append(f"{gate_id}.{check_id}: no requirements configured")

            for requirement in requirements:
                workflow = str(requirement.get("workflow", ""))
                pattern_text = str(requirement.get("job_regex", ""))
                min_count = int(requirement.get("min_count", 1))
                try:
                    pattern = re.compile(pattern_text)
                except re.error as exc:
                    check_ok = False
                    gate_errors.append(f"{gate_id}.{check_id}: invalid regex {pattern_text!r}: {exc}")
                    continue

                run, jobs = load_workflow(workflow)
                if not run:
                    check_ok = False
                    requirement_evidence.append({
                        "workflow": workflow,
                        "job_regex": pattern_text,
                        "min_count": min_count,
                        "run": None,
                        "matched_jobs": [],
                        "error": f"no successful completed run for exact SHA {commit}",
                    })
                    continue

                run_id = int(run["id"])
                gate_runs[run_id] = run
                matched = [job for job in jobs if pattern.search(str(job.get("name", "")))]
                successful = [job for job in matched if job.get("status") == "completed" and job.get("conclusion") == "success"]
                cardinality_ok = len(matched) >= min_count
                all_matches_success = bool(matched) and len(successful) == len(matched)
                requirement_ok = cardinality_ok and all_matches_success
                check_ok = check_ok and requirement_ok
                if not requirement_ok:
                    gate_errors.append(
                        f"{gate_id}.{check_id}: {workflow} / {pattern_text!r} matched={len(matched)} "
                        f"success={len(successful)} required>={min_count}"
                    )
                requirement_evidence.append({
                    "workflow": workflow,
                    "run_id": run_id,
                    "run_url": run.get("html_url"),
                    "run_created_at": run.get("created_at"),
                    "run_updated_at": run.get("updated_at"),
                    "head_sha": run.get("head_sha"),
                    "job_regex": pattern_text,
                    "min_count": min_count,
                    "matched_count": len(matched),
                    "successful_count": len(successful),
                    "matched_jobs": [
                        {
                            "id": job.get("id"),
                            "name": job.get("name"),
                            "status": job.get("status"),
                            "conclusion": job.get("conclusion"),
                            "started_at": job.get("started_at"),
                            "completed_at": job.get("completed_at"),
                            "url": job.get("html_url"),
                        }
                        for job in matched
                    ],
                })
            checks.append({"id": check_id, "ok": check_ok, "evidence": requirement_evidence})

        local_artifacts, artifact_errors, artifact_details = validate_local_artifacts(gate)
        gate_errors.extend(artifact_errors)

        run_values = list(gate_runs.values())
        starts: list[datetime] = []
        finishes: list[datetime] = []
        for run in run_values:
            try:
                starts.append(parse_time(str(run.get("created_at", ""))))
                finishes.append(parse_time(str(run.get("updated_at", ""))))
            except Exception as exc:
                gate_errors.append(f"run {run.get('id')}: invalid timestamps: {exc}")

        started_at = z(min(starts)) if starts else "1970-01-01T00:00:00Z"
        finished_at = z(max(finishes)) if finishes else "1970-01-01T00:00:00Z"
        gate_ok = bool(checks) and not gate_errors and all(check.get("ok") is True for check in checks)

        detail = {
            "schema_version": 1,
            "gate_id": gate_id,
            "repository": repository,
            "commit_sha": commit,
            "workflow_runs": [
                {
                    "id": run.get("id"),
                    "name": run.get("name"),
                    "workflow_id": run.get("workflow_id"),
                    "event": run.get("event"),
                    "head_sha": run.get("head_sha"),
                    "status": run.get("status"),
                    "conclusion": run.get("conclusion"),
                    "created_at": run.get("created_at"),
                    "updated_at": run.get("updated_at"),
                    "url": run.get("html_url"),
                }
                for run in run_values
            ],
            "checks": checks,
            "local_artifact_validation": artifact_details,
            "errors": gate_errors,
        }
        detail_path = OUT / f"{gate_id.replace('_', '-')}-workflow-details.json"
        detail_path.write_text(json.dumps(detail, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        receipt_artifacts = [{"path": str(detail_path.relative_to(ROOT)), "sha256": sha256(detail_path)}, *local_artifacts]
        receipt = {
            "schema_version": 1,
            "gate_id": gate_id,
            "commit_sha": commit,
            "ok": gate_ok,
            "started_at": started_at,
            "finished_at": finished_at,
            "environment": gate.get("environment", {"real": False, "class": "github-actions"}),
            "checks": checks,
            "artifacts": receipt_artifacts,
            "waivers": [],
            "skipped": [],
            "errors": gate_errors,
        }
        receipt_path = OUT / receipt_name
        receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        print(f"{gate_id}: ok={str(gate_ok).lower()} receipt={receipt_path.relative_to(ROOT)}")
        for check in checks:
            print(f"  {'PASS' if check['ok'] else 'FAIL'} {check['id']}")
        for error in gate_errors:
            print(f"  FAIL {error}")
        if not gate_ok:
            global_failures.append(gate_id)

    return 1 if args.strict and global_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
