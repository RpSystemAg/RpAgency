#!/usr/bin/env python3
"""Prove declared required checks exist and are enforced by GitHub.

Authority is live GitHub state by default. A local/offline run may use the
explicit ``PRSTUDIO_GOVERNANCE_FIXTURE`` JSON input; GitHub Actions may not use
that escape hatch and fails when the live authority cannot be read.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
WORKFLOWS = ROOT / ".github" / "workflows"
DECLARED = Path(__file__).resolve().parent / "required-checks.json"
REPO = os.environ.get("GITHUB_REPOSITORY", "RpSystemAg/RpConnector")
FIXTURE_ENV = "PRSTUDIO_GOVERNANCE_FIXTURE"


def matrix_legs(job: dict[str, Any], label: str) -> list[str]:
    import itertools

    matrix = ((job.get("strategy") or {}).get("matrix") or {})
    if not isinstance(matrix, dict):
        return [label]
    axes = {
        key: value for key, value in matrix.items()
        if key not in {"include", "exclude"}
        and isinstance(value, list)
        and all(isinstance(item, (str, int, float, bool)) for item in value)
    }
    combinations = [dict(zip(axes.keys(), combo)) for combo in itertools.product(*axes.values())] if axes else []
    for included in matrix.get("include") or []:
        if isinstance(included, dict) and all(isinstance(value, (str, int, float, bool)) for value in included.values()):
            combinations.append(included)
    if not combinations:
        return [label]
    output: list[str] = []
    for combo in combinations:
        rendered = label
        for key, value in combo.items():
            rendered = re.sub(r"\$\{\{\s*matrix\." + re.escape(key) + r"\s*\}\}", str(value), rendered)
        if "${{" not in rendered and rendered not in output:
            output.append(rendered)
    return output or [label]


def workflow_jobs() -> tuple[dict[str, str], set[str]]:
    try:
        import yaml
    except ImportError as exc:
        raise SystemExit(f"FAIL PyYAML is required for workflow-name validation: {exc}")

    workflow_files = sorted(WORKFLOWS.glob("*.yml")) + sorted(WORKFLOWS.glob("*.yaml"))
    if workflow_files != [WORKFLOWS / "unified-h24-control.yml"]:
        raise SystemExit("FAIL exactly one unified-h24-control.yml workflow is required")
    names: dict[str, str] = {}
    dynamic: set[str] = set()
    for path in workflow_files:
        try:
            document = yaml.safe_load(path.read_text(encoding="utf-8", errors="strict"))
        except (UnicodeError, yaml.YAMLError) as exc:
            raise SystemExit(f"FAIL {path.name} does not parse: {exc}") from exc
        if not isinstance(document, dict) or not isinstance(document.get("jobs"), dict):
            raise SystemExit(f"FAIL {path.name} has no jobs mapping")
        for job_id, job in document["jobs"].items():
            label = job.get("name", job_id) if isinstance(job, dict) else job_id
            if not isinstance(label, str) or not label.strip():
                raise SystemExit(f"FAIL {path.name}:{job_id} has an invalid rendered name")
            # U+0008 in the previous regex silently replaced the intended word
            # boundary. Keep this ASCII source and match github.* correctly.
            if re.search(r"\$\{\{[^}]*\bgithub\.", label):
                dynamic.add(f"{path.name}:{job_id} -> {label}")
                continue
            if "${{" in label:
                legs = matrix_legs(job, label)
                if any("${{" in leg for leg in legs):
                    dynamic.add(f"{path.name}:{job_id} -> {label}")
                    continue
                for leg in legs:
                    names[leg] = path.name
                continue
            names[label] = path.name
    return names, dynamic


def declared_contexts() -> list[str]:
    try:
        payload = json.loads(DECLARED.read_text(encoding="utf-8", errors="strict"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read {DECLARED.name}: {exc}") from exc
    required = payload.get("required") if isinstance(payload, dict) else None
    if not isinstance(required, list) or not required:
        raise ValueError("required must be a non-empty array")
    if any(not isinstance(item, str) or not item.strip() for item in required):
        raise ValueError("required entries must be non-empty strings")
    if len(required) != len(set(required)):
        raise ValueError("required entries must be unique")
    return required


def _gh_json(endpoint: str) -> Any:
    env = os.environ.copy()
    if env.get("GITHUB_TOKEN") and not env.get("GH_TOKEN"):
        env["GH_TOKEN"] = env["GITHUB_TOKEN"]
    run = subprocess.run(["gh", "api", endpoint], cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
    if run.returncode != 0:
        raise RuntimeError(run.stderr.strip() or f"gh api {endpoint} exited {run.returncode}")
    return json.loads(run.stdout)


def load_authority() -> dict[str, Any]:
    fixture = os.environ.get(FIXTURE_ENV, "").strip()
    if fixture:
        if os.environ.get("GITHUB_ACTIONS", "").lower() == "true":
            raise RuntimeError(f"{FIXTURE_ENV} is forbidden in GitHub Actions")
        path = Path(fixture)
        if not path.is_absolute():
            path = ROOT / path
        try:
            payload = json.loads(path.read_text(encoding="utf-8", errors="strict"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"invalid governance fixture {path}: {exc}") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("repository"), dict) or not isinstance(payload.get("rulesets"), list):
            raise RuntimeError("governance fixture must contain repository and rulesets")
        return payload

    repository = _gh_json(f"repos/{REPO}")
    summaries = _gh_json(f"repos/{REPO}/rulesets?includes_parents=true")
    if not isinstance(summaries, list):
        raise RuntimeError("ruleset authority returned a non-list")
    details = [_gh_json(f"repos/{REPO}/rulesets/{item['id']}?includes_parents=true") for item in summaries if isinstance(item, dict) and item.get("id")]
    return {"repository": repository, "rulesets": details}


def enforced_contexts(authority: dict[str, Any]) -> set[str]:
    default_branch = authority.get("repository", {}).get("default_branch")
    if not isinstance(default_branch, str) or not default_branch:
        raise ValueError("authority has no default_branch")
    contexts: set[str] = set()
    applicable = 0
    for ruleset in authority.get("rulesets", []):
        if not isinstance(ruleset, dict) or ruleset.get("target") != "branch" or ruleset.get("enforcement") != "active":
            continue
        ref_names = (ruleset.get("conditions") or {}).get("ref_name") or {}
        includes = ref_names.get("include") or []
        excludes = ref_names.get("exclude") or []
        if "~DEFAULT_BRANCH" not in includes or "~DEFAULT_BRANCH" in excludes or f"refs/heads/{default_branch}" in excludes:
            continue
        applicable += 1
        for rule in ruleset.get("rules") or []:
            if isinstance(rule, dict) and rule.get("type") == "required_status_checks":
                for check in (rule.get("parameters") or {}).get("required_status_checks") or []:
                    context = check.get("context") if isinstance(check, dict) else None
                    if isinstance(context, str) and context:
                        contexts.add(context)
    if applicable == 0:
        raise ValueError("no active branch ruleset applies through ~DEFAULT_BRANCH")
    return contexts


def main() -> int:
    problems: list[str] = []
    try:
        declared = declared_contexts()
    except ValueError as exc:
        print(f"FAIL {exc}", file=sys.stderr)
        return 1

    names, dynamic = workflow_jobs()
    if dynamic:
        problems.extend(f"dynamic job name cannot be required safely: {entry}" for entry in sorted(dynamic))
    for context in declared:
        if context not in names:
            problems.append(f"required check {context!r} matches no static workflow job")

    try:
        live = enforced_contexts(load_authority())
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        problems.append(f"live governance authority unavailable or invalid: {exc}")
        live = set()
    missing = sorted(set(declared) - live)
    extra = sorted(live - set(declared))
    if missing:
        problems.append(f"declared but not enforced on ~DEFAULT_BRANCH: {', '.join(missing)}")
    if extra:
        problems.append(f"enforced but not declared: {', '.join(extra)}")

    print(f"REQUIRED CHECKS: declared={len(declared)} enforced={len(live)} static_jobs={len(names)}")
    for problem in problems:
        print(f"FAIL {problem}", file=sys.stderr)
    if problems:
        return 1
    print("required checks are exact and live-enforced")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
