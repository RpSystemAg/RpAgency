#!/usr/bin/env python3
import json, pathlib, re, sys
from ruamel.yaml import YAML
R=pathlib.Path(__file__).resolve().parents[1]
workflow_dir=R/'.github/workflows'
files=sorted(list(workflow_dir.glob('*.yml'))+list(workflow_dir.glob('*.yaml')))
errors=[]
if len(files)!=1 or files[0].name!='unified-h24-control.yml': errors.append(f'exactly one authoritative workflow required, found {[p.name for p in files]}')
mp=json.load(open(R/'quality/github-workflow-consolidation-map.json'))
if mp.get('historical_workflow_count')!=35 or len(mp.get('historical_to_current_jobs',{}))!=35: errors.append('historical workflow map must contain exactly 35 workflows')
y=YAML(typ='safe'); doc=y.load(files[0].read_text()) if files else {}; jobs=set((doc or {}).get('jobs',{}))
for historical,mapped in mp.get('historical_to_current_jobs',{}).items():
    if not mapped: errors.append(f'{historical}: no consolidated job mapping')
    for job in mapped:
        if job not in jobs: errors.append(f'{historical}: mapped job missing: {job}')
raw=files[0].read_text() if files else ''
for legacy in mp.get('historical_to_current_jobs',{}):
    # Historical filenames may appear only in provenance docs/map, never as signer/runtime workflow paths inside YAML.
    if legacy!='unified-h24-control.yml' and f'/.github/workflows/{legacy}' in raw: errors.append(f'legacy signer/provider path remains in unified YAML: {legacy}')
if 'actions/attest-build-provenance@' not in raw: errors.append('artifact attestation job missing from consolidated workflow')
if 'OWASP ZAP full active scan' not in raw: errors.append('historical DAST gate not consolidated')
if 'Toxiproxy 2.12.0' not in raw: errors.append('historical network-chaos gate not consolidated')
if 'WordPress Plugin Check (blocking)' not in raw: errors.append('historical WordPress Plugin Check gate not consolidated')
if errors:
 print('FAIL github workflow consolidation')
 for e in errors: print(' -',e)
 sys.exit(1)
print(f'PASS: one GitHub Actions workflow; historical workflows mapped=35; consolidated jobs={len(jobs)}')
