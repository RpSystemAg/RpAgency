<?php
declare(strict_types=1);
define('PRSTUDIO_UC_TESTING', true);
final class WP_Error { public function __construct(private string $code='',private string $message='',private $data=null){} public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} public function get_error_data(){return $this->data;} }
function is_wp_error($v){return $v instanceof WP_Error;}
function sanitize_key($v){return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v));}
function sanitize_text_field($v){return trim((string)$v);}
function esc_url_raw($v){return (string)$v;}
function wp_json_encode($v,$f=0){return json_encode($v,$f);}
final class PRSTUDIO_UC_MCP_Auth_V5 {
    public static int $writeChecks=0;
    public static function bearer_token_from_request(){return 'fixture-token';}
    public static function verify_access_token($token,$write){if($write)self::$writeChecks++;return ['client_id'=>'fixture'];}
}
final class PRSTUDIO_UC_Schema_Validator { public static function validate($args,$schema){return [];} }
final class PRSTUDIO_UC_Execution_Router {
    public static function annotate_capability($cap){$cap['supports_flow']=true;return $cap;}
    public static function tool_contract($tool,$ann){return ['can_execute_inline'=>true];}
}
final class PRSTUDIO_UC_Capability_Registry {
    public static function get($id){
        $write=str_contains($id,'write');
        return ['id'=>$id,'read_only'=>!$write,'input_schema'=>['type'=>'object'],'supports_flow'=>true,'domain'=>$write?'content_seo':'operations'];
    }
}
final class PRSTUDIO_UC_Pre_Mutation_Safety {
    public static int $begins=0,$ends=0,$directChecks=0;
    public static function scope_for_capability($cap){return empty($cap['read_only'])?'content':'none';}
    public static function scope_for_direct_tool($tool,$args=[]){return 'wordpress';}
    public static function flow_scope_for($scopes){return $scopes?reset($scopes):'none';}
    public static function begin_flow($scope,$tool,$args=[]){self::$begins++;return ['ok'=>true,'scope'=>$scope];}
    public static function end_flow(){self::$ends++;}
    public static function before_commit($scope,$tool,$args=[]){self::$directChecks++;return true;}
}
final class PRSTUDIO_UC_Execution_Gateway {
    public static int $calls=0;
    public static array $requests=[];
    public static function execute($req){self::$calls++;self::$requests[]=$req;return ['capability'=>$req['capability'],'value'=>$req['arguments']['value']??self::$calls];}
}
final class PRSTUDIO_UC_Execution_Lanes {
    public static array $ensureCalls=[];
    public static function ensure_runtime_lane($args,$context=[]){
        self::$ensureCalls[]=['args'=>$args,'context'=>$context];
        $credential=(string)($args['lane_handle']??$args['lane_token']??'');
        $lane=$credential!==''?$credential:'lane_'.str_repeat('c',32);
        return ['ok'=>true,'lane_id'=>$lane,'lane_handle'=>$lane,'mission_id'=>'mission:test','auto_bootstrapped'=>$credential===''];
    }
    public static function resolve($credential,$owner=''){return $credential===''?null:['lane_id'=>(string)$credential,'mission_id'=>'mission:test'];}
}
final class PRSTUDIO_UC_Bridge {
    public static array $calls=[];
    public static function dispatch($device,$args,$meta){self::$calls[]=['device'=>$device,'args'=>$args,'meta'=>$meta];return ['ok'=>true,'task_id'=>str_repeat('b',32)];}
}
final class PRSTUDIO_UC_Contract {
    public static function by_action($route,$action){return ['action'=>$action,'executor'=>'browser_agent'];}
}
require dirname(__DIR__).'/prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php';
function ok($c,$m){if(!$c){fwrite(STDERR,"FAIL $m\n");exit(1);}fwrite(STDOUT,"PASS $m\n");}
$method=new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class,'execute_flow');$method->setAccessible(true);
$auth=['client_id'=>'fixture'];
$read=$method->invoke(null,['steps'=>[
 ['capability'=>'fixture.read.one','arguments'=>['value'=>1],'save_as'=>'first'],
 ['capability'=>'fixture.read.two','arguments'=>['value'=>'${first.value}','_prstudio_lane_id'=>'lane_attacker','lane_token'=>'lane_attacker','_client_id'=>'attacker']],
],'_prstudio_lane_id'=>'lane_trusted','lane_token'=>'lane_trusted','_client_id'=>'fixture','_prstudio_correlation_id'=>'corr_fixture'],$auth);
ok(!is_wp_error($read)&&($read['ok']??false)===true,'read-only flow completes');
ok(PRSTUDIO_UC_Pre_Mutation_Safety::$begins===0&&PRSTUDIO_UC_MCP_Auth_V5::$writeChecks===0,'read-only flow bypasses anti-crash and write auth');
ok(($read['execution']['tool_calls']??0)===1&&($read['execution']['model_roundtrips_avoided']??0)===1,'two deterministic steps report one MCP call and one avoided model round-trip');
ok(($read['results'][1]['result']['value']??null)===1,'saved flow result resolves locally into later arguments');
$laneReq=PRSTUDIO_UC_Execution_Gateway::$requests[1]??[];
ok(($laneReq['lane_token']??'')==='lane_trusted'&&($laneReq['arguments']['_prstudio_lane_id']??'')==='lane_trusted'&&($laneReq['arguments']['_client_id']??'')==='fixture','flow overrides nested lane spoofing with OAuth-resolved lane context');
PRSTUDIO_UC_Pre_Mutation_Safety::$begins=PRSTUDIO_UC_Pre_Mutation_Safety::$ends=0;PRSTUDIO_UC_MCP_Auth_V5::$writeChecks=0;PRSTUDIO_UC_Execution_Gateway::$calls=0;PRSTUDIO_UC_Execution_Gateway::$requests=[];
$write=$method->invoke(null,['steps'=>[
 ['capability'=>'fixture.read.one','arguments'=>['value'=>1]],
 ['capability'=>'fixture.write.one','arguments'=>['value'=>2]],
 ['capability'=>'fixture.write.two','arguments'=>['value'=>3]],
]],$auth);
ok(!is_wp_error($write)&&($write['ok']??false)===true,'mixed write flow completes');
ok(PRSTUDIO_UC_Pre_Mutation_Safety::$begins===1&&PRSTUDIO_UC_Pre_Mutation_Safety::$ends===1,'mixed write flow enters existing anti-crash flow exactly once');
ok(PRSTUDIO_UC_MCP_Auth_V5::$writeChecks===1,'mixed write flow checks write authorization once');
ok(($write['execution']['tool_calls']??0)===1&&($write['execution']['model_roundtrips_avoided']??0)===2,'three deterministic steps report one MCP call and two avoided model round-trips');

$callTool=new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class,'call_tool');$callTool->setAccessible(true);
$searchConsoleUrl='https://search.google.com/search-console/performance/search-analytics?resource_id=sc-domain%3Aexample.test';
$firstAttempt=$callTool->invoke(null,'browser_open',['url'=>$searchConsoleUrl,'_prstudio_correlation_id'=>'corr_first_attempt'],$auth);
$firstAttemptCall=PRSTUDIO_UC_Bridge::$calls[count(PRSTUDIO_UC_Bridge::$calls)-1]??[];
$firstEnsure=PRSTUDIO_UC_Execution_Lanes::$ensureCalls[0]??[];
ok(!is_wp_error($firstAttempt)&&($firstAttemptCall['meta']['action']??'')==='playwright_new_page'&&($firstAttemptCall['args']['url']??'')===$searchConsoleUrl,'first Search Console browser_open reaches the real bridge without a prior context_open call');
ok(($firstEnsure['args']['lane_handle']??'')===''&&($firstEnsure['args']['lane_token']??'')===''&&($firstEnsure['context']['tool']??'')==='browser_open','first stateful call invokes server-side lane bootstrap instead of trusting model orchestration');
ok(($firstAttemptCall['args']['_prstudio_lane_id']??'')==='lane_'.str_repeat('c',32)&&($firstAttemptCall['args']['lane_token']??'')==='lane_'.str_repeat('c',32)&&($firstAttemptCall['args']['_client_id']??'')==='fixture','auto-bootstrapped OAuth-bound lane is injected before the first Browser Agent dispatch');

$batch=$callTool->invoke(null,'browser_batch',['steps'=>[['type'=>'click','selector'=>'#save']],'tab_id'=>7,'_prstudio_lane_id'=>'lane_trusted','lane_token'=>'lane_trusted','_client_id'=>'fixture','_prstudio_correlation_id'=>'corr_batch'],$auth);
$batchCall=PRSTUDIO_UC_Bridge::$calls[count(PRSTUDIO_UC_Bridge::$calls)-1]??[];
ok(!is_wp_error($batch)&&($batchCall['meta']['action']??'')==='playwright_flow'&&($batchCall['args']['_prstudio_lane_id']??'')==='lane_trusted'&&($batchCall['args']['lane_token']??'')==='lane_trusted','browser_batch preserves the trusted lane through bridge dispatch');

$advanced=$callTool->invoke(null,'browser_action',['action'=>'playwright_click','arguments'=>['selector'=>'#delete','_prstudio_lane_id'=>'lane_attacker','lane_token'=>'lane_attacker','_client_id'=>'attacker'],'_prstudio_lane_id'=>'lane_trusted','lane_token'=>'lane_trusted','_client_id'=>'fixture','_prstudio_correlation_id'=>'corr_action'],$auth);
$advancedCall=PRSTUDIO_UC_Bridge::$calls[count(PRSTUDIO_UC_Bridge::$calls)-1]??[];
ok(!is_wp_error($advanced)&&($advancedCall['meta']['action']??'')==='playwright_click'&&($advancedCall['args']['_prstudio_lane_id']??'')==='lane_trusted'&&($advancedCall['args']['lane_token']??'')==='lane_trusted'&&($advancedCall['args']['_client_id']??'')==='fixture','browser_action rejects nested lane spoofing by overwriting it with trusted context');
fwrite(STDOUT,"OK prstudio_flow deterministic composition smoke\n");
