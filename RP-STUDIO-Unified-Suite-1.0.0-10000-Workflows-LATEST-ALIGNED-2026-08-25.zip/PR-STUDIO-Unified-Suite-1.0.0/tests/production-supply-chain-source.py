#!/usr/bin/env python3
"""Fail-closed source audit for release/build dependencies.

Checks package-manager lock coverage, immutable GitHub Actions, immutable Docker
image references and obviously floating tool/dependency specifications. This is
not a vulnerability scanner; it proves that the inputs intended to be scanned
and built are reproducibly selected.
"""
from __future__ import annotations

import argparse
import json
import re
import shlex
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"
FULL_SHA = re.compile(r"^[0-9a-f]{40}$", re.I)
DOCKER_IMAGE = re.compile(r"(?<![A-Za-z0-9_.-])((?:mariadb|mysql|postgres|redis|node|python|php|wordpress|ubuntu|alpine):[^\s'\"}\],]+)", re.I)
USES = re.compile(r"^\s*-?\s*uses:\s*([^\s#]+)", re.M)
JOB_HEADER = re.compile(r"(?m)^  ([A-Za-z0-9_-]+):\s*$")
SECRET_REFERENCE = re.compile(r"\$\{\{\s*secrets\.[A-Za-z0-9_]+\s*\}\}")
FLOATING = re.compile(r"(?:@latest\b|:\s*latest\b|\b(?:pip|pip3)\s+install\s+[^\n]*\b(?:--pre\b|-[Uu]\b)|\bnpm\s+(?:install|i)\s+[^\n]*@latest\b)", re.I)
COMPOSER_REQUIRE = re.compile(r"composer\s+(?:global\s+)?require[^\n\\]*(.*)", re.I)
EXECUTABLE_DOWNLOAD_SUFFIXES = (".phar", ".sh", ".bash", ".py", ".pl", ".rb", ".jar", ".bin", ".exe", ".run")

MANIFEST_LOCKS = {
    "composer.json": ["composer.lock"],
    "package.json": ["package-lock.json", "npm-shrinkwrap.json", "pnpm-lock.yaml", "yarn.lock"],
    "pyproject.toml": ["uv.lock", "poetry.lock", "pdm.lock"],
    "Pipfile": ["Pipfile.lock"],
}
DEPENDABOT = ROOT / ".github" / "dependabot.yml"


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace("\\", "/")


def package_lock_findings() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    manifests: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    ignored = {"vendor", "node_modules", ".git", "dist", "evidence"}
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in ignored for part in path.parts):
            continue
        name = path.name
        if name in MANIFEST_LOCKS:
            locks = [path.parent / candidate for candidate in MANIFEST_LOCKS[name]]
            present = [candidate for candidate in locks if candidate.is_file()]
            manifests.append({"manifest": rel(path), "locks": [rel(p) for p in present]})
            if not present:
                findings.append({"file": rel(path), "reason": "package-manager manifest has no recognized lock file"})
        elif name.startswith("requirements") and name.endswith(".txt"):
            unpinned = []
            for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                value = line.split("#", 1)[0].strip()
                if not value or value.startswith(("-r", "--requirement", "--index-url", "--extra-index-url")):
                    continue
                if "==" not in value or any(op in value for op in (">=", "<=", "~=", "!=", "<", ">")):
                    unpinned.append({"line": line_no, "value": value})
            manifests.append({"manifest": rel(path), "requirements": True})
            if unpinned:
                findings.append({"file": rel(path), "reason": "requirements contain non-exact versions", "entries": unpinned})
    return manifests, findings


def dependabot_cooldown_findings() -> list[dict[str, Any]]:
    """Require an explicit seven-day stability window for every ecosystem.

    Security updates are not delayed by Dependabot cooldowns. This gate covers
    ordinary version churn and mirrors zizmor's dependabot-cooldown audit
    without depending on a locally installed YAML package.
    """
    if not DEPENDABOT.is_file():
        return [{"file": rel(DEPENDABOT), "reason": "Dependabot configuration is missing"}]
    text = DEPENDABOT.read_text(encoding="utf-8", errors="replace")
    blocks = re.findall(
        r"(?ms)^  - package-ecosystem:\s*([^\n#]+).*?(?=^  - package-ecosystem:|\Z)",
        text,
    )
    full_blocks = re.findall(
        r"(?ms)^  - package-ecosystem:\s*[^\n#]+.*?(?=^  - package-ecosystem:|\Z)",
        text,
    )
    if not blocks or len(blocks) != len(full_blocks):
        return [{"file": rel(DEPENDABOT), "reason": "Dependabot ecosystem entries are not auditable"}]
    findings: list[dict[str, Any]] = []
    for ecosystem, block in zip(blocks, full_blocks):
        match = re.search(r"(?m)^    cooldown:\s*\n      default-days:\s*(\d+)\s*$", block)
        days = int(match.group(1)) if match else 0
        if days < 7 or days > 90:
            findings.append({
                "file": rel(DEPENDABOT),
                "ecosystem": ecosystem.strip().strip("'\""),
                "default_days": days,
                "reason": "explicit Dependabot cooldown must be between 7 and 90 days",
            })
    return findings


def workflow_secret_environment_findings(text: str, file_name: str) -> list[dict[str, Any]]:
    """Reject every Actions secret reference outside a named Environment.

    This deliberately audits the workflow source without requiring PyYAML: it
    runs before any dependency installation in the workflow-security job. Job
    boundaries and environment declarations have fixed YAML indentation in a
    GitHub Actions document, while comment-only lines are excluded so prose
    cannot create either a finding or a false-green Environment.
    """
    effective = "\n".join(
        "" if line.lstrip().startswith("#") else line
        for line in text.splitlines()
    )
    headers = list(JOB_HEADER.finditer(effective))
    findings: list[dict[str, Any]] = []
    for index, header in enumerate(headers):
        end = headers[index + 1].start() if index + 1 < len(headers) else len(effective)
        block = effective[header.end():end]
        references = list(SECRET_REFERENCE.finditer(block))
        if not references:
            continue
        environment = re.search(r"(?m)^    environment:\s*([^#\n]*)$", block)
        environment_name = environment.group(1).strip().strip("'\"") if environment else ""
        if not environment_name and environment:
            nested = re.search(r"(?m)^      name:\s*([^#\n]+)$", block[environment.end():])
            environment_name = nested.group(1).strip().strip("'\"") if nested else ""
        if environment_name:
            continue
        first_reference_offset = header.end() + references[0].start()
        findings.append({
            "file": file_name,
            "job": header.group(1),
            "line": effective.count("\n", 0, first_reference_offset) + 1,
            "reason": "Actions secret is consumed outside a named dedicated Environment",
        })
    return findings



def workflow_images(path: Path) -> list[tuple[str, str]]:
    """Yield (image, location) for every container image a workflow declares.

    Reads the parsed document so comments and shell text cannot be mistaken for
    an image reference. If the file will not parse, nothing is reported from
    here: an unparseable workflow is a different failure and the YAML linter is
    the thing that should say so.
    """
    try:
        import yaml
    except ImportError:
        return []
    try:
        doc = yaml.safe_load(path.read_text(encoding="utf-8", errors="replace"))
    except yaml.YAMLError:
        return []
    if not isinstance(doc, dict):
        return []

    found: list[tuple[str, str]] = []
    for job_id, job in (doc.get("jobs") or {}).items():
        if not isinstance(job, dict):
            continue
        container = job.get("container")
        if isinstance(container, str):
            found.append((container, f"jobs.{job_id}.container"))
        elif isinstance(container, dict) and isinstance(container.get("image"), str):
            found.append((container["image"], f"jobs.{job_id}.container.image"))
        for svc_id, svc in (job.get("services") or {}).items():
            if isinstance(svc, str):
                found.append((svc, f"jobs.{job_id}.services.{svc_id}"))
            elif isinstance(svc, dict) and isinstance(svc.get("image"), str):
                found.append((svc["image"], f"jobs.{job_id}.services.{svc_id}.image"))
    return found


def executable_download_findings(text: str, file_name: str) -> list[dict[str, Any]]:
    """Reject downloaded executables that are invoked before integrity proof.

    Exact versions in URLs do not make release assets immutable: a replaced or
    intercepted binary is still executable input. A SHA-256/SHA-512 check must
    contain a pinned literal digest, name the downloaded path and run in check
    mode before the first interpreter/direct invocation. A detached GPG verify
    is accepted as the stronger alternative.
    """
    lines = text.splitlines()
    downloads: list[tuple[int, str, str]] = []
    findings: list[dict[str, Any]] = []

    for index, raw_line in enumerate(lines):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if re.search(r"\b(?:curl|wget)\b[^\n|]*\|\s*(?:sudo\s+)?(?:bash|sh|php|python3?|node)\b", line, re.I):
            findings.append({
                "file": file_name,
                "line": index + 1,
                "value": line,
                "reason": "network response is piped directly to an interpreter without integrity verification",
            })
            continue
        try:
            tokens = shlex.split(line, comments=True, posix=True)
        except ValueError:
            continue
        if not tokens:
            continue
        command = Path(tokens[0]).name.lower()
        target = ""
        url = ""
        if command == "curl":
            for position, token in enumerate(tokens):
                if token in ("-o", "--output") and position + 1 < len(tokens):
                    target = tokens[position + 1]
                elif token.startswith("--output="):
                    target = token.split("=", 1)[1]
                if token.startswith(("https://", "http://")):
                    url = token
        elif command == "wget":
            for position, token in enumerate(tokens):
                if token in ("-O", "--output-document") and position + 1 < len(tokens):
                    target = tokens[position + 1]
                elif token.startswith("--output-document="):
                    target = token.split("=", 1)[1]
                if token.startswith(("https://", "http://")):
                    url = token
        elif command in ("cp", "install") and len(tokens) >= 3:
            # A PHAR provisioned by a pinned setup action is still executable
            # bytes. Copying it to the well-known runtime path starts a new
            # verification boundary just like a network download.
            target = tokens[-1]
            url = "local-provisioned-executable"
        if target.lower().endswith(EXECUTABLE_DOWNLOAD_SUFFIXES):
            downloads.append((index, target, url))

    for download_index, target, url in downloads:
        verified = False
        executed_at = 0
        escaped = re.escape(target)
        for index in range(download_index + 1, len(lines)):
            line = lines[index].strip()
            if target not in line:
                continue
            checksum_check = (
                re.search(r"\bsha(?:256|512)sum\b", line, re.I)
                and re.search(r"(?:--check\b|(?:^|\s)-[A-Za-z]*c[A-Za-z]*(?:\s|$))", line)
                and re.search(r"\b[0-9a-fA-F]{64}(?:[0-9a-fA-F]{64})?\b", line)
            )
            release_api_digest_check = (
                re.search(r"\btest\b", line)
                and re.search(r"\bsha(?:256|512)sum\s+" + escaped + r"\b", line, re.I)
                and re.search(r"=\s*[\"']\$(?:[A-Za-z_][A-Za-z0-9_]*_)?digest[\"']", line, re.I)
            )
            signature_check = re.search(r"\bgpg\b[^\n]*\s--verify\b[^\n]*" + escaped, line, re.I)
            if checksum_check or release_api_digest_check or signature_check:
                verified = True
                continue
            interpreter_exec = re.search(
                r"(?:^|[;&|]\s*)(?:sudo\s+)?(?:php|bash|sh|python3?|node|java\s+-jar)\b[^\n]*" + escaped,
                line,
                re.I,
            )
            direct_exec = re.search(r"(?:^|&&|;)\s*['\"]?" + escaped + r"(?:['\"]?\s|$)", line)
            if interpreter_exec or direct_exec:
                executed_at = index + 1
                break
        if executed_at and not verified:
            findings.append({
                "file": file_name,
                "line": download_index + 1,
                "executed_line": executed_at,
                "value": url or target,
                "target": target,
                "reason": "downloaded or provisioned executable is invoked before a pinned checksum or signature is verified",
            })
    return findings


def workflow_findings() -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    action_findings: list[dict[str, Any]] = []
    dependency_findings: list[dict[str, Any]] = []
    observations: list[dict[str, Any]] = []
    for path in sorted(WORKFLOWS.glob("*.y*ml")):
        text = path.read_text(encoding="utf-8", errors="replace")
        for value in USES.findall(text):
            if value.startswith("./"):
                continue
            if value.startswith("docker://"):
                if "@sha256:" not in value:
                    action_findings.append({"file": rel(path), "value": value, "reason": "docker action lacks digest"})
                continue
            if "@" not in value:
                action_findings.append({"file": rel(path), "value": value, "reason": "GitHub Action has no ref"})
                continue
            ref_value = value.rsplit("@", 1)[1]
            if not FULL_SHA.fullmatch(ref_value):
                action_findings.append({"file": rel(path), "value": value, "reason": "GitHub Action ref is not immutable 40-hex SHA"})

        # Container images are read from the parsed document, not from the raw
        # text. Text scanning matched things that are not images at all: the
        # comment "# mariadb:11.4 -- multi-platform index pinned" sitting
        # directly above a correctly digest-pinned image, and a fragment of a
        # grep expression inside a run: block. Both were reported as mutable
        # production dependencies. A supply-chain gate that cries wolf about a
        # comment is one people learn to override, so it now looks only where
        # an image can actually be declared.
        for value, where in workflow_images(path):
            if "@sha256:" in value:
                continue
            dependency_findings.append({"file": rel(path), "where": where, "value": value, "reason": "container image is tag-only; production dependency is mutable"})

        dependency_findings.extend( executable_download_findings( text, rel( path ) ) )

        for match in FLOATING.finditer(text):
            line_no = text.count("\n", 0, match.start()) + 1
            dependency_findings.append({"file": rel(path), "line": line_no, "value": match.group(0), "reason": "floating dependency/tool selector"})

        # Exact composer CLI constraints use package:version. Reject common open ranges.
        for line_no, line in enumerate(text.splitlines(), 1):
            if "composer global require" not in line and "composer require" not in line:
                continue
            if any(token in line for token in ("^", "~", "*", ">", "<", " dev-", "@dev")):
                dependency_findings.append({"file": rel(path), "line": line_no, "value": line.strip(), "reason": "Composer build tool uses an open version range"})
            observations.append({"file": rel(path), "line": line_no, "composer_requirement": line.strip()})
    return action_findings, dependency_findings, observations


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json-output", default="")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    manifests, package_findings = package_lock_findings()
    cooldown_findings = dependabot_cooldown_findings()
    action_findings, workflow_dependency_findings, observations = workflow_findings()
    secret_environment_findings: list[dict[str, Any]] = []
    for workflow_path in sorted(WORKFLOWS.glob("*.y*ml")):
        secret_environment_findings.extend(workflow_secret_environment_findings(
            workflow_path.read_text(encoding="utf-8", errors="replace"),
            rel(workflow_path),
        ))
    dependency_findings = package_findings + workflow_dependency_findings

    result = {
        "schema_version": 1,
        "checks": {
            "github_actions_commit_pinned": {"ok": not action_findings, "findings": action_findings},
            "github_actions_secrets_environment_scoped": {"ok": not secret_environment_findings, "findings": secret_environment_findings},
            "dependencies_locked": {"ok": not dependency_findings, "manifests": manifests, "findings": dependency_findings, "observations": observations},
            "dependabot_stability_cooldown": {"ok": not cooldown_findings, "findings": cooldown_findings},
        },
    }
    output = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.json_output:
        path = Path(args.json_output)
        if not path.is_absolute():
            path = ROOT / path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(output, encoding="utf-8")
    print("PRODUCTION SUPPLY-CHAIN SOURCE AUDIT")
    for check_id, check in result["checks"].items():
        print(f"{'PASS' if check['ok'] else 'FAIL'} {check_id}")
        finding_count = len(check.get("findings", []))
        if finding_count:
            print(f"  FINDINGS count={finding_count}; details retained only in the bounded JSON artifact")
    failed = [check_id for check_id, check in result["checks"].items() if not check["ok"]]
    return 1 if args.strict and failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
