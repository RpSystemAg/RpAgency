#!/usr/bin/env python3
"""Fail-closed proof of the live ruleset protecting the default branch.

Live GitHub authority is mandatory. For deterministic local regression only,
``PRSTUDIO_GOVERNANCE_FIXTURE`` may name a captured JSON authority document;
that mode is explicitly forbidden when ``GITHUB_ACTIONS=true``.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REPO = os.environ.get("GITHUB_REPOSITORY", "RpSystemAg/RpConnector")
FIXTURE_ENV = "PRSTUDIO_GOVERNANCE_FIXTURE"
DECLARED = ROOT / "tests" / "required-checks.json"
EXPECTED_PULL_REQUEST_PARAMETERS: dict[str, Any] = {
    "allowed_merge_methods": ["merge"],
    "dismiss_stale_reviews_on_push": False,
    "require_code_owner_review": False,
    "require_extra_approval_for_unattributed_changes": True,
    "require_last_push_approval": False,
    "required_approving_review_count": 0,
    "required_review_thread_resolution": True,
    "required_reviewers": [],
}


def exact_pull_request_parameter_types(parameters: Any) -> bool:
    if not isinstance(parameters, dict):
        return False
    boolean_fields = {
        "dismiss_stale_reviews_on_push",
        "require_code_owner_review",
        "require_extra_approval_for_unattributed_changes",
        "require_last_push_approval",
        "required_review_thread_resolution",
    }
    if any(type(parameters.get(field)) is not bool for field in boolean_fields):
        return False
    if type(parameters.get("required_approving_review_count")) is not int:
        return False
    allowed = parameters.get("allowed_merge_methods")
    reviewers = parameters.get("required_reviewers")
    return (
        type(allowed) is list
        and all(type(item) is str for item in allowed)
        and type(reviewers) is list
        and all(isinstance(item, dict) for item in reviewers)
    )


def declared_contexts() -> list[str]:
    payload = json.loads(DECLARED.read_text(encoding="utf-8", errors="strict"))
    required = payload.get("required") if isinstance(payload, dict) else None
    if not isinstance(required, list) or not required:
        raise ValueError("required-checks.json required must be a non-empty array")
    if any(not isinstance(item, str) or not item.strip() for item in required):
        raise ValueError("required check contexts must be non-empty strings")
    if len(required) != len(set(required)):
        raise ValueError("required check contexts must be unique")
    return required


def _gh_json(endpoint: str) -> Any:
    env = os.environ.copy()
    if env.get("GITHUB_TOKEN") and not env.get("GH_TOKEN"):
        env["GH_TOKEN"] = env["GITHUB_TOKEN"]
    run = subprocess.run(["gh", "api", endpoint], cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
    if run.returncode != 0:
        raise RuntimeError(run.stderr.strip() or f"gh api {endpoint} exited {run.returncode}")
    return json.loads(run.stdout)


def load_authority() -> tuple[dict[str, Any], str]:
    fixture = os.environ.get(FIXTURE_ENV, "").strip()
    if fixture:
        if os.environ.get("GITHUB_ACTIONS", "").lower() == "true":
            raise RuntimeError(f"{FIXTURE_ENV} is forbidden in GitHub Actions")
        path = Path(fixture)
        if not path.is_absolute():
            path = ROOT / path
        payload = json.loads(path.read_text(encoding="utf-8", errors="strict"))
        if not isinstance(payload, dict) or not isinstance(payload.get("repository"), dict) or not isinstance(payload.get("rulesets"), list):
            raise RuntimeError("governance fixture must contain repository and rulesets")
        return payload, f"fixture:{path.resolve()}"

    repository = _gh_json(f"repos/{REPO}")
    summaries = _gh_json(f"repos/{REPO}/rulesets?includes_parents=true")
    if not isinstance(summaries, list):
        raise RuntimeError("ruleset authority returned a non-list")
    rulesets = [
        _gh_json(f"repos/{REPO}/rulesets/{summary['id']}?includes_parents=true")
        for summary in summaries
        if isinstance(summary, dict) and summary.get("id")
    ]
    return {"repository": repository, "rulesets": rulesets}, "github-api"


def audit_authority(authority: dict[str, Any], required: list[str]) -> tuple[dict[str, Any], list[str]]:
    errors: list[str] = []
    checks: dict[str, dict[str, Any]] = {}

    def record(name: str, ok: bool, detail: Any) -> None:
        checks[name] = {"ok": bool(ok), "detail": detail}
        if not ok:
            errors.append(name)

    repository = authority.get("repository")
    if not isinstance(repository, dict):
        return {"checks": checks}, ["repository_metadata: missing"]
    default_branch = repository.get("default_branch")
    record("default_branch_observable", isinstance(default_branch, str) and bool(default_branch), default_branch)

    applicable: list[dict[str, Any]] = []
    for ruleset in authority.get("rulesets", []):
        if not isinstance(ruleset, dict):
            continue
        ref_name = (ruleset.get("conditions") or {}).get("ref_name") or {}
        includes = ref_name.get("include") or []
        excludes = ref_name.get("exclude") or []
        applies = (
            ruleset.get("target") == "branch"
            and ruleset.get("enforcement") == "active"
            and "~DEFAULT_BRANCH" in includes
            and not excludes
        )
        if applies:
            applicable.append(ruleset)

    record(
        "active_default_branch_ruleset_present",
        bool(applicable),
        [{"id": item.get("id"), "name": item.get("name")} for item in applicable],
    )
    record(
        "no_ruleset_bypass",
        bool(applicable) and all(not (item.get("bypass_actors") or []) and item.get("current_user_can_bypass") == "never" for item in applicable),
        [
            {
                "id": item.get("id"),
                "bypass_actors": item.get("bypass_actors"),
                "current_user_can_bypass": item.get("current_user_can_bypass"),
            }
            for item in applicable
        ],
    )

    rule_types: set[str] = set()
    enforced: set[str] = set()
    status_rules = 0
    all_status_rules_strict = True
    pull_request_rules: list[Any] = []
    for ruleset in applicable:
        for rule in ruleset.get("rules") or []:
            if not isinstance(rule, dict) or not isinstance(rule.get("type"), str):
                continue
            rule_types.add(rule["type"])
            if rule["type"] == "pull_request":
                pull_request_rules.append(rule.get("parameters"))
            if rule["type"] != "required_status_checks":
                continue
            status_rules += 1
            parameters = rule.get("parameters") or {}
            if parameters.get("strict_required_status_checks_policy") is not True:
                all_status_rules_strict = False
            for check in parameters.get("required_status_checks") or []:
                context = check.get("context") if isinstance(check, dict) else None
                if isinstance(context, str) and context:
                    enforced.add(context)

    pr_parameters = pull_request_rules[0] if len(pull_request_rules) == 1 else None
    pr_shape_exact = isinstance(pr_parameters, dict) and set(pr_parameters) == set(EXPECTED_PULL_REQUEST_PARAMETERS)
    pr_types_exact = exact_pull_request_parameter_types(pr_parameters)
    pr_exact = pr_shape_exact and pr_types_exact and pr_parameters == EXPECTED_PULL_REQUEST_PARAMETERS
    pr_detail = {
        "rules": len(pull_request_rules),
        "actual": pr_parameters,
        "expected": EXPECTED_PULL_REQUEST_PARAMETERS,
    }
    record("pull_request_required", "pull_request" in rule_types, sorted(rule_types))
    record("single_applicable_pull_request_rule", len(pull_request_rules) == 1, pr_detail)
    record("pull_request_parameter_shape_exact", pr_shape_exact, pr_detail)
    record("pull_request_parameter_types_exact", pr_types_exact, pr_detail)
    record("required_review_thread_resolution", isinstance(pr_parameters, dict) and pr_parameters.get("required_review_thread_resolution") is True, pr_detail)
    record("extra_unattributed_change_approval", isinstance(pr_parameters, dict) and pr_parameters.get("require_extra_approval_for_unattributed_changes") is True, pr_detail)
    record("allowed_merge_methods_exact", isinstance(pr_parameters, dict) and pr_parameters.get("allowed_merge_methods") == ["merge"], pr_detail)
    record("required_approvals_exact_zero", isinstance(pr_parameters, dict) and type(pr_parameters.get("required_approving_review_count")) is int and pr_parameters.get("required_approving_review_count") == 0, pr_detail)
    record("single_maintainer_review_shape_exact", isinstance(pr_parameters, dict) and pr_parameters.get("dismiss_stale_reviews_on_push") is False and pr_parameters.get("require_code_owner_review") is False and pr_parameters.get("require_last_push_approval") is False and pr_parameters.get("required_reviewers") == [], pr_detail)
    record("pull_request_parameters_exact", pr_exact, pr_detail)
    record("deletion_blocked", "deletion" in rule_types, sorted(rule_types))
    record("non_fast_forward_blocked", "non_fast_forward" in rule_types, sorted(rule_types))
    record("strict_required_status_checks", status_rules > 0 and all_status_rules_strict, {"rules": status_rules, "strict": all_status_rules_strict})
    record("required_status_contexts_exact", enforced == set(required), {"declared": sorted(required), "enforced": sorted(enforced)})

    security = repository.get("security_and_analysis")
    record(
        "security_settings_observable",
        isinstance(security, dict),
        "present" if isinstance(security, dict) else "security_and_analysis omitted; Administration(read) proof is mandatory",
    )
    if isinstance(security, dict):
        secret_status = (security.get("secret_scanning") or {}).get("status")
        push_status = (security.get("secret_scanning_push_protection") or {}).get("status")
        record("secret_scanning_enabled", secret_status == "enabled", secret_status)
        record("push_protection_enabled", push_status == "enabled", push_status)
    else:
        # A public-repository inference cannot prove the repository-level push
        # protection setting. Missing Administration(read) evidence is itself a
        # failed control, never a warning that a required gate may ignore.
        record("secret_scanning_enabled", False, "unobservable")
        record("push_protection_enabled", False, "unobservable")

    return {
        "repository": REPO,
        "default_branch": default_branch,
        "required_contexts": required,
        "applicable_ruleset_ids": [item.get("id") for item in applicable],
        "checks": checks,
    }, errors


def safe_diagnostic_report(evidence: dict[str, Any], source: str) -> dict[str, Any]:
    """Return a log-safe governance projection without GitHub payload values."""
    raw_checks = evidence.get("checks")
    checks = raw_checks if isinstance(raw_checks, dict) else {}
    check_results = {
        str(name): {"ok": isinstance(result, dict) and result.get("ok") is True}
        for name, result in sorted(checks.items(), key=lambda item: str(item[0]))
    }
    return {
        "repository": REPO,
        "authority_source": source.partition(":")[0],
        "checks": check_results,
        "failed_checks": [name for name, result in check_results.items() if not result["ok"]],
    }


def full_surface_self_test() -> int:
    required = declared_contexts()
    authority = {
        "repository": {
            "default_branch": "master",
            "security_and_analysis": {
                "secret_scanning": {"status": "enabled"},
                "secret_scanning_push_protection": {"status": "enabled"},
            },
        },
        "rulesets": [{
            "id": 1,
            "name": "protected-master",
            "target": "branch",
            "enforcement": "active",
            "bypass_actors": [],
            "current_user_can_bypass": "never",
            "conditions": {"ref_name": {"include": ["~DEFAULT_BRANCH"], "exclude": []}},
            "rules": [
                {"type": "pull_request", "parameters": EXPECTED_PULL_REQUEST_PARAMETERS},
                {"type": "required_status_checks", "parameters": {
                    "strict_required_status_checks_policy": True,
                    "required_status_checks": [{"context": context} for context in required],
                }},
                {"type": "deletion"},
                {"type": "non_fast_forward"},
            ],
        }],
    }
    evidence, errors = audit_authority(authority, required)
    if errors or any(result.get("ok") is not True for result in evidence.get("checks", {}).values()):
        raise RuntimeError("valid governance authority was rejected")
    weakened = json.loads(json.dumps(authority))
    weakened["repository"]["security_and_analysis"]["secret_scanning_push_protection"]["status"] = "disabled"
    _, weakened_errors = audit_authority(weakened, required)
    if "push_protection_enabled" not in weakened_errors:
        raise RuntimeError("governance audit accepted disabled push protection")
    report = safe_diagnostic_report(evidence, "fixture:self-test")
    if report.get("authority_source") != "fixture" or report.get("failed_checks"):
        raise RuntimeError("governance diagnostic projection diverged")
    print(f"PASS repository governance internal self-test: contexts={len(required)}")
    return 0


def main() -> int:
    if os.environ.get("PRSTUDIO_FULL_SURFACE_EXECUTION") == "1" and len(sys.argv) == 1:
        return full_surface_self_test()
    try:
        required = declared_contexts()
        authority, source = load_authority()
        evidence, errors = audit_authority(authority, required)
    except (OSError, UnicodeError, ValueError, RuntimeError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        print(f"GOV-00 authority unavailable or invalid: {exc}", file=sys.stderr)
        return 1

    report = safe_diagnostic_report(evidence, source)
    print(json.dumps(report, indent=2, sort_keys=True))
    print(f"REPOSITORY GOVERNANCE: errors={len(errors)}")
    for failed_check in report["failed_checks"]:
        print("ERROR", failed_check)
    if errors:
        print("ACTION: configure exactly one active, no-bypass ~DEFAULT_BRANCH PR rule with the declared single-maintainer shape, merge-only policy, thread resolution, unattributed-change approval, strict exact checks, deletion and non-fast-forward rules.")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
