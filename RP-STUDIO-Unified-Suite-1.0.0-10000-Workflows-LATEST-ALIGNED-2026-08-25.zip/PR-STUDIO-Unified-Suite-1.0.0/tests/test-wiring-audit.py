#!/usr/bin/env python3
"""Fail closed when any tracked test-surface file is unreachable from CI.

The graph includes workflow roots, repository runners outside ``tests/``, and
every tracked file (code or data) below both test roots. Reachability is a
fixed point, so a workflow -> release runner -> nested test chain is not lost
merely because the runner's filename does not contain the word ``test``.
"""
from __future__ import annotations

import fnmatch
import re
import subprocess
import sys
from pathlib import Path

try:
    import yaml
except ImportError as exc:
    raise SystemExit(f"FAIL PyYAML is required for wiring audit: {exc}")

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW_DIR = ROOT / ".github" / "workflows"
TEST_ROOTS = ("tests/", "prstudio-unified-browser-agent/tests/")
GRAPH_ROOTS = ("tests/", "prstudio-unified-browser-agent/tests/", ".github/scripts/")
GRAPH_SUFFIXES = {".py", ".php", ".mjs", ".js", ".cjs", ".sh", ".bash", ".json", ".yml", ".yaml", ".xml"}
GLOB_RE = re.compile(r"[A-Za-z0-9_./-]*(?:tests|scripts)/[A-Za-z0-9_.*?\[\]-]+")
DYNAMIC_RUNNER = ".github/scripts/full-surface-execution.py"


def tracked_paths() -> list[str]:
    raw = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT)
    return sorted(item.decode("utf-8") for item in raw.split(b"\0") if item)


def effective_text(text: str) -> str:
    """Discard comment-only lines so a prose mention cannot wire a test."""
    lines = []
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith(("#", "//", "/*", "*")):
            continue
        lines.append(line)
    return "\n".join(lines)


def workflow_run_text(paths: list[Path]) -> str:
    commands: list[str] = []
    for path in paths:
        try:
            document = yaml.safe_load(path.read_text(encoding="utf-8", errors="replace"))
        except yaml.YAMLError as exc:
            raise SystemExit(f"FAIL {path.name} does not parse: {exc}") from exc
        if not isinstance(document, dict):
            raise SystemExit(f"FAIL {path.name} has no workflow mapping")
        jobs = document.get("jobs")
        if not isinstance(jobs, dict):
            raise SystemExit(f"FAIL {path.name} has no jobs mapping")
        for job in jobs.values():
            if not isinstance(job, dict):
                continue
            for step in job.get("steps") or []:
                if isinstance(step, dict) and isinstance(step.get("run"), str):
                    commands.append(step["run"])
    return "\n".join(commands)


def referenced(text: str, target: str, unique_basenames: set[str], glob_tokens: tuple[str, ...]) -> bool:
    if re.search(rf"(?<![A-Za-z0-9_.-]){re.escape(target)}(?![A-Za-z0-9_.-])", text):
        return True
    basename = target.rsplit("/", 1)[-1]
    if basename in unique_basenames:
        if re.search(rf"(?<![A-Za-z0-9_.-]){re.escape(basename)}(?![A-Za-z0-9_.-])", text):
            return True
    suffixes = [target]
    if "/tests/" in target:
        suffixes.append("tests/" + target.split("/tests/", 1)[1])
    for pattern in glob_tokens:
        if any(fnmatch.fnmatch(suffix, pattern) for suffix in suffixes):
            return True
    return False


def build_reachability(file_texts: dict[str, str], surface: set[str], workflow_text: str) -> set[str]:
    all_paths = set(file_texts)
    basename_counts: dict[str, int] = {}
    for path in all_paths:
        basename = path.rsplit("/", 1)[-1]
        basename_counts[basename] = basename_counts.get(basename, 0) + 1
    unique_basenames = {name for name, count in basename_counts.items() if count == 1}
    cleaned = {path: effective_text(text) for path, text in file_texts.items()}
    globs = {path: tuple(GLOB_RE.findall(text)) for path, text in cleaned.items()}
    workflow_text = effective_text(workflow_text)
    workflow_globs = tuple(GLOB_RE.findall(workflow_text))
    reachable = {
        path for path in all_paths
        if referenced(workflow_text, path, unique_basenames, workflow_globs)
    }
    changed = True
    while changed:
        changed = False
        for source in tuple(reachable):
            text = cleaned.get(source, "")
            for target in all_paths - reachable:
                if referenced(text, target, unique_basenames, globs.get(source, ())):
                    reachable.add(target)
                    changed = True

        # The dynamic edge is valid only after the exact runner is reachable
        # and still proves exact-checkout discovery plus direct execution.
        if DYNAMIC_RUNNER in reachable:
            runner = file_texts.get(DYNAMIC_RUNNER, "")
            runtime_discovery = (
                'Path("tests")' in runner
                and 'Path("prstudio-unified-browser-agent/tests")' in runner
                and "tracked_files()" in runner
                and "execution_command(rel)" in runner
                and '"git", "ls-files", "-z"' in runner
            )
            if runtime_discovery and not surface.issubset(reachable):
                reachable.update(surface)
                changed = True
    return reachable


def graph_regression() -> None:
    surface = {"tests/release-runner.mjs", "tests/nested-smoke.php", "tests/fixture.json"}
    files = {
        ".github/scripts/entry.py": 'subprocess.run(["node", "tests/release-runner.mjs"])',
        "tests/release-runner.mjs": 'spawnSync("php", ["tests/nested-smoke.php"])',
        "tests/nested-smoke.php": "<?php echo 'PASS';",
        "tests/fixture.json": "{}",
    }
    reached = build_reachability(files, surface, "python .github/scripts/entry.py")
    assert "tests/release-runner.mjs" in reached, "non-test-named runner edge was lost"
    assert "tests/nested-smoke.php" in reached, "fixed-point nested edge was lost"
    assert "tests/fixture.json" not in reached, "unreferenced data received a false-green edge"

    files[DYNAMIC_RUNNER] = (
        'TEST_ROOTS=(Path("tests"),Path("prstudio-unified-browser-agent/tests")); '
        'subprocess.run(["git", "ls-files", "-z"]); tracked_files(); execution_command(rel)'
    )
    files[".github/scripts/entry.py"] += f'\nrun("{DYNAMIC_RUNNER}")'
    reached = build_reachability(files, surface, "python .github/scripts/entry.py")
    assert surface.issubset(reached), "reachable exact-checkout runner did not wire the full surface"


def main() -> int:
    graph_regression()
    workflow_files = sorted(WORKFLOW_DIR.glob("*.yml")) + sorted(WORKFLOW_DIR.glob("*.yaml"))
    expected = WORKFLOW_DIR / "unified-h24-control.yml"
    if workflow_files != [expected]:
        print("FAIL exactly one unified-h24-control.yml workflow is required", file=sys.stderr)
        return 1

    tracked = tracked_paths()
    surface = {path for path in tracked if any(path.startswith(root) for root in TEST_ROOTS)}
    graph_paths = {
        path for path in tracked
        if any(path.startswith(root) for root in GRAPH_ROOTS)
        and (Path(path).suffix.lower() in GRAPH_SUFFIXES or not Path(path).suffix)
    }
    graph_paths.update(path for path in tracked if re.fullmatch(r"phpunit[^/]*\.xml(?:\.dist)?", path))
    file_texts = {
        path: (ROOT / path).read_text(encoding="utf-8", errors="replace")
        for path in sorted(graph_paths)
    }
    reachable = build_reachability(file_texts, surface, workflow_run_text(workflow_files))
    unwired = sorted(surface - reachable)

    print(
        f"TEST WIRING: surface={len(surface)} graph_nodes={len(file_texts)} "
        f"reachable_surface={len(surface & reachable)} unwired={len(unwired)} workflows=1"
    )
    for path in sorted(surface & reachable):
        print("WIRED", path)
    for path in unwired:
        print("ERROR UNWIRED", path)
    if unwired:
        print("Every tracked test-surface file must be reachable from the unified workflow; reclassification and silent inventory are forbidden.")
    return 1 if unwired else 0


if __name__ == "__main__":
    raise SystemExit(main())
