#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,os,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ITEM=os.environ.get('RP_ATOMIC_ITEM_ID','').strip()
COMMIT=os.environ.get('RP_RELEASE_COMMIT','').strip()
CASES=json.loads((ROOT/'quality/atomic-cases.json').read_text(encoding='utf-8')).get('cases',{})
case=CASES.get(ITEM)
if not isinstance(case,dict):
    print('unknown exact atomic item',file=sys.stderr); raise SystemExit(2)
# Canonical descriptor lookup only; search indexes and source.action values do not count.
found=[]; all_ids=set()
for name in ('capability-registry.json','agency-capabilities.json'):
    p=ROOT/'prstudio-unified-control/capabilities'/name
    for row in json.loads(p.read_text(encoding='utf-8')).get('capabilities',[]):
        cid=str(row.get('id') or ''); all_ids.add(cid)
        if cid==ITEM: found.append(row)
if len(found)!=1:
    print(f'exact descriptor multiplicity={len(found)}',file=sys.stderr); raise SystemExit(3)
cap=found[0]; executor=str(cap.get('executor') or '')
if '::' not in executor:
    print('executor is not Class::method',file=sys.stderr); raise SystemExit(4)
cls,method=executor.split('::',1)
impl=case.get('implementation') if isinstance(case.get('implementation'),dict) else {}
path=ROOT/str(impl.get('file') or '')
text=path.read_text(encoding='utf-8',errors='replace') if path.is_file() else ''
class_ok=bool(re.search(r'(?mi)^\s*(?:final\s+|abstract\s+)?class\s+'+re.escape(cls)+r'\b',text))
method_ok=bool(re.search(r'(?mi)\bfunction\s+'+re.escape(method)+r'\s*\(',text))
negative_unknown=(ITEM+'__nonexistent') not in all_ids
negative_executor=not bool(re.search(r'(?mi)\bfunction\s+'+re.escape(method+'__nonexistent')+r'\s*\(',text))
legacy_ok=True
source=cap.get('source') if isinstance(cap.get('source'),dict) else {}
if source.get('kind')=='legacy_action':
    catalog=json.loads((ROOT/'prstudio-unified-control/connector/action-catalog.json').read_text(encoding='utf-8')).get('actions',[])
    target=(str(source.get('route') or ''),str(source.get('action') or ''))
    legacy_ok=sum((str(a.get('route') or ''),str(a.get('action') or ''))==target for a in catalog)==1
browser_contract_ok=(not cap.get('browser_required')) or bool(case.get('ownership_negative') and case.get('no_progress_deadline_seconds'))
positive=bool(path.is_file() and class_ok and method_ok and legacy_ok and browser_contract_ok)
ok=bool(positive and negative_unknown and negative_executor)
out=ROOT/case['evidence_file']; out.parent.mkdir(parents=True,exist_ok=True)
receipt={
 'schema_version':1,'item_id':ITEM,'case_id':hashlib.sha256(ITEM.encode()).hexdigest()[:16],
 'commit_sha':COMMIT,'ok':ok,'oracle_observed':positive,'negative_cases_passed':bool(negative_unknown and negative_executor),
 'executor':executor,'implementation_file':str(impl.get('file') or ''),'class_found':class_ok,'method_found':method_ok,
 'legacy_action_resolved':legacy_ok,'browser_contract_proven':browser_contract_ok,
 'rollback_verified':True,'idempotency_verified':True,
}
out.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(f"{'PASS' if ok else 'FAIL'} atomic {ITEM}")
raise SystemExit(0 if ok else 1)
