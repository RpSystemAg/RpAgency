<?php
/**
 * Runtime collision smoke tests for the optional-integration PHPStan scan file.
 *
 * The scan file is linted by CI even though production never loads it. Run the
 * two relevant states in isolated PHP processes so a loaded optional extension
 * cannot make the test itself environment-dependent.
 */

declare(strict_types=1);

$stub = __DIR__ . '/phpstan-external-stubs.php';

function run_stub_process( string $code ): array {
	$process = proc_open(
		array( PHP_BINARY, '-n', '-d', 'display_errors=1', '-r', $code ),
		array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		),
		$pipes
	);
	if ( ! is_resource( $process ) ) {
		return array( 'exit' => 127, 'output' => 'Unable to start isolated PHP process.' );
	}
	fclose( $pipes[0] );
	$stdout = stream_get_contents( $pipes[1] );
	$stderr = stream_get_contents( $pipes[2] );
	fclose( $pipes[1] );
	fclose( $pipes[2] );
	return array(
		'exit'   => proc_close( $process ),
		'output' => trim( (string) $stdout . "\n" . (string) $stderr ),
	);
}

function assert_process_ok( array $result, string $message ): void {
	if ( 0 !== $result['exit'] ) {
		fwrite( STDERR, "FAIL {$message}: {$result['output']}\n" );
		exit( 1 );
	}
	fwrite( STDOUT, "PASS {$message}\n" );
}

$quoted_stub = var_export( $stub, true );

assert_process_ok(
	run_stub_process(
		'require ' . $quoted_stub . ';'
		. 'if (!function_exists("yaml_parse")) { fwrite(STDERR, "stub did not declare yaml_parse"); exit(2); }'
	),
	'scan file loads when ext-yaml is absent'
);

assert_process_ok(
	run_stub_process(
		'function yaml_parse(string $input, int $pos = 0, int &$ndocs = 0, array $callbacks = array()): mixed {'
		. 'return "preexisting:" . $input;'
		. '}'
		. 'require ' . $quoted_stub . ';'
		. '$documents = 0;'
		. 'if (yaml_parse("fixture", 0, $documents) !== "preexisting:fixture") {'
		. 'fwrite(STDERR, "scan file replaced the pre-existing function"); exit(3);'
		. '}'
	),
	'scan file preserves a pre-existing yaml_parse without redeclaration'
);

// Also load it under the test runner's normal extension set. On CI this is the
// regression case when ext-yaml is enabled; locally it remains a third lint/load
// check using the developer PHP configuration.
require $stub;
fwrite( STDOUT, "PASS scan file loads with the runner's configured extensions\n" );
