#!/usr/bin/env python3
"""Measure every complete tools/list page with real host tokenizers.

Why this exists
---------------
The budget authority must count the descriptor that actually crosses the wire:
title, description, inputSchema, outputSchema, securitySchemes, annotations and
_meta.  A prior implementation counted only name/description/inputSchema; that
projection called an 18k-token payload a 5k-token payload.  This test walks the
entire cursor chain and makes that false-green structurally impossible.

For every page it asserts that the assembler-accounted bytes equal the complete
JSON descriptor array, that both supported encodings stay under 5,000 tokens,
that the stored byte ratio remains conservative, and that all tools are reached
exactly once.  It also retains the old projection solely as a negative oracle:
the complete payload must be larger and must contain all enterprise fields.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MCP_SOURCE = ROOT / "prstudio-unified-control" / "includes" / "class-prstudio-uc-mcp-v5.php"
BUDGET_TOKENS = 5000
ENCODINGS = ("o200k_base", "cl100k_base")

# How far below the measured ratio the committed one sits.
#
# The ratio is a property of the text, and the text changes whenever a tool is
# added or a description reworded. Measured across many surface compositions on
# 19-20 Aug 2026 it moved between 4.63 and 4.81 -- about four percent. Two
# percent of margin absorbs ordinary drift between the moment it is measured and
# the moment the surface next changes; it does not absorb a redesign, which is
# why the check below still runs on every push rather than trusting the stored
# value forever.
SAFETY_MARGIN = 0.98


def committed_ratio() -> float | None:
    """The bytes-per-token ratio the assembler is currently using."""
    match = re.search(r"TOKEN_BYTES_RATIO\s*=\s*([0-9.]+)\s*;", MCP_SOURCE.read_text(encoding="utf-8"))
    return float(match.group(1)) if match else None


def write_ratio(value: float) -> None:
    """Store a measured ratio in the assembler."""
    source = MCP_SOURCE.read_text(encoding="utf-8")
    updated = re.sub(r"(TOKEN_BYTES_RATIO\s*=\s*)[0-9.]+(\s*;)", rf"\g<1>{value:.2f}\g<2>", source, count=1)
    MCP_SOURCE.write_text(updated, encoding="utf-8", newline="\n")

# Emits exactly what a host ingests for tool selection, after the budget
# assembler has run. Kept here rather than as a file under tests/ so it is not a
# second surface file that has to justify its own execution.
DUMP_PHP = r"""<?php
declare( strict_types = 1 );
define( 'PRSTUDIO_UC_TESTING', true );
if ( ! function_exists( 'is_wp_error' ) ) {
    function is_wp_error( $value ): bool { return $value instanceof WP_Error; }
}
require %s . '/prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php';

$method = new ReflectionMethod( 'PRSTUDIO_UC_MCP_V5', 'tools_within_budget' );
$method->setAccessible( true );
$pages = array();
$cursor = '';
$seen = 0;
do {
    $budgeted = $method->invoke( null, $cursor );
    if ( is_wp_error( $budgeted ) ) { throw new RuntimeException( $budgeted->get_error_message() ); }
    $legacy_subset = array_map(
        static function ( array $tool ): array {
            return array(
                'name'        => $tool['name'] ?? '',
                'description' => $tool['description'] ?? '',
                'inputSchema' => $tool['inputSchema'] ?? array(),
            );
        },
        $budgeted['tools']
    );
    $pages[] = array(
        'surface'         => json_encode( $budgeted['tools'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
        'legacy_subset'   => json_encode( $legacy_subset, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
        'emitted'         => count( $budgeted['tools'] ),
        'remaining'       => $budgeted['withheld'],
        'accounted_bytes' => $budgeted['bytes'],
        'estimated'       => $budgeted['tokens'],
    );
    $seen += count( $budgeted['tools'] );
    $cursor = (string) ( $budgeted['nextCursor'] ?? '' );
    if ( count( $pages ) > 100 ) { throw new RuntimeException( 'tools/list cursor did not terminate' ); }
} while ( '' !== $cursor );

echo json_encode(
    array(
        'pages'          => $pages,
        'seen'           => $seen,
        'catalog_count'  => count( PRSTUDIO_UC_MCP_V5::tools() ),
    ),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
"""


def php_binary() -> str:
    """Locate PHP.

    RP_PHP_BIN wins so a machine without php on PATH can still run this bare.
    A missing interpreter is a hard failure: LAW 11 has no skip class, and a
    check that quietly passes when it could not run is the defect it exists to
    catch.
    """
    override = os.environ.get("RP_PHP_BIN", "").strip()
    if override:
        return override
    found = shutil.which("php")
    if not found:
        print(
            "no PHP interpreter: set RP_PHP_BIN or put php on PATH. "
            "This check cannot certify the token ceiling without running the assembler.",
            file=sys.stderr,
        )
        raise SystemExit(1)
    return found


def emitted_surface() -> dict:
    php = php_binary()
    with tempfile.TemporaryDirectory() as tmp:
        script = Path(tmp) / "dump-surface.php"
        script.write_text(DUMP_PHP % json.dumps(ROOT.as_posix()), encoding="utf-8")
        run = subprocess.run(
            [php, "-d", "error_reporting=E_ALL", "-f", str(script)],
            capture_output=True,
            text=True,
            timeout=120,
        )
    if run.returncode != 0:
        print(f"the surface assembler did not run (exit {run.returncode})", file=sys.stderr)
        print(run.stderr[-2000:], file=sys.stderr)
        raise SystemExit(1)
    try:
        return json.loads(run.stdout)
    except json.JSONDecodeError:
        print("the surface assembler produced no parseable JSON", file=sys.stderr)
        print(run.stdout[-2000:], file=sys.stderr)
        raise SystemExit(1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--update-ratio",
        action="store_true",
        help="measure the real bytes-per-token ratio and store it, instead of only checking it",
    )
    args = parser.parse_args()

    try:
        import tiktoken
    except ImportError:
        print(
            "tiktoken is required to measure the ceiling. Install it in the job that "
            "runs this check; estimating instead is what this replaces.",
            file=sys.stderr,
        )
        return 1

    data = emitted_surface()
    problems = []
    measured = []
    names: list[str] = []
    required_fields = {
        "name", "title", "description", "inputSchema", "outputSchema",
        "securitySchemes", "annotations", "_meta",
    }
    print(
        f"pages: {len(data['pages'])}  seen: {data['seen']}  "
        f"catalogue: {data['catalog_count']}"
    )
    for page_number, page in enumerate(data["pages"], start=1):
        payload = page["surface"]
        payload_bytes = len(payload.encode("utf-8"))
        subset_bytes = len(page["legacy_subset"].encode("utf-8"))
        estimated = int(page["estimated"])
        accounted = int(page["accounted_bytes"])
        try:
            descriptors = json.loads(payload)
        except json.JSONDecodeError as exc:
            problems.append(f"page {page_number}: complete surface is not JSON: {exc}")
            descriptors = []
        if payload_bytes != accounted:
            problems.append(
                f"page {page_number}: assembler accounted {accounted} bytes but emitted {payload_bytes}"
            )
        if descriptors and payload_bytes <= subset_bytes:
            problems.append(
                f"page {page_number}: complete surface collapsed to the legacy three-field projection"
            )
        for descriptor in descriptors:
            missing = sorted(required_fields.difference(descriptor))
            if missing:
                problems.append(
                    f"page {page_number} tool {descriptor.get('name', '?')}: missing wire fields {missing}"
                )
            names.append(str(descriptor.get("name", "")))

        print(
            f"page {page_number:02d}: tools {page['emitted']:3d}  remaining {page['remaining']:3d}  "
            f"bytes {payload_bytes:6d}  legacy-subset {subset_bytes:6d}  estimate {estimated:4d}"
        )
        for name in ENCODINGS:
            real = len(tiktoken.get_encoding(name).encode(payload))
            ratio = payload_bytes / real if real else 0.0
            measured.append(ratio)
            headroom = BUDGET_TOKENS - real
            print(f"  {name:12} real tokens: {real:6d}  bytes/token: {ratio:.2f}  headroom: {headroom:+d}")

            if real >= BUDGET_TOKENS:
                problems.append(
                    f"page {page_number} {name}: complete descriptor payload is {real} tokens, "
                    f"at or over the {BUDGET_TOKENS} ceiling"
                )
            if estimated < real:
                problems.append(
                    f"page {page_number} {name}: internal divisor under-counts ({estimated} vs {real})"
                )

    if data["seen"] != data["catalog_count"] or len(names) != len(set(names)) or "" in names:
        problems.append("cursor chain is not a unique, lossless traversal of the direct-tool catalogue")

    # The ratio the assembler should use: the densest encoding observed, minus a
    # margin. Densest, not average -- the surface has to fit under whichever
    # tokenizer the host actually uses, and averaging would pick a number that is
    # wrong for one of them.
    committed = committed_ratio()
    recommended = round(min(measured) * SAFETY_MARGIN, 2) if measured else 0.0
    print(f"  measured min: {min(measured):.2f}  safe ratio: {recommended:.2f}  in use: {committed}")

    if args.update_ratio:
        if problems:
            print("", file=sys.stderr)
            for item in problems:
                print(f"  {item}", file=sys.stderr)
            print("\n  refusing to store a ratio measured on a surface that is already over the ceiling.", file=sys.stderr)
            return 1
        write_ratio(recommended)
        print(f"stored {recommended:.2f} bytes per token, measured rather than chosen")
        return 0

    if committed is not None and committed > min(measured):
        problems.append(
            f"the stored ratio {committed} is above the measured {min(measured):.2f}, so the "
            f"assembler under-counts and will admit more than the ceiling allows. Run this "
            f"check with --update-ratio to store {recommended:.2f}."
        )

    if problems:
        print("", file=sys.stderr)
        for item in problems:
            print(f"  {item}", file=sys.stderr)
        return 1

    print("every complete descriptor page is under the ceiling and the cursor chain is lossless")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
