#!/usr/bin/env python3
"""Behavioral regressions for required-check and repository ruleset gates."""
from __future__ import annotations

import copy
import contextlib
import importlib.util
import io
import json
import os
import re
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


required_gate = load("required_gate", "tests/validate-required-checks.py")
governance_gate = load("governance_gate", "tests/repository-governance.py")

required = ["Unified final gate"]
authority = {
    "repository": {
        "default_branch": "master",
        "security_and_analysis": {
            "secret_scanning": {"status": "enabled"},
            "secret_scanning_push_protection": {"status": "enabled"},
        },
    },
    "rulesets": [{
        "id": 1,
        "name": "default branch production gate",
        "target": "branch",
        "enforcement": "active",
        "conditions": {"ref_name": {"include": ["~DEFAULT_BRANCH"], "exclude": []}},
        "bypass_actors": [],
        "current_user_can_bypass": "never",
        "rules": [
            {
                "type": "pull_request",
                "parameters": copy.deepcopy(governance_gate.EXPECTED_PULL_REQUEST_PARAMETERS),
            },
            {"type": "deletion"},
            {"type": "non_fast_forward"},
            {
                "type": "required_status_checks",
                "parameters": {
                    "strict_required_status_checks_policy": True,
                    "required_status_checks": [{"context": "Unified final gate"}],
                },
            },
        ],
    }],
}

assert required_gate.enforced_contexts(authority) == set(required)
assert required_gate.matrix_legs(
    {"strategy": {"matrix": {"include": [{"language": "python"}, {"language": "actions"}]}}},
    "CodeQL (${{ matrix.language }})",
) == ["CodeQL (python)", "CodeQL (actions)"]
_, errors = governance_gate.audit_authority(authority, required)
assert errors == [], errors

log_safe_report = governance_gate.safe_diagnostic_report(
    {
        "checks": {
            "passing_control": {"ok": True, "detail": "SENTINEL_PASS_PAYLOAD"},
            "secret_scanning_enabled": {"ok": False, "detail": "SENTINEL_SECRET_PAYLOAD"},
        },
    },
    "fixture:C:/SENTINEL_SECRET_PATH",
)
serialized_log_safe_report = json.dumps(log_safe_report, sort_keys=True)
assert "SENTINEL" not in serialized_log_safe_report, serialized_log_safe_report
assert log_safe_report["authority_source"] == "fixture"
assert log_safe_report["failed_checks"] == ["secret_scanning_enabled"]
assert log_safe_report["checks"] == {
    "passing_control": {"ok": True},
    "secret_scanning_enabled": {"ok": False},
}

mutations = []
bad = copy.deepcopy(authority)
bad["rulesets"][0]["bypass_actors"] = [{"actor_id": 1}]
mutations.append(("ruleset bypass", bad, "no_ruleset_bypass"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"] = [rule for rule in bad["rulesets"][0]["rules"] if rule["type"] != "pull_request"]
mutations.append(("missing pull request rule", bad, "pull_request_required"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["required_review_thread_resolution"] = False
mutations.append(("review threads need not be resolved", bad, "required_review_thread_resolution"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["require_extra_approval_for_unattributed_changes"] = False
mutations.append(("unattributed changes need no extra approval", bad, "extra_unattributed_change_approval"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["allowed_merge_methods"] = ["merge", "squash"]
mutations.append(("non-merge method allowed", bad, "allowed_merge_methods_exact"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["required_approving_review_count"] = 1
mutations.append(("human approval introduced for single maintainer", bad, "required_approvals_exact_zero"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["require_code_owner_review"] = True
mutations.append(("code owner approval introduced", bad, "single_maintainer_review_shape_exact"))
bad = copy.deepcopy(authority)
del bad["rulesets"][0]["rules"][0]["parameters"]["required_reviewers"]
mutations.append(("pull request parameter omitted", bad, "pull_request_parameter_shape_exact"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["dismiss_stale_reviews_on_push"] = 0
mutations.append(("boolean parameter encoded as integer", bad, "pull_request_parameter_types_exact"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][0]["parameters"]["unexpected_policy"] = False
mutations.append(("unknown pull request parameter", bad, "pull_request_parameter_shape_exact"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"].insert(1, copy.deepcopy(bad["rulesets"][0]["rules"][0]))
mutations.append(("duplicate applicable pull request rule", bad, "single_applicable_pull_request_rule"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][3]["parameters"]["strict_required_status_checks_policy"] = False
mutations.append(("non-strict required checks", bad, "strict_required_status_checks"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["rules"][3]["parameters"]["required_status_checks"].append({"context": "Undeclared context"})
mutations.append(("extra required context", bad, "required_status_contexts_exact"))
bad = copy.deepcopy(authority)
bad["rulesets"][0]["conditions"]["ref_name"]["include"] = ["refs/heads/master"]
mutations.append(("non-default ruleset selector", bad, "active_default_branch_ruleset_present"))
bad = copy.deepcopy(authority)
del bad["repository"]["security_and_analysis"]
bad["repository"]["private"] = False
bad["repository"]["visibility"] = "public"
mutations.append(("security settings omitted for public repository", bad, "security_settings_observable"))
bad = copy.deepcopy(authority)
bad["repository"]["security_and_analysis"]["secret_scanning"]["status"] = "disabled"
mutations.append(("secret scanning disabled", bad, "secret_scanning_enabled"))
bad = copy.deepcopy(authority)
bad["repository"]["security_and_analysis"]["secret_scanning_push_protection"]["status"] = "disabled"
mutations.append(("push protection disabled", bad, "push_protection_enabled"))
bad = copy.deepcopy(authority)
bad["repository"]["security_and_analysis"] = {}
mutations.append(("security settings malformed", bad, "secret_scanning_enabled"))

for name, candidate, expected_control in mutations:
    evidence, candidate_errors = governance_gate.audit_authority(candidate, required)
    assert candidate_errors, f"unsafe governance mutation {name!r} was accepted"
    assert evidence["checks"][expected_control]["ok"] is False, (name, evidence["checks"])
    assert all(check["ok"] in (True, False) for check in evidence["checks"].values()), (
        f"governance mutation {name!r} produced a non-binary gate",
        evidence["checks"],
    )

original_gh_json = governance_gate._gh_json
previous_fixture_for_api_test = os.environ.pop("PRSTUDIO_GOVERNANCE_FIXTURE", None)


def denied_api(_endpoint: str):
    raise RuntimeError("simulated GitHub API denial")


try:
    governance_gate._gh_json = denied_api
    try:
        governance_gate.load_authority()
    except RuntimeError as exc:
        assert "simulated GitHub API denial" in str(exc)
    else:
        raise AssertionError("GitHub API denial did not fail governance authority loading")
finally:
    governance_gate._gh_json = original_gh_json
    if previous_fixture_for_api_test is not None:
        os.environ["PRSTUDIO_GOVERNANCE_FIXTURE"] = previous_fixture_for_api_test

with tempfile.TemporaryDirectory(prefix="rp-governance-regression-") as directory:
    fixture = Path(directory) / "authority.json"
    fixture.write_text(json.dumps(authority), encoding="utf-8")
    previous_fixture = os.environ.get("PRSTUDIO_GOVERNANCE_FIXTURE")
    previous_actions = os.environ.get("GITHUB_ACTIONS")
    try:
        os.environ["PRSTUDIO_GOVERNANCE_FIXTURE"] = str(fixture)
        os.environ.pop("GITHUB_ACTIONS", None)
        loaded, source = governance_gate.load_authority()
        assert loaded == authority and source.startswith("fixture:")
        assert required_gate.load_authority() == authority

        negative_fixture = Path(directory) / "authority-security-settings-omitted.json"
        negative_authority = copy.deepcopy(authority)
        del negative_authority["repository"]["security_and_analysis"]
        negative_authority["repository"].update({"private": False, "visibility": "public"})
        negative_fixture.write_text(json.dumps(negative_authority), encoding="utf-8")
        os.environ["PRSTUDIO_GOVERNANCE_FIXTURE"] = str(negative_fixture)
        captured = io.StringIO()
        with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
            assert governance_gate.main() == 1, "negative governance fixture did not fail the CLI gate"
        assert "security_settings_observable" in captured.getvalue()

        os.environ["PRSTUDIO_GOVERNANCE_FIXTURE"] = str(fixture)
        os.environ["GITHUB_ACTIONS"] = "true"
        for loader in (governance_gate.load_authority, required_gate.load_authority):
            try:
                loader()
            except RuntimeError:
                pass
            else:
                raise AssertionError("GitHub Actions accepted offline authority")
    finally:
        if previous_fixture is None:
            os.environ.pop("PRSTUDIO_GOVERNANCE_FIXTURE", None)
        else:
            os.environ["PRSTUDIO_GOVERNANCE_FIXTURE"] = previous_fixture
        if previous_actions is None:
            os.environ.pop("GITHUB_ACTIONS", None)
        else:
            os.environ["GITHUB_ACTIONS"] = previous_actions

assert b"\x08" not in (ROOT / "tests/validate-required-checks.py").read_bytes()
assert required_gate.declared_contexts() == required

workflow = (ROOT / ".github/workflows/unified-h24-control.yml").read_text(encoding="utf-8", errors="strict")
app_action = "actions/create-github-app-token@67018539274d69449ef7c02e8e71183d1719ab42"
assert workflow.count(app_action) == 1, "governance App token action must be immutable and unique"


def workflow_job(job_id: str) -> str:
    marker = f"\n  {job_id}:\n"
    assert marker in workflow, f"workflow job {job_id!r} is missing"
    body = workflow.split(marker, 1)[1]
    match = re.search(r"(?m)^  [A-Za-z0-9_-]+:\s*$", body)
    return body[:match.start()] if match else body


governance_job = workflow_job("repository_governance")
full_surface_job = workflow_job("full_surface")
unified_gate_job = workflow_job("unified_gate")

assert "    environment: governance-attestation\n" in governance_job, (
    "governance secrets must be protected by the dedicated governance-attestation Environment"
)
assert "${{ secrets." not in full_surface_job, "full-surface execution must not consume repository secrets"
assert "governance-app-token.outputs.token" not in full_surface_job, (
    "governance credentials must not enter the broad full-surface job"
)
assert workflow.count("${{ secrets.") == 1, "only the dedicated governance attestor may consume an Actions secret"
assert "${{ secrets.RP_GOVERNANCE_APP_PRIVATE_KEY }}" in governance_job
for pinned_action in (
    "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1",
    "actions/setup-python@5fda3b95a4ea91299a34e894583c3862153e4b97",
    app_action,
):
    assert pinned_action in governance_job, f"dedicated governance job lacks pinned action {pinned_action!r}"
for command in (
    "python tests/validate-required-checks.py",
    "python tests/repository-governance.py",
    "python tests/governance-gates-regression.py",
):
    assert command in governance_job, f"dedicated governance job lacks blocking command {command!r}"
for command in (
    "python tests/validate-test-inventory.py",
    "python tests/full_surface_execution_constitution.py",
    "python tests/test-wiring-audit.py",
):
    assert command in full_surface_job, f"full-surface inventory/wiring command was lost {command!r}"
assert re.search(r"(?m)^\s*-\s*repository_governance\s*$", unified_gate_job)
assert "test '${{ needs.repository_governance.result }}' = success" in unified_gate_job

for fragment in (
    "app-id: ${{ vars.RP_GOVERNANCE_APP_ID }}",
    "private-key: ${{ secrets.RP_GOVERNANCE_APP_PRIVATE_KEY }}",
    "permission-administration: read",
    "permission-metadata: read",
    "skip-token-revoke: false",
    "GH_TOKEN: ${{ steps.governance-app-token.outputs.token }}",
    "GITHUB_TOKEN: ${{ steps.governance-app-token.outputs.token }}",
):
    assert fragment in governance_job, f"least-privilege governance token wiring missing {fragment!r}"
token_step = governance_job.split(app_action, 1)[1].split("\n      - ", 1)[0]
assert "owner:" not in token_step and "repositories:" not in token_step, (
    "governance App token must retain the action's current-repository-only default scope"
)
permission_inputs = {
    line.strip()
    for line in token_step.splitlines()
    if line.strip().startswith("permission-")
}
assert permission_inputs == {"permission-administration: read", "permission-metadata: read"}, (
    f"governance App token permissions are not exact least privilege: {sorted(permission_inputs)!r}"
)
assert "permission-administration: write" not in governance_job
assert "skip-token-revoke: true" not in governance_job
print("GOVERNANCE_GATE_REGRESSION: PASS")
