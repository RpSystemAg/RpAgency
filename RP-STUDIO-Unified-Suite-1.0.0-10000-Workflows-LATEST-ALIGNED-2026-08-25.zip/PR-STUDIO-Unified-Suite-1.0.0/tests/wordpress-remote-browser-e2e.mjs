import { spawn, spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import {
  canonicalRemoteE2EFailureEvidence,
  canonicalRemoteE2EEvidence,
  sanitizeLogValue,
  writeBoundedJsonArtifact,
  writeBoundedTextArtifact,
} from '../.github/scripts/security-artifact-boundaries.mjs';

const sleep = (ms) => new Promise((resolvePromise) => setTimeout(resolvePromise, ms));
const startedAt = new Date().toISOString();
const wpUrl = String(process.env.WP_URL || 'http://127.0.0.1:8082').replace(/\/+$/, '');
const wpPath = String(process.env.WP_PATH || '/tmp/prstudio-wp');
const wpCli = String(process.env.WP_CLI || '/tmp/wp-cli.phar');
const chrome = String(process.env.CHROME_BIN || '/usr/bin/google-chrome-stable');
const originA = String(process.env.REMOTE_E2E_ORIGIN_A || 'http://127.0.0.1:8083').replace(/\/+$/, '');
const originB = String(process.env.REMOTE_E2E_ORIGIN_B || 'http://127.0.0.1:8084').replace(/\/+$/, '');
const extensionDir = resolve('prstudio-unified-browser-agent');
const artifactDir = resolve('artifacts/remote-wordpress-chrome');
const forbiddenCodes = [
  'technical_tab_not_controlled',
  'target_origin_mismatch',
  'contract_executor_missing',
  'cdp_protocol_incompatible',
];
const exceptionGroupPattern = /\b(?:Base)?ExceptionGroup\b/i;

for (const [label, path] of [['Chrome', chrome], ['WP-CLI', wpCli], ['WordPress', wpPath], ['extension', extensionDir]]) {
  if (!existsSync(path)) throw new Error(`${label}_missing:${path}`);
}
await mkdir(artifactDir, { recursive: true });

const versionProbe = spawnSync(chrome, ['--version'], { encoding: 'utf8' });
const binaryVersion = `${versionProbe.stdout || ''}${versionProbe.stderr || ''}`.trim();
if (versionProbe.status !== 0 || !/Google Chrome|Chrome for Testing/i.test(binaryVersion) || /Chromium/i.test(binaryVersion)) {
  throw new Error(`google_chrome_required:${chrome}:${binaryVersion}`);
}

function wpEval(code) {
  const result = spawnSync('php', [wpCli, 'eval', code, `--path=${wpPath}`], {
    encoding: 'utf8', timeout: 30000, maxBuffer: 8 * 1024 * 1024,
  });
  if (result.status !== 0) {
    throw new Error(`wp_eval_failed:${String(result.stderr || result.stdout).slice(0, 4000)}`);
  }
  return String(result.stdout || '').trim();
}

function wpJson(code) {
  const output = wpEval(code);
  const lines = output.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try { return JSON.parse(lines[index]); } catch {}
  }
  throw new Error(`wp_json_invalid:${output.slice(0, 4000)}`);
}

function phpJsonLiteral(value) {
  return Buffer.from(JSON.stringify(value), 'utf8').toString('base64');
}

function createRemoteTask(deviceId, action, args) {
  const encoded = phpJsonLiteral(args);
  const code = `$a=json_decode(base64_decode('${encoded}'),true);$r=PRSTUDIO_UC_Job_Engine::create_browser_task('${action}',$a,'${deviceId}','');echo wp_json_encode($r);`;
  const task = wpJson(code);
  if (!task?.task_uuid) throw new Error(`remote_task_create_failed:${JSON.stringify(task)}`);
  return task;
}

function readRemoteTask(taskId) {
  return wpJson(`$r=PRSTUDIO_UC_Store::get_task('${taskId}');echo wp_json_encode($r);`);
}

async function waitRemoteTask(taskId, timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  let last = null;
  while (Date.now() < deadline) {
    last = readRemoteTask(taskId);
    const status = String(last?.status || '').toLowerCase();
    if (status === 'completed') return last;
    if (['failed', 'cancelled', 'expired', 'technical_error', 'dead_letter'].includes(status)) {
      throw new Error(`remote_task_terminal_failure:${taskId}:${status}:${JSON.stringify(last?.error || {})}`);
    }
    await sleep(300);
  }
  throw new Error(`remote_task_timeout:${taskId}:${JSON.stringify({status:last?.status,step_index:last?.step_index,error:last?.error})}`);
}

const userDataDir = await mkdtemp(join(tmpdir(), 'prstudio-remote-owned-'));
const debugPort = 9600 + (process.pid % 250);
const chromeArgs = [
  '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-background-networking',
  '--disable-default-apps', '--disable-sync', '--no-first-run',
  `--remote-debugging-port=${debugPort}`,
  `--user-data-dir=${userDataDir}`,
  `--disable-extensions-except=${extensionDir}`,
  `--load-extension=${extensionDir}`,
  'about:blank',
];
const child = spawn(chrome, chromeArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
let chromeStdout = '';
let chromeStderr = '';
child.stdout.on('data', (chunk) => { chromeStdout = (chromeStdout + chunk.toString()).slice(-500000); });
child.stderr.on('data', (chunk) => { chromeStderr = (chromeStderr + chunk.toString()).slice(-500000); });

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${response.status}:${url}`);
  return response.json();
}

async function waitChrome() {
  let last;
  for (let i = 0; i < 200; i += 1) {
    try {
      const version = await fetchJson(`http://127.0.0.1:${debugPort}/json/version`);
      if (version?.webSocketDebuggerUrl) return version;
    } catch (error) { last = error; }
    await sleep(100);
  }
  throw last || new Error('chrome_devtools_unavailable');
}

class Cdp {
  constructor(url) {
    this.ws = new WebSocket(url);
    this.id = 1;
    this.pending = new Map();
    this.opened = new Promise((resolvePromise, reject) => {
      this.ws.addEventListener('open', resolvePromise, { once: true });
      this.ws.addEventListener('error', () => reject(new Error('browser_cdp_open_failed')), { once: true });
    });
    this.ws.addEventListener('message', (event) => {
      const msg = JSON.parse(String(event.data));
      if (!msg.id) return;
      const waiter = this.pending.get(msg.id);
      if (!waiter) return;
      this.pending.delete(msg.id);
      clearTimeout(waiter.timer);
      if (msg.error) waiter.reject(new Error(`CDP ${waiter.method}: ${JSON.stringify(msg.error)}`));
      else waiter.resolve(msg.result);
    });
  }
  async send(method, params = {}, sessionId = undefined, timeoutMs = 15000) {
    await this.opened;
    const id = this.id++;
    return new Promise((resolvePromise, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`cdp_timeout:${method}`)); }, timeoutMs);
      this.pending.set(id, { resolve: resolvePromise, reject, timer, method });
      const payload = { id, method, params };
      if (sessionId) payload.sessionId = sessionId;
      this.ws.send(JSON.stringify(payload));
    });
  }
  close() { try { this.ws.close(); } catch {} }
}

async function attachPage(cdp, targetId) {
  const attached = await cdp.send('Target.attachToTarget', { targetId, flatten: true });
  await cdp.send('Runtime.enable', {}, attached.sessionId);
  await cdp.send('Page.enable', {}, attached.sessionId);
  return attached.sessionId;
}

async function evaluate(cdp, sessionId, expression, timeoutMs = 15000) {
  const result = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true }, sessionId, timeoutMs);
  if (result.exceptionDetails) throw new Error(`runtime_evaluate_failed:${result.exceptionDetails.text || 'exception'}`);
  return result.result?.value;
}

async function waitExpression(cdp, sessionId, expression, label, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  let last;
  while (Date.now() < deadline) {
    try {
      last = await evaluate(cdp, sessionId, expression, 5000);
      if (last) return last;
    } catch (error) { last = String(error?.message || error); }
    await sleep(150);
  }
  throw new Error(`wait_expression_timeout:${label}:${JSON.stringify(last)}`);
}

async function waitPairedPollingStatus(cdp, sessionId, expectedDeviceId, label, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  let last;
  while (Date.now() < deadline) {
    try {
      // Keep the browser program static. The device identifier originates at
      // the real WordPress boundary and must be compared as data in Node, not
      // interpolated into Runtime.evaluate source code.
      last = await evaluate(
        cdp,
        sessionId,
        `(async()=>{const s=await chrome.runtime.sendMessage({type:'status'});return s||null;})()`,
        5000,
      );
      if (last?.paired === true && last?.deviceId === expectedDeviceId && last?.pollLoopRunning === true) return last;
    } catch (error) { last = String(error?.message || error); }
    await sleep(150);
  }
  throw new Error(`wait_paired_polling_status_timeout:${label}:${JSON.stringify(last)}`);
}

async function targets(cdp) { return (await cdp.send('Target.getTargets')).targetInfos || []; }

async function waitWorker(cdp, previousTargetId = '') {
  let last = [];
  for (let i = 0; i < 200; i += 1) {
    last = await targets(cdp);
    const worker = last.find((target) => target.type === 'service_worker'
      && String(target.url || '').startsWith('chrome-extension://')
      && String(target.url || '').endsWith('/service-worker-bootstrap.js')
      && (!previousTargetId || target.targetId !== previousTargetId));
    if (worker) return worker;
    await sleep(100);
  }
  throw new Error(`mv3_worker_missing:${JSON.stringify(last.slice(0, 30))}`);
}

async function waitTargetGone(cdp, targetId) {
  for (let i = 0; i < 50; i += 1) {
    if (!(await targets(cdp)).some((target) => target.targetId === targetId)) return true;
    await sleep(100);
  }
  throw new Error('mv3_terminated_target_still_present');
}

function publicTask(row) {
  return {
    task_uuid: row?.task_uuid || '', status: row?.status || '', action: row?.action || '',
    step_index: row?.step_index ?? null, attempt_count: row?.attempt_count ?? null,
    checkpoint: row?.checkpoint || null, verification: row?.verification || null,
    has_result: Boolean(row?.result), error: row?.error || null,
  };
}

function flowStepResults(row) {
  const result = row?.checkpoint?.last_result || row?.result || null;
  const rows = Array.isArray(result?.results) ? result.results : [];
  return rows.map((item) => item?.result || null).filter((item) => item && typeof item === 'object');
}

const evidence = {
  schema_version: '1.0.0', ok: false, started_at: startedAt,
  chrome_binary: chrome, chrome_binary_version: binaryVersion,
  wp_url: wpUrl, origins: [originA, originB], checks: [], tasks: [],
};
async function persistRemoteEvidence() {
  return writeBoundedJsonArtifact(artifactDir, 'remote-e2e.json', canonicalRemoteE2EEvidence(evidence), { maxBytes: 64 * 1024 });
}
async function persistRemoteFailure(error) {
  return writeBoundedJsonArtifact(
    artifactDir,
    'remote-e2e.json',
    canonicalRemoteE2EFailureEvidence(evidence, error),
    { maxBytes: 64 * 1024 },
  );
}
function check(name, ok, detail = {}) {
  evidence.checks.push({ name, ok: Boolean(ok), at: new Date().toISOString(), ...detail });
  if (!ok) throw new Error(`${name}:${JSON.stringify(detail)}`);
  console.log(`PASS ${name}`);
}

function exceptionGroupPaths(value, path = '$', seen = new WeakSet(), matches = []) {
  if (typeof value === 'string') {
    if (exceptionGroupPattern.test(value)) matches.push(path);
    return matches;
  }
  if (!value || typeof value !== 'object') return matches;
  if (seen.has(value)) return matches;
  seen.add(value);
  for (const [key, nested] of Object.entries(value)) {
    if (exceptionGroupPattern.test(String(key))) matches.push(`${path}.${key}`);
    exceptionGroupPaths(nested, `${path}.${key}`, seen, matches);
  }
  return matches;
}

function assertNoExceptionGroup(stage, ...values) {
  const matches = values.flatMap((value, index) => exceptionGroupPaths(value, `$[${index}]`));
  check(`${stage} never exposes or propagates ExceptionGroup`, matches.length === 0, { matches });
}

let cdp;
let extensionId = '';
let extensionTargetId = '';
let extensionSessionId = '';
let workerTarget = null;
let deviceId = '';

async function extensionEval(expression, timeoutMs = 15000) {
  return evaluate(cdp, extensionSessionId, expression, timeoutMs);
}
async function storageSnapshot() {
  return extensionEval(`chrome.storage.local.get(['prstudioConfig','prstudioTabRegistry','prstudioTabAffinity','prstudioLastAgentTab','prstudioLogs','prstudioRuntimeSessions'])`);
}
async function assertNoForbiddenErrors(stage) {
  const snapshot = await storageSnapshot();
  const text = JSON.stringify(snapshot?.prstudioLogs || []).toLowerCase();
  const found = forbiddenCodes.filter((code) => text.includes(code));
  check(`no forbidden production error after ${stage}`, found.length === 0, { found });
}
function ownedRows(snapshot) {
  const raw = snapshot?.prstudioTabRegistry || {};
  return Object.values(raw).filter((row) => row && typeof row === 'object').map((row) => ({
    tabId: Number(row.tabId || 0), windowId: Number(row.windowId || 0), laneId: String(row.laneId || ''),
    taskId: String(row.taskId || ''), url: String(row.url || ''), expectedOrigin: String(row.expectedOrigin || ''),
    provisional: Boolean(row.provisional), ownership: String(row.ownership || row.owner || ''),
  }));
}

try {
  const chromeVersion = await waitChrome();
  evidence.chrome_product = chromeVersion.Browser || '';
  evidence.chrome_protocol_version = chromeVersion['Protocol-Version'] || '';
  cdp = new Cdp(chromeVersion.webSocketDebuggerUrl);
  check('Google Chrome process is real', /Chrome\//.test(evidence.chrome_product) && !/Chromium/i.test(evidence.chrome_product), { product: evidence.chrome_product });

  workerTarget = await waitWorker(cdp);
  extensionId = String(workerTarget.url).split('/')[2] || '';
  evidence.extension_id = extensionId;
  evidence.service_worker_target = workerTarget.url;
  check('exact MV3 bootstrap service worker is live', Boolean(extensionId) && workerTarget.url.endsWith('/service-worker-bootstrap.js'), { worker: workerTarget.url });

  const extensionTarget = await cdp.send('Target.createTarget', { url: `chrome-extension://${extensionId}/sidepanel.html` });
  extensionTargetId = extensionTarget.targetId;
  extensionSessionId = await attachPage(cdp, extensionTargetId);
  await waitExpression(cdp, extensionSessionId, `document.readyState === 'complete'`, 'extension page ready');
  const identity = await extensionEval(`(async()=>{const m=await import(chrome.runtime.getURL('lib/executor-meta.js'));return {manifest:chrome.runtime.getManifest().manifest_version,version:chrome.runtime.getManifest().version,build:m.EXECUTOR_BUILD_ID,source:m.EXECUTOR_SOURCE_SHA,builtAt:m.EXECUTOR_BUILD_TIMESTAMP,protocol:m.EXECUTOR_PROTOCOL_VERSION,capabilityHash:m.CAPABILITY_CONTRACT_SHA256,gsc:m.GSC_DIMENSION_SESSION_VERSION,ua:navigator.userAgent};})()`);
  evidence.browser_agent_identity = identity;
  check('Browser Agent build is bound to Git', /^prstudio-browser-1\.0\.0\+git\.[0-9a-f]{12}$/.test(identity?.build || '') && /^[0-9a-f]{40}$/.test(identity?.source || '') && identity?.builtAt !== 'UNSTAMPED', identity || {});
  check('Browser Agent contract identity is v4-compatible', identity?.protocol === '3.0.0' && identity?.gsc === '4.0.0' && /^[0-9a-f]{64}$/.test(identity?.capabilityHash || ''), identity || {});
  check('Chrome user agent is Chrome', /Chrome\//.test(identity?.ua || '') && !/Chromium/i.test(identity?.ua || ''), { ua: identity?.ua || '' });

  const pairingCode = wpEval(`echo PRSTUDIO_UC_Auth::create_pairing_code();`);
  if (!/^[A-Z0-9_-]{4,}$/.test(pairingCode)) throw new Error(`pairing_code_invalid_length:${pairingCode.length}`);
  const pairResult = await extensionEval(`chrome.runtime.sendMessage(${JSON.stringify({type:'pair', siteUrl:wpUrl, code:pairingCode, name:'CI Remote Ownership Certification'})})`, 25000);
  const pairError = pairResult?.error && typeof pairResult.error === 'object' ? pairResult.error : null;
  check('real WordPress pairing request is accepted', pairResult?.ok === true, {
    responseOk: pairResult?.ok === true,
    responseHasDeviceId: Boolean(pairResult?.deviceId),
    error: pairError ? {
      name: String(pairError.name || ''),
      code: String(pairError.code || ''),
      message: String(pairError.message || '').slice(0, 1000),
      details: pairError.details && typeof pairError.details === 'object' ? pairError.details : null,
    } : null,
  });
  const paired = await waitExpression(
    cdp,
    extensionSessionId,
    `(async()=>{const s=await chrome.storage.local.get(['prstudioConfig']);return s?.prstudioConfig?.deviceId?s:null;})()`,
    'paired Browser Agent config persisted',
    10000,
  );
  deviceId = String(paired?.prstudioConfig?.deviceId || '');
  evidence.device_uuid = deviceId;
  check('paired device UUID is persisted', /^[a-f0-9-]{20,64}$/i.test(deviceId), { deviceId });
  const initialStatus = await waitPairedPollingStatus(
    cdp,
    extensionSessionId,
    deviceId,
    'initial paired remote polling state',
    20000,
  );
  check('status returns the live paired Browser Agent state', initialStatus?.paired === true && initialStatus?.deviceId === deviceId && initialStatus?.pollLoopRunning === true, {
    paired:initialStatus?.paired === true,
    deviceMatches:initialStatus?.deviceId === deviceId,
    polling:initialStatus?.pollLoopRunning === true,
  });
  assertNoExceptionGroup('status', initialStatus);
  await assertNoForbiddenErrors('pairing');

  const laneA = 'ci-remote-lane-a';
  const firstArgs = {
    _prstudio_lane_id: laneA,
    steps: [
      { type: 'open_tab', url: `${originA}/parity-a.html`, expectedOrigin: originA },
      { type: 'wait_selector', selector: '#parity-button', timeoutMs: 10000 },
      {
        type: 'javascript_exec',
        script: `(()=>{const probe=document.createElement('div');probe.id='prstudio-native-event-probe';probe.hidden=true;document.body.appendChild(probe);const events=[];const record=(event)=>{events.push({type:String(event.type||''),isTrusted:event.isTrusted===true,targetId:String(event.target?.id||''),button:Number(event.button??-1),buttons:Number(event.buttons??0),at:Number(performance.now().toFixed(3))});probe.textContent=JSON.stringify(events)};for(const type of ['pointerdown','mousedown','pointerup','mouseup','click','wheel'])document.addEventListener(type,record,{capture:true,passive:true});addEventListener('scroll',record,{capture:true,passive:true});document.body.style.minHeight='2200px';return true})()`,
        risk: 'identity',
      },
      { type: 'fill', selector: '#parity-input', value: 'remote-owned-one' },
      { type: 'press', selector: '#parity-input', key: 'End' },
      { type: 'click', selector: '#parity-button' },
      { type: 'scroll', y: 700 },
      { type: 'wait', ms: 100 },
      { type: 'javascript_exec', script: `console.log('prstudio-remote-console');document.body.dataset.remoteCdp='yes';fetch('/api.json').catch(()=>{});true`, risk: 'identity' },
      { type: 'dom_snapshot' },
      { type: 'accessibility_snapshot' },
      { type: 'screenshot' },
      { type: 'console_report' },
      { type: 'network_report' },
    ],
  };
  const firstCreated = createRemoteTask(deviceId, 'playwright_flow', firstArgs);
  const first = await waitRemoteTask(firstCreated.task_uuid, 75000);
  evidence.tasks.push(publicTask(first));
  check('remote task 1 claimed and completed through tasks/next', String(first.status).toLowerCase() === 'completed' && Number(first.attempt_count || 0) >= 1, publicTask(first));
  check('remote task 1 has checkpoint evidence', Number(first.step_index || 0) >= 1 && Boolean(first.checkpoint), { step_index:first.step_index, checkpoint:Boolean(first.checkpoint) });

  const afterFirst = await storageSnapshot();
  const firstOwned = ownedRows(afterFirst).filter((row) => row.laneId === laneA);
  check('Agent-created task tab is in owned registry', firstOwned.length === 1 && firstOwned[0].tabId > 0, { registry:firstOwned });
  const tabA = firstOwned[0].tabId;
  const firstTaskAffinity = afterFirst?.prstudioTabAffinity?.[first.task_uuid] || null;
  check('task affinity points to the lane-owned tab without replacing lane ownership', firstOwned[0].laneId === laneA && Number(firstTaskAffinity?.tabId || 0) === tabA, { laneId:firstOwned[0].laneId, taskId:first.task_uuid, affinity:firstTaskAffinity });
  const firstFlowResults = flowStepResults(first);
  const nativeFill = firstFlowResults.find((item) => item.stepType === 'fill') || null;
  const nativeClick = firstFlowResults.find((item) => item.stepType === 'click') || null;
  const nativeScroll = firstFlowResults.find((item) => item.stepType === 'scroll') || null;
  check('native fill is verified without DOM recovery', nativeFill?.application_effect_verified === true && nativeFill?.recoveryUsed === false && nativeFill?.replacementStrategy === 'native_keyboard_platform_aware', {
    applicationEffectVerified: nativeFill?.application_effect_verified ?? null,
    recoveryUsed: nativeFill?.recoveryUsed ?? null,
    replacementStrategy: nativeFill?.replacementStrategy || '',
    transport: nativeFill?.transport || '',
  });
  check('native click and wheel were dispatched through the owned CDP path', nativeClick?.executed === true && Number(nativeClick?.dispatched || 0) === 3 && nativeScroll?.executed === true && Number(nativeScroll?.dispatched || 0) === 1, {
    click: nativeClick ? { executed:nativeClick.executed, dispatched:nativeClick.dispatched, transport:nativeClick.transport || '' } : null,
    scroll: nativeScroll ? { executed:nativeScroll.executed, dispatched:nativeScroll.dispatched, transport:nativeScroll.transport || '' } : null,
  });
  const pageState = await extensionEval(`(async()=>{const r=await chrome.scripting.executeScript({target:{tabId:${tabA}},func:()=>{let nativeEvents=[];try{nativeEvents=JSON.parse(document.querySelector('#prstudio-native-event-probe')?.textContent||'[]')}catch{}return {url:location.href,value:document.querySelector('#parity-input')?.value||'',clicked:document.body.dataset.clicked||'',remoteCdp:document.body.dataset.remoteCdp||'',scrollY:Number(scrollY||0),nativeEvents}}});return r?.[0]?.result||null;})()`);
  const buttonEventTypes = (pageState?.nativeEvents || []).filter((event) => event.targetId === 'parity-button').map((event) => event.type);
  const expectedButtonEvents = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];
  const buttonEventsTrusted = (pageState?.nativeEvents || []).filter((event) => event.targetId === 'parity-button').every((event) => event.isTrusted === true);
  const wheelIndex = (pageState?.nativeEvents || []).findIndex((event) => event.type === 'wheel' && event.isTrusted === true);
  const scrollIndex = (pageState?.nativeEvents || []).findIndex((event) => event.type === 'scroll' && event.isTrusted === true);
  check('real Chrome emitted the ordered trusted pointer/click sequence', JSON.stringify(buttonEventTypes) === JSON.stringify(expectedButtonEvents) && buttonEventsTrusted, {
    expected: expectedButtonEvents,
    actual: buttonEventTypes,
    trusted: buttonEventsTrusted,
  });
  check('real Chrome emitted trusted wheel then scroll effects', wheelIndex >= 0 && scrollIndex > wheelIndex && Number(pageState?.scrollY || 0) > 0, {
    wheelIndex,
    scrollIndex,
    scrollY: Number(pageState?.scrollY || 0),
  });
  check('remote fill/click/scroll/CDP mutation reached real page', pageState?.value === 'remote-owned-one' && pageState?.clicked === 'yes' && pageState?.remoteCdp === 'yes' && Number(pageState?.scrollY || 0) > 0, pageState || {});

  const cdpEvidence = await extensionEval(`(async()=>{const d={tabId:${tabA}};let attached=false;try{try{await chrome.debugger.attach(d,'1.3');attached=true;}catch(e){if(!/already attached|another debugger/i.test(String(e?.message||e)))throw e;}const runtime=await chrome.debugger.sendCommand(d,'Runtime.evaluate',{expression:'document.title',returnByValue:true});const dom=await chrome.debugger.sendCommand(d,'DOM.getDocument',{depth:1});const shot=await chrome.debugger.sendCommand(d,'Page.captureScreenshot',{format:'png'});return {protocol:'1.3',title:runtime?.result?.value||'',rootNodeId:dom?.root?.nodeId||0,pngBytes:String(shot?.data||'').length,alreadyAttached:!attached};}finally{if(attached)await chrome.debugger.detach(d);}})()`, 20000);
  evidence.cdp = cdpEvidence;
  check('real Chrome CDP Runtime DOM Page commands succeed', cdpEvidence?.protocol === '1.3' && cdpEvidence?.rootNodeId > 0 && cdpEvidence?.pngBytes > 1000, cdpEvidence || {});
  await assertNoForbiddenErrors('remote task 1');

  const secondCreated = createRemoteTask(deviceId, 'playwright_flow', {
    _prstudio_lane_id: laneA,
    steps: [
      { type: 'navigate', url: `${originB}/parity-b.html`, expectedOrigin: originB },
      { type: 'wait_selector', selector: '#parity-button', timeoutMs: 10000 },
      { type: 'fill', selector: '#parity-input', value: 'remote-cross-origin-two' },
      { type: 'click', selector: '#parity-button' },
      { type: 'screenshot' },
    ],
  });
  const second = await waitRemoteTask(secondCreated.task_uuid, 75000);
  evidence.tasks.push(publicTask(second));
  check('second remote task same lane completes', String(second.status).toLowerCase() === 'completed', publicTask(second));
  const afterSecond = await storageSnapshot();
  const secondOwned = ownedRows(afterSecond).filter((row) => row.laneId === laneA);
  const originalOriginRow = secondOwned.find((row) => row.tabId === tabA) || null;
  const crossOriginRow = secondOwned.find((row) => row.taskId === second.task_uuid) || null;
  const tabCrossOrigin = Number(crossOriginRow?.tabId || 0);
  check('cross-origin task gets a distinct owned tab without stealing the lane origin', secondOwned.length === 2 && originalOriginRow?.taskId === first.task_uuid && tabCrossOrigin > 0 && tabCrossOrigin !== tabA, { before:firstOwned, after:secondOwned });
  check('cross-origin ownership is bound to the exact expected origin', crossOriginRow?.url?.startsWith(originB) && crossOriginRow?.expectedOrigin === originB, { record:crossOriginRow });
  const navigatedFixture = await extensionEval(`(async()=>{const r=await chrome.scripting.executeScript({target:{tabId:${tabCrossOrigin}},func:()=>({href:location.href,value:document.querySelector('#parity-input')?.value||'',clicked:document.body.dataset.clicked||'',readyState:document.readyState})});return r?.[0]?.result||null;})()`);
  check('navigate operates on the real cross-origin fixture and its page effects are observable', navigatedFixture?.href === `${originB}/parity-b.html` && navigatedFixture?.value === 'remote-cross-origin-two' && navigatedFixture?.clicked === 'yes' && navigatedFixture?.readyState === 'complete', navigatedFixture || {});
  assertNoExceptionGroup('navigate', second, flowStepResults(second), navigatedFixture, afterSecond?.prstudioLogs || []);
  await assertNoForbiddenErrors('same-lane cross-origin isolation');

  const oldWorkerId = workerTarget.targetId;
  const closedWorker = await cdp.send('Target.closeTarget', { targetId: oldWorkerId });
  if (closedWorker?.success === false) throw new Error('mv3_worker_termination_refused');
  await waitTargetGone(cdp, oldWorkerId);
  // Per Chrome's MV3 termination guidance, an extension event revives a
  // terminated worker. Use the read-only status contract as the wake/liveness
  // event: unlike local_page_health it does not depend on whichever local or
  // remote tab happens to own window focus. The following polling assertion
  // separately proves that the new worker completed runtime startup.
  const [restartedWorker, restartStatus] = await Promise.all([
    waitWorker(cdp, oldWorkerId),
    extensionEval(`chrome.runtime.sendMessage({type:'status'})`, 15000),
  ]);
  workerTarget = restartedWorker;
  check('MV3 service worker restarts with same extension identity', String(workerTarget.url).startsWith(`chrome-extension://${extensionId}/`) && workerTarget.url.endsWith('/service-worker-bootstrap.js') && workerTarget.targetId !== oldWorkerId && restartStatus?.paired === true && restartStatus?.deviceId === deviceId, {
    worker:workerTarget.url,
    targetChanged:workerTarget.targetId !== oldWorkerId,
    paired:restartStatus?.paired === true,
    deviceMatches:restartStatus?.deviceId === deviceId,
  });
  assertNoExceptionGroup('status wake after service-worker restart', restartStatus);
  const reconnectedStatus = await waitPairedPollingStatus(
    cdp,
    extensionSessionId,
    deviceId,
    'paired remote polling reconnect after MV3 restart',
    20000,
  );
  check('paired remote polling reconnects after MV3 restart', reconnectedStatus?.paired === true && reconnectedStatus?.deviceId === deviceId && reconnectedStatus?.pollLoopRunning === true, {
    paired:reconnectedStatus?.paired === true,
    deviceMatches:reconnectedStatus?.deviceId === deviceId,
    polling:reconnectedStatus?.pollLoopRunning === true,
  });
  assertNoExceptionGroup('status after service-worker restart', reconnectedStatus);
  const afterRestart = await storageSnapshot();
  const restartedRows = ownedRows(afterRestart);
  check('ownership registry survives MV3 restart', [tabA, tabCrossOrigin].every((tabId) => restartedRows.some((row) => row.tabId === tabId && row.laneId === laneA)), { registry:restartedRows });

  const thirdCreated = createRemoteTask(deviceId, 'playwright_flow', {
    _prstudio_lane_id: laneA,
    steps: [
      { type: 'fill', selector: '#parity-input', value: 'after-worker-restart' },
      { type: 'press', selector: '#parity-input', key: 'End' },
      { type: 'click', selector: '#parity-button' },
      { type: 'screenshot' },
    ],
  });
  const third = await waitRemoteTask(thirdCreated.task_uuid, 75000);
  evidence.tasks.push(publicTask(third));
  check('remote task after MV3 restart completes', String(third.status).toLowerCase() === 'completed', publicTask(third));
  const postRestartState = await extensionEval(`(async()=>{const r=await chrome.scripting.executeScript({target:{tabId:${tabCrossOrigin}},func:()=>({value:document.querySelector('#parity-input')?.value||'',clicked:document.body.dataset.clicked||''})});return r?.[0]?.result||null;})()`);
  check('post-restart page runtime remains effective', postRestartState?.value === 'after-worker-restart' && postRestartState?.clicked === 'yes', postRestartState || {});
  const postRestartSnapshot = await storageSnapshot();
  assertNoExceptionGroup('post-restart real fixture operation', third, flowStepResults(third), postRestartState, postRestartSnapshot?.prstudioLogs || []);
  await assertNoForbiddenErrors('MV3 restart recovery task');

  const laneB = 'ci-remote-lane-b';
  const fourthCreated = createRemoteTask(deviceId, 'playwright_flow', {
    _prstudio_lane_id: laneB,
    steps: [
      { type: 'open_tab', url: `${originA}/parity-a.html?second=1`, expectedOrigin: originA },
      { type: 'fill', selector: '#parity-input', value: 'second-owned-tab' },
      { type: 'screenshot' },
    ],
  });
  const fourth = await waitRemoteTask(fourthCreated.task_uuid, 75000);
  evidence.tasks.push(publicTask(fourth));
  const multi = await storageSnapshot();
  const rows = ownedRows(multi);
  const laneBRows = rows.filter((row) => row.laneId === laneB);
  check('multi-tab ownership is independent by lane', rows.some((row) => row.tabId === tabA && row.laneId === laneA) && laneBRows.length === 1 && laneBRows[0].tabId !== tabA, { registry:rows });
  const tabB = laneBRows[0].tabId;

  const closeCreated = createRemoteTask(deviceId, 'playwright_flow', {
    _prstudio_lane_id: laneB,
    // Exact observable parity: close the tab selected by the caller. The
    // executor must not infer another tab from global focus or retry against a
    // different target after the physical close effect.
    steps: [{ type: 'close_tab', tabId: tabB }],
  });
  const closedTask = await waitRemoteTask(closeCreated.task_uuid, 60000);
  evidence.tasks.push(publicTask(closedTask));
  const finalSnapshot = await storageSnapshot();
  const finalRows = ownedRows(finalSnapshot);
  const tabBExists = await extensionEval(`(async()=>{try{await chrome.tabs.get(${tabB});return true;}catch{return false;}})()`);
  check('remote close cleans owned tab and registry', tabBExists === false && !finalRows.some((row) => row.tabId === tabB), { tabB, registry:finalRows });
  check('primary owned tab remains controlled after other tab closes', finalRows.some((row) => row.tabId === tabA && row.laneId === laneA), { tabA, registry:finalRows });
  await assertNoForbiddenErrors('multi-tab close cleanup');

  const controlIdentity = wpJson(`echo wp_json_encode(json_decode(file_get_contents(PRSTUDIO_UC_DIR.'BUILD-INFO.json'),true));`);
  evidence.control_identity = controlIdentity;
  check('Control build identity is bound to same source SHA', /^prstudio-control-1\.0\.0\+git\.[0-9a-f]{12}$/.test(controlIdentity?.build_id || '') && controlIdentity?.source_commit === identity?.source && controlIdentity?.built_at_utc !== 'UNSTAMPED', { build_id:controlIdentity?.build_id, source_commit:controlIdentity?.source_commit });
  check('Browser and Control contract/protocol hashes are identical', controlIdentity?.contract_file_sha256 === (await extensionEval(`(async()=>{const b=await fetch(chrome.runtime.getURL('BUILD-INFO.json')).then(r=>r.json());return b.control_contract_sha256;})()`)) && controlIdentity?.protocol_file_sha256 === (await extensionEval(`(async()=>{const b=await fetch(chrome.runtime.getURL('BUILD-INFO.json')).then(r=>r.json());return b.control_protocol_sha256;})()`)), { contract_sha256:controlIdentity?.contract_file_sha256, protocol_sha256:controlIdentity?.protocol_file_sha256 });

  evidence.ownership_registry = finalRows;
  evidence.tab_affinity = finalSnapshot?.prstudioTabAffinity || {};
  evidence.total_remote_checks = evidence.checks.length;
  evidence.ok = evidence.checks.every((row) => row.ok) && evidence.tasks.every((row) => String(row.status).toLowerCase() === 'completed');
  check('final remote E2E acceptance', evidence.ok, { checks:evidence.total_remote_checks, tasks:evidence.tasks.length });
  evidence.finished_at = new Date().toISOString();
  await persistRemoteEvidence();
  console.log(`PASS remote WordPress→Chrome E2E: ${evidence.checks.length} checks, ${evidence.tasks.length} remote tasks`);
} catch (error) {
  evidence.error = { code:String(error?.code || error?.message || error).split(':', 1)[0] };
  evidence.finished_at = new Date().toISOString();
  try {
    await persistRemoteFailure(error);
    console.error('FAIL remote WordPress→Chrome E2E; redacted canonical diagnostic persisted as remote-e2e.json');
  } catch (diagnosticError) {
    console.error(`FAIL remote WordPress→Chrome E2E; diagnostic artifact persistence failed:${sanitizeLogValue(String(diagnosticError?.message || diagnosticError).split(':', 1)[0], 160)}`);
  }
  process.exitCode = 1;
} finally {
  await writeBoundedTextArtifact(artifactDir, 'chrome-stdout.log', chromeStdout, { maxBytes: 1024 * 1024 }).catch(() => {});
  await writeBoundedTextArtifact(artifactDir, 'chrome-stderr.log', chromeStderr, { maxBytes: 1024 * 1024 }).catch(() => {});
  try { cdp?.close(); } catch {}
  try { child.kill('SIGKILL'); } catch {}
  await sleep(150);
  await rm(userDataDir, { recursive: true, force: true });
}
