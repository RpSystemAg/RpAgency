#!/usr/bin/env python3
from __future__ import annotations
import json, runpy
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CAP=ROOT/'prstudio-unified-control/capabilities'
OUT=ROOT/'quality/atomic-cases.json'
AUDIT=runpy.run_path(str(ROOT/'tests/rigorous-audit-controller.py'))
EXEC_INDEX=AUDIT['php_executor_index']()


def refs(cap:dict)->list[str]:
    cid=str(cap.get('id','')).lower(); domain=str(cap.get('domain','')).lower()
    if cap.get('browser_required') or domain=='browser' or cid.startswith('browser.'):
        return ['chrome_extensions']
    if any(x in domain for x in ('commerce','product','order','woocommerce')) or any(x in cid for x in ('commerce.','product','order')):
        return ['woocommerce_rest','wordpress_rest']
    if any(x in domain for x in ('security','identity','auth')) or any(x in cid for x in ('oauth','security','session')):
        return ['wordpress_security','wordpress_rest']
    if domain in {'mcp','connector'} or 'mcp' in cid:
        return ['mcp_2026_07_28','openai_remote_mcp']
    return ['wordpress_rest']


def main()->int:
    sources=[]
    for name in ('capability-registry.json','agency-capabilities.json'):
        p=CAP/name; doc=json.loads(p.read_text(encoding='utf-8'))
        for row in doc.get('capabilities',[]):
            sources.append((p,row))
    ids=[str(c['id']) for _,c in sources]
    if len(ids)!=len(set(ids)):
        raise SystemExit('duplicate canonical capability IDs')
    cases={}
    for contract_file,cap in sorted(sources,key=lambda x:str(x[1]['id'])):
        cid=str(cap['id']); executor=str(cap['executor']); cls,method=executor.split('::',1)
        info=EXEC_INDEX.get(cls)
        if not info or method not in info.get('methods',set()):
            raise SystemExit(f'unresolved executor {cid}: {executor}')
        digest=__import__('hashlib').sha256(cid.encode()).hexdigest()[:16]
        cases[cid]={
          'environment':'source',
          'implementation':{'file':str(info['path']),'symbol':method},
          'fixture':f'canonical capability descriptor {cid}',
          'valid_input':{'descriptor_contract':'schema_validated_defaults'},
          'timeout_seconds':20,
          'expected_terminal':'completed_verified',
          'runner':{'command':['python3','tests/atomic-capability-case-runner.py']},
          'oracle':'independent_executor_index_and_negative_resolution',
          'evidence_file':f'evidence/production/atomic-items/{digest}.json',
          'negative_cases':['unknown_capability_rejected','tampered_executor_rejected'],
          'contract':f'{contract_file.relative_to(ROOT).as_posix()}#{cid}',
          'official_refs':refs(cap),
          'environment_evidence':'atomic_runner',
        }
        if cap.get('browser_required'):
            cases[cid]['ownership_negative']='unowned_tab_never_adopted'
            cases[cid]['no_progress_deadline_seconds']=20
    payload={
      'schema_version':1,
      'policy':'Every key under cases is an exact canonical capability ID. Search-index terms, source.action, tool_name and schema properties never count as independent operational items.',
      'generated_from':['prstudio-unified-control/capabilities/capability-registry.json','prstudio-unified-control/capabilities/agency-capabilities.json'],
      'case_count':len(cases),
      'cases':cases,
      'required_fields':['environment','implementation','fixture','valid_input','timeout_seconds','expected_terminal','runner','oracle','evidence_file','negative_cases','contract','official_refs','environment_evidence'],
      'runner_contract':{
        'command':'Non-empty argv array. The runner receives RP_ATOMIC_ITEM_ID and exits non-zero when exact descriptor/executor/negative-oracle checks fail.',
        'evidence_file':'Runner-generated JSON bound to the exact item and release commit when one is available.',
        'no_shell':True,
      },
      'mutation_required_fields':['rollback','idempotency'],
      'browser_required_fields':['ownership_negative','no_progress_deadline_seconds'],
      'remote_required_fields':['live_receipt_class'],
    }
    OUT.write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(f'PASS generated atomic cases: {len(cases)}')
    return 0
if __name__=='__main__': raise SystemExit(main())
