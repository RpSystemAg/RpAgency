#!/usr/bin/env python3
import json, pathlib, sys
R=pathlib.Path(__file__).resolve().parents[1]
idx=json.load(open(R/'prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-25.json',encoding='utf-8'))
build=json.load(open(R/'prstudio-unified-control/BUILD-INFO.json',encoding='utf-8'))
desc=json.load(open(R/'RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json',encoding='utf-8'))
inv=json.load(open(R/'docs/CUMULATIVE-WORKFLOW-INVENTORY-2026-08-25.json',encoding='utf-8'))
expected_waves={'1':300,'2':300,'3':300,'4':380,'5':600,'6':299,'7':200,'8':299,'9':7322}
truth={'workflows':10000,'phases':40715,'domains':178,'tools':123,'caps':1364,'actions':1076}
errors=[]
if idx.get('workflow_count')!=truth['workflows'] or idx.get('phase_count')!=truth['phases'] or idx.get('waves')!=expected_waves or len(idx.get('domains',{}))!=truth['domains']:
    errors.append('authoritative workflow index mismatch')
if (build.get('enterprise_workflow_count'),build.get('enterprise_workflow_phase_count'),build.get('mcp_tool_count'),build.get('capability_count'),build.get('legacy_action_count')) != (truth['workflows'],truth['phases'],truth['tools'],truth['caps'],truth['actions']):
    errors.append('BUILD-INFO current-state counts mismatch')
wc=desc.get('workflow_catalog') or {}
for key,val in [('canonical_workflows',truth['workflows']),('phase_count',truth['phases']),('domain_count',truth['domains']),('public_mcp_tools',truth['tools']),('internal_capabilities',truth['caps']),('legacy_actions',truth['actions'])]:
    if wc.get(key)!=val: errors.append(f'descriptor workflow_catalog.{key} mismatch')
if wc.get('waves')!=expected_waves: errors.append('descriptor Waves 1–9 map mismatch')
if inv.get('canonical_workflow_count')!=truth['workflows'] or inv.get('phase_count')!=truth['phases'] or inv.get('domain_count')!=truth['domains'] or inv.get('waves')!=expected_waves:
    errors.append('cumulative documentation inventory mismatch')
if inv.get('public_mcp_tool_count')!=truth['tools'] or inv.get('canonical_capability_count')!=truth['caps'] or inv.get('legacy_action_count')!=truth['actions']:
    errors.append('cumulative execution-surface inventory mismatch')
checks={
 'RP-STUDIO-CHATGPT-PLUGIN-INSTRUCTIONS-1.0.0.txt':['40.715 fasi grounded','Waves 1–9','123 tool MCP pubblici'],
 'ARCHITECTURE-1.0.0.md':['123 tool tipizzati','10,000 workflow canonici','40,715 fasi grounded','1,364 capability','1,076 action legacy'],
 'RP-STUDIO-CHATGPT-PLUGIN-SETUP-1.0.0.md':['10,000 workflow canonici','40,715 fasi','wave` 1–9','`prstudio_workflow`'],
 'prstudio-unified-control/README.md':['123 bounded tools','1,364 internal capabilities','10,000 executable workflows','40,715 grounded phases'],
 'prstudio-unified-control/readme.txt':['123 typed tools','1,364 capabilities','10,000 executable workflows','40,715 grounded phases'],
 'prstudio-unified-control/workflows/README.md':['10,000','40,715','178','7,322','123 tools','1,364','1,076'],
 'docs/CUMULATIVE-10000-WORKFLOW-ARCHITECTURE-2026-08-25.md':['10,000','40,715','178','Waves 1–9','123 public tools','1,364 canonical capabilities','1,076 legacy actions'],
 'docs/RELEASE-DOCUMENTATION-ALIGNMENT-2026-08-25.md':['10,000','40,715','178','123','1,364','1,076'],
}
for rel,tokens in checks.items():
    p=R/rel
    if not p.is_file(): errors.append(f'missing documentation {rel}'); continue
    text=p.read_text(encoding='utf-8')
    for token in tokens:
        if token not in text: errors.append(f'{rel}: missing aligned token {token!r}')
stale=[('RP-STUDIO-CHATGPT-PLUGIN-INSTRUCTIONS-1.0.0.txt','10.231 fasi grounded'),('ARCHITECTURE-1.0.0.md','122 tool tipizzati'),('prstudio-unified-control/README.md','1,376 internal capabilities'),('prstudio-unified-control/readme.txt','1,376 capabilities')]
for rel,token in stale:
    if token in (R/rel).read_text(encoding='utf-8'): errors.append(f'{rel}: stale current-state token {token!r}')
if errors:
    print('FAIL documentation alignment')
    for e in errors: print(' -',e)
    sys.exit(1)
print('PASS documentation alignment: 10000 workflows / 40715 phases / Waves 1-9 / 178 domains / 123 MCP tools / 1364 capabilities / 1076 actions')
