<?php
declare(strict_types=1);

define('PRSTUDIO_UC_TESTING', true);
define('PRSTUDIO_UC_DIR', dirname(__DIR__) . '/prstudio-unified-control/');

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($value, int $flags = 0, int $depth = 512) {
        return json_encode($value, $flags, $depth);
    }
}
if (!function_exists('is_wp_error')) {
    function is_wp_error($value): bool { return $value instanceof WP_Error; }
}
if (!class_exists('WP_Error')) {
    final class WP_Error {
        public function __construct(private string $code = '', private string $message = '', private array $data = array()) {}
        public function get_error_code(): string { return $this->code; }
        public function get_error_message(): string { return $this->message; }
        public function get_error_data(): array { return $this->data; }
    }
}
// Makes one native capability describable without loading the WordPress runtime.
if (!class_exists('PRSTUDIO_UC_Browser_Orchestrator')) {
    final class PRSTUDIO_UC_Browser_Orchestrator { public static function inspect(array $args): array { return $args; } }
}
if (!class_exists('PRSTUDIO_UC_Agency_Capabilities')) {
    final class PRSTUDIO_UC_Agency_Capabilities { public static function agency_status(array $args = array()): array { return $args; } }
}

require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-capability-registry.php';
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-mcp-v5.php';
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-turn.php';
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-seo-operating-policy.php';
require dirname(__DIR__) . '/prstudio-unified-control/includes/class-prstudio-uc-agent-model.php';

function schema_fail(string $message): never { fwrite(STDERR, "FAIL {$message}\n"); exit(1); }
function schema_ok(bool $condition, string $message): void {
    if (!$condition) schema_fail($message);
    fwrite(STDOUT, "PASS {$message}\n");
}

/** Validate the JSON representation, where `{}` and `[]` are distinguishable. */
function assert_schema_node($node, string $path): void {
    if (is_bool($node)) return;
    if (!is_object($node)) schema_fail("{$path} must serialize as a JSON Schema object or boolean");
    foreach (array('properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas') as $keyword) {
        if (!property_exists($node, $keyword)) continue;
        $map = $node->{$keyword};
        if (!is_object($map)) schema_fail("{$path}.{$keyword} must serialize as an object, never []");
        foreach (get_object_vars($map) as $name => $child) assert_schema_node($child, "{$path}.{$keyword}.{$name}");
    }
    foreach (array('items', 'contains', 'additionalProperties', 'unevaluatedProperties', 'propertyNames', 'not', 'if', 'then', 'else') as $keyword) {
        if (property_exists($node, $keyword) && (is_object($node->{$keyword}) || is_bool($node->{$keyword}))) {
            assert_schema_node($node->{$keyword}, "{$path}.{$keyword}");
        }
    }
    foreach (array('allOf', 'anyOf', 'oneOf', 'prefixItems') as $keyword) {
        if (!property_exists($node, $keyword)) continue;
        if (!is_array($node->{$keyword})) schema_fail("{$path}.{$keyword} must be an array of schemas");
        foreach ($node->{$keyword} as $index => $child) assert_schema_node($child, "{$path}.{$keyword}[{$index}]");
    }
}

function assert_transport_schema($schema, string $path): void {
    $json = json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) schema_fail("{$path} is not JSON encodable: " . json_last_error_msg());
    assert_schema_node(json_decode($json), $path);
}

$tools = PRSTUDIO_UC_MCP_V5::tools();
$byName = array();
foreach ($tools as $tool) {
    $name = (string)($tool['name'] ?? '');
    if ($name === '' || isset($byName[$name])) schema_fail('tool names must be present and unique');
    $byName[$name] = $tool;
    foreach (array('title', 'description', 'inputSchema', 'outputSchema', 'securitySchemes', 'annotations') as $field) {
        if (!array_key_exists($field, $tool)) schema_fail("{$name} missing {$field}");
    }
    if (trim((string)$tool['title']) === '' || trim((string)$tool['description']) === '') schema_fail("{$name} title/description must be non-empty");
    assert_transport_schema($tool['inputSchema'], "{$name}.inputSchema");
    assert_transport_schema($tool['outputSchema'], "{$name}.outputSchema");
    foreach (array('readOnlyHint', 'destructiveHint', 'idempotentHint', 'openWorldHint') as $hint) {
        if (!is_bool($tool['annotations'][$hint] ?? null)) schema_fail("{$name} missing boolean {$hint}");
    }
    $scopes = (array)($tool['securitySchemes'][0]['scopes'] ?? array());
    if (!in_array('prstudio.read', $scopes, true)) schema_fail("{$name} missing prstudio.read OAuth scope");
    if (empty($tool['annotations']['readOnlyHint']) && !in_array('prstudio.write', $scopes, true)) schema_fail("{$name} write contract missing prstudio.write OAuth scope");
    if (!empty($tool['annotations']['readOnlyHint']) && in_array('prstudio.write', $scopes, true)) schema_fail("{$name} read-only descriptor overstates OAuth scope");
}
schema_ok(count($tools) === 123, '123 direct tools expose title, inputSchema, outputSchema, OAuth and all safety annotations');
schema_ok(($byName['prstudio_execute']['annotations']['destructiveHint'] ?? false) === true, 'generic capability executor advertises worst-case destructive behavior');
schema_ok(($byName['prstudio_flow']['annotations']['readOnlyHint'] ?? true) === false && ($byName['prstudio_flow']['annotations']['destructiveHint'] ?? false) === true, 'flow annotations reflect mutating/destructive steps');

// Deployment descriptor and BUILD-INFO are public inventory claims, not
// hand-maintained estimates. Tie them to the runtime and source inventories.
$descriptor = json_decode((string)file_get_contents(dirname(__DIR__) . '/RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json'), true);
$buildInfo = json_decode((string)file_get_contents(dirname(__DIR__) . '/prstudio-unified-control/BUILD-INFO.json'), true);
$baseDocument = json_decode((string)file_get_contents(dirname(__DIR__) . '/prstudio-unified-control/capabilities/capability-registry.json'), true);
$overlayDocument = json_decode((string)file_get_contents(dirname(__DIR__) . '/prstudio-unified-control/capabilities/agency-capabilities.json'), true);
$runtimeTotal = count(PRSTUDIO_UC_Capability_Registry::all());
$baseTotal = count((array)($baseDocument['capabilities'] ?? array()));
$overlayTotal = count((array)($overlayDocument['capabilities'] ?? array()));
$descriptorToolNames = array_values((array)($descriptor['tool_names'] ?? array()));
$runtimeToolNames = array_keys($byName);
sort($descriptorToolNames, SORT_STRING);
sort($runtimeToolNames, SORT_STRING);
schema_ok(
    (int)($descriptor['expected_tools'] ?? -1) === count($tools)
    && $descriptorToolNames === $runtimeToolNames,
    'deployment descriptor tool inventory exactly matches the runtime'
);
schema_ok(
    (int)($descriptor['internal_capabilities']['runtime_total'] ?? -1) === $runtimeTotal
    && (int)($descriptor['internal_capabilities']['base'] ?? -1) === $baseTotal
    && (int)($descriptor['internal_capabilities']['agency_overlay'] ?? -1) === $overlayTotal
    && (int)($buildInfo['capability_count'] ?? -1) === $runtimeTotal
    && (int)($buildInfo['base_capability_count'] ?? -1) === $baseTotal
    && (int)($buildInfo['agency_capability_overlay_count'] ?? -1) === $overlayTotal,
    'descriptor and BUILD-INFO capability totals match the authoritative 1364-item runtime'
);

// Every tools/list page stays bounded and nextCursor reaches every direct tool.
$listed = array();
$cursor = '';
$toolPages = 0;
do {
    $page = PRSTUDIO_UC_MCP_V5::advertised_tools_for_test($cursor);
    if (is_wp_error($page)) schema_fail('valid tools/list cursor rejected: ' . $page->get_error_message());
    $wire = json_encode($page['tools'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($wire === false || strlen($wire) !== (int)($page['bytes'] ?? -1)) schema_fail('tools/list budget must account for the complete emitted descriptors');
    if ((int)$page['tokens'] > PRSTUDIO_UC_MCP_V5::tools_list_budget_for_test()) schema_fail('tools/list page exceeds 5,000-token budget');
    foreach ((array)$page['tools'] as $tool) {
        $name = (string)$tool['name'];
        if (isset($listed[$name])) schema_fail("tools/list pagination duplicated {$name}");
        $listed[$name] = true;
    }
    $cursor = (string)($page['nextCursor'] ?? '');
    if (++$toolPages > 100) schema_fail('tools/list cursor did not terminate');
} while ($cursor !== '');
schema_ok(array_keys($listed) === array_keys($byName) || (count($listed) === count($byName) && !array_diff_key($listed, $byName)), 'tools/list nextCursor reaches every direct tool without truncation');
schema_ok($toolPages > 1, "tools/list exercises {$toolPages} bounded pages under the hard context budget");

// Enumerate the complete runtime capability inventory and verify every contract.
$expectedCapabilities = PRSTUDIO_UC_Capability_Registry::all();
$catalogNames = array();
$cursor = '';
$catalogPages = 0;
do {
    $page = PRSTUDIO_UC_Capability_Registry::catalog(array('cursor'=>$cursor, 'page_size'=>25, 'include_schemas'=>true));
    if (is_wp_error($page)) schema_fail('valid capability cursor rejected: ' . $page->get_error_message());
    if (($page['catalogLossless'] ?? false) !== true) schema_fail('catalog must declare lossless pagination');
    foreach ((array)$page['items'] as $item) {
        $name = (string)($item['name'] ?? '');
        if ($name === '' || isset($catalogNames[$name])) schema_fail("capability catalog duplicated/omitted a name at {$name}");
        $catalogNames[$name] = true;
        foreach (array('title', 'description', 'inputSchema', 'outputSchema', 'annotations') as $field) {
            if (!array_key_exists($field, $item)) schema_fail("{$name} catalog item missing {$field}");
        }
        if (trim((string)$item['title']) === '' || trim((string)$item['description']) === '') schema_fail("{$name} catalog metadata is empty");
        assert_transport_schema($item['inputSchema'], "{$name}.inputSchema");
        assert_transport_schema($item['outputSchema'], "{$name}.outputSchema");
        foreach (array('readOnlyHint', 'destructiveHint', 'idempotentHint', 'openWorldHint') as $hint) {
            if (!is_bool($item['annotations'][$hint] ?? null)) schema_fail("{$name} catalog annotation {$hint} is missing/non-boolean");
        }
    }
    $cursor = (string)($page['page']['nextCursor'] ?? '');
    $isFinal = $cursor === '';
    if ((bool)($page['complete'] ?? false) !== $isFinal) schema_fail('catalog complete flag must match final-page state');
    if (++$catalogPages > 1000) schema_fail('capability cursor did not terminate');
} while ($cursor !== '');
schema_ok(count($catalogNames) === count($expectedCapabilities), 'paginated catalog exposes the complete ' . count($expectedCapabilities) . "-capability runtime inventory across {$catalogPages} pages");

// The compact search index must not erase safety flags carried by the full
// runtime descriptor. agency.status is idempotent in the overlay contract.
$overlaySearch = PRSTUDIO_UC_Capability_Registry::search('agency status', array('limit'=>25));
$overlayRow = null;
foreach ((array)$overlaySearch['items'] as $item) { if (($item['id'] ?? '') === 'agency.status') { $overlayRow = $item; break; } }
$overlayDescribe = PRSTUDIO_UC_Capability_Registry::describe('agency.status');
schema_ok(
    is_array($overlayRow) && is_array($overlayDescribe) && $overlayRow['annotations'] === $overlayDescribe['tool_annotations'],
    'search, catalog and describe preserve identical runtime safety annotations'
);

// Real structuredContent produced by the server must satisfy its descriptor.
$success = new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class, 'tool_success');
$failure = new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class, 'tool_error');
$validate = new ReflectionMethod(PRSTUDIO_UC_MCP_V5::class, 'validate_schema_value');
$catalogResult = PRSTUDIO_UC_Capability_Registry::catalog(array('page_size'=>1));
$searchResult = PRSTUDIO_UC_Capability_Registry::search('browser inspect', array('limit'=>1));
$describeResult = PRSTUDIO_UC_Capability_Registry::describe('browser.inspect');
if (!is_array($describeResult)) schema_fail('native describe fixture is unavailable');
$representative = array(
    'prstudio_capability_catalog'=>$catalogResult,
    'prstudio_capability_search'=>$searchResult,
    'prstudio_capability_describe'=>$describeResult,
);
foreach ($byName as $name => $tool) {
    $raw = $representative[$name] ?? array('value'=>'contract-probe');
    $result = $success->invoke(null, $raw, $name, 'schema-contract-probe');
    $error = $validate->invoke(null, $result['structuredContent'], $tool['outputSchema'], '$');
    if (is_wp_error($error)) schema_fail("{$name} structuredContent violates outputSchema: " . $error->get_error_message());
    $failed = $failure->invoke(null, new WP_Error('contract_probe', 'Expected contract probe failure.', array('retryable'=>false)), 'schema-contract-probe');
    $failureError = $validate->invoke(null, $failed['structuredContent'], $tool['outputSchema'], '$');
    if (is_wp_error($failureError)) schema_fail("{$name} error structuredContent violates outputSchema: " . $failureError->get_error_message());
}
schema_ok(true, 'success and error structuredContent envelopes conform to every advertised outputSchema');

// A continuation is emitted by PRSTUDIO_UC_Turn as an executable object, not a
// string label. Validate both the descriptor and a real pending wire result so
// ChatGPT can call the documented tool with the documented arguments directly.
$nextActionSchema = $byName['browser_open']['outputSchema']['properties']['next_action'] ?? null;
schema_ok(
    is_array($nextActionSchema)
    && ($nextActionSchema['type'] ?? '') === 'object'
    && ($nextActionSchema['required'] ?? array()) === array('tool', 'arguments')
    && ($nextActionSchema['properties']['tool']['type'] ?? '') === 'string'
    && ($nextActionSchema['properties']['arguments']['type'] ?? '') === 'object',
    'outputSchema advertises next_action as the exact {tool, arguments} continuation object'
);
$pendingTurn = PRSTUDIO_UC_Turn::pending(
    'schema-pending-probe',
    array('tool'=>'browser_status', 'arguments'=>array('task_id'=>str_repeat('a', 32), 'wait_seconds'=>5)),
    2
);
$pendingResult = $success->invoke(null, $pendingTurn, 'browser_open', 'schema-pending-probe');
$pendingError = $validate->invoke(null, $pendingResult['structuredContent'], $byName['browser_open']['outputSchema'], '$');
schema_ok(
    !is_wp_error($pendingError)
    && ($pendingResult['structuredContent']['next_action'] ?? null) === $pendingTurn['next_action'],
    'real PRSTUDIO_UC_Turn pending structuredContent conforms to the advertised next_action schema'
);

$instructions = PRSTUDIO_UC_Agent_Model::instructions(count($tools));
$lead = substr($instructions, 0, 512);
schema_ok(str_contains($lead, 'RP STUDIO Connector') && str_contains($lead, 'prstudio_capability_catalog'), 'first 512 instruction characters establish identity and lossless discovery');
schema_ok(str_contains($instructions, 'follow nextCursor') && strlen($instructions) < 6400, 'server instructions teach pagination and remain compact');

$generatedInstructions = (string)file_get_contents(dirname(__DIR__) . '/RP-STUDIO-CHATGPT-PLUGIN-INSTRUCTIONS-1.0.0.txt');
$instructionAssembler = (string)file_get_contents(__DIR__ . '/assemble-release-evidence.py');
schema_ok(
    str_contains($generatedInstructions, 'execution lane viene creata o recuperata automaticamente dal server')
    && str_contains($generatedInstructions, 'non anteporre prstudio_context_open')
    && !preg_match('/(?:prima|before)[^\n]{0,120}prstudio_context_open/iu', $generatedInstructions),
    'generated ChatGPT instructions require direct first-attempt execution with server-side lane bootstrap'
);
schema_ok(
    str_contains($instructionAssembler, 'non anteporre prstudio_context_open')
    && !str_contains($instructionAssembler, 'Per mutazioni apri un contesto'),
    'release assembler cannot regenerate the obsolete context-open-first workflow'
);

fwrite(STDOUT, "OK ChatGPT enterprise schema contract\n");
