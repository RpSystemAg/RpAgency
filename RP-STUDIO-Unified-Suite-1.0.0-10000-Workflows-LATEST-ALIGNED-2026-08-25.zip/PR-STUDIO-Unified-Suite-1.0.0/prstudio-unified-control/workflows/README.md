# Enterprise Workflow Registry

Reference cutoff: **2026-08-25**. Canonical workflows: **10,000**. Grounded phases: **40,715**. Domains: **178**.

| Wave | Count | Purpose |
|---:|---:|---|
| 1 | 300 | General browser automation, tab ownership and recovery; first 50 are browser/tab control procedures. |
| 2 | 300 | Original 300-workflow corpus preserved with migration metadata. |
| 3 | 300 | Logs, bugs, refactor, file analysis, defensive/authorized security. |
| 4 | 380 | Global agency expansion and specialist centres of excellence. |
| 5 | 600 | Agency operating-system meta workflows. |
| 6 | 299 | First exact 299-workflow consulting/production specification. |
| 7 | 200 | Gutenberg, HTML, JavaScript, Java and CSS enterprise engineering. |
| 8 | 299 | Second distinct exact 299-workflow productivity/social/local/content/keyword/ads specification. |
| 9 | 7,322 | Enterprise Atlas expansion: 73 domains × 100 lifecycle procedures + 22 cross-domain controls. |

All workflows are internal canonical procedures and are fully discoverable/runnable from ChatGPT through the MCP `prstudio_workflow` gateway. Catalog and search are paginated (`limit`, `offset`, `has_more`, `next_offset`) so the 10,000-workflow registry does not expand into 10,000 top-level MCP tools. The public MCP surface is 123 tools; the canonical capability registry is 1,364 and the legacy action catalog contains 1,076 actions.

The 2026-08-24 Wave 1/2 manifests are retained only as migration fixtures proving preservation of the original 300 IDs. They are not loaded by the runtime registry.
