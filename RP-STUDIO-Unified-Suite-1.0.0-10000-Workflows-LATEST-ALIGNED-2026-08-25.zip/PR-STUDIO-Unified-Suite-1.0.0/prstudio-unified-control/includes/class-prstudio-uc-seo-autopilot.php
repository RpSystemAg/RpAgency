<?php
// phpcs:ignore missing_direct_file_access_protection -- direct-access guard IS present on the line below; it uses `&& ! defined('PRSTUDIO_UC_TESTING')` for testability and Plugin Check's static pattern doesn't recognize that compound form.
if ( ! defined( 'ABSPATH' ) && ! defined( 'PRSTUDIO_UC_TESTING' ) ) { exit; }

/**
 * SEO Autopilot campaign memory -- the server-side answer to "Prossimo".
 *
 * A brand-new ChatGPT chat has zero prior context. Before this class existed,
 * "continue the SEO work" could only mean "re-derive progress from the
 * conversation", which repeats completed products and loses claimed-but-
 * unfinished ones on every crash or new chat. This table is the single
 * source of truth: which of the ~800+ WooCommerce products in the active
 * campaign are PENDING, CLAIMED, APPLIED_UNVERIFIED, COMPLETED, BLOCKED or
 * REVIEW_REQUIRED, and which entity a caller gets next -- independent of
 * prompt, chat history or which session asks.
 *
 * Storage follows the pattern already proven by PRSTUDIO_UC_Store for tasks
 * and jobs: a real table, a transactional `SELECT ... FOR UPDATE` + `UPDATE`
 * claim, and a lease that a crashed worker eventually gives back. The
 * `ACTIVE_SEO_MISSION` alias itself lives in PRSTUDIO_UC_Memory::mission(),
 * which is exactly what that method is for -- a low-frequency named state
 * alias -- while campaign counters stay in this table so counter updates
 * never contend with Memory's sitewide flock().
 *
 * AGENTS.md LAW 1-3 bound what BLOCKED/REVIEW_REQUIRED may mean here: only a
 * genuine technical/business impossibility, never model uncertainty. Post-
 * execution uncertainty about a mutation that already ran renders as a
 * completed row with `verification.verified=false, degraded=true` -- it is
 * evidence attached to a done thing, not a gate that stops one.
 */
final class PRSTUDIO_UC_SEO_Autopilot {
    public const VERSION = '1.3.0';
    public const MISSION_ALIAS = 'ACTIVE_SEO_MISSION';

    public const PENDING = 'PENDING';
    public const CLAIMED = 'CLAIMED';
    public const APPLIED_UNVERIFIED = 'APPLIED_UNVERIFIED';
    public const COMPLETED = 'COMPLETED';
    public const BLOCKED = 'BLOCKED';
    public const REVIEW_REQUIRED = 'REVIEW_REQUIRED';

    private const STATES = array( self::PENDING, self::CLAIMED, self::APPLIED_UNVERIFIED, self::COMPLETED, self::BLOCKED, self::REVIEW_REQUIRED );
    private const CLAIM_LEASE_SECONDS = 1800;
    private const SEED_PAGE_SIZE = 200;
    private const SCHEMA_OPTION = 'prstudio_uc_seo_autopilot_schema';
    private const SCHEMA_VERSION = 1;

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'prstudio_uc_seo_campaign_entities';
    }

    public static function install(): void {
        global $wpdb;
        if ( (int) get_option( self::SCHEMA_OPTION, 0 ) === self::SCHEMA_VERSION ) { return; }
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sql = 'CREATE TABLE ' . self::table() . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            campaign_id varchar(64) NOT NULL,
            entity_type varchar(32) NOT NULL,
            entity_id varchar(64) NOT NULL,
            entity_key varchar(190) NOT NULL,
            status varchar(24) NOT NULL DEFAULT 'PENDING',
            source_fingerprint char(64) NULL,
            completed_fingerprint char(64) NULL,
            claim_token varchar(64) NULL,
            claim_expires_gmt datetime NULL,
            worker_id varchar(160) NULL,
            attempt_count int unsigned NOT NULL DEFAULT 0,
            resolved_issues longtext NULL,
            remaining_issues longtext NULL,
            verification longtext NULL,
            block_reason varchar(255) NULL,
            created_gmt datetime NOT NULL,
            updated_gmt datetime NOT NULL,
            completed_gmt datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY campaign_entity (campaign_id, entity_type, entity_id),
            KEY campaign_status (campaign_id, status),
            KEY entity_id (entity_id)
        ) $charset;";
        dbDelta( $sql );
        update_option( self::SCHEMA_OPTION, self::SCHEMA_VERSION, false );
    }

    private static function ensure(): bool {
        if ( (int) get_option( self::SCHEMA_OPTION, 0 ) !== self::SCHEMA_VERSION ) { self::install(); }
        return true;
    }

    private static function now(): string { return gmdate( 'Y-m-d H:i:s' ); }

    private static function encode( $value ): string {
        return (string) wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    }

    private static function decode_row( array $row ): array {
        foreach ( array( 'resolved_issues', 'remaining_issues', 'verification' ) as $field ) {
            if ( array_key_exists( $field, $row ) ) {
                $decoded = null !== $row[ $field ] ? json_decode( (string) $row[ $field ], true ) : null;
                $row[ $field ] = is_array( $decoded ) ? $decoded : array();
            }
        }
        $row['attempt_count'] = (int) ( $row['attempt_count'] ?? 0 );
        return $row;
    }

    /** entity_type:entity_id -- stable, never the URL. Shared format with PRSTUDIO_UC_Interventions. */
    public static function entity_key( string $type, $id ): string {
        return class_exists( 'PRSTUDIO_UC_Interventions' )
            ? PRSTUDIO_UC_Interventions::normalize_entity( $type, $id )
            : substr( sanitize_key( $type ) . ':' . trim( (string) $id ), 0, 190 );
    }

    /** Verbatim template of PRSTUDIO_UC_Product_Audit::fingerprint() -- same fields, same canonicalisation. */
    private static function fingerprint_of( $product ): string {
        $id = (int) $product->get_id();
        $parts = array(
            'id' => $id,
            'modified' => function_exists( 'get_post_modified_time' ) ? (string) get_post_modified_time( 'U', true, $id ) : '',
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'status' => $product->get_status(),
            'stock' => $product->get_stock_quantity(),
            'stock_status' => $product->get_stock_status(),
            'image' => $product->get_image_id(),
        );
        foreach ( array( 'rank_math_focus_keyword', 'rank_math_title', 'rank_math_description', 'rank_math_canonical_url', 'rank_math_robots', 'rank_math_seo_score' ) as $k ) {
            $v = function_exists( 'get_post_meta' ) ? get_post_meta( $id, $k, true ) : '';
            $parts[ $k ] = is_scalar( $v ) ? (string) $v : $v;
        }
        return class_exists( 'PRSTUDIO_UC_Memory' ) ? PRSTUDIO_UC_Memory::fingerprint( $parts ) : hash( 'sha256', (string) wp_json_encode( $parts ) );
    }

    /* -------------------------------------------------------------------
     * Mission alias -- which campaign is "active" right now.
     * ---------------------------------------------------------------- */

    public static function active_mission(): array {
        return class_exists( 'PRSTUDIO_UC_Memory' ) ? PRSTUDIO_UC_Memory::mission( self::MISSION_ALIAS ) : array();
    }

    private static function campaign_mission_id( string $campaign_id ): string {
        return 'SEO_CAMPAIGN:' . substr( sanitize_key( $campaign_id ), 0, 64 );
    }

    private static function campaign_spec( string $campaign_id ): array {
        if ( '' === $campaign_id || ! class_exists( 'PRSTUDIO_UC_Memory' ) ) { return array(); }
        $row = PRSTUDIO_UC_Memory::mission( self::campaign_mission_id( $campaign_id ) );
        return is_array( $row ) ? $row : array();
    }

    private static function save_campaign_spec( string $campaign_id, array $spec ): void {
        if ( ! class_exists( 'PRSTUDIO_UC_Memory' ) ) { return; }
        $spec['campaign_id'] = $campaign_id;
        PRSTUDIO_UC_Memory::mission( self::campaign_mission_id( $campaign_id ), $spec );
    }

    /**
     * Bounded public representation of a campaign scope. The internal target
     * list may contain thousands of product IDs; returning the entire list on
     * every status/next call creates needless MCP-token pressure and can make
     * routing worse. Keep the denominator and a small unresolved sample public
     * while retaining the complete target set server-side.
     */
    private static function public_scope( array $spec ): array {
        $unresolved = array_values( (array) ( $spec['unresolved_urls'] ?? array() ) );
        return array(
            'scope_mode' => (string) ( $spec['scope_mode'] ?? 'catalog' ),
            'target_count' => (int) ( $spec['target_count'] ?? 0 ),
            'resolved_target_count' => count( (array) ( $spec['entity_ids'] ?? array() ) ),
            'unresolved_url_count' => count( $unresolved ),
            'unresolved_urls_sample' => array_slice( $unresolved, 0, 20 ),
            'source_report_id' => (string) ( $spec['source_report_id'] ?? '' ),
            'source_report_hash' => (string) ( $spec['source_report_hash'] ?? '' ),
            'requirements' => (array) ( $spec['requirements'] ?? array() ),
        );
    }

    private static function set_active_mission( string $campaign_id ): void {
        if ( class_exists( 'PRSTUDIO_UC_Memory' ) ) {
            PRSTUDIO_UC_Memory::mission( self::MISSION_ALIAS, array( 'campaign_id' => $campaign_id ) );
        }
    }

    private static function normalized_requirements( array $args, array $existing = array() ): array {
        $rank_target = array_key_exists( 'rank_math_target_score', $args ) ? (int) $args['rank_math_target_score'] : (int) ( $existing['rank_math_target_score'] ?? 0 );
        $min_keywords = array_key_exists( 'min_focus_keywords', $args ) ? (int) $args['min_focus_keywords'] : (int) ( $existing['min_focus_keywords'] ?? 0 );
        $media_policy = sanitize_key( (string) ( $args['media_policy'] ?? ( $existing['media_policy'] ?? 'preserve' ) ) );
        if ( ! in_array( $media_policy, array( 'preserve', 'review_if_available', 'require_image' ), true ) ) { $media_policy = 'preserve'; }
        return array(
            'rank_math_target_score' => max( 0, min( 100, $rank_target ) ),
            'min_focus_keywords' => max( 0, min( 20, $min_keywords ) ),
            'media_policy' => $media_policy,
            'strict_scope' => array_key_exists( 'strict_scope', $args ) ? (bool) $args['strict_scope'] : (bool) ( $existing['strict_scope'] ?? false ),
            'require_verified' => array_key_exists( 'require_verified', $args ) ? (bool) $args['require_verified'] : (bool) ( $existing['require_verified'] ?? false ),
            'require_live_rank_math_score' => array_key_exists( 'require_live_rank_math_score', $args ) ? (bool) $args['require_live_rank_math_score'] : (bool) ( $existing['require_live_rank_math_score'] ?? false ),
            // Cross-session product rotation. Historical manual SEO passes can
            // settle a campaign row only while this cooldown is still current.
            // Proper Autopilot completions remain fingerprint-driven instead.
            'rotation_cooldown_days' => max( 1, min( 3650, array_key_exists( 'rotation_cooldown_days', $args ) ? (int) $args['rotation_cooldown_days'] : (int) ( $existing['rotation_cooldown_days'] ?? 120 ) ) ),
        );
    }

    private static function resolve_explicit_targets( array $args ): array {
        $ids = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $args['entity_ids'] ?? array() ) ) ) ) );
        $unresolved = array();
        foreach ( (array) ( $args['entity_urls'] ?? array() ) as $url ) {
            $url = trim( (string) $url );
            if ( '' === $url ) { continue; }
            $id = function_exists( 'url_to_postid' ) ? absint( url_to_postid( $url ) ) : 0;
            if ( $id && ( ! function_exists( 'get_post_type' ) || 'product' === get_post_type( $id ) ) ) {
                $ids[] = $id;
            } else {
                $unresolved[] = esc_url_raw( $url );
            }
        }
        $ids = array_values( array_unique( array_filter( $ids ) ) );
        sort( $ids, SORT_NUMERIC );
        return array( 'entity_ids' => array_slice( $ids, 0, 5000 ), 'unresolved_urls' => array_slice( array_values( array_unique( $unresolved ) ), 0, 5000 ) );
    }

    private static function build_or_merge_spec( string $campaign_id, array $args, array $existing = array() ): array {
        $has_explicit_targets = array_key_exists( 'entity_ids', $args ) || array_key_exists( 'entity_urls', $args );
        $scope_mode = sanitize_key( (string) ( $args['scope_mode'] ?? ( $has_explicit_targets ? 'explicit' : ( $existing['scope_mode'] ?? 'catalog' ) ) ) );
        if ( ! in_array( $scope_mode, array( 'catalog', 'explicit' ), true ) ) { $scope_mode = 'catalog'; }
        $targets = $has_explicit_targets ? self::resolve_explicit_targets( $args ) : array(
            'entity_ids' => array_values( array_map( 'absint', (array) ( $existing['entity_ids'] ?? array() ) ) ),
            'unresolved_urls' => array_values( (array) ( $existing['unresolved_urls'] ?? array() ) ),
        );
        if ( 'explicit' === $scope_mode && ! $has_explicit_targets && empty( $targets['entity_ids'] ) && empty( $targets['unresolved_urls'] ) ) {
            $scope_mode = 'catalog';
        }
        $requirements = self::normalized_requirements( $args, (array) ( $existing['requirements'] ?? array() ) );
        $source_report_id = sanitize_text_field( (string) ( $args['source_report_id'] ?? ( $existing['source_report_id'] ?? '' ) ) );
        $source_report_hash = strtolower( trim( (string) ( $args['source_report_hash'] ?? ( $existing['source_report_hash'] ?? '' ) ) ) );
        if ( $source_report_hash && ! preg_match( '/^[a-f0-9]{32,128}$/', $source_report_hash ) ) { $source_report_hash = ''; }
        return array(
            'campaign_id' => $campaign_id,
            'scope_mode' => $scope_mode,
            'entity_ids' => 'explicit' === $scope_mode ? $targets['entity_ids'] : array(),
            'unresolved_urls' => 'explicit' === $scope_mode ? $targets['unresolved_urls'] : array(),
            'target_count' => 'explicit' === $scope_mode ? count( $targets['entity_ids'] ) + count( $targets['unresolved_urls'] ) : 0,
            'source_report_id' => $source_report_id,
            'source_report_hash' => $source_report_hash,
            'requirements' => $requirements,
        );
    }

    /* -------------------------------------------------------------------
     * Inventory -- seeding and reconciliation.
     * ---------------------------------------------------------------- */

    private static function upsert_pending_row( string $campaign_id, string $type, string $id, string $fingerprint ): bool {
        global $wpdb;
        $now = self::now();
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional: bulk campaign-inventory seeding is set-based by design, matching PRSTUDIO_UC_Store; INSERT IGNORE is the idempotency mechanism (unique key on campaign_id+entity_type+entity_id), not a fallback.
        $result = $wpdb->query( $wpdb->prepare(
            'INSERT IGNORE INTO ' . self::table() . ' (campaign_id, entity_type, entity_id, entity_key, status, source_fingerprint, created_gmt, updated_gmt) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)',
            $campaign_id, sanitize_key( $type ), $id, self::entity_key( $type, $id ), self::PENDING, $fingerprint, $now, $now
        ) );
        return 1 === (int) $result;
    }

    /**
     * Walks the full WooCommerce catalogue (HPOS-safe, same wc_get_products()
     * call as PRSTUDIO_UC_Operational_Twin::commerce_entities()) once. New
     * products become PENDING rows; a COMPLETED row whose live fingerprint no
     * longer matches its completed_fingerprint reopens. PENDING/CLAIMED/
     * APPLIED_UNVERIFIED/BLOCKED/REVIEW_REQUIRED rows are never touched here --
     * this never overwrites in-flight or settled-with-a-reason work.
     */
    private static function sync_inventory( string $campaign_id ): array {
        if ( ! function_exists( 'wc_get_products' ) ) { return array( 'added' => 0, 'reopened' => 0 ); }
        $spec = self::campaign_spec( $campaign_id );
        $added = 0;
        $reopened = 0;
        if ( 'explicit' === (string) ( $spec['scope_mode'] ?? '' ) ) {
            foreach ( (array) ( $spec['entity_ids'] ?? array() ) as $raw_id ) {
                $id = absint( $raw_id );
                if ( ! $id ) { continue; }
                $product = wc_get_product( $id );
                if ( ! $product ) { continue; }
                $fingerprint = self::fingerprint_of( $product );
                $existing = self::get_entity( $campaign_id, 'product', (string) $id );
                if ( ! $existing ) {
                    if ( self::upsert_pending_row( $campaign_id, 'product', (string) $id, $fingerprint ) ) { ++$added; }
                } elseif ( self::COMPLETED === (string) $existing['status'] && ! hash_equals( (string) ( $existing['completed_fingerprint'] ?? '' ), $fingerprint ) ) {
                    self::reopen_if_changed( $campaign_id, 'product', (string) $id, $fingerprint );
                    ++$reopened;
                }
            }
            return array(
                'added' => $added, 'reopened' => $reopened, 'scope_mode' => 'explicit',
                'target_count' => (int) ( $spec['target_count'] ?? 0 ),
                'resolved_target_count' => count( (array) ( $spec['entity_ids'] ?? array() ) ),
                'unresolved_urls' => array_values( (array) ( $spec['unresolved_urls'] ?? array() ) ),
            );
        }
        $page = 1;
        do {
            $products = wc_get_products( array(
                'limit' => self::SEED_PAGE_SIZE, 'page' => $page,
                'status' => array( 'publish', 'draft', 'pending', 'private' ),
                'orderby' => 'ID', 'order' => 'ASC', 'return' => 'objects',
            ) );
            foreach ( (array) $products as $product ) {
                if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) { continue; }
                $id = (string) $product->get_id();
                $fingerprint = self::fingerprint_of( $product );
                $existing = self::get_entity( $campaign_id, 'product', $id );
                if ( ! $existing ) {
                    if ( self::upsert_pending_row( $campaign_id, 'product', $id, $fingerprint ) ) { ++$added; }
                    continue;
                }
                if ( self::COMPLETED === (string) $existing['status'] && ! hash_equals( (string) ( $existing['completed_fingerprint'] ?? '' ), $fingerprint ) ) {
                    self::reopen_if_changed( $campaign_id, 'product', $id, $fingerprint );
                    ++$reopened;
                }
            }
            ++$page;
        } while ( count( $products ) === self::SEED_PAGE_SIZE );
        return array( 'added' => $added, 'reopened' => $reopened, 'scope_mode' => 'catalog' );
    }

    /** Idempotent: a second call with no active campaign change is a no-op, never a second campaign. */
    public static function ensure_campaign( array $args = array() ): array {
        self::ensure();
        $mission = self::active_mission();
        $active_id = (string) ( $mission['campaign_id'] ?? '' );
        $requested_id = ! empty( $args['campaign_id'] ) ? substr( sanitize_key( (string) $args['campaign_id'] ), 0, 64 ) : '';
        $campaign_id = $requested_id ?: $active_id;
        if ( '' === $campaign_id ) {
            $campaign_id = substr( 'seo-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_uuid4(), 0, 64 );
        }
        $existing = self::campaign_spec( $campaign_id );
        $has_spec_args = array_intersect( array_keys( $args ), array( 'scope_mode','entity_ids','entity_urls','source_report_id','source_report_hash','rank_math_target_score','min_focus_keywords','media_policy','strict_scope','require_verified','require_live_rank_math_score','rotation_cooldown_days' ) );
        if ( empty( $existing ) || ! empty( $has_spec_args ) ) {
            $spec = self::build_or_merge_spec( $campaign_id, $args, $existing );
            self::save_campaign_spec( $campaign_id, $spec );
        } else {
            $spec = $existing;
        }
        self::set_active_mission( $campaign_id );
        $sync = self::sync_inventory( $campaign_id );
        return array( 'campaign_id' => $campaign_id, 'created' => empty( $existing ), 'scope' => self::public_scope( $spec ), 'inventory' => $sync );
    }

    /**
     * Historical intervention evidence is deliberately reconciled into the
     * campaign state-machine rather than read as a parallel source of truth.
     * A row is backfilled only when the intervention is settled, the product
     * has not changed since that intervention, and every current acceptance
     * requirement that can be proven from server-side state is satisfied.
     * Requirements that need live/editor/report evidence are never guessed.
     */
    private static function historical_acceptance_provable( int $product_id, array $requirements ): array {
        if ( ! function_exists( 'wc_get_product' ) ) { return array( 'ok'=>false, 'reason'=>'woocommerce_unavailable' ); }
        $product = wc_get_product( $product_id );
        if ( ! $product ) { return array( 'ok'=>false, 'reason'=>'product_missing' ); }
        if ( ! empty( $requirements['strict_scope'] ) ) { return array( 'ok'=>false, 'reason'=>'strict_scope_requires_current_report_evidence' ); }
        if ( ! empty( $requirements['require_verified'] ) ) { return array( 'ok'=>false, 'reason'=>'current_verification_required' ); }
        if ( ! empty( $requirements['require_live_rank_math_score'] ) ) { return array( 'ok'=>false, 'reason'=>'live_rank_math_editor_evidence_required' ); }
        if ( 'review_if_available' === (string) ( $requirements['media_policy'] ?? 'preserve' ) ) { return array( 'ok'=>false, 'reason'=>'current_media_human_review' ); }
        $score_raw = function_exists( 'get_post_meta' ) ? get_post_meta( $product_id, 'rank_math_seo_score', true ) : '';
        $score = is_numeric( $score_raw ) ? (float) $score_raw : null;
        $target = (int) ( $requirements['rank_math_target_score'] ?? 0 );
        if ( $target > 0 && ( null === $score || $score < $target ) ) { return array( 'ok'=>false, 'reason'=>'rank_math_target_not_provable', 'score'=>$score, 'target'=>$target ); }
        $focus_raw = function_exists( 'get_post_meta' ) ? trim( (string) get_post_meta( $product_id, 'rank_math_focus_keyword', true ) ) : '';
        $focus = array_values( array_filter( array_map( 'trim', preg_split( '/\s*,\s*/', $focus_raw ) ?: array() ) ) );
        $min_kw = (int) ( $requirements['min_focus_keywords'] ?? 0 );
        if ( $min_kw > 0 && count( $focus ) < $min_kw ) { return array( 'ok'=>false, 'reason'=>'focus_keyword_target_not_provable', 'observed'=>count( $focus ), 'target'=>$min_kw ); }
        if ( 'require_image' === (string) ( $requirements['media_policy'] ?? 'preserve' ) && (int) $product->get_image_id() <= 0 ) { return array( 'ok'=>false, 'reason'=>'product_image_required' ); }
        return array( 'ok'=>true, 'product'=>$product, 'score'=>$score, 'focus_keyword_count'=>count( $focus ), 'image_id'=>(int) $product->get_image_id() );
    }

    private static function settled_seo_intervention( string $entity_key ): ?array {
        if ( ! class_exists( 'PRSTUDIO_UC_Interventions' ) ) { return null; }
        $check = PRSTUDIO_UC_Interventions::filter_new( array(
            array( 'entity_key'=>$entity_key, 'intervention_key'=>'seo_autopilot_pass' ),
            array( 'entity_key'=>$entity_key, 'intervention_key'=>'seo_rotation_cooldown' ),
        ), true );
        $settled = array_values( (array) ( $check['already_settled'] ?? array() ) );
        if ( ! $settled ) { return null; }
        // A canonical Autopilot pass wins over the legacy/manual cooldown key.
        usort( $settled, static function ( array $a, array $b ): int {
            $pa = 'seo_autopilot_pass' === (string) ( $a['intervention_key'] ?? '' ) ? 0 : 1;
            $pb = 'seo_autopilot_pass' === (string) ( $b['intervention_key'] ?? '' ) ? 0 : 1;
            return $pa <=> $pb;
        } );
        return $settled[0];
    }

    private static function convergence_candidate( array $row, array $requirements ): array {
        if ( 'product' !== sanitize_key( (string) ( $row['entity_type'] ?? '' ) ) ) { return array( 'ok'=>false, 'reason'=>'unsupported_entity_type' ); }
        $id = absint( $row['entity_id'] ?? 0 ); if ( ! $id ) { return array( 'ok'=>false, 'reason'=>'invalid_product_id' ); }
        $settled = self::settled_seo_intervention( self::entity_key( 'product', $id ) );
        if ( ! $settled ) { return array( 'ok'=>false, 'reason'=>'no_settled_intervention' ); }
        $applied = (string) ( $settled['applied_gmt'] ?? '' ); $applied_ts = $applied ? strtotime( $applied . ' UTC' ) : false;
        if ( ! $applied_ts ) { return array( 'ok'=>false, 'reason'=>'settlement_timestamp_missing' ); }
        $key = (string) ( $settled['intervention_key'] ?? '' );
        if ( 'seo_rotation_cooldown' === $key ) {
            $days = max( 1, (int) ( $requirements['rotation_cooldown_days'] ?? 120 ) );
            if ( $applied_ts + ( $days * 86400 ) <= time() ) { return array( 'ok'=>false, 'reason'=>'rotation_cooldown_expired', 'settlement'=>$settled ); }
        }
        $proof = self::historical_acceptance_provable( $id, $requirements );
        if ( empty( $proof['ok'] ) ) { return $proof + array( 'settlement'=>$settled ); }
        $modified_ts = function_exists( 'get_post_modified_time' ) ? (int) get_post_modified_time( 'U', true, $id ) : 0;
        // Five minutes tolerates the normal post-save -> ledger-write sequence,
        // but rejects later edits so historical completion can never mask drift.
        if ( $modified_ts > 0 && $modified_ts > (int) $applied_ts + 300 ) { return array( 'ok'=>false, 'reason'=>'entity_changed_after_intervention', 'modified_ts'=>$modified_ts, 'applied_ts'=>(int)$applied_ts, 'settlement'=>$settled ); }
        $fingerprint = self::fingerprint_of( $proof['product'] );
        return array( 'ok'=>true, 'entity_id'=>$id, 'fingerprint'=>$fingerprint, 'settlement'=>$settled, 'acceptance'=>array_diff_key( $proof, array( 'product'=>true ) ) );
    }

    private static function converge_settled_interventions( string $campaign_id, int $limit = 5000 ): array {
        global $wpdb; $spec = self::campaign_spec( $campaign_id ); $requirements = (array) ( $spec['requirements'] ?? array() );
        $limit = max( 1, min( 5000, $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            'SELECT id, entity_type, entity_id, entity_key, status FROM ' . self::table() . ' WHERE campaign_id = %s AND status = %s ORDER BY id ASC LIMIT %d',
            $campaign_id, self::PENDING, $limit
        ), ARRAY_A );
        $out = array( 'checked'=>0, 'backfilled'=>0, 'skipped'=>0, 'skip_reasons'=>array() ); $now = self::now();
        foreach ( (array) $rows as $row ) {
            ++$out['checked']; $candidate = self::convergence_candidate( (array) $row, $requirements );
            if ( empty( $candidate['ok'] ) ) { ++$out['skipped']; $reason=(string)($candidate['reason']??'not_provable');$out['skip_reasons'][$reason]=(int)($out['skip_reasons'][$reason]??0)+1; continue; }
            $settled = (array) $candidate['settlement'];
            $verification = array(
                'verified'=>true, 'degraded'=>false, 'historical_backfill'=>true,
                'settlement_source'=>(string) ( $settled['intervention_key'] ?? '' ),
                'settlement_state'=>(string) ( $settled['state'] ?? '' ),
                'settlement_applied_gmt'=>(string) ( $settled['applied_gmt'] ?? '' ),
                'evidence_class'=>'persisted_intervention_plus_unchanged_live_fingerprint',
                'acceptance'=>(array) ( $candidate['acceptance'] ?? array() ),
            );
            $updated = $wpdb->query( $wpdb->prepare(
                'UPDATE ' . self::table() . ' SET status = %s, source_fingerprint = %s, completed_fingerprint = %s, claim_token = NULL, claim_expires_gmt = NULL, worker_id = NULL, verification = %s, completed_gmt = %s, updated_gmt = %s WHERE id = %d AND status = %s',
                self::COMPLETED, (string)$candidate['fingerprint'], (string)$candidate['fingerprint'], self::encode($verification), (string)($settled['applied_gmt']?:$now), $now, (int)$row['id'], self::PENDING
            ) );
            if ( 1 === (int) $updated ) { ++$out['backfilled']; }
        }
        ksort( $out['skip_reasons'] ); return $out;
    }

    private static function reopen_expired_rotation_backfills( string $campaign_id ): int {
        global $wpdb; $spec = self::campaign_spec( $campaign_id ); $days = max( 1, (int) ( $spec['requirements']['rotation_cooldown_days'] ?? 120 ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            'SELECT id, entity_id, verification FROM ' . self::table() . ' WHERE campaign_id = %s AND status = %s ORDER BY id ASC LIMIT %d',
            $campaign_id, self::COMPLETED, 5000
        ), ARRAY_A );
        $reopened = 0; $now = self::now();
        foreach ( (array) $rows as $row ) {
            $v = json_decode( (string) ( $row['verification'] ?? '' ), true ); if ( ! is_array( $v ) || empty( $v['historical_backfill'] ) || 'seo_rotation_cooldown' !== (string) ( $v['settlement_source'] ?? '' ) ) { continue; }
            $applied = (string) ( $v['settlement_applied_gmt'] ?? '' ); $ts = $applied ? strtotime( $applied . ' UTC' ) : false; if ( ! $ts || $ts + ( $days * 86400 ) > time() ) { continue; }
            $product = function_exists('wc_get_product') ? wc_get_product(absint($row['entity_id']??0)) : null; if(!$product)continue; $fingerprint=self::fingerprint_of($product);
            $updated=$wpdb->query($wpdb->prepare('UPDATE '.self::table().' SET status = %s, source_fingerprint = %s, completed_fingerprint = NULL, verification = %s, completed_gmt = NULL, updated_gmt = %s WHERE id = %d AND status = %s',self::PENDING,$fingerprint,self::encode(array('reopened_reason'=>'rotation_cooldown_expired','previous_settlement'=>$v)),$now,(int)$row['id'],self::COMPLETED));
            if(1===(int)$updated)++$reopened;
        }
        return $reopened;
    }

    public static function converge( string $campaign_id ): array {
        self::ensure();
        return array( 'campaign_id'=>$campaign_id, 'expired_rotation_reopened'=>self::reopen_expired_rotation_backfills($campaign_id), 'historical'=>self::converge_settled_interventions($campaign_id) );
    }

    public static function reconcile( string $campaign_id ): array {
        self::ensure();
        $stale = self::recover_stale_claims( $campaign_id );
        $inventory = self::sync_inventory( $campaign_id );
        $convergence = self::converge( $campaign_id );
        $spec = self::campaign_spec( $campaign_id );
        $spec['last_reconcile_gmt'] = self::now();
        self::save_campaign_spec( $campaign_id, $spec );
        // Preserve the legacy top-level inventory fields so existing clients
        // that read added/reopened/scope_mode do not break when convergence is
        // added to the response contract.
        return array( 'campaign_id'=>$campaign_id ) + $inventory + array( 'stale_claims_recovered'=>$stale, 'inventory'=>$inventory, 'convergence'=>$convergence );
    }

    private static function reconcile_if_due( string $campaign_id, int $interval_seconds = 300 ): array {
        $spec = self::campaign_spec( $campaign_id );
        $last = (string) ( $spec['last_reconcile_gmt'] ?? '' );
        $last_ts = $last ? strtotime( $last . ' UTC' ) : false;
        if ( $last_ts && ( time() - (int) $last_ts ) < max( 30, $interval_seconds ) ) {
            return array( 'campaign_id'=>$campaign_id, 'skipped'=>true, 'reason'=>'recent_reconcile', 'last_reconcile_gmt'=>$last );
        }
        return self::reconcile( $campaign_id );
    }

    /* -------------------------------------------------------------------
     * Reads.
     * ---------------------------------------------------------------- */

    public static function get_entity( string $campaign_id, string $entity_type, string $entity_id ): ?array {
        global $wpdb;
        // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        $row = $wpdb->get_row( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
            'SELECT * FROM ' . self::table() . ' WHERE campaign_id = %s AND entity_type = %s AND entity_id = %s',
            $campaign_id, sanitize_key( $entity_type ), (string) $entity_id
        ), ARRAY_A );
        return is_array( $row ) ? self::decode_row( $row ) : null;
    }

    private static function row_by_id( int $id ): ?array {
        global $wpdb;
        // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A );
        return is_array( $row ) ? self::decode_row( $row ) : null;
    }

    private static function counters( string $campaign_id ): array {
        global $wpdb;
        // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        $rows = $wpdb->get_results( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
            'SELECT status, COUNT(*) AS n FROM ' . self::table() . ' WHERE campaign_id = %s GROUP BY status',
            $campaign_id
        ), ARRAY_A );
        $totals = array_fill_keys( self::STATES, 0 );
        foreach ( (array) $rows as $row ) {
            $status = (string) $row['status'];
            if ( isset( $totals[ $status ] ) ) { $totals[ $status ] = (int) $row['n']; }
        }
        $totals['total'] = array_sum( $totals );
        return $totals;
    }

    private static function completion_state( string $campaign_id ): array {
        $counters = self::counters( $campaign_id );
        $spec = self::campaign_spec( $campaign_id );
        $unresolved = array_values( (array) ( $spec['unresolved_urls'] ?? array() ) );
        $expected_rows = 'explicit' === (string) ( $spec['scope_mode'] ?? '' )
            ? count( (array) ( $spec['entity_ids'] ?? array() ) )
            : (int) ( $counters['total'] ?? 0 );
        $open = (int) ( $counters[ self::PENDING ] ?? 0 ) + (int) ( $counters[ self::CLAIMED ] ?? 0 ) + (int) ( $counters[ self::APPLIED_UNVERIFIED ] ?? 0 ) + (int) ( $counters[ self::BLOCKED ] ?? 0 ) + (int) ( $counters[ self::REVIEW_REQUIRED ] ?? 0 );
        $complete = empty( $unresolved ) && 0 === $open && $expected_rows > 0 && (int) ( $counters[ self::COMPLETED ] ?? 0 ) === $expected_rows;
        return array(
            'campaign_complete' => $complete,
            'expected_entity_rows' => $expected_rows,
            'unresolved_source_url_count' => count( $unresolved ),
            'unresolved_source_urls_sample' => array_slice( $unresolved, 0, 20 ),
            'unmaterialized_entity_rows' => max( 0, $expected_rows - (int) ( $counters['total'] ?? 0 ) ),
            'remaining_entity_rows' => max( 0, $expected_rows - (int) ( $counters[ self::COMPLETED ] ?? 0 ) ),
        );
    }

    public static function status( array $args = array() ): array {
        self::ensure();
        $mission = self::active_mission();
        $campaign_id = (string) ( $args['campaign_id'] ?? ( $mission['campaign_id'] ?? '' ) );
        if ( '' === $campaign_id ) {
            return array( 'active_campaign' => false, 'campaign_id' => '', 'counters' => array_fill_keys( array_merge( self::STATES, array( 'total' ) ), 0 ), 'campaign_complete' => false );
        }
        return array(
            'active_campaign' => true,
            'campaign_id' => $campaign_id,
            'scope' => self::public_scope( self::campaign_spec( $campaign_id ) ),
            'counters' => self::counters( $campaign_id ),
        ) + self::completion_state( $campaign_id );
    }

    /* -------------------------------------------------------------------
     * Stale-claim recovery.
     *
     * CLAIMED (no mutation executed yet) safely reverts to PENDING on lease
     * expiry -- nothing was lost. APPLIED_UNVERIFIED (a mutation already
     * executed) never reverts to PENDING: LAW 2 forbids treating verification
     * uncertainty as grounds to re-execute. Its lease is released so a
     * verification pass can pick it back up, but claim_next() only ever
     * selects PENDING rows, so it structurally cannot be handed out again.
     * ---------------------------------------------------------------- */

    private static function recover_stale_claims( string $campaign_id ): int {
        global $wpdb;
        // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        $reverted = (int) $wpdb->query( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional: lease-expiry sweep is set-based by design, matching PRSTUDIO_UC_Store::recover_stale_tasks().
            'UPDATE ' . self::table() . ' SET status = %s, claim_token = NULL, claim_expires_gmt = NULL, worker_id = NULL, updated_gmt = %s WHERE campaign_id = %s AND status = %s AND claim_expires_gmt IS NOT NULL AND claim_expires_gmt < UTC_TIMESTAMP()',
            self::PENDING, self::now(), $campaign_id, self::CLAIMED
        ) );
        // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
        $wpdb->query( $wpdb->prepare(
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional: lease-release-only sweep for already-executed mutations (status is deliberately not changed here -- see method docblock).
            'UPDATE ' . self::table() . ' SET claim_token = NULL, claim_expires_gmt = NULL, worker_id = NULL, updated_gmt = %s WHERE campaign_id = %s AND status = %s AND claim_expires_gmt IS NOT NULL AND claim_expires_gmt < UTC_TIMESTAMP()',
            self::now(), $campaign_id, self::APPLIED_UNVERIFIED
        ) );
        return $reverted;
    }

    /* -------------------------------------------------------------------
     * Atomic claim -- transactional SELECT ... FOR UPDATE + UPDATE, the
     * exact pattern proven by PRSTUDIO_UC_Store::claim_next(). WHERE status
     * = PENDING structurally excludes COMPLETED and APPLIED_UNVERIFIED rows;
     * the row lock inside one transaction is what makes two concurrent
     * callers land on different rows instead of colliding.
     * ---------------------------------------------------------------- */

    public static function claim_next( string $campaign_id, string $worker_id ): ?array {
        self::ensure();
        global $wpdb;
        self::recover_stale_claims( $campaign_id );
        $token = bin2hex( random_bytes( 16 ) );
        $expires = gmdate( 'Y-m-d H:i:s', time() + self::CLAIM_LEASE_SECONDS );
        $table = self::table();

        $wpdb->query( 'START TRANSACTION' );
        try {
            // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table identifier only, from the fixed table() helper -- never external input; values are parameterized via $wpdb->prepare()
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional: transactional atomic claim, matching PRSTUDIO_UC_Store::claim_next() exactly; object-cache/WP_Query are unsuitable for a locked row claim.
                    "SELECT * FROM $table WHERE campaign_id = %s AND status = %s ORDER BY id ASC LIMIT 1 FOR UPDATE",
                    $campaign_id,
                    self::PENDING
                ),
                ARRAY_A
            );
            if ( ! is_array( $row ) ) {
                $wpdb->query( 'COMMIT' );
                return null;
            }
            $wpdb->update(
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- intentional: part of the same atomic claim transaction as the SELECT ... FOR UPDATE above.
                $table,
                array(
                    'status' => self::CLAIMED,
                    'claim_token' => $token,
                    'claim_expires_gmt' => $expires,
                    'worker_id' => substr( sanitize_text_field( $worker_id ), 0, 160 ),
                    'attempt_count' => (int) ( $row['attempt_count'] ?? 0 ) + 1,
                    'updated_gmt' => self::now(),
                ),
                array( 'id' => (int) $row['id'] ),
                array( '%s', '%s', '%s', '%s', '%d', '%s' ),
                array( '%d' )
            );
            $wpdb->query( 'COMMIT' );
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            throw $e;
        }
        $entity = self::row_by_id( (int) $row['id'] );
        if ( $entity ) { $entity['claim_token'] = $token; }
        return $entity;
    }

    /* -------------------------------------------------------------------
     * Transitions past the claim.
     * ---------------------------------------------------------------- */

    public static function mark_applied_unverified( string $campaign_id, string $entity_type, string $entity_id, string $claim_token, array $resolved_issues = array() ): ?array {
        global $wpdb;
        $updated = $wpdb->update(
            self::table(),
            array( 'status' => self::APPLIED_UNVERIFIED, 'resolved_issues' => self::encode( $resolved_issues ), 'updated_gmt' => self::now() ),
            array( 'campaign_id' => $campaign_id, 'entity_type' => sanitize_key( $entity_type ), 'entity_id' => (string) $entity_id, 'claim_token' => $claim_token, 'status' => self::CLAIMED ),
            array( '%s', '%s', '%s' ),
            array( '%s', '%s', '%s', '%s', '%s' )
        );
        return 1 === (int) $updated ? self::get_entity( $campaign_id, $entity_type, $entity_id ) : null;
    }

    private static function completion_acceptance( string $campaign_id, string $entity_type, string $entity_id, array $meta ): array {
        $spec = self::campaign_spec( $campaign_id );
        $requirements = (array) ( $spec['requirements'] ?? array() );
        $violations = array();
        $snapshot = array( 'entity_type' => $entity_type, 'entity_id' => $entity_id );
        if ( 'product' === sanitize_key( $entity_type ) && function_exists( 'wc_get_product' ) ) {
            $product = wc_get_product( absint( $entity_id ) );
            if ( $product ) {
                $id = (int) $product->get_id();
                $score_raw = function_exists( 'get_post_meta' ) ? get_post_meta( $id, 'rank_math_seo_score', true ) : '';
                $score = is_numeric( $score_raw ) ? (float) $score_raw : null;
                $focus_raw = function_exists( 'get_post_meta' ) ? trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) ) : '';
                $focus = array_values( array_filter( array_map( 'trim', preg_split( '/\s*,\s*/', $focus_raw ) ?: array() ) ) );
                $image_id = (int) $product->get_image_id();
                $alt = $image_id && function_exists( 'get_post_meta' ) ? trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) : '';
                $snapshot += array(
                    'rank_math_score' => $score, 'rank_math_score_available' => null !== $score,
                    'focus_keywords' => $focus, 'focus_keyword_count' => count( $focus ),
                    'image_id' => $image_id, 'image_alt_present' => '' !== $alt,
                    'gallery_image_ids' => array_values( array_map( 'absint', (array) $product->get_gallery_image_ids() ) ),
                );
                $target = (int) ( $requirements['rank_math_target_score'] ?? 0 );
                if ( $target > 0 && ( null === $score || $score < $target ) ) {
                    $violations[] = array( 'code' => null === $score ? 'rank_math_score_unavailable' : 'rank_math_score_below_target', 'target' => $target, 'observed' => $score );
                }
                $min_kw = (int) ( $requirements['min_focus_keywords'] ?? 0 );
                if ( $min_kw > 0 && count( $focus ) < $min_kw ) {
                    $violations[] = array( 'code' => 'focus_keyword_count_below_target', 'target' => $min_kw, 'observed' => count( $focus ) );
                }
                $media_policy = (string) ( $requirements['media_policy'] ?? 'preserve' );
                $media_decision = sanitize_key( (string) ( $meta['media_decision'] ?? '' ) );
                $media_search_performed = ! empty( $meta['media_search_performed'] );
                $media_candidates_found = max( 0, (int) ( $meta['media_candidates_found'] ?? 0 ) );
                $media_changed = ! empty( $meta['media_changed'] );
                $gallery_ids = array_values( array_map( 'absint', (array) $product->get_gallery_image_ids() ) );
                $media_available = $image_id > 0 || ! empty( $gallery_ids ) || $media_candidates_found > 0;
                $snapshot['media_decision'] = $media_decision;
                $snapshot['media_search_performed'] = $media_search_performed;
                $snapshot['media_candidates_found'] = $media_candidates_found;
                $snapshot['media_changed'] = $media_changed;
                if ( 'require_image' === $media_policy && $image_id <= 0 ) {
                    $violations[] = array( 'code' => 'product_image_required' );
                } elseif ( 'review_if_available' === $media_policy ) {
                    if ( ! $media_search_performed ) {
                        $violations[] = array( 'code' => 'media_search_required' );
                    }
                    $accepted_decisions = $media_available ? array( 'updated', 'kept_relevant' ) : array( 'none_available', 'updated' );
                    if ( ! in_array( $media_decision, $accepted_decisions, true ) ) {
                        $violations[] = array( 'code' => 'media_review_not_recorded', 'accepted' => $accepted_decisions );
                    }
                    if ( 'updated' === $media_decision && ! $media_changed ) {
                        $violations[] = array( 'code' => 'media_update_not_evidenced' );
                    }
                    if ( 'kept_relevant' === $media_decision && $image_id > 0 && '' === $alt ) {
                        $violations[] = array( 'code' => 'kept_media_missing_alt' );
                    }
                }
            }
        }
        $remaining = array_values( array_filter( array_map( 'strval', (array) ( $meta['remaining_issues'] ?? array() ) ) ) );
        if ( ! empty( $requirements['strict_scope'] ) && ! empty( $remaining ) ) {
            $violations[] = array( 'code' => 'remaining_report_issues', 'issues' => array_slice( $remaining, 0, 50 ) );
        }
        if ( ! empty( $requirements['require_verified'] ) && empty( $meta['verified'] ) ) {
            $violations[] = array( 'code' => 'verification_required' );
        }
        if ( ! empty( $requirements['require_live_rank_math_score'] ) ) {
            $observed = isset( $meta['rank_math_score_observed'] ) && is_numeric( $meta['rank_math_score_observed'] ) ? (float) $meta['rank_math_score_observed'] : null;
            $snapshot['rank_math_score_observed'] = $observed;
            $target = (int) ( $requirements['rank_math_target_score'] ?? 0 );
            if ( null === $observed ) {
                $violations[] = array( 'code' => 'live_rank_math_score_not_observed' );
            } elseif ( $target > 0 && $observed < $target ) {
                $violations[] = array( 'code' => 'live_rank_math_score_below_target', 'target' => $target, 'observed' => $observed );
            }
        }
        return array( 'ok' => empty( $violations ), 'requirements' => $requirements, 'snapshot' => $snapshot, 'violations' => $violations );
    }

    /**
     * CLAIMED or APPLIED_UNVERIFIED both complete. `meta.verified`/`meta.degraded`
     * are stored as evidence (LAW 2: `executed=true, verified=false,
     * degraded=true, blocking=false`) -- they never prevent completion.
     */
    public static function complete_entity( string $campaign_id, string $entity_type, string $entity_id, string $claim_token, array $meta = array() ): ?array {
        global $wpdb;
        $entity = self::get_entity( $campaign_id, $entity_type, $entity_id );
        if ( ! $entity || '' === $claim_token || ! hash_equals( (string) ( $entity['claim_token'] ?? '' ), $claim_token ) ) { return null; }
        if ( ! in_array( (string) $entity['status'], array( self::CLAIMED, self::APPLIED_UNVERIFIED ), true ) ) { return null; }
        $fingerprint = (string) ( $meta['completed_fingerprint'] ?? '' );
        // A successful SEO pass normally changes the product. Recording the
        // pre-edit source fingerprint would make the next reconcile reopen the
        // row immediately. Unless the caller supplied an explicit post-edit
        // fingerprint, compute it from the live product now.
        if ( '' === $fingerprint && 'product' === sanitize_key( $entity_type ) && function_exists( 'wc_get_product' ) ) {
            $current_product = wc_get_product( absint( $entity_id ) );
            if ( $current_product ) { $fingerprint = self::fingerprint_of( $current_product ); }
        }
        if ( '' === $fingerprint ) { $fingerprint = (string) ( $entity['source_fingerprint'] ?? '' ); }
        $verified = (bool) ( $meta['verified'] ?? false );
        $updated = $wpdb->update(
            self::table(),
            array(
                'status' => self::COMPLETED,
                'completed_fingerprint' => $fingerprint,
                'remaining_issues' => self::encode( $meta['remaining_issues'] ?? array() ),
                'verification' => self::encode( array( 'verified' => $verified, 'degraded' => (bool) ( $meta['degraded'] ?? ! $verified ) ) ),
                'claim_token' => null, 'claim_expires_gmt' => null, 'worker_id' => null,
                'updated_gmt' => self::now(), 'completed_gmt' => self::now(),
            ),
            array( 'campaign_id' => $campaign_id, 'entity_type' => sanitize_key( $entity_type ), 'entity_id' => (string) $entity_id, 'claim_token' => $claim_token ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ),
            array( '%s', '%s', '%s', '%s' )
        );
        if ( 1 !== (int) $updated ) { return null; }
        if ( class_exists( 'PRSTUDIO_UC_Interventions' ) ) {
            PRSTUDIO_UC_Interventions::record(
                self::entity_key( $entity_type, $entity_id ), 'seo_autopilot_pass', PRSTUDIO_UC_Interventions::APPLIED,
                array( 'summary' => 'SEO Autopilot campaign pass completed.', 'correlation_id' => $campaign_id )
            );
        }
        return self::get_entity( $campaign_id, $entity_type, $entity_id );
    }

    /**
     * BLOCKED is constitutionally narrow (AGENTS.md: no feature but the
     * Anti-Crash guard may stop a technically valid action). Call this only
     * for a genuine technical/business impossibility -- never for model
     * uncertainty, which belongs in complete_entity()'s degraded=true path.
     */
    public static function block_entity( string $campaign_id, string $entity_type, string $entity_id, string $claim_token, string $reason ): ?array {
        global $wpdb;
        $entity = self::get_entity( $campaign_id, $entity_type, $entity_id );
        if ( ! $entity || '' === $claim_token || ! hash_equals( (string) ( $entity['claim_token'] ?? '' ), $claim_token ) ) { return null; }
        $updated = $wpdb->update(
            self::table(),
            array( 'status' => self::BLOCKED, 'block_reason' => substr( sanitize_text_field( $reason ), 0, 255 ), 'claim_token' => null, 'claim_expires_gmt' => null, 'worker_id' => null, 'updated_gmt' => self::now() ),
            array( 'campaign_id' => $campaign_id, 'entity_type' => sanitize_key( $entity_type ), 'entity_id' => (string) $entity_id, 'claim_token' => $claim_token ),
            array( '%s', '%s', '%s', '%s', '%s', '%s' ),
            array( '%s', '%s', '%s', '%s' )
        );
        return 1 === (int) $updated ? self::get_entity( $campaign_id, $entity_type, $entity_id ) : null;
    }

    /** Gives back a claim before any mutation happened (CLAIMED only -- see recover_stale_claims() for the automatic path). */
    public static function release_claim( string $campaign_id, string $entity_type, string $entity_id, string $claim_token ): ?array {
        global $wpdb;
        $entity = self::get_entity( $campaign_id, $entity_type, $entity_id );
        if ( ! $entity || '' === $claim_token || ! hash_equals( (string) ( $entity['claim_token'] ?? '' ), $claim_token ) || self::CLAIMED !== (string) $entity['status'] ) { return null; }
        $updated = $wpdb->update(
            self::table(),
            array( 'status' => self::PENDING, 'claim_token' => null, 'claim_expires_gmt' => null, 'worker_id' => null, 'updated_gmt' => self::now() ),
            array( 'campaign_id' => $campaign_id, 'entity_type' => sanitize_key( $entity_type ), 'entity_id' => (string) $entity_id, 'claim_token' => $claim_token ),
            array( '%s', '%s', '%s', '%s', '%s' ),
            array( '%s', '%s', '%s', '%s' )
        );
        return 1 === (int) $updated ? self::get_entity( $campaign_id, $entity_type, $entity_id ) : null;
    }

    /** A COMPLETED row whose live fingerprint drifted reopens to PENDING; an unchanged fingerprint is left untouched. */
    public static function reopen_if_changed( string $campaign_id, string $entity_type, string $entity_id, string $current_fingerprint ): ?array {
        global $wpdb;
        $entity = self::get_entity( $campaign_id, $entity_type, $entity_id );
        if ( ! $entity || self::COMPLETED !== (string) $entity['status'] ) { return $entity; }
        if ( hash_equals( (string) ( $entity['completed_fingerprint'] ?? '' ), $current_fingerprint ) ) { return $entity; }
        $updated = $wpdb->update(
            self::table(),
            array( 'status' => self::PENDING, 'source_fingerprint' => $current_fingerprint, 'updated_gmt' => self::now() ),
            array( 'campaign_id' => $campaign_id, 'entity_type' => sanitize_key( $entity_type ), 'entity_id' => (string) $entity_id, 'status' => self::COMPLETED ),
            array( '%s', '%s', '%s' ),
            array( '%s', '%s', '%s', '%s' )
        );
        return 1 === (int) $updated ? self::get_entity( $campaign_id, $entity_type, $entity_id ) : $entity;
    }

    /* -------------------------------------------------------------------
     * MCP entry points.
     * ---------------------------------------------------------------- */

    /** prstudio_seo_autopilot_status -- read-only. */
    public static function mcp_status( array $args = array() ): array {
        return self::status( $args );
    }

    /** prstudio_seo_autopilot_next -- resolves/creates the campaign, reconciles, atomically claims one entity. */
    public static function mcp_next( array $args = array() ): array {
        self::ensure();
        $bootstrap = self::ensure_campaign( $args );
        $campaign_id = (string) $bootstrap['campaign_id'];
        if ( empty( $args['skip_reconcile'] ) ) { self::reconcile_if_due( $campaign_id ); }
        $worker_id = (string) ( $args['worker_id'] ?? ( $args['_client_id'] ?? 'seo-autopilot' ) );
        $claim = self::claim_next( $campaign_id, $worker_id );
        if ( ! $claim ) {
            return array( 'campaign_id' => $campaign_id, 'has_next' => false, 'scope' => self::public_scope( self::campaign_spec( $campaign_id ) ), 'counters' => self::counters( $campaign_id ), 'meaning' => 'No PENDING entity remains in this campaign.' ) + self::completion_state( $campaign_id );
        }
        $settled = array();
        if ( class_exists( 'PRSTUDIO_UC_Interventions' ) ) {
            $check = PRSTUDIO_UC_Interventions::filter_new(
                array(
                    array( 'entity_key' => self::entity_key( $claim['entity_type'], $claim['entity_id'] ), 'intervention_key' => 'seo_autopilot_pass' ),
                    array( 'entity_key' => self::entity_key( $claim['entity_type'], $claim['entity_id'] ), 'intervention_key' => 'seo_rotation_cooldown' )
                ),
                true
            );
            $settled = $check['already_settled'] ?? array();
        }
        return array(
            'campaign_id' => $campaign_id,
            'has_next' => true,
            'entity' => array(
                'entity_type' => $claim['entity_type'],
                'entity_id' => $claim['entity_id'],
                'entity_key' => $claim['entity_key'],
                'claim_token' => $claim['claim_token'],
                'claim_expires_gmt' => $claim['claim_expires_gmt'],
                'source_fingerprint' => $claim['source_fingerprint'],
                'attempt_count' => (int) $claim['attempt_count'],
            ),
            'already_settled_elsewhere' => $settled,
            'scope' => self::public_scope( self::campaign_spec( $campaign_id ) ),
            'counters' => self::counters( $campaign_id ),
        ) + self::completion_state( $campaign_id );
    }

    /** prstudio_seo_autopilot_control -- action-based mutations on the claimed entity or the campaign itself. */
    public static function mcp_control( array $args = array() ): array {
        self::ensure();
        $action = sanitize_key( (string) ( $args['action'] ?? '' ) );
        $mission = self::active_mission();
        $campaign_id = (string) ( $args['campaign_id'] ?? ( $mission['campaign_id'] ?? '' ) );
        if ( '' === $campaign_id && 'init' !== $action ) {
            return array( 'ok' => false, 'reason' => 'no_active_campaign' );
        }
        $entity_type = (string) ( $args['entity_type'] ?? 'product' );
        $entity_id = (string) ( $args['entity_id'] ?? '' );
        $claim_token = (string) ( $args['claim_token'] ?? '' );

        switch ( $action ) {
            case 'init':
                return array( 'ok' => true ) + self::ensure_campaign( $args );
            case 'reconcile':
                return array( 'ok' => true ) + self::reconcile( $campaign_id );
            case 'converge':
                return array( 'ok' => true ) + self::converge( $campaign_id );
            case 'mark_applied_unverified':
                $row = self::mark_applied_unverified( $campaign_id, $entity_type, $entity_id, $claim_token, (array) ( $args['resolved_issues'] ?? array() ) );
                return $row ? array( 'ok' => true, 'entity' => $row ) : array( 'ok' => false, 'reason' => 'claim_mismatch_or_wrong_state' );
            case 'complete':
                $acceptance = self::completion_acceptance( $campaign_id, $entity_type, $entity_id, (array) $args );
                if ( ! $acceptance['ok'] ) {
                    return array( 'ok' => false, 'reason' => 'acceptance_not_met', 'acceptance' => $acceptance, 'counters' => self::counters( $campaign_id ) ) + self::completion_state( $campaign_id );
                }
                $row = self::complete_entity( $campaign_id, $entity_type, $entity_id, $claim_token, (array) $args );
                return $row ? array( 'ok' => true, 'entity' => $row, 'acceptance' => $acceptance, 'counters' => self::counters( $campaign_id ) ) + self::completion_state( $campaign_id ) : array( 'ok' => false, 'reason' => 'claim_mismatch_or_wrong_state' );
            case 'block':
                $row = self::block_entity( $campaign_id, $entity_type, $entity_id, $claim_token, (string) ( $args['reason'] ?? '' ) );
                return $row ? array( 'ok' => true, 'entity' => $row, 'counters' => self::counters( $campaign_id ) ) : array( 'ok' => false, 'reason' => 'claim_mismatch_or_wrong_state' );
            case 'release':
                $row = self::release_claim( $campaign_id, $entity_type, $entity_id, $claim_token );
                return $row ? array( 'ok' => true, 'entity' => $row ) : array( 'ok' => false, 'reason' => 'claim_mismatch_or_wrong_state' );
            default:
                return array( 'ok' => false, 'reason' => 'unknown_action', 'known_actions' => array( 'init', 'reconcile', 'converge', 'mark_applied_unverified', 'complete', 'block', 'release' ) );
        }
    }
}
