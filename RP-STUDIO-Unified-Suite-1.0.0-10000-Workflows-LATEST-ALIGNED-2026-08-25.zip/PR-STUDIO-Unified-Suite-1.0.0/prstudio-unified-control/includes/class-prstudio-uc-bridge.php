<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class PRSTUDIO_UC_Bridge {
	private static array $registered = array();

	public static function register(): void {
		if ( ! defined( 'WPAIB_DIR' ) ) { return; }
		$catalog_path = trailingslashit( WPAIB_DIR ) . 'connector/action-catalog.json';
		$catalog = is_readable( $catalog_path ) ? json_decode( (string) file_get_contents( $catalog_path ), true ) : null;
		if ( ! is_array( $catalog ) || ! is_array( $catalog['actions'] ?? null ) ) { return; }
		foreach ( $catalog['actions'] as $meta ) {
			if ( ! is_array( $meta ) || '/frontend-manage' !== (string) ( $meta['route'] ?? '' ) ) { continue; }
			$action = sanitize_key( (string) ( $meta['action'] ?? '' ) );
			if ( ! self::is_browser_action( $action ) ) { continue; }
			$hook = sanitize_key( (string) ( $meta['adapter_hook'] ?? '' ) );
			if ( '' === $hook ) { $hook = 'rpconnector_admin_execute_frontend_manage_' . $action; }
			if ( isset( self::$registered[ $hook ] ) ) { continue; }
			add_filter( $hook, array( __CLASS__, 'dispatch' ), 5, 3 );
			self::$registered[ $hook ] = true;
		}
		if ( class_exists( 'PRSTUDIO_UC_Contract' ) ) {
			foreach ( PRSTUDIO_UC_Contract::browser_overlay_actions() as $meta ) {
				$action = sanitize_key( (string) ( $meta['action'] ?? '' ) );
				if ( ! self::is_browser_action( $action ) ) { continue; }
				$hook = sanitize_key( (string) ( $meta['adapter_hook'] ?? '' ) );
				if ( '' === $hook ) { $hook = 'rpconnector_admin_execute_frontend_manage_' . $action; }
				if ( isset( self::$registered[ $hook ] ) ) { continue; }
				add_filter( $hook, array( __CLASS__, 'dispatch' ), 5, 3 );
				self::$registered[ $hook ] = true;
			}
		}
	}

	private static function canonical_browser_action( string $action ): string {
		$action = sanitize_key( $action );
		if ( 'puppeteer_screenshot' === $action || 'puppeteer_page_screenshot' === $action ) { return 'playwright_screenshot_page'; }
		if ( 'puppeteer_screenshot_element' === $action ) { return 'playwright_screenshot_element'; }
		if ( 'puppeteer_new_page' === $action ) { return 'playwright_new_page'; }
		return str_starts_with( $action, 'puppeteer_' ) ? 'playwright_' . substr( $action, 10 ) : $action;
	}

	private static function is_browser_action( string $action ): bool {
		$action = self::canonical_browser_action( $action );
		if ( str_starts_with( $action, 'search_console_' ) ) { return true; }
		if ( 'browserking_agent_prompt' === $action ) { return true; }
		if ( ! class_exists( 'PRSTUDIO_UC_Contract' ) ) { return str_starts_with( $action, 'playwright_' ); }
		$meta = PRSTUDIO_UC_Contract::by_action( '/frontend-manage', $action );
		return is_array( $meta ) && 'browser_agent' === (string) ( $meta['executor'] ?? '' );
	}

	public static function dispatch( $current, array $arguments, array $meta ) {
		if ( null !== $current ) { return $current; }
		$arguments = self::normalize_arguments( $arguments );
		$correlation_id = sanitize_text_field( (string) ( $arguments['_prstudio_correlation_id'] ?? $arguments['correlation_id'] ?? '' ) );
		$correlation_id = preg_match( '/^corr_[a-f0-9]{32}$/', $correlation_id ) ? $correlation_id : '';
		unset( $arguments['_prstudio_correlation_id'] );
		if ( '' !== $correlation_id ) { $arguments['correlation_id'] = $correlation_id; }
		$requested_action = sanitize_key( (string) ( $meta['action'] ?? $arguments['action'] ?? '' ) );
		$action = self::canonical_browser_action( $requested_action );
		if ( $requested_action !== $action ) { $arguments['_prstudio_action_alias'] = $requested_action; }
		$target = sanitize_key( (string) ( $arguments['browser_target'] ?? $arguments['target'] ?? '' ) );
		if ( '' === $target ) {
			$online = array_filter( PRSTUDIO_UC_Store::list_devices(), static fn( $device ) => ! empty( $device['online'] ) );
			$target = $online ? 'live' : 'lab';
		}
		if ( in_array( $target, array( 'lab', 'local', 'playwright' ), true ) ) { return null; }
		if ( ! in_array( $target, array( 'live', 'personal_chrome', 'chrome_extension' ), true ) ) { return null; }
		if ( ! self::is_browser_action( $action ) ) { return null; }

		if ( 'playwright_status' === $action && ! empty( $arguments['task_id'] ) ) {
			$task_id = sanitize_text_field( (string) $arguments['task_id'] );
			$wait = max( 0, min( 20, absint( $arguments['sync_wait_seconds'] ?? $arguments['wait_seconds'] ?? 0 ) ) );
			if ( $wait > 0 && class_exists( 'PRSTUDIO_UC_Wait_Channel' ) ) {
				$outcome = PRSTUDIO_UC_Wait_Channel::wait_until(
					$wait,
					static fn() => PRSTUDIO_UC_Store::get_task( $task_id ),
					static function( $task ): bool {
						return ! is_array( $task ) || PRSTUDIO_UC_State_Machine::is_terminal( (string) ( $task['status'] ?? '' ) );
					}
				);
				$task = is_array( $outcome['value'] ?? null ) ? $outcome['value'] : null;
			} else {
				$task = PRSTUDIO_UC_Store::get_task( $task_id );
			}
			return is_array( $task ) ? self::task_response( $task ) : new WP_Error( 'prstudio_uc_task_missing', 'Task browser non trovato.', array( 'status'=>404 ) );
		}

		if ( 'playwright_status' === $action ) {
			$all_devices = PRSTUDIO_UC_Store::list_devices();
			$include_history = ! empty( $arguments['include_history'] );
			$visible_devices = $include_history ? $all_devices : array_values( array_filter( $all_devices, static fn( $device ) => 'active' === (string) ( $device['status'] ?? '' ) ) );
			$device_filter = sanitize_key( (string) ( $arguments['device_status'] ?? '' ) );
			if ( '' !== $device_filter ) {
				$visible_devices = array_values( array_filter( $visible_devices, static fn( $device ) => $device_filter === (string) ( $device['status'] ?? '' ) || $device_filter === (string) ( $device['connection_status'] ?? '' ) ) );
			}
			$device_id_filter = sanitize_text_field( (string) ( $arguments['device_id'] ?? '' ) );
			if ( '' !== $device_id_filter ) {
				$visible_devices = array_values( array_filter( $visible_devices, static fn( $device ) => $device_id_filter === (string) ( $device['device_uuid'] ?? '' ) ) );
			}
			$matched = count( $visible_devices );
			$limit = max( 1, min( 100, (int) ( $arguments['limit'] ?? ( $include_history ? 25 : 100 ) ) ) );
			$offset = max( 0, (int) ( $arguments['offset'] ?? 0 ) );
			$page = array_slice( $visible_devices, $offset, $limit );
			$devices = PRSTUDIO_UC_Store::public_devices( $page );
			$available = ! empty( array_filter( $all_devices, static fn( $device ) => ! empty( $device['online'] ) ) );
			return array(
				'ok'=>$available,
				'status'=>$available ? 'ready' : 'offline',
				'terminal'=>true,
				'available'=>$available,
				'provider'=>'prstudio_chrome_extension',
				'target'=>'live',
				'devices'=>$devices,
				'page'=>array(
					'returned'=>count( $devices ), 'matched'=>$matched, 'limit'=>$limit, 'offset'=>$offset,
					'has_more'=>( $offset + count( $devices ) ) < $matched,
					'next_offset'=>( $offset + count( $devices ) ) < $matched ? $offset + $limit : null,
					'filters'=>array( 'device_status'=>$device_filter, 'device_id'=>$device_id_filter ),
					'note'=>'Bounded so the response is never truncated in transport. Use offset or filters to reach the rest.',
				),
				'device_history'=>array(
					'total'=>count( $all_devices ),
					'active'=>count( array_filter( $all_devices, static fn( $row ) => 'active' === (string) ( $row['status'] ?? '' ) ) ),
					'online'=>count( array_filter( $all_devices, static fn( $row ) => 'online' === (string) ( $row['connection_status'] ?? '' ) ) ),
					'offline'=>count( array_filter( $all_devices, static fn( $row ) => 'offline' === (string) ( $row['connection_status'] ?? '' ) ) ),
					'stale'=>count( array_filter( $all_devices, static fn( $row ) => 'stale' === (string) ( $row['connection_status'] ?? '' ) ) ),
					'revoked'=>count( array_filter( $all_devices, static fn( $row ) => 'revoked' === (string) ( $row['status'] ?? '' ) ) ),
				),
				'ocr'=>PRSTUDIO_UC_OCR::status(),
				'extension_local_studio'=>class_exists( 'PRSTUDIO_UC_REST' ) ? PRSTUDIO_UC_REST::browser_extension_summary( $include_history ) : array( 'aware'=>false ),
				'integration_chain'=>class_exists( 'PRSTUDIO_UC_REST' ) ? PRSTUDIO_UC_REST::integration_capabilities() : array(),
				'screenshot_storage'=>class_exists( 'PRSTUDIO_UC_Artifacts' ) ? PRSTUDIO_UC_Artifacts::status() : array( 'ok'=>false ),
				'_control_outcome'=>array( 'status'=>$available ? 'verified' : 'technical_error', 'executed'=>true, 'mutated'=>false, 'verified'=>$available, 'degraded'=>false, 'blocking'=>false ),
				'error'=>$available ? array() : array( 'code'=>'prstudio_browser_agent_offline', 'message'=>'Nessun Browser Agent online.', 'retryable'=>true ),
			);
		}

		$job_uuid = sanitize_text_field( (string) ( $arguments['_prstudio_job_uuid'] ?? $arguments['job_id'] ?? '' ) );
		unset( $arguments['browser_target'], $arguments['target'], $arguments['_prstudio_job_uuid'], $arguments['job_id'] );
		$online_devices = array_values( array_filter( PRSTUDIO_UC_Store::list_devices(), static fn( $device ) => ! empty( $device['online'] ) ) );
		if ( ! $online_devices ) {
			return new WP_Error( 'prstudio_browser_agent_offline', 'PR STUDIO Browser Agent non è online.', array( 'status'=>503, 'retryable'=>true, 'devices'=>PRSTUDIO_UC_Store::public_devices( PRSTUDIO_UC_Store::list_devices() ) ) );
		}
		$requested_device = ! empty( $arguments['device_id'] ) ? sanitize_text_field( (string) $arguments['device_id'] ) : (string) $online_devices[0]['device_uuid'];
		$device_id = PRSTUDIO_UC_Store::resolve_device_uuid( $requested_device, true );
		if ( null === $device_id ) {
			return new WP_Error( 'prstudio_browser_device_unavailable', 'Il Browser Agent richiesto non esiste o non è online.', array( 'status'=>409, 'retryable'=>true, 'devices'=>PRSTUDIO_UC_Store::public_devices( $online_devices ) ) );
		}
		unset( $arguments['device_id'] );
		$wait = max( 0, min( 20, absint( $arguments['sync_wait_seconds'] ?? 5 ) ) );
		unset( $arguments['sync_wait_seconds'] );

		$task = PRSTUDIO_UC_Job_Engine::create_browser_task( $action, $arguments, $device_id, $job_uuid );
		$task_uuid = (string) ( $task['task_uuid'] ?? '' );
		if ( '' === $task_uuid || $wait <= 0 ) { return self::task_response( $task ); }

		if ( class_exists( 'PRSTUDIO_UC_Wait_Channel' ) ) {
			$outcome = PRSTUDIO_UC_Wait_Channel::wait_until(
				$wait,
				static fn() => PRSTUDIO_UC_Store::get_task( $task_uuid ),
				static function( $current_task ): bool {
					return is_array( $current_task ) && PRSTUDIO_UC_State_Machine::is_terminal( (string) ( $current_task['status'] ?? '' ) );
				}
			);
			$final_task = is_array( $outcome['value'] ?? null ) ? $outcome['value'] : $task;
			return self::task_response( $final_task );
		}

		$deadline = microtime( true ) + $wait;
		do {
			$current_task = PRSTUDIO_UC_Store::get_task( $task_uuid );
			if ( $current_task && PRSTUDIO_UC_State_Machine::is_terminal( (string) ( $current_task['status'] ?? '' ) ) ) { return self::task_response( $current_task ); }
			usleep( 100000 );
		} while ( microtime( true ) < $deadline );
		return self::task_response( PRSTUDIO_UC_Store::get_task( $task_uuid ) ?? $task );
	}

	private static function normalize_arguments( array $arguments ): array {
		// JSON object {} and JSON array [] both decode to an empty PHP array. CDP
		// params are semantically an object, so remember this specific shape and
		// re-materialize it as stdClass before the task is JSON encoded again.
		$empty_params_object = array_key_exists( 'params', $arguments ) && is_array( $arguments['params'] ) && array() === $arguments['params'];
		foreach ( array( 'payload', 'params', 'body', 'query' ) as $container ) {
			if ( isset( $arguments[$container] ) && is_array( $arguments[$container] ) ) { $arguments = array_replace( $arguments[$container], $arguments ); }
		}
		if ( $empty_params_object ) { $arguments['params'] = new stdClass(); }
		unset( $arguments['_route'], $arguments['_source'], $arguments['mutation'] );
		return $arguments;
	}

	private static function result_tab_id( $value, int $depth = 0 ): int {
		if ( $depth > 6 || ! is_array( $value ) ) { return 0; }
		foreach ( array( 'tabId', 'tab_id' ) as $key ) {
			if ( isset( $value[$key] ) && (int) $value[$key] > 0 ) { return (int) $value[$key]; }
		}
		foreach ( $value as $child ) {
			$tab_id = self::result_tab_id( $child, $depth + 1 );
			if ( $tab_id > 0 ) { return $tab_id; }
		}
		return 0;
	}

	private static function task_response( array $task ): array {
		$status = (string) ( $task['status'] ?? 'unknown' );
		$terminal = PRSTUDIO_UC_State_Machine::is_terminal( $status );
		$verification = is_array( $task['verification'] ?? null ) ? $task['verification'] : array();
		$executed = PRSTUDIO_UC_State_Machine::COMPLETED === $status;
		$completed_verified = $executed && ! empty( $verification['ok'] );
		$cancelled = PRSTUDIO_UC_State_Machine::CANCELLED === $status;
		$expired = PRSTUDIO_UC_State_Machine::EXPIRED === $status;
		$failed = PRSTUDIO_UC_State_Machine::FAILED === $status;

		$correlation_raw = sanitize_text_field( (string) ( $task['arguments']['correlation_id'] ?? $task['result']['correlation_id'] ?? '' ) );
		$correlation_id = substr( (string) preg_replace( '/[^A-Za-z0-9_.:-]/', '', $correlation_raw ), 0, 128 );
		$correlation_canonical = 1 === preg_match( '/^corr_[a-f0-9]{32}$/', $correlation_id );

		if ( $completed_verified ) { $outcome_status = 'verified'; }
		elseif ( $executed ) { $outcome_status = 'degraded'; }
		elseif ( $cancelled ) { $outcome_status = 'cancelled'; }
		elseif ( $expired ) { $outcome_status = 'expired'; }
		elseif ( $terminal ) { $outcome_status = 'technical_error'; }
		else { $outcome_status = 'queued'; }

		$error = is_array( $task['error'] ?? null ) ? $task['error'] : array();
		$verification_warning = array();
		if ( $executed && ! $completed_verified ) {
			$verification_warning = array(
				'code'=>'browser_effect_unverified',
				'message'=>'Il Browser Agent ha eseguito il task; l’effetto applicativo richiede una lettura di verifica.',
				'retryable'=>false,
			);
			if ( $error ) { $verification_warning['executor_details'] = $error; }
			$error = array();
		} elseif ( $failed && empty( $error ) ) {
			$error = array( 'code'=>'browser_task_failed', 'message'=>'Il Browser Agent ha terminato il task con errore.', 'retryable'=>false );
		} elseif ( $expired && empty( $error ) ) {
			$error = array( 'code'=>'browser_task_expired', 'message'=>'Il task Browser Agent è scaduto prima della conclusione.', 'retryable'=>true );
		}

		$ok = ! $terminal || $executed || $cancelled;
		$public_status = $executed && ! $completed_verified ? 'degraded' : $status;
		$lane_handle = sanitize_text_field( (string) ( $task['arguments']['_prstudio_lane_id'] ?? $task['arguments']['lane_handle'] ?? $task['arguments']['lane_token'] ?? '' ) );
		if ( 1 !== preg_match( '/^lane_[a-f0-9]{32}$/', $lane_handle ) ) { $lane_handle = ''; }
		$tab_id = self::result_tab_id( $task['result'] ?? array() );
		$next_action = null;
		if ( $executed && ! $completed_verified && $tab_id > 0 ) {
			$next_arguments = array( 'tab_id'=>$tab_id, 'sync_wait_seconds'=>15 );
			if ( '' !== $lane_handle ) { $next_arguments['lane_handle'] = $lane_handle; }
			$next_action = array( 'tool'=>'browser_snapshot', 'arguments'=>$next_arguments );
		}
		return array(
			'ok'=>$ok,
			'terminal'=>$terminal,
			'provider'=>'prstudio_chrome_extension',
			'target'=>'live',
			'task_id'=>$task['task_uuid'] ?? '',
			'correlation_id'=>$correlation_id,
			'correlation_id_canonical'=>$correlation_canonical,
			'status'=>$public_status,
			'checkpoint'=>$task['checkpoint'] ?? array(),
			'result'=>$task['result'] ?? array(),
			'verification'=>$verification,
			'error'=>$error,
			'verification_warning'=>$verification_warning,
			'lane_handle'=>$lane_handle,
			'executed'=>$executed,
			'effect_verified'=>$completed_verified,
			'message'=>$executed && ! $completed_verified ? 'Task eseguito; verifica consigliata sulla stessa scheda.' : ( $terminal ? 'Task terminato.' : 'Task accodato o in esecuzione.' ),
			'next_action'=>$terminal ? $next_action : array( 'tool'=>'browser_status', 'arguments'=>array( 'task_id'=>(string) ( $task['task_uuid'] ?? '' ), 'wait_seconds'=>5 ) ),
			'_control_outcome'=>array(
				'status'=>$outcome_status,
				'executed'=>$executed,
				'mutated'=>false,
				'verified'=>$completed_verified,
				'degraded'=>$executed && ! $completed_verified,
				'blocking'=>false,
			),
		);
	}
}
