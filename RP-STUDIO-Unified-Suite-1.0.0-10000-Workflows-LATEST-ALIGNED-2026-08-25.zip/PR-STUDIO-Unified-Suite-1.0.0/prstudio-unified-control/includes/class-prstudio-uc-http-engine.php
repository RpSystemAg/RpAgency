<?php
// phpcs:ignore missing_direct_file_access_protection -- direct-access guard IS present on the line below; it uses `&& ! defined('PRSTUDIO_UC_TESTING')` for testability and Plugin Check's static pattern doesn't recognize that compound form.
if ( ! defined( 'ABSPATH' ) && ! defined( 'PRSTUDIO_UC_TESTING' ) ) { exit; }
final class PRSTUDIO_UC_HTTP_Engine {
    private static function allowed(string $url):bool{
        $host=strtolower((string)(function_exists('wp_parse_url')?wp_parse_url($url,PHP_URL_HOST):parse_url($url,PHP_URL_HOST)));
        $scheme=strtolower((string)(function_exists('wp_parse_url')?wp_parse_url($url,PHP_URL_SCHEME):parse_url($url,PHP_URL_SCHEME)));
        if('https'!==$scheme&&'http'!==$scheme)return false;
        $home=function_exists('home_url')?(string)home_url('/'):'http://localhost/';
        $home_host=strtolower((string)(function_exists('wp_parse_url')?wp_parse_url($home,PHP_URL_HOST):parse_url($home,PHP_URL_HOST)));
        if($host===$home_host)return true;
        $extra=function_exists('get_option')?get_option('prstudio_uc_http_allow_hosts',array()):array();
        return in_array($host,array_map('strtolower',array_map('strval',is_array($extra)?$extra:array())),true);
    }
    private static function same_site_host(string $url): bool {
        if(!function_exists('home_url'))return false;
        $u=parse_url($url);$h=parse_url(home_url('/'));
        return is_array($u)&&is_array($h)&&strtolower((string)($u['host']??''))===strtolower((string)($h['host']??''));
    }
    /**
     * Resolve a same-site /wp-json/ URL to an internal REST route plus its query.
     *
     * The query string is part of the request being inspected: /wp/v2/posts and
     * /wp/v2/posts?per_page=5&status=draft are different requests with different
     * responses. Returning the route alone dispatched the bare endpoint and
     * reported it verified, so the caller was told a request succeeded that was
     * never the one it asked about.
     *
     * @return array{route:string,query:array<string,mixed>}|null
     */
    private static function same_site_rest(string $url): ?array {
        if(!function_exists('home_url'))return null; $home=home_url('/');
        $u=parse_url($url);$h=parse_url($home); if(!is_array($u)||!is_array($h)||strtolower((string)($u['host']??''))!==strtolower((string)($h['host']??'')))return null;
        $path=(string)($u['path']??''); $needle='/wp-json/'; $pos=strpos($path,$needle); if(false===$pos)return null;
        $query=array(); $raw=(string)($u['query']??''); if(''!==$raw)parse_str($raw,$query);
        return array('route'=>'/'.ltrim(substr($path,$pos+strlen($needle)),'/'),'query'=>$query);
    }
    public static function inspect(array $args){
        $url=trim((string)($args['url']??'')); if(''===$url||!self::allowed($url))return new WP_Error('prstudio_http_ssrf_forbidden','URL is not in the HTTP allowlist.',array('status'=>403));
        $method=strtoupper((string)($args['method']??'HEAD')); if(!in_array($method,array('HEAD','GET'),true))return new WP_Error('prstudio_http_method_invalid','Only HEAD/GET are allowed.',array('status'=>405));
        $max=max(1024,min(2097152,(int)($args['max_bytes']??65536)));
        $rest=self::same_site_rest($url);
        if(null!==$rest&&function_exists('rest_do_request')){
            $req=new WP_REST_Request($method,$rest['route']);
            if(!empty($rest['query']))$req->set_query_params($rest['query']);
            $resp=rest_do_request($req); $status=is_object($resp)&&method_exists($resp,'get_status')?(int)$resp->get_status():200;
            return array('url'=>$url,'status'=>$status,'ok'=>$status>=200&&$status<400,'transport'=>'wordpress_internal_rest_dispatch','network_loopback'=>false,'verified'=>true,'body_bytes'=>0,'route'=>$rest['route'],'query_params'=>array_keys($rest['query']));
        }
        $request_args=array('method'=>$method,'timeout'=>8,'redirection'=>2,'reject_unsafe_urls'=>true,'limit_response_size'=>$max,'user-agent'=>'PRSTUDIO-Unified-Control/5.0.0');
        $resp=wp_safe_remote_request($url,$request_args); $status=is_wp_error($resp)?0:(int)wp_remote_retrieve_response_code($resp); $transport='wordpress_http_'.$method;
        if('HEAD'===$method&&(is_wp_error($resp)||0===$status||in_array($status,array(405,501),true))){$request_args['method']='GET';$resp=wp_safe_remote_request($url,$request_args);$status=is_wp_error($resp)?0:(int)wp_remote_retrieve_response_code($resp);$transport='wordpress_http_get_fallback';}
        if(is_wp_error($resp)){if(self::same_site_host($url))return array('url'=>$url,'status'=>0,'ok'=>null,'site_offline'=>false,'transport'=>$transport,'network_loopback'=>true,'verified'=>false,'verification'=>'inconclusive_loopback_transport','transport_error'=>array('code'=>$resp->get_error_code(),'message'=>$resp->get_error_message()),'loopback_not_equal_offline'=>true);return new WP_Error('prstudio_http_transport',$resp->get_error_message(),array('status'=>502,'original_code'=>$resp->get_error_code(),'loopback_not_equal_offline'=>true));}
        $body=(string)wp_remote_retrieve_body($resp);
        return array('url'=>$url,'status'=>$status,'ok'=>$status>=200&&$status<400,'transport'=>$transport,'network_loopback'=>true,'verified'=>true,'body_bytes'=>strlen($body),'body'=>substr($body,0,$max));
    }
}
