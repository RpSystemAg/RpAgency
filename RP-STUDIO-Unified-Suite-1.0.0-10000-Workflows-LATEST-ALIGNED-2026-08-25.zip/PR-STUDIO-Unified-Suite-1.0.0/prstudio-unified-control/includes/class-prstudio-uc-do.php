<?php
if ( ! defined( 'ABSPATH' ) && ! defined( 'PRSTUDIO_UC_TESTING' ) ) { exit; }

/**
 * prstudio_do — one verb in front of the whole surface.
 *
 * Codex does not expose a hundred named operations; it exposes a shell and lets
 * the model describe what it wants. That is not fewer capabilities, it is fewer
 * *names to choose between* — and choosing is where a model with a truncated
 * tool list fails.
 *
 * `prstudio_do` is that front door. Every typed tool and capability remains
 * directly callable by name. This adds an ergonomic route for common intents,
 * and also guarantees that a canonical tool name withheld from tools/list by
 * the token budget remains directly routable through this front door.
 */
final class PRSTUDIO_UC_Do {
    public const VERSION = '1.2.0';

    /** Direct intent synonyms. */
    private static function intent_map(): array {
        return array(
            // Browser navigation and interaction.
            'open'        => array( 'tool' => 'browser_open', 'target_arg' => 'url' ),
            'open_tab'    => array( 'tool' => 'browser_open', 'target_arg' => 'url' ),
            'navigate'    => array( 'tool' => 'browser_navigate', 'target_arg' => 'url' ),
            'goto'        => array( 'tool' => 'browser_navigate', 'target_arg' => 'url' ),
            'go_to'       => array( 'tool' => 'browser_navigate', 'target_arg' => 'url' ),
            'visit'       => array( 'tool' => 'browser_navigate', 'target_arg' => 'url' ),
            'reload'      => array( 'tool' => 'browser_reload' ),
            'back'        => array( 'tool' => 'browser_back' ),
            'forward'     => array( 'tool' => 'browser_forward' ),
            'close_tab'   => array( 'tool' => 'browser_close' ),
            'click'       => array( 'tool' => 'browser_click', 'target_arg' => 'selector' ),
            'double_click'=> array( 'tool' => 'browser_double_click', 'target_arg' => 'selector' ),
            'hover'       => array( 'tool' => 'browser_hover', 'target_arg' => 'selector' ),
            'focus'       => array( 'tool' => 'browser_focus', 'target_arg' => 'selector' ),
            'fill'        => array( 'tool' => 'browser_fill', 'target_arg' => 'selector' ),
            'type'        => array( 'tool' => 'browser_type', 'target_arg' => 'selector' ),
            'press'       => array( 'tool' => 'browser_press', 'target_arg' => 'selector' ),
            'select'      => array( 'tool' => 'browser_select', 'target_arg' => 'selector' ),
            'check'       => array( 'tool' => 'browser_check', 'target_arg' => 'selector' ),
            'scroll'      => array( 'tool' => 'browser_scroll' ),
            'screenshot'  => array( 'tool' => 'browser_screenshot' ),
            'capture_page'=> array( 'tool' => 'browser_screenshot' ),
            'snapshot'    => array( 'tool' => 'browser_snapshot' ),
            'extract'     => array( 'tool' => 'browser_extract', 'target_arg' => 'selector' ),
            'read_page'   => array( 'tool' => 'browser_extract', 'target_arg' => 'selector' ),
            'extract_text'=> array( 'tool' => 'browser_extract', 'target_arg' => 'selector' ),
            'wait'        => array( 'tool' => 'browser_wait' ),
            'tabs'        => array( 'tool' => 'browser_tabs' ),
            'adopt_tabs'  => array( 'tool' => 'browser_adopt_tabs' ),
            'console'     => array( 'tool' => 'browser_console' ),
            'network'     => array( 'tool' => 'browser_network' ),
            'page_errors' => array( 'tool' => 'browser_page_errors' ),
            'audit_page'  => array( 'tool' => 'browser_lighthouse' ),
            'vitals'      => array( 'tool' => 'browser_core_web_vitals' ),
            'accessibility' => array( 'tool' => 'browser_accessibility_scan' ),
            'pdf'         => array( 'tool' => 'browser_pdf' ),
            'crawl'       => array( 'tool' => 'browser_link_crawl', 'target_arg' => 'url' ),
            'crawl_sitemap' => array( 'tool' => 'browser_sitemap_crawl', 'target_arg' => 'url' ),
            'responsive'  => array( 'tool' => 'browser_responsive_matrix' ),
            'baseline'    => array( 'tool' => 'browser_capture_baseline' ),
            'compare_baseline' => array( 'tool' => 'browser_compare_baseline' ),

            // Reading and writing site content.
            'read'        => array( 'tool' => 'prstudio_observe' ),
            'observe'     => array( 'tool' => 'prstudio_observe' ),
            'inspect'     => array( 'tool' => 'prstudio_observe' ),
            'analyze_page'=> array( 'tool' => 'prstudio_observe' ),
            'edit_content'=> array( 'tool' => 'wordpress_content_transaction' ),
            'replace_text'=> array( 'tool' => 'wordpress_content_transaction', 'defaults' => array( 'operation' => 'replace_exact' ) ),
            'append_text' => array( 'tool' => 'wordpress_content_transaction', 'defaults' => array( 'operation' => 'append_once' ) ),
            'insert_before' => array( 'tool' => 'wordpress_content_transaction', 'defaults' => array( 'operation' => 'insert_before' ) ),
            'insert_after'=> array( 'tool' => 'wordpress_content_transaction', 'defaults' => array( 'operation' => 'insert_after' ) ),

            // Search Console.
            'gsc_performance' => array( 'tool' => 'gsc_search_analytics' ),
            'gsc_inspect' => array( 'tool' => 'gsc_url_inspection', 'target_arg' => 'inspection_url' ),
            'request_indexing' => array( 'tool' => 'gsc_request_indexing', 'target_arg' => 'inspection_url' ),
            'gsc_sitemaps' => array( 'tool' => 'gsc_sitemaps' ),

            // Commerce, SEO, ranking.
            'product_audit' => array( 'tool' => 'commerce_product_audit' ),

            // Orientation and durable work.
            'backlog'     => array( 'tool' => 'prstudio_backlog' ),
            'todo'        => array( 'tool' => 'prstudio_backlog' ),
            'health'      => array( 'tool' => 'prstudio_health' ),
            'status'      => array( 'tool' => 'prstudio_health' ),
            'job'         => array( 'tool' => 'prstudio_job_get' ),
            'memory'      => array( 'tool' => 'prstudio_memory_search' ),
            'repo_map'    => array( 'tool' => 'engineering_repo_map' ),
            'validate_code' => array( 'tool' => 'engineering_validate' ),
            'mission'     => array( 'tool' => 'agency_submit' ),
            'run_playbook' => array( 'tool' => 'agency_submit' ),
            'execute_playbook' => array( 'tool' => 'agency_submit' ),
            'esegui_playbook' => array( 'tool' => 'agency_submit' ),
            'avvia_playbook' => array( 'tool' => 'agency_submit' ),
        );
    }

    /** Italian aliases for every public fast-path family. */
    private static function italian_aliases(): array {
        return array(
            'apri' => 'open',
            'apri_scheda' => 'open_tab',
            'nuova_scheda' => 'open_tab',
            'naviga' => 'navigate',
            'vai' => 'goto',
            'vai_a' => 'navigate',
            'visita' => 'visit',
            'ricarica' => 'reload',
            'indietro' => 'back',
            'avanti' => 'forward',
            'chiudi_scheda' => 'close_tab',
            'clicca' => 'click',
            'doppio_clic' => 'double_click',
            'passa_sopra' => 'hover',
            'metti_a_fuoco' => 'focus',
            'compila' => 'fill',
            'riempi' => 'fill',
            'scrivi_nel_campo' => 'fill',
            'digita' => 'type',
            'premi' => 'press',
            'seleziona' => 'select',
            'spunta' => 'check',
            'scorri' => 'scroll',
            'schermata' => 'screenshot',
            'cattura_pagina' => 'screenshot',
            'istantanea' => 'snapshot',
            'estrai' => 'extract',
            'leggi_pagina' => 'extract',
            'estrai_testo' => 'extract',
            'attendi' => 'wait',
            'schede' => 'tabs',
            'adotta_schede' => 'adopt_tabs',
            'rete' => 'network',
            'errori_pagina' => 'page_errors',
            'controlla_pagina' => 'audit_page',
            'metriche_vitali' => 'vitals',
            'accessibilita' => 'accessibility',
            'scansiona_sito' => 'crawl',
            'scansiona_link' => 'crawl',
            'esplora_sito' => 'crawl',
            'scansiona_sitemap' => 'crawl_sitemap',
            'riferimento' => 'baseline',
            'confronta_riferimento' => 'compare_baseline',
            'leggi' => 'read',
            'osserva' => 'observe',
            'ispeziona' => 'inspect',
            'analizza_pagina' => 'inspect',
            'modifica_contenuto' => 'edit_content',
            'sostituisci_testo' => 'replace_text',
            'aggiungi_testo' => 'append_text',
            'inserisci_prima' => 'insert_before',
            'inserisci_dopo' => 'insert_after',
            'prestazioni_gsc' => 'gsc_performance',
            'ispeziona_gsc' => 'gsc_inspect',
            'richiedi_indicizzazione' => 'request_indexing',
            'sitemap_gsc' => 'gsc_sitemaps',
            'analizza_prodotto' => 'product_audit',
            'attivita' => 'backlog',
            'cose_da_fare' => 'todo',
            'salute' => 'health',
            'stato' => 'status',
            'lavoro' => 'job',
            'memoria' => 'memory',
            'mappa_repo' => 'repo_map',
            'valida_codice' => 'validate_code',
            'missione' => 'mission',
        );
    }

    /** Complete bilingual routing surface, preserving canonical tool targets. */
    private static function bilingual_intent_map(): array {
        $map = self::intent_map();
        foreach ( self::italian_aliases() as $alias => $canonical ) {
            if ( isset( $map[ $canonical ] ) ) {
                $map[ $alias ] = $map[ $canonical ];
            }
        }
        return $map;
    }

    /** Words that carry no routing information and only add noise to matching. */
    private static function noise(): array {
        return array(
            'the', 'a', 'an', 'to', 'on', 'in', 'of', 'for', 'this', 'that', 'please', 'now',
            'il', 'lo', 'la', 'i', 'gli', 'le', 'un', 'una', 'di', 'da', 'per', 'su', 'con', 'del', 'della',
            'mi', 'ti', 'si', 'e', 'ed', 'o', 'che', 'al', 'allo', 'alla',
        );
    }

    private static function normalize( string $value ): string {
        $value = strtolower( trim( $value ) );
        if ( function_exists( 'remove_accents' ) ) {
            $value = remove_accents( $value );
        } else {
            $value = strtr( $value, array(
                'à' => 'a', 'è' => 'e', 'é' => 'e', 'ì' => 'i',
                'ò' => 'o', 'ù' => 'u', 'À' => 'a', 'È' => 'e',
                'É' => 'e', 'Ì' => 'i', 'Ò' => 'o', 'Ù' => 'u',
            ) );
        }
        $value = preg_replace( '/[^a-z0-9\s_]+/', ' ', $value );
        $value = preg_replace( '/\s+/', ' ', (string) $value );
        return trim( (string) $value );
    }

    /** Exact canonical MCP tool, if the raw intent names one. */
    private static function canonical_tool_match( string $underscored ): ?array {
        if ( '' === $underscored || 'prstudio_do' === $underscored || ! class_exists( 'PRSTUDIO_UC_MCP_V5' ) ) { return null; }
        foreach ( PRSTUDIO_UC_MCP_V5::tools() as $tool ) {
            $name = sanitize_key( (string) ( $tool['name'] ?? '' ) );
            if ( '' !== $name && hash_equals( $name, $underscored ) ) {
                return array(
                    'key' => $name,
                    'spec' => array( 'tool' => $name ),
                    'confidence' => 'canonical_tool',
                );
            }
        }
        return null;
    }

    /**
     * Resolves an intent to a concrete { tool, arguments } call.
     *
     * @return array|WP_Error
     */
    public static function resolve( array $args ) {
        $raw_intent = (string) ( $args['intent'] ?? '' );
        if ( '' === trim( $raw_intent ) ) {
            $map = self::bilingual_intent_map();
            $intents = array();
            foreach ( $map as $key => $spec ) {
                $intents[ (string) $key ] = (string) ( $spec['tool'] ?? '' );
            }
            ksort( $intents );
            return array(
                'ok' => true,
                'listing' => 'intents',
                'count' => count( $intents ),
                'intents' => $intents,
                'usage' => 'Call again with intent="<one of the keys above or an exact canonical tool name>" plus that tool\'s arguments.',
                'note' => 'Fast paths are listed here; every canonical MCP tool name is also directly routable through prstudio_do, including tools withheld from tools/list.',
                'version' => self::VERSION,
                'component' => 'prstudio_do',
                'suite_version' => defined( 'PRSTUDIO_UC_VERSION' ) ? PRSTUDIO_UC_VERSION : '',
            );
        }

        $map = self::bilingual_intent_map();
        $normalized = self::normalize( $raw_intent );
        $underscored = str_replace( ' ', '_', $normalized );

        $match = null;
        if ( isset( $map[ $underscored ] ) ) {
            $match = array( 'key' => $underscored, 'spec' => $map[ $underscored ], 'confidence' => 'exact' );
        }
        // Canonical tool names have stronger semantics than fuzzy intent terms.
        // This closes the budget dead-end: a tool can be omitted from tools/list
        // yet still be addressed exactly through the advertised prstudio_do.
        if ( ! $match ) { $match = self::canonical_tool_match( $underscored ); }
        if ( ! $match ) {
            $tokens = array_values( array_diff( explode( ' ', $normalized ), self::noise() ) );
            $scored = array();
            foreach ( $map as $key => $spec ) {
                $key_tokens = explode( '_', $key );
                $overlap = count( array_intersect( $key_tokens, $tokens ) );
                if ( $overlap < 1 ) { continue; }
                $scored[ $key ] = ( $overlap * 10 ) + ( $overlap === count( $key_tokens ) ? 5 : 0 ) - count( $key_tokens );
            }
            arsort( $scored, SORT_NUMERIC );
            $best = array_key_first( $scored );
            if ( null !== $best ) {
                $top_score = $scored[ $best ];
                $tied = array_keys( array_filter( $scored, static fn( $s ): bool => $s === $top_score ) );
                if ( count( $tied ) > 1 ) {
                    return self::ambiguous( $raw_intent, $tied, $map );
                }
                $match = array( 'key' => $best, 'spec' => $map[ $best ], 'confidence' => 'inferred' );
            }
        }

        if ( ! $match ) {
            return array(
                'tool'      => 'prstudio_capability_search',
                'arguments' => array( 'query' => $raw_intent, 'limit' => 10, 'include_legacy' => true ),
                'routing'   => array(
                    'confidence' => 'fallback',
                    'note'       => 'No direct intent or canonical tool match. Searching the capability registry; run prstudio_execute with the chosen capability.',
                ),
            );
        }

        $spec = $match['spec'];
        $call_args = is_array( $args['params'] ?? null ) ? $args['params'] : array();
        if ( isset( $spec['defaults'] ) && is_array( $spec['defaults'] ) ) {
            $call_args = array_merge( $spec['defaults'], $call_args );
        }
        $target = $args['target'] ?? null;
        if ( null !== $target && '' !== $target ) {
            $target_arg = (string) ( $spec['target_arg'] ?? '' );
            if ( '' !== $target_arg && ! isset( $call_args[ $target_arg ] ) ) {
                $call_args[ $target_arg ] = $target;
            } elseif ( '' === $target_arg && ! isset( $call_args['id'] ) && is_numeric( $target ) ) {
                $call_args['id'] = (int) $target;
            }
        }
        foreach ( array( 'lane_handle', 'lane_token', 'write_token', 'dry_run', 'tab_id', 'device_id' ) as $passthrough ) {
            if ( isset( $args[ $passthrough ] ) && ! isset( $call_args[ $passthrough ] ) ) {
                $call_args[ $passthrough ] = $args[ $passthrough ];
            }
        }

        return array(
            'tool'      => (string) $spec['tool'],
            'arguments' => $call_args,
            'routing'   => array(
                'intent'     => $raw_intent,
                'matched'    => $match['key'],
                'confidence' => $match['confidence'],
            ),
        );
    }

    private static function ambiguous( string $intent, array $candidates, array $map ) {
        $options = array();
        foreach ( array_slice( $candidates, 0, 6 ) as $key ) {
            $options[] = array( 'intent' => $key, 'tool' => (string) ( $map[ $key ]['tool'] ?? '' ) );
        }
        return new WP_Error(
            'prstudio_do_intent_ambiguous',
            'That intent matches several operations equally well. Pick one rather than letting the router guess at a mutation.',
            array(
                'status'     => 409,
                'intent'     => $intent,
                'candidates' => $options,
                'remedy'     => 'Repeat prstudio_do with one of the listed intent values, an exact canonical tool name, or call the tool directly by name.',
            )
        );
    }

    /** Machine-readable catalogue of what `prstudio_do` understands. */
    public static function catalogue(): array {
        $map = self::bilingual_intent_map();
        $by_tool = array();
        foreach ( $map as $intent => $spec ) {
            $tool = (string) $spec['tool'];
            if ( ! isset( $by_tool[ $tool ] ) ) { $by_tool[ $tool ] = array(); }
            $by_tool[ $tool ][] = $intent;
        }
        $canonical = array();
        if ( class_exists( 'PRSTUDIO_UC_MCP_V5' ) ) {
            foreach ( PRSTUDIO_UC_MCP_V5::tools() as $tool ) {
                $name = (string) ( $tool['name'] ?? '' );
                if ( '' !== $name && 'prstudio_do' !== $name ) { $canonical[] = $name; }
            }
            sort( $canonical );
        }
        return array(
            'intent_count' => count( $map ),
            'intents'      => array_keys( $map ),
            'by_tool'      => $by_tool,
            'canonical_tool_count' => count( $canonical ),
            'canonical_tools' => $canonical,
            'note'         => 'Every typed tool remains directly callable by name and exact canonical names are routable through prstudio_do.',
        );
    }
}
