<?php
// phpcs:ignore missing_direct_file_access_protection -- direct-access guard IS present on the line below; it uses `&& ! defined('PRSTUDIO_UC_TESTING')` for testability and Plugin Check's static pattern doesn't recognize that compound form.
if ( ! defined( 'ABSPATH' ) && ! defined( 'PRSTUDIO_UC_TESTING' ) ) { exit; }
final class PRSTUDIO_UC_Safety_Runtime { public const VERSION='2.0.0';
 public static function budget(array $impact,array $policy):array{$r=(int)($policy['risk_score']??0);$b=max(1,(int)($impact['estimated_resources']??1));return['max_runtime_seconds'=>$r>=4?120:($b>1000?180:90),'max_memory_delta_bytes'=>$r>=4?67108864:100663296,'max_resources_per_batch'=>$r>=4?25:($b>1000?100:250),'max_browser_workers'=>$r>=4?2:4,'max_http_requests'=>$b>1000?min(5000,$b*2):max(50,min(1000,$b*3)),'checkpoint_every'=>$r>=4?5:25];}
 public static function begin():array{return['ns'=>function_exists('hrtime')?hrtime(true):(int)(microtime(true)*1e9),'mem'=>memory_get_usage(true)];} public static function check(array $s,array $b):array{$n=function_exists('hrtime')?hrtime(true):(int)(microtime(true)*1e9);$t=($n-(int)$s['ns'])/1e9;$m=memory_get_usage(true)-(int)$s['mem'];$ok=$t<=(float)$b['max_runtime_seconds']&&$m<=(int)$b['max_memory_delta_bytes'];return['ok'=>$ok,'elapsed_seconds'=>round($t,3),'memory_delta_bytes'=>$m,'reason'=>$ok?'within_budget':($t>$b['max_runtime_seconds']?'runtime_budget_exceeded':'memory_budget_exceeded')];}
 public static function adaptive_concurrency(array $s,int $c=2):int{$c=max(1,min(8,$c));$lat=(float)($s['latency_ms']??0);$st=(int)($s['http_status']??200);$er=(float)($s['error_rate']??0);if(in_array($st,[429,503],true)||$er>=.1||$lat>=2500)return max(1,$c-1);if($er<=.01&&$lat>0&&$lat<500)return min(8,$c+1);return$c;}
 private static function sdir():string{$d=PRSTUDIO_UC_Memory::site_dir().'/snapshots';if(!is_dir($d)){function_exists('wp_mkdir_p')?wp_mkdir_p($d):@mkdir($d,0750,true);}return$d;}
 public static function rollback(string $sid,bool $apply=false):array{$sid=preg_replace('/[^a-zA-Z0-9_-]+/','',$sid);$p=self::sdir().'/'.$sid.'.json';if(!is_readable($p))return['ok'=>false,'error'=>'snapshot_missing'];$d=json_decode((string)file_get_contents($p),true);$plan=[];foreach((array)($d['resources']??[]) as $r)$plan[]=['type'=>$r['type']??'','id'=>$r['id']??null,'restorable'=>in_array($r['type']??'',['post','option'],true)];if(!$apply)return['ok'=>true,'preview'=>true,'plan'=>$plan];$done=[];$fail=[];foreach((array)$d['resources'] as $r){if(($r['type']??'')==='post'&&function_exists('wp_update_post')){$post=(array)$r['post'];$post['ID']=(int)$r['id'];$x=wp_update_post($post,true);if(is_wp_error($x))$fail[]=$r['id'];else$done[]=$r['id'];}elseif(($r['type']??'')==='option'&&function_exists('update_option')){update_option((string)$r['id'],$r['value']??null,false);$done[]=$r['id'];}else$fail[]=$r['id']??null;}return['ok'=>!$fail,'restored'=>$done,'failed'=>$fail];}
 // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- intentional: this is a read-only EXPLAIN sandbox for arbitrary caller-supplied SQL, gated to non-mutating verbs (SELECT/WITH) and to authorized MCP/REST callers upstream; the whole point of the tool is inspecting arbitrary SQL, not a leaked injection path.
 public static function database_sandbox(string $sql):array{$sql=trim($sql);$verb=strtoupper((string)strtok(ltrim(preg_replace('#/\\*.*?\\*/#s','',$sql))," \t\r\n"));$mut=in_array($verb,['INSERT','UPDATE','DELETE','REPLACE','ALTER','CREATE','DROP','TRUNCATE','RENAME'],true);$o=['ok'=>true,'executed'=>false,'verb'=>$verb,'mutating'=>$mut,'sql_hash'=>hash('sha256',$sql)];if(!$mut&&in_array($verb,['SELECT','WITH'],true)&&isset($GLOBALS['wpdb'])){global $wpdb;$o['explain']=$wpdb->get_results('EXPLAIN '.$sql,ARRAY_A);$o['db_error']=$wpdb->last_error;}return$o;}
 public static function plugin_sandbox(string $zip):array{if(!is_file($zip)||!class_exists('ZipArchive'))return['ok'=>false,'error'=>'candidate_or_ziparchive_unavailable'];$z=new ZipArchive();if(true!==$z->open($zip))return['ok'=>false,'error'=>'zip_open_failed'];$files=$bytes=$php=0;$err=[];$root='';for($i=0;$i<$z->numFiles;$i++){$s=$z->statIndex($i);$n=str_replace('\\','/',(string)$s['name']);$files++;$bytes+=(int)$s['size'];if(str_contains($n,'../')||str_starts_with($n,'/'))$err[]='unsafe_path';if(!$root)$root=explode('/',$n)[0]??'';if(strtolower(pathinfo($n,PATHINFO_EXTENSION))==='php')$php++;if($files>20000||$bytes>536870912){$err[]='archive_limits';break;}}$z->close();return['ok'=>!$err,'executed'=>false,'files'=>$files,'php_files'=>$php,'bytes'=>$bytes,'root'=>$root,'errors'=>$err,'sha256'=>hash_file('sha256',$zip)];}
 public static function stage_candidate(string $zip,string $ver):array{$c=self::plugin_sandbox($zip);if(empty($c['ok']))return$c;$d=PRSTUDIO_UC_Memory::site_dir().'/release-candidate';if(!is_dir($d))wp_mkdir_p($d);$to=$d.'/candidate-'.preg_replace('/[^a-zA-Z0-9._-]+/','-',$ver).'.zip';$ok=@copy($zip,$to);return['ok'=>$ok,'staged'=>$ok,'active_version'=>defined('PRSTUDIO_UC_VERSION')?PRSTUDIO_UC_VERSION:'','candidate_version'=>$ver,'activation_mode'=>'standard_wordpress_replacement_preserved','sandbox'=>$c];}
 public static function diagnose():array{$h=class_exists('PRSTUDIO_UC_Health')?PRSTUDIO_UC_Health::snapshot():['ok'=>false];return['ok'=>!empty($h['ok']),'mode'=>'read_only','health'=>$h,'memory'=>PRSTUDIO_UC_Memory::snapshot(),'observability'=>PRSTUDIO_UC_Observability::snapshot(),'generated_gmt'=>gmdate('c')];}
 public static function self_heal():array{$r=class_exists('PRSTUDIO_UC_Job_Engine')?PRSTUDIO_UC_Job_Engine::recover():['ok'=>false];return['ok'=>!empty($r['ok']),'scope'=>'safe_housekeeping_only','recovery'=>$r];}
 public static function sign(array $payload,int $ttl=300):array{$sec=PRSTUDIO_UC_Auth::signing_secret();$ts=time();$nonce=bin2hex(random_bytes(16));$body=json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);return['timestamp'=>$ts,'nonce'=>$nonce,'ttl'=>max(30,min(600,$ttl)),'payload'=>$payload,'signature'=>hash_hmac('sha256',$ts."\n".$nonce."\n".$body,$sec),'algorithm'=>'HMAC-SHA256'];}
}
final class PRSTUDIO_UC_Secrets_Vault {
    private static function valid_gcm_tag(mixed $tag):?string{return is_string($tag)&&16===strlen($tag)?$tag:null;}
    private static function path():string{return PRSTUDIO_UC_Memory::site_dir().'/secrets.vault.json';}
    private static function lock_path():string{return PRSTUDIO_UC_Memory::site_dir().'/.secrets.vault.lock';}
    private static function key():string{return hash_hkdf('sha256',PRSTUDIO_UC_Auth::signing_secret(),32,'prstudio-vault-2.0',PRSTUDIO_UC_Memory::site_identity()['canonical_hash']);}
    private static function raw():array{$d=is_readable(self::path())?json_decode((string)file_get_contents(self::path()),true):[];return is_array($d)?$d:[];}

    /**
     * Run a read-modify-write on the vault under an exclusive lock.
     *
     * LOCK_EX on file_put_contents() only serializes that one write call. It does
     * not cover the read that produced the array being written, so two callers
     * storing different secrets could both load the same version, each add their
     * own key, and the second write would drop the first secret entirely -- a
     * silent lost update in the one store where losing a value is least
     * acceptable.
     *
     * The lock is held across read, merge and write, on a separate lock file so
     * the vault itself can be replaced by an atomic rename: a reader either sees
     * the whole previous file or the whole new one, never a partial write.
     */
    private static function mutate(callable $callback):bool{
        $dir=PRSTUDIO_UC_Memory::site_dir();
        if(!is_dir($dir)){function_exists('wp_mkdir_p')?wp_mkdir_p($dir):@mkdir($dir,0750,true);}
        $fh=@fopen(self::lock_path(),'c+');
        if(!is_resource($fh)||!@flock($fh,LOCK_EX)){if(is_resource($fh))@fclose($fh);return false;}
        try{
            $state=self::raw();
            $result=$callback($state);
            if(false===$result)return false;
            $json=json_encode($state,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
            if(false===$json)return false;
            try{$suffix=bin2hex(random_bytes(5));}catch(Throwable $e){$suffix=str_replace('.','',uniqid('',true));}
            $tmp=self::path().'.'.$suffix.'.tmp';
            if(false===@file_put_contents($tmp,$json."\n",LOCK_EX))return false;
            @chmod($tmp,0600);
            if(@rename($tmp,self::path()))return true;
            @unlink($tmp);
            return false;
        }finally{@flock($fh,LOCK_UN);@fclose($fh);}
    }

    public static function set(string $name,string $value):bool{
        if(!function_exists('openssl_encrypt'))return false;
        $name=sanitize_key($name);
        if(''===$name)return false;
        $iv=random_bytes(12);$tag='';
        $c=openssl_encrypt($value,'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$iv,$tag,$name,16);
        $tag_value=self::valid_gcm_tag($tag);
        if($c===false||null===$tag_value)return false;
        $entry=['iv'=>base64_encode($iv),'tag'=>base64_encode($tag_value),'cipher'=>base64_encode($c),'updated_gmt'=>gmdate('c')];
        return self::mutate(static function(array &$state)use($name,$entry){$state[$name]=$entry;return true;});
    }

    public static function forget(string $name):bool{
        $name=sanitize_key($name);
        if(''===$name)return false;
        return self::mutate(static function(array &$state)use($name){unset($state[$name]);return true;});
    }

    public static function get(string $name):?string{$name=sanitize_key($name);$x=self::raw()[$name]??null;if(!is_array($x)||!function_exists('openssl_decrypt'))return null;$v=openssl_decrypt(base64_decode($x['cipher'],true),'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,base64_decode($x['iv'],true),base64_decode($x['tag'],true),$name);return is_string($v)?$v:null;}
}
