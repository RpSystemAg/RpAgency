<?php
if ( ! defined( 'ABSPATH' ) && ! defined( 'PRSTUDIO_UC_TESTING' ) ) { exit; }

/**
 * Canonical enterprise workflow registry (Waves 1–9, cumulative 10,000-workflow edition).
 *
 * Workflows are intentionally internal: ChatGPT sees one compact workflow tool,
 * not thousands of additional MCP tools. The registry compiles known procedures into
 * bounded capability/direct-tool phases and leaves ambiguous mutations behind
 * an explicit planner decision gate.
 */
final class PRSTUDIO_UC_Enterprise_Workflows {
    public const VERSION = '3.0.0';
    public const REFERENCE_DATE = '2026-08-25';
    private static ?array $cache = null;

    private static function dir(): string {
        return ( defined( 'PRSTUDIO_UC_DIR' ) ? PRSTUDIO_UC_DIR : dirname( __DIR__ ) . '/' ) . 'workflows/';
    }

    private static function files(): array {
        return array(
            self::dir() . 'enterprise-workflows-wave1-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave2-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave3-2026-08-25.json',
            self::dir() . 'wave4-enterprise-workflows-2026-08-25.json',
            self::dir() . 'wave5-enterprise-workflows-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave6-consulting-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave7-web-engineering-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave8-productivity-growth-2026-08-25.json',
            self::dir() . 'enterprise-workflows-wave9-enterprise-atlas-2026-08-25.json',
        );
    }

    private static function load(): array {
        if ( is_array( self::$cache ) ) { return self::$cache; }
        $items = array(); $waves = array(); $hashes = array(); $domains = array(); $phase_count = 0;
        foreach ( self::files() as $path ) {
            if ( ! is_readable( $path ) ) { continue; }
            $raw = (string) file_get_contents( $path );
            $doc = json_decode( $raw, true );
            if ( ! is_array( $doc ) || ! is_array( $doc['workflows'] ?? null ) ) { continue; }
            $wave = (int) ( $doc['wave'] ?? 0 );
            $waves[ $wave ] = (int) ( $doc['workflow_count'] ?? count( $doc['workflows'] ) );
            $hashes[] = (string) ( $doc['document_sha256'] ?? hash( 'sha256', $raw ) );
            foreach ( $doc['workflows'] as $workflow ) {
                if ( ! is_array( $workflow ) || empty( $workflow['id'] ) ) { continue; }
                $id = sanitize_key( (string) $workflow['id'] );
                if ( isset( $items[ $id ] ) ) { continue; }
                $workflow['id'] = $id;
                $workflow['wave'] = (int) ( $workflow['wave'] ?? $wave );
                $items[ $id ] = $workflow;
                $phase_count += count( (array) ( $workflow['phases'] ?? array() ) );
                $domain = sanitize_key( (string) ( $workflow['domain'] ?? 'other' ) );
                $domains[ $domain ] = (int) ( $domains[ $domain ] ?? 0 ) + 1;
            }
        }
        ksort( $items ); ksort( $waves ); ksort( $domains );
        self::$cache = array(
            'version'=>self::VERSION, 'reference_date'=>self::REFERENCE_DATE,
            'workflow_count'=>count( $items ), 'phase_count'=>$phase_count,
            'waves'=>$waves, 'domains'=>$domains,
            'registry_hash'=>hash( 'sha256', implode( '|', $hashes ) ), 'items'=>$items,
        );
        return self::$cache;
    }

    public static function reset_for_test(): void { self::$cache = null; }

    public static function catalog( array $args = array() ): array {
        $d = self::load();
        $domain = sanitize_key( (string) ( $args['domain'] ?? '' ) );
        $wave = isset( $args['wave'] ) ? (int) $args['wave'] : 0;
        $risk = sanitize_key( (string) ( $args['risk_class'] ?? '' ) );
        $browser = sanitize_key( (string) ( $args['browser_requirement'] ?? '' ) );
        $mode = sanitize_key( (string) ( $args['execution_mode'] ?? '' ) );
        $limit = max( 1, min( 100, (int) ( $args['limit'] ?? 50 ) ) );
        $offset = max( 0, min( (int) $d['workflow_count'], (int) ( $args['offset'] ?? 0 ) ) );
        $matched = array();
        foreach ( $d['items'] as $w ) {
            if ( $domain && $domain !== sanitize_key( (string) ( $w['domain'] ?? '' ) ) ) { continue; }
            if ( $wave && $wave !== (int) ( $w['wave'] ?? 0 ) ) { continue; }
            if ( $risk && $risk !== sanitize_key( (string) ( $w['risk_class'] ?? '' ) ) ) { continue; }
            if ( $browser && $browser !== sanitize_key( (string) ( $w['browser_requirement'] ?? '' ) ) ) { continue; }
            if ( $mode && $mode !== sanitize_key( (string) ( $w['execution_mode'] ?? '' ) ) ) { continue; }
            $matched[] = self::compact( $w );
        }
        $rows = array_slice( $matched, $offset, $limit );
        $next = $offset + count( $rows );
        return array_intersect_key( $d, array_flip( array( 'version','reference_date','workflow_count','phase_count','waves','domains','registry_hash' ) ) ) + array(
            'items'=>$rows, 'returned'=>count( $rows ), 'matched'=>count( $matched ), 'offset'=>$offset,
            'has_more'=>$next < count( $matched ), 'next_offset'=>$next < count( $matched ) ? $next : null,
            'filters'=>array( 'domain'=>$domain, 'wave'=>$wave, 'risk_class'=>$risk, 'browser_requirement'=>$browser, 'execution_mode'=>$mode ),
        );
    }

    private static function compact( array $w ): array {
        return array(
            'id'=>(string) $w['id'], 'wave'=>(int) ( $w['wave'] ?? 0 ), 'domain'=>(string) ( $w['domain'] ?? '' ),
            'label'=>(string) ( $w['label'] ?? '' ), 'execution_mode'=>(string) ( $w['execution_mode'] ?? 'durable' ),
            'phase_count'=>count( (array) ( $w['phases'] ?? array() ) ), 'triggers'=>array_slice( array_values( (array) ( $w['triggers'] ?? array() ) ), 0, 5 ),
            'planner_assisted'=>'planner_assisted' === (string) ( $w['execution_mode'] ?? '' ),
            'risk_class'=>(string) ( $w['risk_class'] ?? 'legacy' ), 'browser_requirement'=>(string) ( $w['browser_requirement'] ?? ( 'browser' === (string) ( $w['domain'] ?? '' ) ? 'optional' : 'none' ) ),
        );
    }

    public static function get( string $id ): ?array {
        $id = sanitize_key( $id ); $d = self::load(); return is_array( $d['items'][ $id ] ?? null ) ? $d['items'][ $id ] : null;
    }

    public static function describe( string $id ): array {
        $w = self::get( $id );
        return $w ? array( 'ok'=>true, 'workflow'=>$w, 'registry_hash'=>(string) self::load()['registry_hash'] ) : array( 'ok'=>false, 'reason'=>'workflow_not_found', 'workflow_id'=>sanitize_key( $id ) );
    }

    private static function tokens( string $value ): array {
        $value = strtolower( remove_accents( $value ) );
        return array_values( array_unique( array_filter( preg_split( '/[^a-z0-9]+/', $value ) ?: array() ) ) );
    }

    public static function search( string $query, array $args = array() ): array {
        $d = self::load(); $q = self::tokens( $query );
        $domain = sanitize_key( (string) ( $args['domain'] ?? '' ) );
        $wave = isset( $args['wave'] ) ? (int) $args['wave'] : 0;
        $risk = sanitize_key( (string) ( $args['risk_class'] ?? '' ) );
        $browser = sanitize_key( (string) ( $args['browser_requirement'] ?? '' ) );
        $mode = sanitize_key( (string) ( $args['execution_mode'] ?? '' ) );
        $limit = max( 1, min( 100, (int) ( $args['limit'] ?? 12 ) ) );
        $offset = max( 0, min( (int) $d['workflow_count'], (int) ( $args['offset'] ?? 0 ) ) );
        $scored = array();
        foreach ( $d['items'] as $w ) {
            if ( $domain && $domain !== sanitize_key( (string) ( $w['domain'] ?? '' ) ) ) { continue; }
            if ( $wave && $wave !== (int) ( $w['wave'] ?? 0 ) ) { continue; }
            if ( $risk && $risk !== sanitize_key( (string) ( $w['risk_class'] ?? '' ) ) ) { continue; }
            if ( $browser && $browser !== sanitize_key( (string) ( $w['browser_requirement'] ?? '' ) ) ) { continue; }
            if ( $mode && $mode !== sanitize_key( (string) ( $w['execution_mode'] ?? '' ) ) ) { continue; }
            $hay = self::tokens( implode( ' ', array_merge( array( (string) $w['id'], (string) ( $w['label'] ?? '' ), (string) ( $w['purpose'] ?? '' ), (string) ( $w['description'] ?? '' ), (string) ( $w['business_objective'] ?? '' ), (string) ( $w['domain'] ?? '' ) ), (array) ( $w['triggers'] ?? array() ) ) ) );
            $score = 0; foreach ( $q as $token ) { if ( in_array( $token, $hay, true ) ) { $score += 10; } foreach ( $hay as $h ) { if ( strlen( $token ) >= 4 && str_starts_with( $h, $token ) ) { $score += 2; break; } } }
            if ( $score > 0 || empty( $q ) ) { $scored[] = array( 'score'=>$score, 'workflow'=>$w ); }
        }
        usort( $scored, static fn( $a, $b ) => (int) $b['score'] <=> (int) $a['score'] ?: strcmp( (string) $a['workflow']['id'], (string) $b['workflow']['id'] ) );
        $slice = array_slice( $scored, $offset, $limit );
        $items = array(); foreach ( $slice as $row ) { $items[] = array( 'score'=>(int) $row['score'] ) + self::compact( $row['workflow'] ); }
        $next = $offset + count( $items );
        return array( 'query'=>$query, 'count'=>count( $items ), 'matched'=>count( $scored ), 'offset'=>$offset, 'has_more'=>$next < count( $scored ), 'next_offset'=>$next < count( $scored ) ? $next : null, 'items'=>$items, 'registry_hash'=>(string) $d['registry_hash'], 'total_workflows'=>(int) $d['workflow_count'] );
    }

    private static function input_value( array $inputs, string $path, &$found = null ) {
        $current = $inputs; $found = true;
        foreach ( explode( '.', $path ) as $part ) {
            if ( ! is_array( $current ) || ! array_key_exists( $part, $current ) ) { $found = false; return null; }
            $current = $current[ $part ];
        }
        return $current;
    }

    private static function substitute( $value, array $inputs, array &$missing ) {
        if ( is_array( $value ) ) { foreach ( $value as $k=>$v ) { $value[ $k ] = self::substitute( $v, $inputs, $missing ); } return $value; }
        if ( ! is_string( $value ) || ! preg_match( '/^\{\{input\.([A-Za-z0-9_.-]+)\}\}$/', $value, $m ) ) { return $value; }
        $found = false; $resolved = self::input_value( $inputs, $m[1], $found );
        if ( ! $found ) { $missing[] = $m[1]; return $value; }
        return $resolved;
    }

    private static function inject_capability_inputs( array $phase, array $inputs, array &$missing ): array {
        $args = is_array( $phase['arguments'] ?? null ) ? $phase['arguments'] : array();
        if ( 'capability' !== (string) ( $phase['executor_kind'] ?? '' ) || ! class_exists( 'PRSTUDIO_UC_Capability_Registry' ) ) { return $args; }
        $cap = PRSTUDIO_UC_Capability_Registry::get( (string) ( $phase['capability'] ?? '' ) );
        $schema = is_array( $cap['input_schema'] ?? null ) ? $cap['input_schema'] : array();
        foreach ( array_keys( (array) ( $schema['properties'] ?? array() ) ) as $key ) {
            if ( ! array_key_exists( $key, $args ) && array_key_exists( $key, $inputs ) ) { $args[ $key ] = $inputs[ $key ]; }
        }
        foreach ( (array) ( $schema['required'] ?? array() ) as $key ) {
            if ( ! array_key_exists( $key, $args ) ) { $missing[] = (string) $key; }
        }
        return $args;
    }

    public static function compile( string $id, array $inputs = array(), array $phase_arguments = array() ): array {
        $w = self::get( $id ); if ( ! $w ) { return array( 'ok'=>false, 'reason'=>'workflow_not_found', 'workflow_id'=>sanitize_key( $id ) ); }
        $missing = array(); $phases = array();
        foreach ( array_values( (array) ( $w['phases'] ?? array() ) ) as $phase ) {
            if ( ! is_array( $phase ) ) { continue; }
            $pid = sanitize_key( (string) ( $phase['id'] ?? ( 'p' . ( count( $phases ) + 1 ) ) ) );
            $phase['id'] = $pid;
            $args = self::inject_capability_inputs( $phase, $inputs, $missing );
            $args = self::substitute( $args, $inputs, $missing );
            if ( is_array( $phase_arguments[ $pid ] ?? null ) ) { $args = array_replace_recursive( $args, $phase_arguments[ $pid ] ); }
            $phase['arguments'] = $args; $phase['save_as'] = sanitize_key( (string) ( $phase['save_as'] ?? $pid ) ) ?: $pid; $phases[] = $phase;
        }
        $missing = array_values( array_unique( array_filter( array_map( 'sanitize_key', $missing ) ) ) ); sort( $missing );
        return array( 'ok'=>empty( $missing ), 'workflow_id'=>(string) $w['id'], 'workflow_version'=>(string) ( $w['version'] ?? self::VERSION ), 'wave'=>(int) ( $w['wave'] ?? 0 ), 'domain'=>(string) ( $w['domain'] ?? '' ), 'label'=>(string) ( $w['label'] ?? '' ), 'execution_mode'=>(string) ( $w['execution_mode'] ?? 'durable' ), 'decision_gate'=>$w['decision_gate'] ?? null, 'enterprise_controls'=>(array) ( $w['enterprise_controls'] ?? array() ), 'phases'=>$phases, 'missing_inputs'=>$missing, 'registry_hash'=>(string) self::load()['registry_hash'] );
    }

    public static function validate( string $id = '' ): array {
        $items = $id ? array_filter( array( self::get( $id ) ) ) : array_values( self::load()['items'] );
        $errors = array(); $seen = array(); $phase_count = 0;
        foreach ( $items as $w ) {
            $wid = (string) ( $w['id'] ?? '' ); if ( '' === $wid || isset( $seen[ $wid ] ) ) { $errors[] = array( 'workflow'=>$wid, 'error'=>'duplicate_or_empty_id' ); continue; } $seen[ $wid ] = true;
            foreach ( (array) ( $w['phases'] ?? array() ) as $phase ) {
                ++$phase_count; $kind = (string) ( $phase['executor_kind'] ?? '' );
                if ( 'capability' === $kind ) { $cid = (string) ( $phase['capability'] ?? '' ); if ( ! class_exists( 'PRSTUDIO_UC_Capability_Registry' ) || ! PRSTUDIO_UC_Capability_Registry::get( $cid ) ) { $errors[] = array( 'workflow'=>$wid, 'phase'=>$phase['id'] ?? '', 'error'=>'unknown_capability', 'capability'=>$cid ); } }
                elseif ( 'tool' === $kind ) { if ( empty( $phase['tool'] ) ) { $errors[] = array( 'workflow'=>$wid, 'phase'=>$phase['id'] ?? '', 'error'=>'missing_tool' ); } }
                else { $errors[] = array( 'workflow'=>$wid, 'phase'=>$phase['id'] ?? '', 'error'=>'unknown_executor_kind' ); }
            }
        }
        return array( 'ok'=>empty( $errors ), 'workflows_checked'=>count( $items ), 'phases_checked'=>$phase_count, 'errors'=>array_slice( $errors, 0, 100 ), 'error_count'=>count( $errors ), 'registry_hash'=>(string) self::load()['registry_hash'] );
    }
}
