#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, hashlib, collections, re

ROOT=pathlib.Path(__file__).resolve().parents[2]
WF=ROOT/'prstudio-unified-control/workflows'
DOCS=ROOT/'docs'
TODAY='2026-08-25'
TARGET=10000

caps=json.load(open(ROOT/'prstudio-unified-control/capabilities/capability-registry.json',encoding='utf-8'))['capabilities']
by_action={(c.get('source') or {}).get('route','')+'\0'+(c.get('source') or {}).get('action',''):c for c in caps}

def humanize(s:str)->str:
    return re.sub(r'\s+',' ',s.replace('_',' ').replace('-',' ')).strip().title()

def phase(n:int,purpose:str,route:str,action:str,read_only:bool=True):
    c=by_action.get(route+'\0'+action)
    if not c: raise KeyError((route,action))
    src=c.get('source') or {}
    return {
      'id':f'p{n:02d}','phase_id':f'p{n:02d}','purpose':purpose,'executor_kind':'capability',
      'capability':c['id'],'tool_name':src.get('tool_name') or ('rpconnector_'+route.strip('/').replace('-','_')+'_'+action.replace('-','_')),
      'route':route,'action':action,'arguments':{},'read_only':bool(read_only),'mutation':not bool(read_only),'destructive':False,
      'checkpoint':'result_receipt','timeout':{'seconds':45,'hard':True},
      'retry':{'policy':'transient_only','max_attempts':2,'backoff_seconds':[1,3]},'evidence_required':True,
      'success_condition':'terminal_status_with_evidence','failure_condition':'terminal_failure_or_unverified_effect','compensation_or_rollback':'none',
      'success':{'status':['completed','completed_verified','degraded'],'evidence_required':True},
      'failure':{'retry':'transient_only','max_attempts':2,'preserve_checkpoint':True}
    }

SEQS={
 'browser':[('/frontend-manage','playwright_list_pages',1),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_console_report',1),('/frontend-manage','playwright_screenshot_page',1)],
 'browser_perf':[('/frontend-manage','playwright_lighthouse_audit',1),('/frontend-manage','playwright_core_web_vitals',1),('/frontend-manage','playwright_network_idle_report',1),('/frontend-manage','playwright_screenshot_page',1)],
 'browser_cdp':[('/frontend-manage','playwright_start_trace',1),('/frontend-manage','playwright_cdp_send',1),('/frontend-manage','playwright_console_report',1),('/frontend-manage','playwright_stop_trace',1)],
 'files':[('/files-manage','list',1),('/files-manage','read',1),('/files-manage','hash_tree',1),('/files-manage','audit_verify',1)],
 'logs':[('/logs-manage','list',1),('/logs-manage','search',1),('/logs-manage','read',1),('/logs-manage','verify',1)],
 'security':[('/security-manage','audit',1),('/security-manage','check_file_integrity',1),('/security-manage','check_permissions',1),('/security-manage','verify',1)],
 'wordpress':[('/plugins-manage','inspect_plugin_logs',1),('/files-manage','read',1),('/security-manage','audit',1),('/files-manage','audit_verify',1)],
 'gutenberg':[('/plugins-manage','inspect_plugin_blocks',1),('/content-manage','validate_blocks',1),('/templates-manage','lint_template_blocks',1),('/themes-manage','inspect_theme_blocks',1)],
 'frontend':[('/seo-manage','audit_rendered_html',1),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_accessibility_scan',1),('/frontend-manage','playwright_page_errors',1)],
 'seo':[('/seo-manage','audit_rendered_html',1),('/global-search','search_files',1),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_core_web_vitals',1)],
 'commerce':[('/frontend-manage','playwright_locator_snapshot',1),('/seo-manage','audit_product_seo',1),('/frontend-manage','playwright_core_web_vitals',1),('/frontend-manage','playwright_screenshot_page',1)],
 'agency':[('/global-search','search_files',1),('/files-manage','audit_start',1),('/files-manage','audit_status',1),('/files-manage','audit_verify',1)],
 'data':[('/database-manage','check',1),('/files-manage','audit_start',1),('/logs-manage','search',1),('/files-manage','audit_verify',1)],
}

def contract(wid:int|str,wave:int,domain:str,objective:str,seq='agency',browser='none',risk='low',mode='durable',external=None,legal=None,refs=None,tags=None,provenance=None):
    wid=str(wid)
    phases=[phase(i,f'{humanize(a)} — {objective}',r,a,bool(ro)) for i,(r,a,ro) in enumerate(SEQS[seq],1)]
    return {
      'id':wid,'version':'1.0.0','wave':wave,'domain':domain,'label':humanize(wid),'description':objective,'business_objective':objective,
      'triggers':[humanize(wid).lower(),objective.lower()[:140]],
      'intent_examples':[f'Esegui {humanize(wid).lower()} con evidenza verificabile.',f'Gestisci {objective.lower()} senza saltare autorizzazione e verifica.'],
      'negative_intent_examples':['Non dichiarare successo senza verifica.','Non aggirare permessi, access controls, ownership o review gate.'],
      'execution_mode':mode,'risk_class':risk,'browser_requirement':browser,'external_provider_requirements':external or [],
      'input_schema':{'type':'object','additionalProperties':True,'properties':{'request_id':{'type':'string','minLength':8},'target':{'type':'string'},'url':{'type':'string'},'scope':{'type':['string','array','object']},'preview':{'type':'boolean','default':True},'verify':{'type':'boolean','default':True},'authorized_scope':{'type':'boolean','default':False},'constraints':{'type':'object','default':{}},'locale':{'type':'string','default':'it-IT'}},'required':[]},
      'output_schema':{'type':'object','required':['ok','data','meta','warnings'],'properties':{'ok':{'type':'boolean'},'data':{'type':'object'},'meta':{'type':'object','required':['workflow_id','workflow_version','request_id','execution_id','status','started_at','finished_at','duration_ms']},'warnings':{'type':'array'}}},
      'preconditions':['authenticated_contract','idempotent_request_identity','authorized_scope_when_mutating_or_security_sensitive'],
      'permissions':{'wordpress_capability':'manage_options' if risk in {'high','critical'} else 'edit_posts','authorization_required':True,'nonce_is_authorization':False,'scope':'workflow'},
      'data_classification':'internal','phases':phases,'decision_gates':[],'approval_gates':['human_review_for_high_consequence_or_ambiguous_mutation'] if risk in {'high','critical'} else [],
      'rollback':{'required_for_mutation':True,'strategy':'checkpoint_then_compensate_or_restore_when_supported'},
      'verification':{'required':True,'evidence':'objective_specific_postcondition','execution_success_is_not_business_success':True},
      'measurement':{'execution_result':True,'verification_result':True,'business_outcome':'separate','measurement_pending_supported':True},
      'failure_semantics':{'preserve_root_cause':True,'completed_unverified_is_not_failed':True,'no_false_pass':True},
      'retry_policy':{'transient_only':True,'max_attempts':2,'bounded':True},'idempotency':{'request_id_required_for_mutation':True,'deduplicate':True},
      'audit_policy':{'enabled':True,'redact_secrets':True,'record_receipts':True},'observability':{'trace':True,'metrics':True,'phase_receipts':True},
      'rate_limit':{'bounded':True,'per_workflow':True,'per_user':True},'retention':{'follow_existing_suite_policy':True},'i18n':{'locale_aware':True,'wordpress_text_domain':True},
      'source_references':refs or ['openai_agents'],'legal_or_policy_constraints':legal or [],
      'completion_contract':{'allowed_statuses':['planned','ready','executing','waiting_external','waiting_approval','completed_verified','completed_unverified','degraded','failed','cancelled','blocked_compliance','blocked_permission'],'completed_verified_requires_postconditions':True},
      'tags':tags or [],'provenance':provenance or {'kind':'cumulative_expansion','cutoff':TODAY}
    }

# Wave 8: the second 299-workflow prompt preserved as an independent cumulative batch.
GROUPS8={
'personal_assistant': '''daily_morning_briefing today_calendar_summary weekly_calendar_summary find_free_slots schedule_meeting reschedule_meeting cancel_meeting email_unread_digest email_priority_triage email_reply_draft email_followup_needed email_to_task slack_channel_digest slack_urgent_mentions slack_thread_summary slack_message_to_task task_capture task_prioritize task_daily_plan task_weekly_review reminder_set reminder_snooze reminder_complete notes_quick_capture notes_meeting_minutes notes_action_items personal_finance_overview personal_finance_spend_anomalies files_recent_summary decision_log'''.split(),
'social_operations': '''social_create_content_plan social_build_content_calendar social_idea_generator social_caption_writer social_hashtag_research social_keyword_research social_trend_watchlist social_competitor_digest social_analytics_snapshot social_weekly_performance_report social_monthly_performance_report social_audience_insights social_content_gap_analysis social_best_time_to_post social_engagement_triage social_comment_sentiment_summary social_inbox_digest social_ugc_watchlist social_campaign_brief social_campaign_plan social_campaign_report social_campaign_anomaly_alert social_post_draft social_post_batch_drafts social_post_approval_pack social_post_schedule social_post_reschedule social_post_cancel social_post_publish social_post_verify_published social_crosspost_plan social_crosspost_publish social_content_repurpose social_blog_to_posts social_product_to_posts social_video_idea_pack social_reel_script_draft social_tiktok_script_draft social_youtube_shorts_script social_linkedin_post_draft social_x_post_draft social_instagram_caption_draft social_facebook_post_draft social_pinterest_pin_draft social_thread_draft social_live_event_plan social_event_promo_plan social_launch_sequence social_offer_promo_sequence social_evergreen_queue_build social_evergreen_queue_refresh social_content_recycle_plan social_brand_voice_check social_claims_compliance_check social_link_check social_asset_check social_pre_publish_check social_post_publish_monitor social_comment_reply_draft social_dm_reply_draft social_crisis_signal_watch social_crisis_brief social_paid_organic_sync social_influencer_shortlist social_influencer_outreach_draft social_collab_brief social_content_experiment social_ab_test_plan social_ab_test_result social_kpi_dashboard_refresh'''.split(),
'local_listings_seo': '''local_find_business_profile local_profile_health_check local_name_address_phone_audit local_hours_audit local_special_hours_update local_category_audit local_category_update local_description_audit local_description_update local_services_audit local_services_update local_products_audit local_products_update local_attributes_audit local_attributes_update local_photo_inventory local_photo_plan local_photo_publish local_cover_logo_audit local_posts_plan local_post_draft local_post_publish local_qa_audit local_qa_answer_draft local_reviews_digest local_reviews_sentiment local_review_reply_draft local_negative_review_alert local_spam_review_flag local_duplicates_check local_duplicate_suppression_plan local_citation_audit local_citation_opportunities local_local_rank_snapshot local_profile_change_log'''.split(),
'creative_content': '''generate_image create_blog_graphic remove_background replace_background extend_image enhance_image create_icon_set create_product_mockup create_ad_creative generate_storyboard generate_infographic create_thumbnail_set visual_style_transfer asset_variant_generator image_text_overlay batch_resize_images topic_research keyword_research competitor_content_research serp_intent_analysis content_gap_analysis trend_research product_research audience_research source_pack_build faq_research internal_link_research entity_research create_blog_post create_article create_landing_page_copy create_category_copy create_product_description create_product_comparison create_buying_guide create_howto create_faq create_email_newsletter create_email_sequence create_press_release create_case_study create_whitepaper create_ebook_outline create_video_script create_podcast_outline create_social_post create_social_thread create_ad_copy create_meta_title create_meta_description create_schema_faq_draft create_schema_howto_draft create_content_brief create_editorial_calendar create_content_cluster_plan create_link_bait_asset rewrite_content simplify_content expand_content shorten_content tone_shift brand_voice_rewrite grammar_style_polish fact_check_draft citations_check plagiarism_risk_check readability_check seo_onpage_check internal_link_suggestions cannibalization_check content_freshness_check claims_compliance_check legal_disclaimer_check publish_readiness_check qa_content_checklist localization_adapt translation_review terminology_consistency_check update_outdated_content merge_duplicate_content extract_key_points repurpose_content summarize_longform generate_content_variants'''.split(),
'keyword_competitive': '''keyword_volume_check keyword_batch_volume_check keyword_difficulty_check keyword_search_intent_classify keyword_trend_check keyword_seasonality_check keyword_serp_features_check keyword_serp_snapshot keyword_related_queries keyword_people_also_ask keyword_autocomplete_expand keyword_question_expand keyword_entity_expand keyword_cluster keyword_topic_map keyword_content_map keyword_url_map keyword_gap_vs_competitor keyword_opportunity_score keyword_priority_queue keyword_local_variants keyword_language_variants keyword_synonym_expand keyword_longtail_expand keyword_brand_vs_nonbrand keyword_commercial_terms keyword_informational_terms keyword_transactional_terms keyword_navigational_terms keyword_position_tracking_snapshot keyword_rank_change_alert keyword_cannibalization_serp keyword_serp_competitor_extract keyword_top_pages_extract keyword_domain_overlap keyword_competitor_new_keywords keyword_competitor_lost_keywords keyword_export_csv keyword_report_build keyword_research_full'''.split(),
'ads_operations': '''ads_create_campaign ads_create_adset ads_create_ad ads_update_campaign ads_update_adset ads_update_ad ads_pause_campaign ads_resume_campaign ads_pause_adset ads_resume_adset ads_pause_ad ads_resume_ad ads_duplicate_campaign ads_duplicate_adset ads_duplicate_ad ads_campaign_summary ads_performance_report ads_spend_summary ads_budget_pacing ads_budget_alert ads_cpa_alert ads_roas_alert ads_ctr_alert ads_cvr_alert ads_frequency_alert ads_anomaly_detect ads_top_performers ads_bottom_performers ads_creative_fatigue_check ads_audience_overlap_check ads_search_terms_review ads_negative_keyword_suggestions ads_keyword_bid_review ads_placement_review ads_device_breakdown ads_geo_breakdown ads_dayparting_analysis ads_attribution_compare ads_tracking_health_check ads_conversion_gap_check'''.split(),
}
assert {k:len(v) for k,v in GROUPS8.items()}=={'personal_assistant':30,'social_operations':70,'local_listings_seo':35,'creative_content':84,'keyword_competitive':40,'ads_operations':40}
wave8=[]
for domain,names in GROUPS8.items():
    for name in names:
        seq='agency'; browser='optional'; risk='medium'; refs=['openai_agents']
        if domain in {'local_listings_seo','keyword_competitive'}: seq='seo'; refs=['google_search_console','bing_webmaster','indexnow']
        if domain=='creative_content': seq='agency'; refs=['openai_agents']
        if domain=='ads_operations': risk='high' if any(x in name for x in ['create_','update_','pause_','resume_','duplicate_']) else 'medium'
        wave8.append(contract(name,8,domain,f'Exact cumulative workflow from the later 299-workflow specification: {humanize(name).lower()}.',seq,browser,risk,'durable',refs=refs,provenance={'kind':'user_prompt_exact_slug','prompt_batch':'299-productivity-social-local-content-keyword-ads','cutoff':TODAY}))
assert len(wave8)==299

DOMAINS9=[
'browser_tab_lifecycle','browser_dom_observation','browser_playwright_engineering','browser_cdp_diagnostics','browser_performance_lighthouse','browser_crawling_scraping','browser_research_evidence','browser_resilience_recovery',
'github_repository_governance','github_actions_ci','github_code_security','github_supply_chain','github_release_engineering',
'wordpress_core_engineering','wordpress_plugin_engineering','wordpress_theme_engineering','wordpress_gutenberg_engineering','wordpress_vip_engineering','wordpress_woocommerce_engineering',
'frontend_html_architecture','frontend_css_architecture','frontend_javascript_architecture','frontend_accessibility','frontend_performance','frontend_design_systems',
'backend_php_engineering','backend_java_engineering','backend_api_engineering','backend_database_engineering','backend_queue_jobs',
'engineering_observability','engineering_incident_response','engineering_refactoring','engineering_testing_quality','engineering_secure_coding',
'cybersecurity_appsec','cybersecurity_cloud_security','cybersecurity_identity_access','cybersecurity_supply_chain',
'data_analytics_engineering','data_science_decisioning','data_governance_quality',
'ai_agent_orchestration','ai_governance_provenance','ai_research_grounding',
'seo_technical','seo_content_strategy','seo_local','seo_geo_aeo',
'social_organic','social_community_care','content_editorial','content_creative_production','paid_media_campaigns','crm_lifecycle','brand_strategy',
'design_figma_systems','design_canva_factory','design_motion_interaction',
'ecommerce_shopify','ecommerce_woocommerce','ecommerce_merchandising','ecommerce_cro','commerce_agentic','commerce_logistics_returns',
'legal_eu_digital','legal_italy_ecommerce','legal_privacy_consent','legal_import_export',
'agency_client_governance','agency_pricing_profitability','agency_operations_qa','executive_business_intelligence']
assert len(DOMAINS9)==73
STAGES=['observe','diagnose','map','plan','execute','verify','measure','optimize','recover','govern']
CONCERNS={
 'browser':['tabs','navigation','dom_state','network','console','screenshots','accessibility','performance','ownership','recovery'],
 'github':['branches','pull_requests','actions','permissions','code_scanning','dependencies','secrets','artifacts','releases','provenance'],
 'wordpress':['blocks','plugins','themes','rest_api','database','cron','cache','permissions','performance','compatibility'],
 'frontend':['semantics','styles','scripts','accessibility','performance','responsive','assets','state','security','compatibility'],
 'backend':['api_contracts','persistence','concurrency','queues','caching','authorization','errors','performance','migrations','resilience'],
 'engineering':['repository','tests','builds','logs','dependencies','quality','performance','security','recovery','evidence'],
 'cybersecurity':['attack_surface','authentication','authorization','secrets','dependencies','input_validation','logging','incident_response','recovery','evidence'],
 'data':['ingestion','modeling','quality','lineage','privacy','metrics','anomalies','forecasting','experiments','reporting'],
 'ai':['tool_routing','context','memory','provenance','evals','safety','cost','latency','grounding','recovery'],
 'seo':['crawlability','indexing','metadata','structured_data','content_quality','internal_links','performance','local_signals','ai_visibility','measurement'],
 'growth':['audience','content','creative','publishing','engagement','compliance','measurement','experimentation','localization','governance'],
 'design':['tokens','components','layouts','assets','accessibility','variants','handoff','provenance','performance','governance'],
 'commerce':['catalog','pricing','inventory','checkout','payments','merchandising','fulfillment','returns','analytics','compliance'],
 'legal':['obligations','jurisdiction','consent','disclosures','contracts','tax','product_safety','accessibility','evidence','change_monitoring'],
 'agency':['strategy','scope','resources','budget','risk','quality','delivery','measurement','profitability','governance'],
}

def family(domain):
    for f in ['browser','github','wordpress','frontend','backend','engineering','cybersecurity','data','ai','seo','design','legal','agency']:
        if domain.startswith(f): return f
    if domain.startswith(('social_','content_','paid_','crm_','brand_')): return 'growth'
    if domain.startswith(('ecommerce_','commerce_')): return 'commerce'
    if domain.startswith('executive_'): return 'agency'
    return 'agency'

def profile(domain):
    f=family(domain); seq='agency'; browser='none'; risk='medium'; mode='durable'; ext=[]; refs=['openai_agents']; legal=[]
    if f=='browser': seq='browser_perf' if 'performance' in domain else ('browser_cdp' if 'cdp' in domain else 'browser'); browser='required'; refs=['chrome_tabs','chrome_tabgroups','chrome_cdp','chrome_lighthouse','playwright_pages','playwright_tracing']
    elif f=='github': seq='security' if ('security' in domain or 'supply_chain' in domain) else 'files'; ext=['github']; refs=['github_actions','github_code_security','github_attestations']; risk='high' if 'security' in domain or 'supply_chain' in domain else 'medium'
    elif f=='wordpress': seq='gutenberg' if 'gutenberg' in domain else 'wordpress'; browser='optional'; refs=['wordpress_developer','wp71_field_guide','wp_block_editor','wordpress_vip']
    elif f=='frontend': seq='frontend'; browser='optional'; refs=['whatwg_html','tc39_ecma262','w3c_css_snapshot_2025']
    elif f=='backend': seq='files'; refs=['owasp_asvs5','owasp_top10_2025']; risk='medium'
    elif f=='engineering': seq='logs' if 'observability' in domain or 'incident' in domain else 'files'; refs=['owasp_asvs5','github_actions']; risk='high' if 'secure' in domain or 'incident' in domain else 'medium'
    elif f=='cybersecurity': seq='security'; refs=['owasp_asvs5','owasp_top10_2025','github_code_security']; risk='high'; legal=['Defensive and authorized use only. No unauthorized exploitation, persistence, credential theft or evasion.']
    elif f=='data': seq='data'; refs=['openai_agents']; risk='medium'
    elif f=='ai': seq='agency'; refs=['openai_plugins_mcp','openai_plugins_tools','openai_agents','openai_deep_research']; risk='high' if 'governance' in domain else 'medium'
    elif f=='seo': seq='seo'; browser='optional'; refs=['google_search_console','bing_webmaster','indexnow']
    elif f=='growth': seq='agency'; browser='optional'; refs=['openai_agents']; risk='medium'
    elif f=='design': seq='frontend'; browser='optional'; refs=['figma_developers'] if 'figma' in domain else (['canva_connect'] if 'canva' in domain else ['motion_docs'])
    elif f=='commerce': seq='commerce'; browser='optional'; refs=['shopify_dev'] if 'shopify' in domain else ['openai_agents']; risk='medium'
    elif f=='legal': seq='agency'; refs=['eurlex_ai_act','eurlex_gpsr','eu_accessibility','eu_gdpr','eu_dsa','garante_cookie','agcm_official','agenzia_entrate','adm_official','mimit_official']; risk='high'; mode='human_approval_required'; legal=['Compliance-support only. Material or uncertain legal, tax, customs or product-safety classification requires qualified human review.']
    elif f=='agency': seq='agency'; refs=['wpp_open','accenture_song','dept_agency','openai_agents']
    return seq,browser,risk,mode,ext,refs,legal

wave9=[]
for domain in DOMAINS9:
    f=family(domain); concerns=CONCERNS[f]
    seq,browser,risk,mode,ext,refs,legal=profile(domain)
    for concern in concerns:
        for stage in STAGES:
            wid=f'atlas_{domain}_{stage}_{concern}'
            objective=f'{humanize(stage)} the {humanize(concern).lower()} operating objective for {humanize(domain).lower()} with bounded execution, objective-specific evidence, rollback/recovery and measurable outcome.'
            wave9.append(contract(wid,9,domain,objective,seq,browser,risk,mode,external=ext,legal=legal,refs=refs,tags=['enterprise_atlas',f,stage,concern],provenance={'kind':'10k_enterprise_atlas','taxonomy':'73_domains_x_10_concerns_x_10_lifecycle_stages','cutoff':TODAY}))
assert len(wave9)==7300
CROSS9=[
 'atlas_cross_domain_inventory_all_surfaces','atlas_cross_domain_route_first_correct_workflow','atlas_cross_domain_validate_nested_graph','atlas_cross_domain_enforce_phase_budget','atlas_cross_domain_enforce_duration_budget','atlas_cross_domain_enforce_cost_budget','atlas_cross_domain_detect_duplicate_objectives','atlas_cross_domain_detect_semantic_collisions','atlas_cross_domain_verify_source_freshness','atlas_cross_domain_verify_legal_effective_dates','atlas_cross_domain_verify_browser_ownership','atlas_cross_domain_verify_git_provenance','atlas_cross_domain_verify_release_attestation','atlas_cross_domain_verify_accessibility_gate','atlas_cross_domain_verify_security_authorization','atlas_cross_domain_verify_privacy_minimization','atlas_cross_domain_verify_idempotency','atlas_cross_domain_verify_rollback_readiness','atlas_cross_domain_verify_observability_receipts','atlas_cross_domain_measure_first_tool_accuracy','atlas_cross_domain_measure_calls_to_success','atlas_cross_domain_produce_executive_command_center']
for wid in CROSS9:
    wave9.append(contract(wid,9,'cross_domain_enterprise_control',f'Cross-domain enterprise control: {humanize(wid).lower()}.','agency','optional','high','durable',refs=['openai_agents','github_attestations','wp71_field_guide','owasp_asvs5'],tags=['enterprise_atlas','cross_domain'],provenance={'kind':'10k_enterprise_atlas_cross_domain','cutoff':TODAY}))
assert len(wave9)==7322

# Existing Waves 1-7 remain byte-for-byte inputs to this cumulative generator.
PATHS=[
 WF/'enterprise-workflows-wave1-2026-08-25.json',WF/'enterprise-workflows-wave2-2026-08-25.json',WF/'enterprise-workflows-wave3-2026-08-25.json',WF/'wave4-enterprise-workflows-2026-08-25.json',WF/'wave5-enterprise-workflows-2026-08-25.json',WF/'enterprise-workflows-wave6-consulting-2026-08-25.json',WF/'enterprise-workflows-wave7-web-engineering-2026-08-25.json']
docs=[json.load(open(p,encoding='utf-8')) for p in PATHS]
existing=[w for d in docs for w in d['workflows']]
existing_ids={w['id'] for w in existing}
for label,batch in [('wave8',wave8),('wave9',wave9)]:
    ids=[w['id'] for w in batch]
    assert len(ids)==len(set(ids)),f'{label} duplicate IDs'
    dup=existing_ids & set(ids)
    assert not dup,f'{label} collision {sorted(dup)[:20]}'
    existing_ids.update(ids)
assert len(existing)+len(wave8)+len(wave9)==TARGET
assert len(existing_ids)==TARGET

def write_wave(filename,wave,items,extra=None):
    domains=collections.Counter(w['domain'] for w in items)
    doc={'schema_version':'4.0.0','suite_version':'1.0.0','reference_date':TODAY,'wave':wave,'workflow_count':len(items),'phase_count':sum(len(w.get('phases',[])) for w in items),'domains':dict(sorted(domains.items())),'design_contract':{'canonical_internal_workflows':True,'compact_mcp_surface':True,'three_component_architecture_preserved':True,'completion_semantics':'execution != verification != business outcome','target_registry_workflows':TARGET},'workflows':items}
    if extra: doc.update(extra)
    raw=json.dumps(doc,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(); doc['document_sha256']=hashlib.sha256(raw).hexdigest()
    (WF/filename).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return doc

d8=write_wave('enterprise-workflows-wave8-productivity-growth-2026-08-25.json',8,wave8,{'assertions':{k:len(v) for k,v in GROUPS8.items()}|{'total':299},'purpose':'Second distinct 299-workflow user specification preserved cumulatively with exact slugs.'})
d9=write_wave('enterprise-workflows-wave9-enterprise-atlas-2026-08-25.json',9,wave9,{'assertions':{'domains':73,'per_domain':100,'cross_domain':22,'total':7322},'purpose':'Enterprise Atlas expansion bringing the canonical registry to exactly 10,000 workflows.'})

all_items=existing+wave8+wave9
waves={str(i):0 for i in range(1,10)}
for w in all_items: waves[str(w['wave'])]+=1
index={'schema_version':'4.0.0','reference_date':TODAY,'workflow_count':TARGET,'phase_count':sum(len(w.get('phases',[])) for w in all_items),'waves':waves,'domains':dict(sorted(collections.Counter(w['domain'] for w in all_items).items())),'items':[{'id':w['id'],'wave':w['wave'],'domain':w['domain'],'label':w.get('label',''),'execution_mode':w.get('execution_mode','durable'),'risk_class':w.get('risk_class',''),'browser_requirement':w.get('browser_requirement','none'),'phase_count':len(w.get('phases',[]))} for w in all_items], 'cumulative_contract':{'canonical_workflow_target':TARGET,'mcp_surface_policy':'compact_router_not_10000_top_level_tools','preserve_prior_workflows':True,'prompt_batches_preserved':True}}
(WF/'enterprise-workflows-index-2026-08-25.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Documentation
DOCS.mkdir(exist_ok=True)
def doc_wave(path,title,items):
    lines=[f'# {title}','',f'Reference date: {TODAY}. Canonical workflows: **{len(items)}**.','', '| ID | Domain | Mode | Browser | Risk | Purpose |','|---|---|---|---|---|---|']
    for w in items: lines.append(f"| `{w['id']}` | `{w['domain']}` | `{w['execution_mode']}` | `{w['browser_requirement']}` | `{w['risk_class']}` | {w['business_objective'].replace('|','/')} |")
    pathlib.Path(path).write_text('\n'.join(lines)+'\n',encoding='utf-8')
doc_wave(DOCS/'WAVE8-PRODUCTIVITY-GROWTH-WORKFLOWS-2026-08-25.md','Wave 8 — Productivity / Social / Local / Content / Keyword / Ads',wave8)
doc_wave(DOCS/'WAVE9-ENTERPRISE-ATLAS-7322-WORKFLOWS-2026-08-25.md','Wave 9 — Enterprise Atlas 7,322',wave9)
gap=DOCS/'WAVE4-WAVE5-GAP-MATRIX-2026-08-25.md'
if gap.exists():
    gs=gap.read_text(encoding='utf-8')
    gs=gs.replace('Global canonical total after expansion: **2379**; net-new workflows: **2079**.','Foundation total through Wave 7: **2379**. Cumulative canonical registry after Wave 8 + Wave 9: **10000** workflows.')
    gap.write_text(gs,encoding='utf-8')

# Keep ChatGPT/plugin documentation synchronized with the authoritative cumulative registry.
build_info=json.load(open(ROOT/'prstudio-unified-control/BUILD-INFO.json',encoding='utf-8'))
tool_count=int(build_info.get('mcp_tool_count',123))
capability_count=int(build_info.get('capability_count',len(caps)))
action_count=int(build_info.get('legacy_action_count',1076))
domain_count=len(index['domains'])
(DOCS/'CUMULATIVE-10000-WORKFLOW-ARCHITECTURE-2026-08-25.md').write_text(f'''# RP STUDIO — Cumulative 10,000 Workflow Architecture

Cutoff: {TODAY}. Canonical executable workflows: **{TARGET:,}**. Grounded executable phases: **{index['phase_count']:,}**. Domains: **{domain_count}**.

| Wave | Count | Role |
|---:|---:|---|
| 1 | 300 | General BrowserKing/browser automation, tab ownership and recovery. |
| 2 | 300 | Original 300 workflow IDs preserved for backward compatibility. |
| 3 | 300 | Engineering, logs, bugs, refactor, repo/file analysis and defensive security. |
| 4 | 380 | Global agency expansion and specialist centres of excellence. |
| 5 | 600 | Agency operating-system strategic/compositional workflows. |
| 6 | 299 | First exact consulting/production 299-workflow prompt. |
| 7 | 200 | Gutenberg, HTML, JavaScript, Java and CSS engineering. |
| 8 | 299 | Second distinct productivity/social/local/content/keyword/ads 299-workflow prompt. |
| 9 | 7,322 | Enterprise Atlas: 73 domains × 100 lifecycle procedures + 22 cross-domain controls. |
| **Total** | **{TARGET:,}** | **Canonical executable registry** |

The registry preserves every previously loaded workflow ID. Wave 8 preserves the second distinct 299-workflow specification; Wave 9 contributes 7,322 enterprise procedures. Wave 9 is not an alias pack: it is a lifecycle matrix over 73 operating domains, 10 domain concerns and 10 distinct lifecycle objectives (observe, diagnose, map, plan, execute, verify, measure, optimize, recover, govern), plus 22 cross-domain controls.

## How ChatGPT sees the suite

ChatGPT sees a compact MCP surface of **{tool_count} public tools**, backed by **{capability_count:,} canonical capabilities** and **{action_count:,} legacy actions**. It does **not** receive {TARGET:,} top-level workflow tools. The public `prstudio_workflow` gateway exposes all {TARGET:,} canonical workflows through paginated `search`/`catalog`, then `describe`/`validate` and server-side `run`. The gateway accepts Waves 1–9 and a catalog/search limit up to 100 with offset pagination.

This separation keeps tool selection bounded while preserving lossless workflow reachability. Direct primitive requests can still use typed tools; multi-step objectives should prefer the canonical workflow gateway.

## Authoritative count sources

- `prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-25.json` — workflow, phase, wave and domain registry.
- `prstudio-unified-control/BUILD-INFO.json` — MCP tool, capability and action counts.
- `RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json` — ChatGPT/MCP exposure contract.
- `prstudio-unified-control/workflows/README.md` — human-readable registry map.
''',encoding='utf-8')
(DOCS/'RELEASE-DOCUMENTATION-ALIGNMENT-2026-08-25.md').write_text(f'''# RP STUDIO — Release Documentation Alignment

Reference date: {TODAY}. This file records the authoritative current-state numbers used by release documentation and tests.

| Surface | Authoritative value |
|---|---:|
| Canonical workflows | {TARGET:,} |
| Grounded workflow phases | {index['phase_count']:,} |
| Workflow domains | {domain_count} |
| Waves | 1–9 |
| Wave counts | 300 / 300 / 300 / 380 / 600 / 299 / 200 / 299 / 7,322 |
| Public MCP tools | {tool_count} |
| Canonical capabilities | {capability_count:,} |
| Legacy actions | {action_count:,} |
| Workflow gateway | `prstudio_workflow` |
| Gateway operations | `search`, `catalog`, `describe`, `validate`, `run` |
| Catalog page maximum | 100 |

Historical references to **2,379** are valid only when explicitly labelled as the Wave-1-through-Wave-7 foundation. They are not the current canonical total. ChatGPT sees the bounded MCP tool surface and discovers/runs the {TARGET:,} internal workflows through `prstudio_workflow`; it does not receive {TARGET:,} top-level tool definitions.
''',encoding='utf-8')
inv={'cutoff':TODAY,'target':TARGET,'canonical_workflow_count':TARGET,'waves':waves,'phase_count':index['phase_count'],'domain_count':domain_count,'public_mcp_tool_count':tool_count,'canonical_capability_count':capability_count,'legacy_action_count':action_count,'wave8_exact_slug_count':299,'wave9_enterprise_atlas_count':7322,'chatgpt_exposure':{'mode':'compact_mcp_gateway','gateway_tool':'prstudio_workflow','actions':['search','catalog','describe','validate','run'],'top_level_workflow_tools':False,'catalog_limit_max':100,'waves_supported':list(range(1,10))},'authoritative_artifacts':['prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-25.json','prstudio-unified-control/BUILD-INFO.json','RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json']}
(DOCS/'CUMULATIVE-WORKFLOW-INVENTORY-2026-08-25.json').write_text(json.dumps(inv,indent=2)+'\n')

descriptor_path=ROOT/'RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json'
descriptor=json.load(open(descriptor_path,encoding='utf-8'))
wc=descriptor.setdefault('workflow_catalog',{})
wc.update({'canonical_workflows':TARGET,'phase_count':index['phase_count'],'domain_count':domain_count,'waves':waves,'public_mcp_tools':tool_count,'internal_capabilities':capability_count,'legacy_actions':action_count,'exposure_mode':'complete_discovery_and_execution_via_prstudio_workflow','pagination':{'limit_max':100,'offset_supported':True},'top_level_tool_flattening':False,'reason':'Avoid overlapping near-duplicate tool definitions while keeping every canonical workflow reachable through MCP search/catalog/describe/run.'})
for item in ['prstudio-unified-control/workflows/README.md','docs/CUMULATIVE-10000-WORKFLOW-ARCHITECTURE-2026-08-25.md','docs/CUMULATIVE-WORKFLOW-INVENTORY-2026-08-25.json','docs/WAVE8-PRODUCTIVITY-GROWTH-WORKFLOWS-2026-08-25.md','docs/WAVE9-ENTERPRISE-ATLAS-7322-WORKFLOWS-2026-08-25.md','docs/RELEASE-DOCUMENTATION-ALIGNMENT-2026-08-25.md']:
    if item not in descriptor.setdefault('documentation',[]): descriptor['documentation'].append(item)
descriptor_path.write_text(json.dumps(descriptor,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

instructions_path=ROOT/'RP-STUDIO-CHATGPT-PLUGIN-INSTRUCTIONS-1.0.0.txt'
if instructions_path.exists():
    ins=instructions_path.read_text(encoding='utf-8').replace('10000 workflow canonici. 10.231 fasi grounded',f'10000 workflow canonici. {index["phase_count"]:,} fasi grounded'.replace(',', '.'))
    instructions_path.write_text(ins,encoding='utf-8')

print(json.dumps({'target':TARGET,'waves':waves,'phase_count':index['phase_count'],'domains':domain_count,'wave8':len(wave8),'wave9':len(wave9),'mcp_tools':tool_count,'capabilities':capability_count,'actions':action_count},indent=2))
