import { constants } from 'node:fs';
import { lstat, mkdir, open, realpath, rename, rm } from 'node:fs/promises';
import { createHash, randomBytes } from 'node:crypto';
import { basename, isAbsolute, relative, resolve } from 'node:path';

const DEFAULT_MAX_JSON_BYTES = 2 * 1024 * 1024;

export const BROWSER_PARITY_REQUIRED_CHECKS = Object.freeze([
  'exact_mv3_worker_loaded',
  'required_chrome_api_surface',
  'three_tabs_same_window',
  'tabs_query_sees_all_controlled_tabs',
  'wait_ready_real_page',
  'fill_through_page_runtime',
  'click_through_page_runtime',
  'chrome_scripting_observes_real_mutation',
  'background_tab_remains_controllable',
  'tab_group_roundtrip',
  'page_runtime_reconnects_after_navigation',
  'page_runtime_reconnects_after_reload',
  'tab_go_back_keeps_runtime',
  'tab_go_forward_keeps_runtime',
  'visible_tab_screenshot_real',
  'service_worker_local_health_real',
  'mv3_worker_restarts_after_termination',
  'worker_accepts_messages_after_restart',
  'existing_page_runtime_survives_worker_restart',
  'service_worker_pipeline_recovers_after_restart',
  'closed_tab_is_really_gone',
  'closing_one_tab_does_not_break_others',
  'can_open_and_control_new_tab_after_close_restart',
  'final_controlled_tabs_healthy',
]);

export const REMOTE_E2E_REQUIRED_CHECKS = Object.freeze([
  'Google Chrome process is real',
  'exact MV3 bootstrap service worker is live',
  'Browser Agent build is bound to Git',
  'real WordPress pairing request is accepted',
  'remote task 1 claimed and completed through tasks/next',
  'cross-origin task gets a distinct owned tab without stealing the lane origin',
  'cross-origin ownership is bound to the exact expected origin',
  'ownership registry survives MV3 restart',
  'remote task after MV3 restart completes',
  'multi-tab ownership is independent by lane',
  'remote close cleans owned tab and registry',
  'Control build identity is bound to same source SHA',
  'Browser and Control contract/protocol hashes are identical',
  'final remote E2E acceptance',
]);

export function sanitizeLogValue(value, maxChars = 12000) {
  const bounded = Number.isInteger(maxChars) && maxChars > 0 ? Math.min(maxChars, 100000) : 12000;
  return String(value ?? '')
    .replace(/\n|\r/g, ' ')
    .replace(/[\u2028\u2029]/g, ' ')
    .replace(/[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f-\u009f]/g, '?')
    .slice(0, bounded);
}

function checkedArtifactTarget(rootDir, leafName, extension) {
  const leaf = String(leafName ?? '');
  if (!leaf || leaf !== basename(leaf) || isAbsolute(leaf) || !leaf.endsWith(extension) || leaf.includes('\0')) {
    throw new Error(`artifact_leaf_invalid:${sanitizeLogValue(leaf, 200)}`);
  }
  const root = resolve(rootDir);
  const target = resolve(root, leaf);
  const confined = relative(root, target);
  if (!confined || confined.startsWith('..') || isAbsolute(confined)) throw new Error('artifact_path_outside_root');
  return { root, target };
}

export function confinedArtifactRoot(allowedRoot, requestedRoot) {
  const root = resolve(allowedRoot);
  const requested = resolve(requestedRoot);
  const confined = relative(root, requested);
  if (confined.startsWith('..') || isAbsolute(confined)) throw new Error('artifact_root_outside_allowed_tree');
  return requested;
}

function checkedMaxBytes(maxBytes) {
  const value = Number(maxBytes ?? DEFAULT_MAX_JSON_BYTES);
  if (!Number.isSafeInteger(value) || value < 2 || value > 16 * 1024 * 1024) throw new Error('artifact_max_bytes_invalid');
  return value;
}

async function checkedRoot(root) {
  await mkdir(root, { recursive: true, mode: 0o700 });
  const actual = await realpath(root);
  if (!actual) throw new Error('artifact_root_unresolvable');
  return actual;
}

function openFlags(flags) {
  return process.platform === 'win32' ? flags : flags | constants.O_NOFOLLOW;
}

function regularFile(metadata) {
  return metadata && typeof metadata.isFile === 'function' && metadata.isFile() === true;
}

function artifactIdentity(metadata) {
  if (!metadata || metadata.dev === undefined || metadata.ino === undefined) return '';
  const dev = String(metadata.dev);
  const ino = String(metadata.ino);
  if (!/^\d+$/.test(dev) || !/^\d+$/.test(ino) || ino === '0') return '';
  return `${dev}:${ino}`;
}

export function validateWindowsArtifactSourceMetadata(pathMetadata, handleMetadata) {
  if (!pathMetadata || typeof pathMetadata.isSymbolicLink !== 'function' || pathMetadata.isSymbolicLink()) {
    throw new Error('artifact_source_windows_reparse_or_symlink');
  }
  if (!regularFile(pathMetadata) || !regularFile(handleMetadata)) throw new Error('artifact_source_windows_not_regular');
  const pathIdentity = artifactIdentity(pathMetadata);
  const handleIdentity = artifactIdentity(handleMetadata);
  if (!pathIdentity || !handleIdentity || pathIdentity !== handleIdentity) throw new Error('artifact_source_windows_identity_changed');
  return true;
}

export async function readBoundedJsonArtifact(rootDir, leafName, { maxBytes = DEFAULT_MAX_JSON_BYTES } = {}) {
  const limit = checkedMaxBytes(maxBytes);
  const checked = checkedArtifactTarget(rootDir, leafName, '.json');
  const root = await checkedRoot(checked.root);
  const target = resolve(root, basename(checked.target));
  const pathMetadata = process.platform === 'win32' ? await lstat(target) : null;
  const handle = await open(target, openFlags(constants.O_RDONLY));
  try {
    const before = await handle.stat();
    if (process.platform === 'win32') validateWindowsArtifactSourceMetadata(pathMetadata, before);
    if (!before.isFile() || before.size < 2 || before.size > limit) throw new Error(`artifact_source_invalid:size=${before.size}`);
    const bytes = await handle.readFile();
    const after = await handle.stat();
    if (artifactIdentity(after) !== artifactIdentity(before)
      || bytes.length !== before.size || after.size !== before.size || after.mtimeMs !== before.mtimeMs) {
      throw new Error('artifact_source_changed_during_read');
    }
    const text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    const value = JSON.parse(text);
    return {
      value,
      byteLength: bytes.length,
      sha256: createHash('sha256').update(bytes).digest('hex'),
    };
  } finally {
    await handle.close();
  }
}

export async function writeBoundedJsonArtifact(rootDir, leafName, value, { maxBytes = DEFAULT_MAX_JSON_BYTES } = {}) {
  const limit = checkedMaxBytes(maxBytes);
  const bytes = Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8');
  if (bytes.length < 2 || bytes.length > limit) throw new Error(`artifact_bytes_out_of_bounds:${bytes.length}`);
  return writeBoundedArtifactBytes(rootDir, leafName, bytes, { extension: '.json', maxBytes: limit });
}

export async function writeBoundedTextArtifact(rootDir, leafName, value, { maxBytes = 256 * 1024 } = {}) {
  const limit = checkedMaxBytes(maxBytes);
  const text = `${sanitizeLogValue(value, limit)}\n`;
  const bytes = Buffer.from(text, 'utf8');
  if (bytes.length > limit) throw new Error(`artifact_bytes_out_of_bounds:${bytes.length}`);
  return writeBoundedArtifactBytes(rootDir, leafName, bytes, { extension: '.log', maxBytes: limit });
}

export function decodeValidatedPngBase64(value, { maxBytes = 16 * 1024 * 1024, maxPixels = 40_000_000 } = {}) {
  const limit = checkedMaxBytes(maxBytes);
  const source = String(value ?? '');
  if (!source || source.length > Math.ceil(limit * 4 / 3) + 4 || source.length % 4 !== 0) {
    throw new Error('png_base64_length_invalid');
  }
  for (let index = 0; index < source.length; index += 1) {
    const code = source.charCodeAt(index);
    const base64 = (code >= 65 && code <= 90) || (code >= 97 && code <= 122) || (code >= 48 && code <= 57) || code === 43 || code === 47;
    if (!base64 && code !== 61) throw new Error('png_base64_character_invalid');
  }
  const bytes = Buffer.from(source, 'base64');
  if (bytes.length < 45 || bytes.length > limit || bytes.toString('base64') !== source) throw new Error('png_base64_canonical_decode_failed');
  if (!bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) throw new Error('png_signature_invalid');
  if (bytes.readUInt32BE(8) !== 13 || bytes.toString('ascii', 12, 16) !== 'IHDR') throw new Error('png_ihdr_invalid');
  const width = bytes.readUInt32BE(16);
  const height = bytes.readUInt32BE(20);
  if (!width || !height || width > 32768 || height > 32768 || width * height > maxPixels) throw new Error('png_dimensions_invalid');

  let cursor = 8;
  let terminalIend = false;
  let chunks = 0;
  while (cursor < bytes.length) {
    if (cursor + 12 > bytes.length || chunks >= 10000) throw new Error('png_chunk_bounds_invalid');
    const chunkLength = bytes.readUInt32BE(cursor);
    const chunkEnd = cursor + 12 + chunkLength;
    if (chunkEnd > bytes.length) throw new Error('png_chunk_bounds_invalid');
    const chunkType = bytes.toString('ascii', cursor + 4, cursor + 8);
    cursor = chunkEnd;
    chunks += 1;
    if (chunkType === 'IEND') {
      if (chunkLength !== 0 || cursor !== bytes.length) throw new Error('png_iend_invalid');
      terminalIend = true;
      break;
    }
  }
  if (!terminalIend) throw new Error('png_iend_missing');
  return bytes;
}

export async function writeBoundedPngArtifact(rootDir, leafName, bytes, { maxBytes = 16 * 1024 * 1024 } = {}) {
  return writeBoundedArtifactBytes(rootDir, leafName, bytes, { extension: '.png', maxBytes });
}

async function writeBoundedArtifactBytes(rootDir, leafName, value, { extension, maxBytes }) {
  const limit = checkedMaxBytes(maxBytes);
  const checked = checkedArtifactTarget(rootDir, leafName, extension);
  const root = await checkedRoot(checked.root);
  const target = resolve(root, basename(checked.target));
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(value);
  if (!bytes.length || bytes.length > limit) throw new Error(`artifact_bytes_out_of_bounds:${bytes.length}`);

  const stage = resolve(root, `.${basename(target)}.${process.pid}.${randomBytes(12).toString('hex')}.tmp`);
  const handle = await open(stage, openFlags(constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL), 0o600);
  try {
    await handle.writeFile(bytes);
    await handle.sync();
    const metadata = await handle.stat();
    if (!metadata.isFile() || metadata.size !== bytes.length) throw new Error('artifact_stage_write_incomplete');
  } finally {
    await handle.close();
  }

  try {
    // Rename the complete stage directly: POSIX replacement is atomic and does
    // not follow a target symlink. No preflight stat/access check means there is
    // no check/use race. Windows requires an explicit non-recursive unlink.
    await rename(stage, target);
  } catch (error) {
    if (process.platform === 'win32' && ['EEXIST', 'EPERM'].includes(error?.code)) {
      await rm(target, { force: false, recursive: false });
      await rename(stage, target);
    } else {
      await rm(stage, { force: true });
      throw error;
    }
  }
  return { byteLength: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), path: target };
}

export function validateBrowserExtensionReport(report, expectedBaseUrl) {
  if (!report || typeof report !== 'object' || Array.isArray(report) || report.ok !== true) {
    throw new Error('browser_e2e_report_not_green');
  }
  if (report.base_url !== expectedBaseUrl) throw new Error('browser_e2e_base_url_mismatch');
  if (typeof report.browser_version !== 'string' || !/^Chrome\/[0-9]+(?:\.[0-9]+){1,4}$/.test(report.browser_version)) {
    throw new Error('browser_e2e_browser_version_invalid');
  }
  if (!Array.isArray(report.checks) || report.checks.length < BROWSER_PARITY_REQUIRED_CHECKS.length || report.checks.length > 256) {
    throw new Error('browser_e2e_checks_invalid');
  }

  const checks = new Map();
  for (const row of report.checks) {
    if (!row || typeof row !== 'object' || typeof row.name !== 'string' || !/^[a-z0-9_]{1,96}$/.test(row.name) || row.ok !== true) {
      throw new Error('browser_e2e_check_row_invalid');
    }
    if (checks.has(row.name)) throw new Error(`browser_e2e_duplicate_check:${row.name}`);
    checks.set(row.name, row);
  }
  const missing = BROWSER_PARITY_REQUIRED_CHECKS.filter((name) => !checks.has(name));
  if (missing.length) throw new Error(`browser_e2e_required_checks_missing:${missing.join(',')}`);

  const worker = checks.get('exact_mv3_worker_loaded');
  const extensionId = String(worker?.extension_id ?? '');
  if (!/^[a-p]{32}$/.test(extensionId)) throw new Error('browser_e2e_extension_id_invalid');
  if (report.worker_url !== `chrome-extension://${extensionId}/service-worker-bootstrap.js`) {
    throw new Error('browser_e2e_worker_url_invalid');
  }
  if (report.error != null) throw new Error('browser_e2e_success_contains_error');
  if (typeof report.finished_at !== 'string' || report.finished_at.length > 40 || !Number.isFinite(Date.parse(report.finished_at))) {
    throw new Error('browser_e2e_finished_at_invalid');
  }
  return true;
}

export function canonicalBrowserParityEvidence(source) {
  if (!source || !/^[a-f0-9]{64}$/.test(String(source.sha256 ?? ''))) throw new Error('artifact_sha256_invalid');
  if (!Number.isSafeInteger(source.byteLength) || source.byteLength < 2 || source.byteLength > DEFAULT_MAX_JSON_BYTES) {
    throw new Error('artifact_source_size_invalid');
  }
  return {
    schema_version: 1,
    ok: true,
    source_artifact: 'artifacts/browser-e2e/browser-extension-e2e.json',
    source_sha256: source.sha256,
    source_bytes: source.byteLength,
    checks: BROWSER_PARITY_REQUIRED_CHECKS.map((name) => ({ name, ok: true })),
  };
}

export function canonicalRemoteE2EEvidence(evidence) {
  if (!evidence || typeof evidence !== 'object' || Array.isArray(evidence)) throw new Error('remote_e2e_evidence_invalid');
  if (!Array.isArray(evidence.tasks) || evidence.tasks.length > 64) throw new Error('remote_e2e_tasks_invalid');
  if (!Array.isArray(evidence.checks) || evidence.checks.length > 512) throw new Error('remote_e2e_checks_invalid');
  const taskCount = evidence.tasks.length;
  const completedTaskCount = evidence.tasks.filter((row) => String(row?.status || '').toLowerCase() === 'completed').length;
  const checkCount = evidence.checks.length;
  const passedCheckCount = evidence.checks.filter((row) => row?.ok === true).length;
  for (const name of REMOTE_E2E_REQUIRED_CHECKS) {
    const matches = evidence.checks.filter((row) => row?.name === name);
    if (matches.length !== 1 || matches[0]?.ok !== true) throw new Error(`remote_e2e_required_check_invalid:${name}`);
  }
  const receipt = {
    schema_version: '1.0.0',
    ok: evidence.ok === true,
    task_count: taskCount,
    completed_task_count: completedTaskCount,
    check_count: checkCount,
    passed_check_count: passedCheckCount,
    error_present: Boolean(evidence.error),
    required_checks: [...REMOTE_E2E_REQUIRED_CHECKS],
  };
  return {
    ...receipt,
    receipt_algorithm: 'sha256',
    receipt_sha256: createHash('sha256').update(JSON.stringify(receipt), 'utf8').digest('hex'),
  };
}

function remoteFailureCode(error) {
  const raw = String(error?.code || error?.message || error?.name || 'remote_e2e_failure');
  const prefix = raw.split(':', 1)[0].trim().toLowerCase().replace(/[^a-z0-9_.-]+/g, '_');
  return /^[a-z0-9][a-z0-9_.-]{0,95}$/.test(prefix) ? prefix : 'remote_e2e_failure';
}

function remoteFailureLocation(error) {
  const stack = String(error?.stack || '');
  const match = stack.match(/wordpress-remote-browser-e2e\.mjs:(\d{1,6}):(\d{1,6})/);
  if (!match) return { line: 0, column: 0 };
  return { line: Number(match[1]), column: Number(match[2]) };
}

/**
 * Produce a useful failure receipt without copying remote task payloads,
 * browser target metadata, credentials, URLs, error text or stack traces.
 * Success and failure receipts intentionally have distinct exact schemas so a
 * diagnostic can never be mistaken for green certification evidence.
 */
export function canonicalRemoteE2EFailureEvidence(evidence, error) {
  if (!evidence || typeof evidence !== 'object' || Array.isArray(evidence)) throw new Error('remote_e2e_evidence_invalid');
  if (!Array.isArray(evidence.tasks) || evidence.tasks.length > 64) throw new Error('remote_e2e_tasks_invalid');
  if (!Array.isArray(evidence.checks) || evidence.checks.length > 512) throw new Error('remote_e2e_checks_invalid');
  const safeChecks = evidence.checks.filter((row) => row && typeof row === 'object' && typeof row.name === 'string');
  const lastPassed = [...safeChecks].reverse().find((row) => row.ok === true);
  const failed = [...safeChecks].reverse().find((row) => row.ok !== true);
  const location = remoteFailureLocation(error);
  const diagnostic = {
    schema_version: '1.0.0',
    ok: false,
    error_present: true,
    failure_code: remoteFailureCode(error),
    failure_line: location.line,
    failure_column: location.column,
    last_passed_check: sanitizeLogValue(lastPassed?.name || '', 160),
    failed_check: sanitizeLogValue(failed?.name || '', 160),
    task_count: evidence.tasks.length,
    completed_task_count: evidence.tasks.filter((row) => String(row?.status || '').toLowerCase() === 'completed').length,
    check_count: evidence.checks.length,
    passed_check_count: evidence.checks.filter((row) => row?.ok === true).length,
    required_checks_passed: REMOTE_E2E_REQUIRED_CHECKS.filter((name) => safeChecks.some((row) => row.name === name && row.ok === true)),
  };
  return {
    ...diagnostic,
    diagnostic_algorithm: 'sha256',
    diagnostic_sha256: createHash('sha256').update(JSON.stringify(diagnostic), 'utf8').digest('hex'),
  };
}

export function validateRemoteE2EFailureEvidence(diagnostic) {
  if (!diagnostic || typeof diagnostic !== 'object' || Array.isArray(diagnostic)) throw new Error('remote_e2e_failure_diagnostic_invalid');
  const exactKeys = [
    'schema_version', 'ok', 'error_present', 'failure_code', 'failure_line', 'failure_column',
    'last_passed_check', 'failed_check', 'task_count', 'completed_task_count', 'check_count',
    'passed_check_count', 'required_checks_passed', 'diagnostic_algorithm', 'diagnostic_sha256',
  ];
  if (Object.keys(diagnostic).sort().join('\n') !== [...exactKeys].sort().join('\n')) throw new Error('remote_e2e_failure_diagnostic_fields_invalid');
  if (diagnostic.schema_version !== '1.0.0' || diagnostic.ok !== false || diagnostic.error_present !== true) {
    throw new Error('remote_e2e_failure_diagnostic_status_invalid');
  }
  if (!/^[a-z0-9][a-z0-9_.-]{0,95}$/.test(String(diagnostic.failure_code || ''))) throw new Error('remote_e2e_failure_code_invalid');
  for (const field of ['failure_line', 'failure_column', 'task_count', 'completed_task_count', 'check_count', 'passed_check_count']) {
    if (!Number.isSafeInteger(diagnostic[field]) || diagnostic[field] < 0) throw new Error(`remote_e2e_failure_${field}_invalid`);
  }
  if (diagnostic.completed_task_count > diagnostic.task_count || diagnostic.passed_check_count > diagnostic.check_count) {
    throw new Error('remote_e2e_failure_counts_invalid');
  }
  if (typeof diagnostic.last_passed_check !== 'string' || diagnostic.last_passed_check.length > 160
    || typeof diagnostic.failed_check !== 'string' || diagnostic.failed_check.length > 160) {
    throw new Error('remote_e2e_failure_check_name_invalid');
  }
  if (!Array.isArray(diagnostic.required_checks_passed)
    || new Set(diagnostic.required_checks_passed).size !== diagnostic.required_checks_passed.length
    || diagnostic.required_checks_passed.some((name) => !REMOTE_E2E_REQUIRED_CHECKS.includes(name))) {
    throw new Error('remote_e2e_failure_required_checks_invalid');
  }
  if (diagnostic.diagnostic_algorithm !== 'sha256'
    || !/^[a-f0-9]{64}$/.test(String(diagnostic.diagnostic_sha256 || ''))
    || /^0{64}$/.test(diagnostic.diagnostic_sha256)) throw new Error('remote_e2e_failure_hash_invalid');
  const canonical = Object.fromEntries(exactKeys.slice(0, -2).map((key) => [key, diagnostic[key]]));
  const expected = createHash('sha256').update(JSON.stringify(canonical), 'utf8').digest('hex');
  if (diagnostic.diagnostic_sha256 !== expected) throw new Error('remote_e2e_failure_hash_mismatch');
  return true;
}

export function validateRemoteE2EReceipt(receipt) {
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt)) throw new Error('remote_e2e_receipt_invalid');
  const exactKeys = [
    'schema_version', 'ok', 'task_count', 'completed_task_count', 'check_count', 'passed_check_count',
    'error_present', 'required_checks', 'receipt_algorithm', 'receipt_sha256',
  ];
  if (Object.keys(receipt).sort().join('\n') !== [...exactKeys].sort().join('\n')) throw new Error('remote_e2e_receipt_fields_invalid');
  if (receipt.schema_version !== '1.0.0' || receipt.ok !== true || receipt.error_present !== false) throw new Error('remote_e2e_receipt_status_invalid');
  if (!Number.isSafeInteger(receipt.task_count) || receipt.task_count < 5 || receipt.task_count > 64
    || receipt.completed_task_count !== receipt.task_count) throw new Error('remote_e2e_receipt_tasks_invalid');
  if (!Number.isSafeInteger(receipt.check_count) || receipt.check_count < 20 || receipt.check_count > 512
    || receipt.passed_check_count !== receipt.check_count) throw new Error('remote_e2e_receipt_checks_invalid');
  if (!Array.isArray(receipt.required_checks)
    || new Set(receipt.required_checks).size !== REMOTE_E2E_REQUIRED_CHECKS.length
    || receipt.required_checks.length !== REMOTE_E2E_REQUIRED_CHECKS.length
    || receipt.required_checks.some((name, index) => name !== REMOTE_E2E_REQUIRED_CHECKS[index])) {
    throw new Error('remote_e2e_receipt_required_checks_invalid');
  }
  if (receipt.receipt_algorithm !== 'sha256'
    || !/^[a-f0-9]{64}$/.test(String(receipt.receipt_sha256 || ''))
    || /^0{64}$/.test(receipt.receipt_sha256)) throw new Error('remote_e2e_receipt_hash_invalid');
  const canonical = {
    schema_version: receipt.schema_version,
    ok: receipt.ok,
    task_count: receipt.task_count,
    completed_task_count: receipt.completed_task_count,
    check_count: receipt.check_count,
    passed_check_count: receipt.passed_check_count,
    error_present: receipt.error_present,
    required_checks: [...receipt.required_checks],
  };
  const expected = createHash('sha256').update(JSON.stringify(canonical), 'utf8').digest('hex');
  if (receipt.receipt_sha256 !== expected) throw new Error('remote_e2e_receipt_hash_mismatch');
  return true;
}
