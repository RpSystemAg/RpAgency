#!/usr/bin/env python3
from __future__ import annotations
import json, hashlib, pathlib, re, datetime, collections

ROOT=pathlib.Path(__file__).resolve().parents[2]
WF=ROOT/'prstudio-unified-control/workflows'
DOCS=ROOT/'docs'
TODAY='2026-08-25'

caps=json.load(open(ROOT/'prstudio-unified-control/capabilities/capability-registry.json',encoding='utf-8'))['capabilities']
by_action={}
for c in caps:
    src=c.get('source') or {}
    if src.get('route') and src.get('action'):
        by_action[(src['route'],src['action'])]=c

def capability_phase(n,purpose,route,action,read_only=True,args=None,timeout=45,rollback='none'):
    c=by_action.get((route,action))
    if not c: raise KeyError((route,action))
    cid=c['id']
    tool_name=(c.get('source') or {}).get('tool_name') or ('rpconnector_'+route.strip('/').replace('-','_')+'_'+action.replace('-','_'))
    return {
      'id':f'p{n:02d}','phase_id':f'p{n:02d}','purpose':purpose,'executor_kind':'capability',
      'capability':cid,'tool_name':tool_name,'route':route,'action':action,'arguments':args or {},
      'read_only':bool(read_only),'mutation':not bool(read_only),'destructive':False,'checkpoint':'result_receipt',
      'timeout':{'seconds':timeout,'hard':True},'retry':{'policy':'transient_only','max_attempts':2,'backoff_seconds':[1,3]},
      'evidence_required':True,'success_condition':'terminal_status_with_evidence','failure_condition':'terminal_failure_or_unverified_effect',
      'compensation_or_rollback':rollback,
      'success':{'status':['completed','completed_verified','degraded'],'evidence_required':True},
      'failure':{'retry':'transient_only','max_attempts':2,'preserve_checkpoint':True}
    }

BROWSER_SEQS={
 'tab':[('/frontend-manage','playwright_status',1),('/frontend-manage','playwright_launch_chrome',1),('/frontend-manage','playwright_list_pages',1),('/frontend-manage','playwright_new_page',0),('/frontend-manage','playwright_locator_snapshot',1)],
 'observe':[('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_accessibility_snapshot',1),('/frontend-manage','playwright_screenshot_page',1),('/frontend-manage','playwright_page_errors',1)],
 'playwright':[('/frontend-manage','playwright_list_pages',1),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_network_idle_report',1),('/frontend-manage','playwright_console_report',1)],
 'cdp':[('/frontend-manage','playwright_start_trace',1),('/frontend-manage','playwright_cdp_send',1),('/frontend-manage','playwright_console_report',1),('/frontend-manage','playwright_stop_trace',1)],
 'lighthouse':[('/frontend-manage','playwright_lighthouse_audit',1),('/frontend-manage','playwright_core_web_vitals',1),('/frontend-manage','playwright_accessibility_scan',1),('/frontend-manage','playwright_screenshot_page',1)],
 'crawl':[('/frontend-manage','playwright_link_crawl',1),('/frontend-manage','playwright_sitemap_crawl',1),('/frontend-manage','playwright_network_idle_report',1),('/frontend-manage','playwright_locator_snapshot',1)],
 'research':[('/frontend-manage','playwright_new_page',0),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_screenshot_page',1),('/frontend-manage','playwright_console_report',1)],
}
GEN_SEQS={
 'logs':[('/logs-manage','list',1),('/logs-manage','search',1),('/logs-manage','read',1),('/logs-manage','verify',1)],
 'bugs':[('/logs-manage','search',1),('/plugins-manage','inspect_plugin_logs',1),('/files-manage','read',1),('/security-manage','verify',1)],
 'refactor':[('/files-manage','list',1),('/files-manage','read',1),('/files-manage','hash_tree',1),('/files-manage','compare_directories',1)],
 'files':[('/files-manage','list',1),('/files-manage','read',1),('/files-manage','hash',1),('/files-manage','audit_verify',1)],
 'security':[('/security-manage','audit',1),('/security-manage','check_file_integrity',1),('/security-manage','check_permissions',1),('/security-manage','verify',1)],
 'authorized_security':[('/security-manage','audit',1),('/security-manage','scan_malware',1),('/security-manage','audit_content_security_policy',1),('/security-manage','verify',1)],
 'content':[('/global-search','search_files',1),('/seo-manage','audit_rendered_html',1),('/files-manage','read',1),('/files-manage','hash',1)],
 'design':[('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_screenshot_page',1),('/frontend-manage','playwright_accessibility_scan',1),('/frontend-manage','playwright_responsive_matrix',1)],
 'commerce':[('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_screenshot_page',1),('/seo-manage','audit_product_seo',1),('/frontend-manage','playwright_core_web_vitals',1)],
 'agency':[('/global-search','search_files',1),('/files-manage','audit_start',1),('/files-manage','audit_status',1),('/files-manage','audit_verify',1)],
 'gutenberg':[('/plugins-manage','inspect_plugin_blocks',1),('/content-manage','validate_blocks',1),('/templates-manage','lint_template_blocks',1),('/themes-manage','inspect_theme_blocks',1),('/frontend-manage','playwright_accessibility_scan',1)],
 'html':[('/seo-manage','audit_rendered_html',1),('/frontend-manage','playwright_locator_snapshot',1),('/frontend-manage','playwright_accessibility_snapshot',1),('/frontend-manage','playwright_page_errors',1)],
 'javascript':[('/files-manage','list',1),('/files-manage','read',1),('/frontend-manage','playwright_console_report',1),('/frontend-manage','playwright_page_errors',1),('/frontend-manage','playwright_network_idle_report',1)],
 'java':[('/files-manage','list',1),('/files-manage','read',1),('/files-manage','hash_tree',1),('/security-manage','audit',1),('/files-manage','audit_verify',1)],
 'css':[('/global-search','search_styles',1),('/frontend-manage','computed_styles',1),('/frontend-manage','playwright_responsive_matrix',1),('/frontend-manage','playwright_accessibility_scan',1),('/frontend-manage','playwright_screenshot_page',1)],
}

def humanize(s): return re.sub(r'\s+',' ',s.replace('_',' ')).strip().title()

def contract(wid,wave,domain,objective,seqkey='agency',browser='none',risk='low',mode='durable',external=None,legal=None,triggers=None,negative=None,notes='',migrated_from=None):
    seq=BROWSER_SEQS.get(seqkey) or GEN_SEQS.get(seqkey) or GEN_SEQS['agency']
    phases=[]
    for i,(route,action,ro) in enumerate(seq,1): phases.append(capability_phase(i,f'{humanize(action)} — {objective}',route,action,bool(ro)))
    legal=legal or []
    ext=external or []
    permissions={'wordpress_capability':'manage_options' if risk in {'high','critical'} else 'edit_posts','authorization_required':True,'nonce_is_authorization':False,'scope':'workflow'}
    inp={'type':'object','additionalProperties':True,'properties':{
      'request_id':{'type':'string','minLength':8},'target':{'type':'string'},'url':{'type':'string'},'scope':{'type':['string','array','object']},
      'preview':{'type':'boolean','default':True},'verify':{'type':'boolean','default':True},'authorized_scope':{'type':'boolean','default':False},
      'constraints':{'type':'object','default':{}},'locale':{'type':'string','default':'it-IT'}},'required':[]}
    out={'type':'object','required':['ok','data','meta','warnings'],'properties':{'ok':{'type':'boolean'},'data':{'type':'object'},'meta':{'type':'object','required':['workflow_id','workflow_version','request_id','execution_id','status','started_at','finished_at','duration_ms']},'warnings':{'type':'array'}}}
    row={
      'id':wid,'version':'1.0.0','wave':wave,'domain':domain,'label':humanize(wid),'description':objective,
      'business_objective':objective,'triggers':triggers or [humanize(wid).lower(),objective.lower()[:120]],
      'intent_examples':[f'Esegui {humanize(wid).lower()} con evidenza verificabile.',f'Analizza e governa: {objective}.'],
      'negative_intent_examples':negative or ['Non dichiarare successo senza verifica.','Non aggirare permessi, access controls o ownership.'],
      'execution_mode':mode,'risk_class':risk,'browser_requirement':browser,'external_provider_requirements':ext,
      'input_schema':inp,'output_schema':out,'preconditions':['authenticated_contract','request_identity','authorized_scope_when_required'],
      'permissions':permissions,'data_classification':'internal_confidential','phases':phases,
      'decision_gates':[{'id':'scope_and_evidence_gate','condition':'scope_known_and_evidence_available','on_fail':'degraded_or_waiting_approval'}],
      'approval_gates':[{'id':'high_risk_gate','required':risk in {'high','critical'},'authority':'authorized_operator'}],
      'rollback':{'supported':False,'strategy':'read_only_or_provider_specific_compensation'},
      'verification':{'required':True,'objective_specific':True,'evidence':['receipt','postcondition','source_or_runtime_observation']},
      'measurement':{'execution_result':True,'verification_result':True,'business_outcome':'separate','measurement_pending_allowed':True},
      'failure_semantics':{'truthful':True,'no_fabrication':True,'preserve_root_cause':True,'statuses':['degraded','failed','blocked_permission','blocked_compliance','waiting_external']},
      'retry_policy':{'bounded':True,'transient_only':True,'max_attempts':2,'no_infinite_retry':True},
      'idempotency':{'required_for_mutation':True,'key':'request_id'},'audit_policy':{'enabled':True,'redact_secrets':True,'payload_reduced':True},
      'observability':{'trace':True,'metrics':['duration_ms','success','error','retry_count','verification_state'],'correlation_id':True},
      'rate_limit':{'enabled':True,'scope':['workflow','caller']},'retention':{'evidence':'policy_controlled','secrets':'never_log'},
      'i18n':{'enabled':True,'default_locale':'it-IT','wordpress_text_domain':'prstudio-unified-control'},
      'source_references':[],'legal_or_policy_constraints':legal,
      'completion_contract':{'completed_verified_only_if_postconditions':True,'execution_result_separate':True,'verification_result_separate':True,'business_outcome_separate':True},
      'notes':notes,
      'completion':{'requires_all_non_decision_phases_terminal':True,'accepts_degraded_evidence':True,'report_denominator_when_scoped':True},
      'enterprise_controls':{'checkpoint_each_phase':True,'durable_resume':True,'transient_retry_only':True,'redact_secrets':True,'bounded_execution':True,'traceable_receipts':True,'data_lineage':True}
    }
    if migrated_from is not None: row['migration']={'migrated_from_wave':migrated_from,'date':TODAY,'semantic_contract_changed':False}
    return row

# --- Wave 1: browser-first operating system, first 50 are tab opening/recovery procedures ---
first50=[
'open_single_owned_tab','open_multiple_owned_tabs','open_background_owned_tab','open_active_owned_tab','open_authenticated_site_tab','open_exact_url_tab','open_bare_host_tab','open_new_window_owned_tab','open_isolated_application_tab','open_cross_origin_research_tabs',
'list_owned_tabs','activate_owned_tab','verify_tab_url','verify_tab_ownership','verify_tab_lane','recover_technical_tab_not_controlled','recover_tab_lane_conflict','recover_target_origin_mismatch','recover_adoptable_tabs_not_found','recover_missing_browser_window',
'recover_offline_browser_agent','recover_stale_browser_device','recover_stale_lane_affinity','recover_orphaned_tab_registry','recover_interrupted_navigation','recover_about_blank_bootstrap','recover_tab_replacement','recover_service_worker_restart','recover_cdp_detach','recover_cdp_target_busy',
'recover_page_crash','recover_navigation_timeout','recover_network_timeout','recover_auth_challenge','recover_user_closed_tab','recover_duplicate_agent_tabs','recover_wrong_active_tab','recover_wrong_origin_tab','recover_stale_task_lease','recover_pending_browser_task',
'adopt_explicit_user_tab','adopt_multiple_user_tabs','release_adopted_user_tab','close_owned_tab_safely','close_multiple_owned_tabs','reopen_last_owned_tab','restore_previous_tab_affinity','reconcile_owned_tab_registry','clean_stale_tab_affinity','verify_browser_control_recovered']
assert len(first50)==50
wave1=[]
for i,name in enumerate(first50,1):
    wid=f'browser_control_{name}'
    objective=(f'Procedure {i:02d}/50: establish or recover explicit Browser Agent tab ownership and lane control for {humanize(name).lower()}; '
               'preserve the previous good tab, never fall back to an arbitrary user tab, retain the underlying technical error code, and verify the final tab URL/ownership before continuing.')
    wave1.append(contract(wid,1,'browser_tab_control',objective,'tab','required','medium','durable',triggers=[name.replace('_',' '),'apri tab browser','recupera controllo tab','technical_tab_not_controlled','tab_lane_conflict']))

categories={
 'browser_observation_screenshot':('observe',40,['capture_page_evidence','capture_element_evidence','capture_full_page_evidence','capture_viewport_evidence','capture_region_evidence','capture_mobile_evidence','capture_desktop_evidence','capture_before_after_evidence','capture_visual_baseline','compare_visual_baseline','inspect_dom_snapshot','inspect_accessibility_tree','inspect_semantic_targets','inspect_computed_styles','inspect_visible_text','inspect_rendered_state','inspect_iframe_state','inspect_dialog_state','inspect_download_state','inspect_upload_state','measure_screenshot_pixel_budget','redact_sensitive_screenshot','archive_screenshot_receipt','verify_screenshot_freshness','verify_screenshot_tab_identity','verify_screenshot_origin','verify_visual_change','detect_visual_regression','detect_dynamic_regions','mask_dynamic_regions','inspect_dark_mode','inspect_light_mode','inspect_reduced_motion','inspect_responsive_matrix','inspect_color_contrast','inspect_page_error_evidence','inspect_console_evidence','inspect_network_evidence','bundle_browser_observations','verify_observation_completeness']),
 'browser_playwright_automation':('playwright',50,['navigate_exact_url','reload_page','go_back','go_forward','wait_for_load','wait_for_url','wait_for_selector','find_semantic_target','click_semantic_target','double_click_target','hover_target','focus_target','blur_target','fill_field','type_text','press_key','select_option','check_control','uncheck_control','drag_and_drop','scroll_progressively','tap_target','upload_file','handle_dialog','set_viewport','emulate_device','set_locale','set_timezone','set_geolocation','set_color_scheme','set_reduced_motion','set_offline_mode','set_http_headers','set_user_agent','manage_cookies','manage_storage_state','route_network_request','mock_network_response','continue_network_request','abort_network_request','replay_har','record_video','record_har','record_trace','export_trace','generate_test','run_test','verify_dom_change','verify_pixel_change','run_form_smoke_test']),
 'browser_devtools_cdp':('cdp',40,['inspect_cdp_targets','send_safe_cdp_command','subscribe_cdp_event','inspect_network_domain','inspect_runtime_domain','inspect_dom_domain','inspect_page_domain','inspect_performance_domain','inspect_log_domain','inspect_security_domain','inspect_service_workers','trace_performance_timeline','trace_long_tasks','trace_layout_shifts','trace_network_waterfall','trace_cpu_profile','inspect_js_coverage','inspect_css_coverage','inspect_memory_pressure','inspect_resource_timing','inspect_navigation_timing','inspect_console_exceptions','inspect_unhandled_rejections','inspect_failed_requests','inspect_response_headers','inspect_security_headers','inspect_cors_behavior','inspect_cache_behavior','inspect_service_worker_cache','inspect_websocket_activity','inspect_third_party_requests','inspect_main_thread_work','inspect_layout_thrashing','inspect_dom_mutations','inspect_frame_tree','inspect_storage_quota','inspect_cookie_attributes','verify_cdp_session_ownership','recover_cdp_session','verify_cdp_trace_evidence']),
 'browser_lighthouse_performance':('lighthouse',30,['run_lighthouse_audit','audit_performance','audit_accessibility','audit_best_practices','audit_seo','measure_core_web_vitals','measure_lcp','measure_cls','measure_inp','measure_ttfb','measure_fcp','measure_speed_index','audit_javascript_cost','audit_css_cost','audit_image_cost','audit_font_loading','audit_third_party_cost','audit_render_blocking','audit_unused_javascript','audit_unused_css','audit_cache_policy','audit_compression','audit_mobile_performance','compare_performance_baseline','verify_performance_budget','diagnose_lighthouse_regression','archive_lighthouse_evidence','prioritize_lighthouse_fixes','verify_lighthouse_fix','produce_performance_scorecard']),
 'browser_scraping_crawl':('crawl',30,['crawl_rendered_links','crawl_same_origin','crawl_sitemap','crawl_pagination','crawl_category_tree','crawl_product_catalog','crawl_internal_links','crawl_external_links','crawl_redirect_chain','crawl_http_statuses','extract_structured_data','extract_metadata','extract_headings','extract_links','extract_tables','extract_product_facts','extract_search_results','extract_accessible_text','extract_visible_content','detect_duplicate_pages','detect_orphan_links','detect_broken_links','detect_soft_404','detect_canonical_conflicts','detect_noindex_conflicts','respect_robots_policy','respect_rate_limits','checkpoint_crawl','resume_crawl','verify_crawl_coverage']),
 'browser_tab_groups_sessions':('tab',20,['create_agent_tab_group','name_agent_tab_group','move_owned_tabs_to_group','list_agent_tab_groups','expand_agent_tab_group','collapse_agent_tab_group','restore_tab_group_layout','reconcile_group_membership','isolate_research_tab_group','isolate_admin_tab_group','isolate_test_tab_group','move_group_between_windows','preserve_group_on_restart','recover_missing_tab_group','recover_moved_tab_group','verify_group_ownership','close_group_safely','archive_group_session','restore_group_session','verify_group_recovery']),
 'browser_deep_research':('research',20,['plan_browser_research','open_research_source_set','collect_primary_sources','collect_authenticated_sources','collect_cross_engine_sources','capture_source_evidence','score_source_quality','check_source_freshness','detect_source_contradictions','track_research_unknowns','build_claim_evidence_map','verify_citation_support','verify_temporal_validity','compare_competitor_evidence','compare_market_evidence','analyze_time_bounded_authenticated_dashboard','research_analytics_evidence','synthesize_browser_evidence','produce_research_gap_ledger','verify_research_completion']),
 'browser_resilience_recovery':('tab',20,['detect_browser_degradation','diagnose_browser_queue','diagnose_browser_worker','diagnose_browser_storage','diagnose_browser_registry','diagnose_browser_lane','diagnose_browser_affinity','diagnose_browser_extension','diagnose_browser_permissions','diagnose_browser_dispatch','recover_browser_queue','recover_browser_worker','recover_browser_registry','recover_browser_storage','recover_browser_affinity','recover_browser_dispatch','replay_safe_read_operation','avoid_duplicate_mutation','verify_recovery_receipt','produce_browser_incident_report'])
}
for domain,(seqkey,count,names) in categories.items():
    assert len(names)==count,(domain,len(names),count)
    for name in names:
        wave1.append(contract(f'{domain}_{name}',1,domain,f'Execute enterprise browser procedure {humanize(name).lower()} with explicit tab identity, bounded retries and verifiable evidence.',seqkey,'required','medium','durable'))
# Wave 1 is deliberately provider-neutral: product-specific dashboards are consumers of the browser foundation.
assert len(wave1)==300

# --- Wave 2: merge both original waves into continuity wave, IDs unchanged ---
old=[]
for fn in ['enterprise-workflows-wave1-2026-08-24.json','enterprise-workflows-wave2-2026-08-24.json']:
    d=json.load(open(WF/fn,encoding='utf-8'))
    for w in d['workflows']:
        w=dict(w); oldwave=int(w.get('wave',d.get('wave',0))); w['wave']=2; w['migration']={'migrated_from_wave':oldwave,'date':TODAY,'semantic_contract_changed':False}; old.append(w)
assert len(old)==300 and len({w['id'] for w in old})==300
wave2=old

# --- Wave 3: 300 engineering workflows ---
eng_domains={
 'engineering_logs_observability':('logs',['collect','tail','search','filter','correlate','normalize','redact','classify','cluster','deduplicate','sample','timestamp_align','trace_request','trace_job','trace_browser_task','trace_wordpress_hook','trace_rest_call','trace_database_query','trace_external_call','detect_anomaly','detect_error_spike','detect_latency_spike','detect_retry_storm','detect_dead_letter_growth','detect_queue_backlog','detect_log_gap','detect_clock_skew','detect_missing_correlation','detect_secret_leak','detect_pii_leak','build_incident_timeline','build_correlation_graph','build_error_fingerprint','build_slo_view','build_error_budget_view','verify_log_rotation','verify_log_retention','verify_redaction','verify_audit_chain','verify_trace_completeness','recover_logging_pipeline','recover_missing_trace','recover_broken_correlation','archive_incident_logs','export_support_bundle','compare_pre_post_logs','measure_mttr_signals','prioritize_log_findings','produce_observability_scorecard','produce_incident_evidence_pack']),
 'engineering_bug_diagnostics':('bugs',['reproduce_bug','minimize_reproduction','classify_bug','triage_bug_severity','locate_fault_domain','trace_stack_failure','trace_async_failure','trace_race_condition','trace_state_corruption','trace_cache_bug','trace_database_bug','trace_rest_bug','trace_browser_bug','trace_extension_bug','trace_wordpress_bug','trace_plugin_conflict','trace_theme_conflict','trace_javascript_bug','trace_php_bug','trace_css_bug','trace_network_bug','trace_auth_bug','trace_permission_bug','trace_timeout_bug','trace_memory_bug','trace_performance_bug','trace_concurrency_bug','trace_idempotency_bug','trace_retry_bug','trace_serialization_bug','compare_good_bad_run','bisect_configuration_change','bisect_release_change','inspect_exception_chain','preserve_root_exception','map_exception_group_children','build_failure_tree','build_bug_hypotheses','rank_bug_hypotheses','validate_bug_hypothesis','design_regression_test','verify_bug_fix','verify_no_regression','verify_failure_semantics','verify_error_actionability','recover_failed_test_environment','archive_bug_evidence','produce_bug_report','produce_root_cause_analysis','produce_postmortem']),
 'engineering_refactor_quality':('refactor',['inventory_code_structure','map_module_dependencies','map_runtime_dependencies','detect_duplicate_logic','detect_dead_code','detect_large_functions','detect_high_complexity','detect_circular_dependency','detect_architecture_drift','detect_contract_drift','detect_naming_drift','detect_schema_drift','detect_test_gap','detect_error_handling_gap','detect_observability_gap','detect_security_smell','plan_safe_refactor','plan_module_split','plan_dependency_inversion','plan_interface_extraction','plan_state_machine_refactor','plan_async_refactor','plan_cache_refactor','plan_database_refactor','plan_browser_runtime_refactor','plan_mcp_contract_refactor','plan_test_refactor','plan_configuration_refactor','plan_logging_refactor','plan_security_refactor','estimate_refactor_risk','estimate_refactor_blast_radius','create_refactor_checkpoint','create_refactor_baseline','apply_small_safe_refactor','apply_mechanical_rename','apply_dead_code_cleanup','apply_duplicate_cleanup','apply_testability_refactor','verify_behavior_parity','verify_api_parity','verify_schema_parity','verify_performance_parity','verify_security_parity','verify_browser_parity','verify_wordpress_parity','compare_pre_post_hashes','prepare_refactor_pr','produce_refactor_report','govern_refactor_rollout']),
 'engineering_file_analysis':('files',['inventory_files','classify_files','detect_binary_files','detect_generated_files','detect_large_files','detect_duplicate_files','detect_orphan_files','detect_stale_files','detect_untracked_artifacts','detect_sensitive_files','detect_secret_material','detect_license_files','detect_manifest_drift','detect_integrity_drift','detect_line_ending_drift','detect_encoding_drift','detect_permission_drift','detect_ownership_drift','hash_file','hash_tree','compare_file_hashes','compare_directories','compare_release_trees','inspect_text_file','inspect_json_file','inspect_yaml_file','inspect_xml_file','inspect_csv_file','inspect_php_file','inspect_javascript_file','inspect_css_file','inspect_html_file','inspect_sql_file','inspect_log_file','inspect_archive_manifest','validate_json_schema','validate_manifest','validate_integrity_file','validate_build_info','validate_release_identity','trace_file_reference','trace_file_dependency','trace_generated_artifact','detect_broken_reference','detect_missing_reference','prepare_file_audit','export_file_inventory','archive_file_evidence','produce_file_diff_report','produce_file_risk_report']),
 'engineering_security_defensive':('security',['establish_authorized_scope','inventory_attack_surface','model_threats','assess_authentication','assess_authorization','assess_session_security','assess_input_validation','assess_output_encoding','assess_csrf_controls','assess_csp','assess_sri','assess_cors','assess_security_headers','assess_file_integrity','assess_file_permissions','assess_upload_security','assess_secret_storage','assess_log_redaction','assess_dependency_risk','assess_supply_chain','assess_rest_permissions','assess_wordpress_capabilities','assess_nonce_usage','assess_sql_safety','assess_remote_requests','assess_browser_permissions','assess_extension_permissions','assess_cdp_allowlist','assess_mcp_tool_surface','assess_rate_limits','assess_idempotency','assess_auditability','detect_malware','detect_credential_exposure','detect_suspicious_admins','detect_suspicious_sessions','detect_integrity_change','triage_vulnerability','prioritize_remediation','plan_hardening','verify_hardening','verify_security_fix','verify_no_secret_in_logs','verify_backup_recoverability','verify_incident_containment','build_security_evidence_pack','produce_security_scorecard','produce_threat_model','produce_remediation_backlog','govern_security_exception']),
 'engineering_authorized_security_research':('authorized_security',['confirm_written_authorization','define_test_boundary','define_safe_test_plan','map_exposed_surface','enumerate_public_routes','enumerate_authorized_endpoints','review_auth_flows','review_session_flows','review_access_controls','review_input_boundaries','review_upload_boundaries','review_api_boundaries','review_browser_boundaries','review_mcp_boundaries','review_wordpress_boundaries','review_dependency_boundaries','review_supply_chain_boundaries','review_configuration_exposure','review_error_disclosure','review_metadata_disclosure','analyze_sast_findings','analyze_dast_findings','analyze_codeql_findings','analyze_dependency_findings','analyze_secret_scanning_findings','analyze_csp_findings','analyze_cors_findings','analyze_auth_findings','analyze_session_findings','analyze_file_integrity_findings','reproduce_vulnerability_safely','validate_vulnerability_without_exploit','estimate_vulnerability_impact','estimate_exploitability_defensively','classify_cwe','classify_owasp_risk','prepare_responsible_disclosure','prepare_remediation_patch_plan','verify_remediation','verify_regression_test','verify_detection_rule','verify_monitoring_coverage','verify_rate_limit_control','verify_permission_control','verify_secret_rotation','verify_session_revocation','archive_authorized_test_evidence','produce_defensive_pentest_report','produce_security_retest_report','close_authorized_assessment'])
}
wave3=[]
for domain,(seqkey,names) in eng_domains.items():
    assert len(names)==50,(domain,len(names))
    for name in names:
        legal=['Defensive and explicitly authorized security assessment only. No unauthorized exploitation, persistence, credential theft, evasion, or destructive action.'] if 'security' in domain else []
        risk='high' if 'security' in domain else 'medium'
        wave3.append(contract(f'{domain}_{name}',3,domain,f'Enterprise engineering procedure to {humanize(name).lower()} with reproducible evidence and bounded change control.',seqkey,'optional',risk,'durable',legal=legal))
assert len(wave3)==300

# --- Wave 4 exact 380 ---
w4a_domains=['canva_creative_automation','motion_interactive_web','bing_webmaster_indexnow','geo_ai_search_visibility','serp_competitive_intelligence','analytics_data_science','organic_social','paid_media_creative_testing','video_shorts_youtube','local_seo_reputation','cro_experimentation','crm_lifecycle_retention','digital_pr_influencer_ugc','attribution_data_governance','agency_client_governance']
w4a_default=['audit_current_state','inventory_dependencies','benchmark_performance','detect_gaps','define_strategy','design_operating_model','plan_execution','execute_pilot','verify_output','measure_impact','govern_quality','produce_handover']
w4a_specific={
'canva_creative_automation':['apply_brand_templates','run_autofill','build_campaign_pack','localize_creative','convert_catalog_to_creative','export_multi_format','verify_brand_compliance','version_creative','update_dynamic_product_creative','route_approval','trace_asset_lineage','handoff_publishing'],
'motion_interactive_web':['audit_animation','design_microinteraction','design_scroll_storytelling','implement_view_transitions','implement_layout_animation','design_conversion_animation','govern_motion_tokens','enforce_performance_budget','measure_cls_inp_impact','enforce_reduced_motion','verify_mobile_motion','run_motion_regression'],
'bing_webmaster_indexnow':['inspect_bwt_health','audit_crawl_index_health','govern_sitemaps','find_keyword_page_opportunity','inspect_url_indexing','submit_indexnow','submit_indexnow_delta','recover_failed_submission','compare_google_bing_gaps','handoff_bing_ai_visibility','migrate_deprecated_api','measure_indexing_effect'],
'geo_ai_search_visibility':['measure_google_generative_visibility','measure_bing_ai_visibility','measure_citation_share','research_grounding_queries','map_intents_topics','verify_entity_consistency','detect_citation_source_gap','audit_content_retrievability','score_source_quality','assess_agentic_commerce_discoverability','measure_before_after','compare_ai_engines'],
'serp_competitive_intelligence':['capture_live_serp','inventory_serp_features','measure_serp_volatility','detect_intent_drift','analyze_competitor_gap','measure_image_video_local_presence','measure_ai_feature_presence','measure_brand_visibility','compare_product_results','map_result_ownership','attribute_serp_change','archive_serp_evidence'],
'analytics_data_science':['audit_ga4','audit_bigquery_export','analyze_funnel','analyze_cohorts','detect_anomalies','model_ltv','analyze_product_economics','map_search_to_revenue','measure_content_value','forecast_kpis','build_executive_intelligence','build_decision_support_model']}
wave4=[]
for domain in w4a_domains:
    names=w4a_specific.get(domain,w4a_default); assert len(names)==12
    for name in names: wave4.append(contract(f'{domain}_{name}',4,domain,f'Wave 4 global-agency procedure: {humanize(name).lower()} for {humanize(domain).lower()}.','agency','optional','medium','durable'))

w4b_domains=['github_engineering','github_security_supply_chain','cybersecurity_appsec','deep_research_evidence_intelligence','higgsfield_creative_ai','editorial_magazine','color_design_color_science','figma_design_systems','wordpress_vip_theme_engineering','wordpress_vip_plugin_engineering','humanizer_editorial_quality','mobbin_design_intelligence','shopify_enterprise','eu_import_operations','eu_export_operations','eu_digital_ecommerce_compliance','italy_digital_ecommerce_compliance','regulatory_evidence_governance']
w4b_specific={
'github_engineering':['assess_repository_health','orchestrate_issue_branch_pr','classify_pr_risk','orchestrate_review','manage_release_branch','assess_workflow_health','diagnose_actions','plan_repo_migration','govern_codeowners','produce_engineering_scorecard'],
'github_security_supply_chain':['review_dependencies','scan_secrets','verify_push_protection','run_codeql','govern_security_campaign','generate_sbom','attest_artifact','verify_provenance','enforce_license_policy','validate_agentic_autofix'],
'cybersecurity_appsec':['model_threats','run_authorized_sast','run_authorized_dast','harden_application','coordinate_incident_response','triage_vulnerability','investigate_credential_exposure','analyze_session_auth','assess_supply_chain_risk','verify_remediation'],
'deep_research_evidence_intelligence':['plan_research','select_sources','collect_web_file_connected_evidence','build_evidence_log','detect_contradictions','score_source_quality','verify_citation_completeness','verify_temporal_validity','analyze_research_gaps','produce_executive_synthesis'],
'higgsfield_creative_ai':['convert_brief_to_shot_plan','plan_cinema_studio','specify_camera_lens_focal','convert_still_to_motion','preserve_identity_consistency','design_first_last_frame','apply_motion_references','compare_models','orchestrate_canvas_graph','verify_production_acceptance'],
'editorial_magazine':['triage_editorial_pitch','manage_assignment','build_source_dossier','fact_check','verify_quotes','check_conflicts_of_interest','clear_image_rights','run_copy_desk','craft_headline_deck','govern_corrections_versioning'],
'color_design_color_science':['define_brand_palette','verify_contrast','measure_perceptual_difference','verify_accessibility','govern_color_spaces','govern_icc_profiles','verify_print_digital_parity','verify_dark_mode','synchronize_color_tokens','run_color_regression'],
'figma_design_systems':['inventory_files_folders','audit_variables','audit_collections_modes','synchronize_tokens','assess_library_health','map_components','verify_code_connect','verify_dev_mode','detect_webhook_drift','verify_design_to_code'],
'wordpress_vip_theme_engineering':['design_block_theme_architecture','govern_theme_json','verify_wp_coding_standards','verify_vipcs','verify_accessibility','run_theme_check','verify_theme_security','verify_query_asset_scale','verify_rendering_performance','verify_release_acceptance'],
'wordpress_vip_plugin_engineering':['review_plugin_architecture','verify_namespaces_autoload','verify_capability_auth','verify_nonce_semantics','verify_sanitization_escaping','verify_query_scale','verify_caching','verify_cron_queues','verify_rest_schema','verify_vip_release_readiness'],
'humanizer_editorial_quality':['remove_robotic_repetition','vary_language_cadence','remove_filler','remove_fake_certainty','remove_ai_cliches','adapt_vocabulary','verify_idiom_localization','preserve_factual_meaning','enforce_brand_voice','run_natural_language_qa'],
'mobbin_design_intelligence':['research_patterns','research_flows','compare_apps','cluster_patterns','benchmark_ux','build_evidence_board','enrich_design_brief','adapt_without_copying','verify_implementation','trace_pattern_provenance'],
'shopify_enterprise':['govern_markets','govern_channel_markets','govern_catalog_availability','govern_localization','govern_pricing_currency','verify_checkout_extensibility','verify_functions','verify_web_pixels','verify_extension_quality','verify_wordpress_woocommerce_interop'],
'eu_import_operations':['classify_movement_context','collect_product_evidence','collect_origin_evidence','collect_valuation_evidence','assess_vat_oss_ioss','assess_product_compliance','prepare_documents','validate_operator_data','route_customs_review','archive_import_evidence'],
'eu_export_operations':['classify_export_context','collect_product_evidence','collect_origin_evidence','collect_valuation_evidence','assess_vat_export_treatment','assess_destination_requirements','prepare_documents','validate_operator_data','route_customs_review','archive_export_evidence'],
'eu_digital_ecommerce_compliance':['assess_gdpr','assess_dsa','assess_consumer_rights','assess_gpsr','assess_eaa','assess_ai_act','assess_geo_blocking','assess_online_sales_information','assess_product_safety','assess_consent'],
'italy_digital_ecommerce_compliance':['assess_cookie_tracking','assess_profiling_consent','assess_ecommerce_information','assess_unfair_practices','assess_invoicing_vat','assess_italian_privacy','assess_italian_product_rules','assess_italian_accessibility','build_italian_evidence_pack','route_italian_legal_review'],
'regulatory_evidence_governance':['build_obligation_register','build_legal_source_register','track_effective_dates','map_jurisdictions','build_evidence_pack','manage_unresolved_questions','monitor_compliance_changes','assign_control_ownership','route_approval','preserve_audit_trail']}
for domain in w4b_domains:
    names=w4b_specific[domain]; assert len(names)==10
    legal=[]; risk='medium'; mode='durable'
    if domain=='cybersecurity_appsec': legal=['Defensive and authorized use only; no unauthorized exploitation.']; risk='high'
    if domain in {'eu_import_operations','eu_export_operations','eu_digital_ecommerce_compliance','italy_digital_ecommerce_compliance','regulatory_evidence_governance'}:
        legal=['Compliance-support only; materially consequential or uncertain classifications require qualified human review.','legal_review_required=true when uncertainty is material.']; risk='high'; mode='human_approval_required'
    if domain=='humanizer_editorial_quality': legal=['Editorial quality only; never evade AI detection, strip required provenance, or impersonate a real person.']
    if domain=='mobbin_design_intelligence': legal=['Authorized Mobbin access only; never scrape around access controls or clone competitor interfaces.']
    seq='security' if domain=='cybersecurity_appsec' else ('design' if domain in {'figma_design_systems','color_design_color_science','higgsfield_creative_ai','mobbin_design_intelligence'} else 'agency')
    for name in names: wave4.append(contract(f'{domain}_{name}',4,domain,f'Wave 4 specialist centre procedure: {humanize(name).lower()} for {humanize(domain).lower()}.',seq,'optional',risk,mode,legal=legal))
for domain in ['integrated_agency_delivery','global_risk_quality_governance']:
    names=['orchestrate_strategy_research','orchestrate_research_design','orchestrate_design_production','orchestrate_production_media','orchestrate_media_commerce','orchestrate_commerce_measurement','verify_cross_discipline_handoff','govern_approval_gates','govern_launch_rollback','archive_post_launch_evidence'] if domain=='integrated_agency_delivery' else ['gate_brand_risk','gate_legal_risk','gate_security_risk','gate_accessibility','gate_source_provenance','gate_ai_transparency','gate_launch_readiness','gate_rollback_readiness','verify_post_launch_controls','produce_global_risk_pack']
    for name in names: wave4.append(contract(f'{domain}_{name}',4,domain,f'Cross-domain agency control: {humanize(name).lower()}.','agency','optional','high' if domain.endswith('governance') else 'medium','durable'))
assert len(wave4)==380

# --- Wave 5 exact 600 ---
w5_domains=['global_strategy_market_intelligence','brand_architecture_portfolio','consumer_behavior_insights','product_service_innovation','martech_architecture','cdp_customer_data_operations','marketing_measurement_causal','media_mix_budget_science','loyalty_lifecycle_value','b2b_abm_sales_enablement','retail_media_marketplaces','agentic_commerce','internationalization_transcreation','accessibility_inclusive_experience','sustainability_green_claims','legal_regulatory_change_intelligence','privacy_consent_data_ethics','ai_governance_content_provenance','content_supply_chain_dam_pim','creative_operations_production','film_video_audio_podcast','community_social_care','creators_influencer_partnerships','reputation_crisis_communications','newsroom_pr_editorial_intelligence','global_commerce_merchandising','logistics_fulfillment_returns','revenue_margin_financial_assurance','agency_sow_sla_resource_profitability','workflow_intelligence_self_improvement']
w5_names=['observe_baseline','inventory_system','diagnose_gap','diagnose_risk','map_dependencies','model_scenarios','plan_roadmap','design_operating_model','prioritize_portfolio','execute_pilot','orchestrate_rollout','coordinate_market_adaptation','verify_controls','verify_outcomes','measure_kpis','measure_economics','detect_anomalies','learn_from_evidence','govern_exceptions','produce_executive_decision_pack']
wave5=[]
for domain in w5_domains:
    for name in w5_names:
        legal=[]; risk='medium'; mode='durable'
        if any(k in domain for k in ['legal_','privacy_','sustainability_']): legal=['Use current authoritative sources; unresolved high-consequence classifications require human review.']; risk='high'; mode='human_approval_required'
        if domain=='marketing_measurement_causal': legal+=['Do not claim causation from correlation; report uncertainty and design evidence.']
        if domain=='agentic_commerce': legal+=['Represent products factually and consistently to humans and AI shopping agents; do not manipulate or deceive agents.']
        if domain=='workflow_intelligence_self_improvement': legal+=['Production traces alone may not rewrite production workflow logic; replay, eval, negative tests, security review and human approval are required before promotion.']
        wave5.append(contract(f'{domain}_{name}',5,domain,f'Wave 5 agency operating system objective: {humanize(name).lower()} for {humanize(domain).lower()}, separating execution, verification and business outcome.', 'agency','optional',risk,mode,legal=legal))
assert len(wave5)==600

# --- Wave 6: exact 299 from attached consultant prompt ---
prompt2=pathlib.Path('/mnt/data/Pasted text (2).txt').read_text(encoding='utf-8')
groups={}
for group in ['social-image','commerce-image','ux-cro','exec-design','social-content','campaigns']:
    m=re.search(rf"### Gruppo capability: `{re.escape(group)}`[\s\S]*?\*\*Workflow \(\d+\):\*\* (.*?)(?:\n\n|\Z)",prompt2)
    if not m: raise RuntimeError('cannot parse '+group)
    names=[x.strip() for x in m.group(1).replace('\n',' ').split(',') if x.strip()]
    groups[group]=names
expected={'social-image':50,'commerce-image':50,'ux-cro':49,'exec-design':50,'social-content':50,'campaigns':50}
assert {k:len(v) for k,v in groups.items()}==expected,{k:len(v) for k,v in groups.items()}
wave6=[]
for group,names in groups.items():
    domain=group.replace('-','_')
    seq='design' if group in {'social-image','commerce-image','ux-cro','exec-design','social-content'} else 'agency'
    browser='optional' if group!='campaigns' else 'optional'
    for name in names:
        wave6.append(contract(f'{domain}_{name}',6,domain,f'Consulting/production workflow {humanize(name).lower()} in capability group {group}, preserving brand, permissions, audit, preview and verification requirements.',seq,browser,'medium','planner_assisted' if any(name.startswith(v) for v in ['design','create','build','fix','setup','retouch','remove','replace','add','generate']) else 'durable'))
assert len(wave6)==299

# --- Wave 7: exact 200 web-platform / Gutenberg engineering workflows ---
wave7_domains={
 'gutenberg_block_engineering':('gutenberg',[
  'inventory_registered_blocks','audit_block_metadata','validate_block_json','audit_block_api_version','audit_block_supports','audit_block_attributes','audit_block_context','audit_block_transforms','audit_block_variations','audit_block_patterns',
  'audit_block_bindings','audit_block_hooks','audit_dynamic_rendering','audit_static_serialization','detect_invalid_block_markup','repair_invalid_block_markup','normalize_block_markup','audit_deprecated_block_versions','plan_block_deprecation_migration','audit_interactivity_api',
  'audit_interactivity_directives','audit_interactivity_store','audit_interactivity_ssr_hydration','audit_client_navigation_compatibility','audit_script_modules','audit_editor_assets','audit_frontend_assets','audit_block_accessibility','audit_block_keyboard_navigation','audit_block_focus_management',
  'audit_block_responsive_behavior','audit_block_theme_json_integration','audit_global_styles_integration','audit_style_variations','audit_block_style_engine','audit_template_compatibility','audit_template_part_compatibility','audit_pattern_override_compatibility','audit_data_views_integration','audit_abilities_integration',
  'audit_react_compatibility','audit_block_performance','audit_block_bundle_size','audit_block_security','audit_block_permissions','verify_block_editor_parity','verify_block_frontend_parity','verify_block_migration','produce_block_engineering_scorecard','produce_gutenberg_release_readiness']),
 'html_web_platform':('html',[
  'audit_document_conformance','audit_semantic_structure','audit_heading_outline','audit_landmarks','audit_language_metadata','audit_metadata_head','audit_canonical_links','audit_resource_hints','audit_forms_semantics','audit_form_labels',
  'audit_form_validation','audit_autocomplete_tokens','audit_dialog_semantics','audit_details_summary','audit_table_semantics','audit_list_semantics','audit_media_semantics','audit_picture_sources','audit_lazy_loading','audit_custom_elements',
  'audit_declarative_shadow_dom','audit_aria_in_html','audit_focus_order','audit_tabindex_usage','audit_link_relations','audit_download_links','audit_embed_security','audit_iframe_sandbox','audit_content_security_boundaries','audit_structured_data_markup',
  'detect_invalid_nesting','detect_duplicate_ids','detect_obsolete_markup','detect_inline_event_handlers','audit_progressive_enhancement','audit_html_performance','verify_html_after_render','verify_html_accessibility','produce_html_conformance_report','produce_html_release_readiness']),
 'javascript_engineering':('javascript',[
  'inventory_module_graph','audit_esm_boundary','audit_import_attributes','audit_dynamic_imports','audit_top_level_await','audit_async_error_handling','audit_promise_lifecycles','audit_abort_signal_usage','audit_event_listener_lifecycle','audit_dom_mutation_patterns',
  'audit_web_worker_usage','audit_service_worker_usage','audit_storage_usage','audit_fetch_resilience','audit_websocket_lifecycle','audit_memory_leaks','audit_long_tasks','audit_main_thread_budget','audit_bundle_splitting','audit_tree_shaking',
  'audit_source_maps','audit_runtime_exceptions','audit_unhandled_rejections','audit_dependency_surface','audit_prototype_pollution_risk','audit_dom_xss_sinks','audit_safe_url_handling','audit_csp_compatibility','audit_module_integrity','audit_browser_compatibility',
  'audit_progressive_enhancement','audit_accessibility_interactions','audit_internationalization','audit_temporal_usage','audit_iterator_resource_cleanup','verify_javascript_after_build','verify_javascript_runtime','verify_javascript_performance','produce_javascript_quality_scorecard','produce_javascript_release_readiness']),
 'java_enterprise_engineering':('java',[
  'inventory_java_modules','audit_java_version_target','audit_jdk25_lts_baseline','audit_jdk26_compatibility','audit_module_descriptors','audit_package_boundaries','audit_records_usage','audit_sealed_hierarchies','audit_pattern_matching','audit_virtual_threads',
  'audit_structured_concurrency_preview','audit_scoped_values','audit_thread_local_usage','audit_executor_lifecycle','audit_synchronization','audit_deadlock_risk','audit_io_blocking','audit_http_client_usage','audit_serialization_risk','audit_deserialization_boundaries',
  'audit_reflection_usage','audit_jni_usage','audit_unsafe_usage','audit_crypto_usage','audit_tls_configuration','audit_dependency_manifest','audit_maven_structure','audit_gradle_structure','audit_test_architecture','audit_jfr_observability',
  'audit_gc_assumptions','audit_memory_configuration','plan_java_lts_migration','produce_java_architecture_scorecard','produce_java_release_readiness']),
 'css_architecture':('css',[
  'inventory_stylesheets','audit_cascade_layers','audit_specificity','audit_scope_rules','audit_nesting','audit_custom_properties','audit_design_tokens','audit_container_queries','audit_style_queries','audit_subgrid',
  'audit_grid_layout','audit_flex_layout','audit_logical_properties','audit_writing_modes','audit_color_spaces','audit_color_contrast','audit_relative_colors','audit_font_loading','audit_variable_fonts','audit_responsive_typography',
  'audit_view_transitions','audit_scroll_snap','audit_scroll_driven_animation','audit_reduced_motion','audit_forced_colors','audit_print_styles','audit_css_containment','audit_content_visibility','audit_css_coverage','audit_unused_css',
  'audit_render_blocking_css','audit_css_performance_budget','verify_css_visual_parity','produce_css_architecture_scorecard','produce_css_release_readiness'])
}
assert {k:len(v[1]) for k,v in wave7_domains.items()}=={'gutenberg_block_engineering':50,'html_web_platform':40,'javascript_engineering':40,'java_enterprise_engineering':35,'css_architecture':35}
wave7=[]
for domain,(seqkey,names) in wave7_domains.items():
    for name in names:
        legal=[]; risk='medium'; browser='optional'
        notes=''
        if domain=='java_enterprise_engineering':
            browser='none'; notes='Static repository/build-configuration analysis only unless an existing bounded compiler/test executor is explicitly available; never fabricate compilation or test success.'
        if name=='audit_structured_concurrency_preview':
            notes=(notes+' JDK Structured Concurrency is preview-sensitive at the 2026-08-25 cutoff; require explicit project opt-in and record the selected JDK release.').strip()
        if domain=='gutenberg_block_engineering':
            legal=['Target WordPress 7.1/Gutenberg behavior as of 2026-08-25; preserve backward compatibility and mark experimental/preview editor APIs explicitly.']
        wave7.append(contract(f'{domain}_{name}',7,domain,f'Wave 7 enterprise web engineering procedure: {humanize(name).lower()} for {humanize(domain).lower()} with source-grounded compatibility, security, accessibility, performance and release evidence.',seqkey,browser,risk,'durable',legal=legal,notes=notes))
assert len(wave7)==200

# global collisions
all_new=wave1+wave3+wave4+wave5+wave6+wave7
existing_ids={w['id'] for w in wave2}
new_ids=[w['id'] for w in all_new]
assert len(new_ids)==2079 and len(set(new_ids))==2079
assert not (set(new_ids)&existing_ids), sorted(set(new_ids)&existing_ids)[:10]
assert len(existing_ids)==300
assert len(existing_ids|set(new_ids))==2379

# source ids by domain family; assigned at workflow level after research register exists
source_map={
 'browser':['chrome_tabs','chrome_tabgroups','chrome_cdp','chrome_lighthouse','playwright_pages','playwright_tracing','openai_deep_research'],
 'github':['github_code_security'], 'wordpress':['wordpress_developer','wordpress_vip'], 'figma':['figma_developers'], 'shopify':['shopify_dev'],
 'eu':['eurlex_ai_act','eurlex_gpsr','eu_accessibility'], 'italy':['garante_cookie'], 'agency':['openai_agents','openai_deep_research'],
 'gutenberg':['wp71_field_guide','wp_interactivity_api','wp_block_editor'], 'html':['whatwg_html'], 'javascript':['tc39_ecma262'], 'java':['oracle_java_se26','openjdk_jdk25'], 'css':['w3c_css_snapshot_2025','w3c_css_nesting','w3c_css_containment']}
for w in all_new:
    d=w['domain']
    refs=[]
    if d.startswith('browser_'): refs=list(source_map['browser'])
    if d=='gutenberg_block_engineering': refs=source_map['gutenberg']
    elif d=='html_web_platform': refs=source_map['html']
    elif d=='javascript_engineering': refs=source_map['javascript']
    elif d=='java_enterprise_engineering': refs=source_map['java']
    elif d=='css_architecture': refs=source_map['css']
    elif 'github' in d: refs=source_map['github']
    elif 'wordpress' in d: refs=source_map['wordpress']
    elif 'figma' in d: refs=source_map['figma']
    elif 'shopify' in d: refs=source_map['shopify']
    elif d.startswith('eu_'): refs=source_map['eu']
    elif d.startswith('italy_'): refs=source_map['italy']
    else: refs=source_map['agency']
    w['source_references']=refs

# write documents deterministically with self hash

def write_wave(filename,wave,items,extra=None):
    domains=collections.Counter(w['domain'] for w in items)
    doc={'schema_version':'3.0.0','suite_version':'1.0.0','reference_date':TODAY,'wave':wave,'workflow_count':len(items),'phase_count':sum(len(w.get('phases',[])) for w in items),'domains':dict(sorted(domains.items())),'design_contract':{'canonical_internal_workflows':True,'compact_mcp_surface':True,'three_component_architecture_preserved':True,'completion_semantics':'execution != verification != business outcome'},'workflows':items}
    if extra: doc.update(extra)
    raw=json.dumps(doc,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(); doc['document_sha256']=hashlib.sha256(raw).hexdigest()
    (WF/filename).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return doc

d1=write_wave('enterprise-workflows-wave1-2026-08-25.json',1,wave1,{'purpose':'Browser automation, tab ownership and recovery foundation; first 50 are tab-control operating procedures.'})
d2=write_wave('enterprise-workflows-wave2-2026-08-25.json',2,wave2,{'purpose':'Continuity wave containing the original 300 workflows, preserving IDs and semantics while moving former Wave 1 into Wave 2.'})
d3=write_wave('enterprise-workflows-wave3-2026-08-25.json',3,wave3,{'purpose':'Engineering, logs, bugs, refactor, file analysis and defensive/authorized security.'})
d4=write_wave('wave4-enterprise-workflows-2026-08-25.json',4,wave4,{'assertions':{'W4_A':180,'W4_B':180,'W4_C':20,'total':380}})
d5=write_wave('wave5-enterprise-workflows-2026-08-25.json',5,wave5,{'assertions':{'domains':30,'per_domain':20,'total':600}})
d6=write_wave('enterprise-workflows-wave6-consulting-2026-08-25.json',6,wave6,{'capability_groups':expected,'purpose':'Exact 299-workflow consultant expansion from the attached prompt.'})
d7=write_wave('enterprise-workflows-wave7-web-engineering-2026-08-25.json',7,wave7,{'assertions':{'gutenberg_block_engineering':50,'html_web_platform':40,'javascript_engineering':40,'java_enterprise_engineering':35,'css_architecture':35,'total':200},'purpose':'Enterprise Gutenberg, HTML, JavaScript, Java and CSS engineering at the 2026-08-25 research cutoff.'})

all_items=wave1+wave2+wave3+wave4+wave5+wave6+wave7
index={'schema_version':'3.0.0','reference_date':TODAY,'workflow_count':len(all_items),'new_workflow_count':2079,'preexisting_workflow_count':300,'phase_count':sum(len(w.get('phases',[])) for w in all_items),'waves':{str(i):len(x) for i,x in [(1,wave1),(2,wave2),(3,wave3),(4,wave4),(5,wave5),(6,wave6),(7,wave7)]},'domains':dict(sorted(collections.Counter(w['domain'] for w in all_items).items())),'items':[{'id':w['id'],'wave':w['wave'],'domain':w['domain'],'label':w.get('label',''),'execution_mode':w.get('execution_mode','durable'),'risk_class':w.get('risk_class',''),'browser_requirement':w.get('browser_requirement','none'),'phase_count':len(w.get('phases',[]))} for w in all_items]}
(WF/'enterprise-workflows-index-2026-08-25.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Inventory before requested expansion (source of truth)
inv={'generated_at':TODAY,'source':'uploaded suite before 2026-08-25 expansion','existing_workflow_count':300,'existing_workflow_ids':sorted(existing_ids),'existing_capability_count':len(caps),'existing_public_mcp_tool_count':123,'existing_domains':sorted({w.get('domain','') for w in wave2}),'existing_routes':sorted({(c.get('source') or {}).get('route','') for c in caps if (c.get('source') or {}).get('route')}),'existing_direct_tools':'see class-prstudio-uc-mcp-v5.php','existing_native_capabilities':sum(1 for c in caps if not str(c.get('id','')).startswith('legacy.'))}
(ROOT/'build').mkdir(exist_ok=True)
(ROOT/'build/workflow-inventory-before-wave4-wave5.json').write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n')

# concise gap matrix and docs
DOCS.mkdir(exist_ok=True)
(DOCS/'WAVE4-WAVE5-GAP-MATRIX-2026-08-25.md').write_text(f'''# Wave 4–5 Gap Matrix — {TODAY}\n\nBaseline: 300 canonical workflows. New foundation Wave 1 adds 300 browser-specialist workflows; original Wave 1/2 are consolidated into continuity Wave 2; Wave 3 adds 300 engineering workflows. Wave 4 adds exactly 380 and Wave 5 exactly 600. The attached 299-workflow consultant expansion is isolated as Wave 6 so the Wave 4/5 non-negotiable counts remain exact.\n\n| Area | Baseline gap | Implemented response |\n|---|---|---|\n| Browser control | Ownership recovery was procedural rather than canonical | 300 Wave-1 workflows; first 50 dedicated to opening/recovery |\n| Engineering | Logs/bugs/refactor/files/security fragmented | 300 Wave-3 workflows |\n| Global agency specialist breadth | Missing required specialist COEs | Wave 4 = 380 |\n| Agency operating system | Missing compositional strategic layer | Wave 5 = 600 |\n| Consultant production groups | 299 requested capabilities absent | Wave 6 = 299 |
| Gutenberg/Web engineering | Missing dedicated Gutenberg/HTML/JS/Java/CSS enterprise procedures | Wave 7 = 200 |\n\nWave 7 adds 200 source-grounded Gutenberg/HTML/JavaScript/Java/CSS workflows.

Foundation total through Wave 7: **2379**. Final cumulative registry after Wave 8 + Wave 9: **10000** workflows.\n''',encoding='utf-8')

# generic wave docs
def doc_wave(path,title,items):
    lines=[f'# {title}', '', f'Reference date: {TODAY}. Canonical workflows: **{len(items)}**.', '', '| ID | Domain | Mode | Browser | Risk | Purpose |','|---|---|---|---|---|---|']
    for w in items: lines.append(f"| `{w['id']}` | `{w['domain']}` | `{w['execution_mode']}` | `{w['browser_requirement']}` | `{w['risk_class']}` | {w['business_objective'].replace('|','/')} |")
    pathlib.Path(path).write_text('\n'.join(lines)+'\n',encoding='utf-8')
doc_wave(DOCS/'WAVE1-BROWSER-ENTERPRISE-WORKFLOWS-2026-08-25.md','Wave 1 — Browser Enterprise Workflows',wave1)
doc_wave(DOCS/'WAVE3-ENGINEERING-ENTERPRISE-WORKFLOWS-2026-08-25.md','Wave 3 — Engineering Enterprise Workflows',wave3)
doc_wave(DOCS/'WAVE4-ENTERPRISE-WORKFLOWS-2026-08-25.md','Wave 4 — Enterprise Workflows',wave4)
doc_wave(DOCS/'WAVE5-ENTERPRISE-WORKFLOWS-2026-08-25.md','Wave 5 — Agency Operating System',wave5)
doc_wave(DOCS/'WAVE6-CONSULTING-WORKFLOWS-2026-08-25.md','Wave 6 — Consultant Expansion',wave6)
doc_wave(DOCS/'WAVE7-WEB-ENGINEERING-WORKFLOWS-2026-08-25.md','Wave 7 — Gutenberg / HTML / JavaScript / Java / CSS Enterprise Engineering',wave7)

(DOCS/'WAVE4-WAVE5-ENTERPRISE-ARCHITECTURE.md').write_text('''# Wave 4–5 Enterprise Architecture\n\nThe suite remains a three-component system: principal orchestration/workflow registry, BrowserKing-derived browser executor, and WordPress control plane. New workflows are internal canonical procedures routed through the existing compact workflow surface; they do not become thousands of top-level MCP tools.\n\nExecution success, verification success and business outcome remain separate states. All retries are bounded, mutations require authorization/idempotency, and high-consequence legal/security decisions require human review.\n''')
(DOCS/'WAVE4-WAVE5-ROUTING-GUIDE.md').write_text('''# Wave 4–5 Routing Guide\n\nRoute direct primitive requests to existing typed tools/capabilities; route known multi-step objectives to canonical workflows; route strategic cross-domain objectives to Wave-5 workflows. Search metadata includes domain, risk, browser requirement, execution mode and workflow version.\n''')
(DOCS/'WAVE4-WAVE5-SECURITY-AND-COMPLIANCE.md').write_text('''# Wave 4–5 Security and Compliance\n\nSecurity workflows are defensive and authorized only. No workflow permits unauthorized exploitation. Legal/tax/customs workflows are evidence and decision-support systems; unresolved material classifications set a human-review gate. Secrets are excluded from workflow definitions and logs.\n''')
(DOCS/'WAVE4-WAVE5-MIGRATION.md').write_text('''# Wave Migration\n\nOn 2026-08-25 the former Wave 1 and Wave 2 corpus (300 IDs total) is consolidated into continuity Wave 2 without renaming workflow IDs or changing their execution semantics. The new Wave 1 is a 300-workflow browser-control foundation. Wave 3 is engineering/reliability/security. Wave 4 and Wave 5 retain the exact 380/600 counts required by the master prompt. The separate 299-workflow consultant prompt is Wave 6. Wave 7 adds exactly 200 Gutenberg/HTML/JavaScript/Java/CSS enterprise workflows grounded to the 2026-08-25 research cutoff.\n''')
(DOCS/'WAVE4-WAVE5-OPERATIONS-RUNBOOK.md').write_text('''# Wave 4–5 Operations Runbook\n\n1. Inventory registry and verify manifest counts. 2. Search/describe before execution. 3. Confirm permissions and high-risk gates. 4. Execute bounded phases with request/correlation IDs. 5. Preserve the root technical error and nested cause. 6. Verify objective-specific postconditions. 7. Record execution/verification/business-outcome separately. 8. For browser failures, retain the owned lane, inspect tab registry/affinity, and never use an arbitrary user tab as fallback.\n''')

print(json.dumps({'wave1':len(wave1),'wave2':len(wave2),'wave3':len(wave3),'wave4':len(wave4),'wave5':len(wave5),'wave6':len(wave6),'wave7':len(wave7),'total':len(all_items),'new':len(all_new)},indent=2))

# Chain the foundation generator into the authoritative cumulative 10,000-workflow registry.
import subprocess, sys
_cumulative = ROOT/'.github/scripts/generate-cumulative-workflows-10000-2026-08-25.py'
if not _cumulative.is_file():
    raise SystemExit('missing cumulative 10,000-workflow generator')
subprocess.run([sys.executable, str(_cumulative)], cwd=ROOT, check=True)
