import { resolve } from 'node:path';
import {
  BROWSER_PARITY_REQUIRED_CHECKS,
  readBoundedJsonArtifact,
  sanitizeLogValue,
} from './security-artifact-boundaries.mjs';

const { value: report } = await readBoundedJsonArtifact(
  resolve('artifacts/browser-parity'),
  'browser-parity-live-probe.json',
);
const byName = new Map((report.checks || []).map((row) => [row.name, row]));
const missing = BROWSER_PARITY_REQUIRED_CHECKS.filter((name) => !byName.get(name)?.ok);
if (report.ok !== true || missing.length) {
  throw new Error(`browser_parity_evidence_failed: report_ok=${report.ok === true} missing_or_failed=${sanitizeLogValue(missing.join(','), 2000)}`);
}
console.log(`PASS Browser parity evidence: ${BROWSER_PARITY_REQUIRED_CHECKS.length}/${BROWSER_PARITY_REQUIRED_CHECKS.length} critical live checks green; source_sha256=${sanitizeLogValue(report.source_sha256, 64)}`);
