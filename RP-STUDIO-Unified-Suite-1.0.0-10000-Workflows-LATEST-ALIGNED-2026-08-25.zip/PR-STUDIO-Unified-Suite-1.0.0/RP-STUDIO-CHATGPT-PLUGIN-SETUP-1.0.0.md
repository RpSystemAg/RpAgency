
# Setup RP Studio Connector 1.0.0

## Aggiornamento invariato

Carica `prstudio-unified-control-1.0.0.zip` come normale aggiornamento plugin WordPress. Il pacchetto deve aprirsi nella cartella `prstudio-unified-control` con bootstrap `prstudio-unified-control.php`.

Per aggiornare il Browser Agent, **non caricare una nuova estensione e non cambiare cartella**: estrai `prstudio-unified-browser-agent-1.0.0.zip`, sostituisci i file dentro la stessa cartella unpacked `prstudio-unified-browser-agent` già caricata e premi **Ricarica** in `chrome://extensions`. `prstudioConfig` e pairing restano invariati e l'upgrade normale non richiede nuovo pairing. La 1.0.0 usa `system.display` per le trasformazioni screenshot↔CSS↔screen; non espone Browser LIVE, streaming, viewer, `tabCapture` o documenti offscreen. Il pairing resta `/wp-json/prstudio-unified/v1/pair`; wire protocol 3.0.0, rolling acceptance 4.0.0.

## ChatGPT

In ChatGPT **Developer mode**, crea o aggiorna il connettore chiamato **RP Studio Connector** usando:

`https://example.com/wp-json/prstudio-unified/v1/mcp`

L'autenticazione resta OAuth 2.1 Authorization Code + PKCE S256. Un aggiornamento non deve eliminare `prstudio_mcp_v5_clients`, `prstudio_mcp_v5_tokens` o `prstudio_mcp_v5_generation`.

Prima del refresh in ChatGPT, verifica initialize, tools/list e una lettura con **MCP Inspector**. Prova poi una mutazione browser senza `lane_handle`: il server deve creare/recuperare automaticamente la lane, restituire l'handle pubblico e mantenere segreto il token interno. Verifica anche heartbeat/close sull'handle restituito.

### Verifica catalogo workflow dopo Scan Tools

La release corrente espone **123 tool MCP pubblici** e mantiene **10,000 workflow canonici** server-side (Waves 1–9, **40,715 fasi**, **178 domini**). Dopo `tools/list`, verifica che `prstudio_workflow` sia presente e dichiari `search`, `catalog`, `describe`, `validate`, `run`, `wave` 1–9, `limit` massimo 100 e paginazione via `offset`. Non aspettarti 10,000 tool distinti: la completezza è data dalla raggiungibilità lossless del catalogo interno tramite quel gateway.

## Accettazione

Esegui upgrade su staging con backup, pairing/restart Chrome, OAuth reale, e la matrice visuale home/shop/prodotto/cart/checkout/account a 360×800, 430×932, 768×1024, 1440×1000 e 1920×1080. Non cambiare il tema senza baseline reali prima/dopo.

## Refresh MCP dopo modifiche a tool/schema

Le modifiche al repository o ai JSON non implicano che una chat già aperta stia usando i metadata nuovi. La documentazione ufficiale OpenAI per le app MCP indica che la configurazione usa **Scan Tools** e, per le app approvate in workspace, ChatGPT usa uno snapshot congelato di tool e input finché un admin non aggiorna/pubblica la revisione.

Runbook dopo ogni modifica a nomi, descrizioni, input schema, output schema, annotazioni o auth:

1. deploy/restart del server MCP aggiornato;
2. esegui MCP Inspector su `initialize` e `tools/list`;
3. in ChatGPT usa **Scan Tools** per una app dev oppure **Refresh actions / review + publish** per una app workspace approvata;
4. controlla il diff dei metadata e che il conteggio/tool names corrispondano a questo artifact;
5. apri una **nuova conversazione** per il test di regressione, così non confondi stato conversazionale e snapshot precedente;
6. esegui i golden prompt di `quality/first-tool-routing-cases.json` e registra `first_correct_tool_rate` e `calls_to_success`.

Riferimenti ufficiali verificati il 24/08/2026:

- https://help.openai.com/en/articles/12584461-developer-mode-and-full-mcp-connectors-in-chatgpt
- https://developers.openai.com/api/docs/guides/latest-model
- https://developers.openai.com/api/reference/resources/responses/methods/create
