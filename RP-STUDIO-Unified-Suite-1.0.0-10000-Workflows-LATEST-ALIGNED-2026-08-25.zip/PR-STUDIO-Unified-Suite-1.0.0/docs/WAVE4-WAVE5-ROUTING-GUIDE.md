# Wave 4–5 Routing Guide

Route direct primitive requests to existing typed tools/capabilities; route known multi-step objectives to canonical workflows; route strategic cross-domain objectives to Wave-5 workflows. Search metadata includes domain, risk, browser requirement, execution mode and workflow version.
