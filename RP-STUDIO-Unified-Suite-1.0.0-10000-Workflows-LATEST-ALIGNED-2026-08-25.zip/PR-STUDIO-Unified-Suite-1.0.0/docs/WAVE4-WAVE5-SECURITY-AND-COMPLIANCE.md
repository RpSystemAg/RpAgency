# Wave 4–5 Security and Compliance

Security workflows are defensive and authorized only. No workflow permits unauthorized exploitation. Legal/tax/customs workflows are evidence and decision-support systems; unresolved material classifications set a human-review gate. Secrets are excluded from workflow definitions and logs.
