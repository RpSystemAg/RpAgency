# RP STUDIO — Release Documentation Alignment

Reference date: 2026-08-25. This file records the authoritative current-state numbers used by release documentation and tests.

| Surface | Authoritative value |
|---|---:|
| Canonical workflows | 10,000 |
| Grounded workflow phases | 40,715 |
| Workflow domains | 178 |
| Waves | 1–9 |
| Wave counts | 300 / 300 / 300 / 380 / 600 / 299 / 200 / 299 / 7,322 |
| Public MCP tools | 123 |
| Canonical capabilities | 1,364 |
| Legacy actions | 1,076 |
| Workflow gateway | `prstudio_workflow` |
| Gateway operations | `search`, `catalog`, `describe`, `validate`, `run` |
| Catalog page maximum | 100 |

Historical references to **2,379** are valid only when explicitly labelled as the Wave-1-through-Wave-7 foundation. They are not the current canonical total. ChatGPT sees the bounded MCP tool surface and discovers/runs the 10,000 internal workflows through `prstudio_workflow`; it does not receive 10,000 top-level tool definitions.
