# PR STUDIO — 300 Enterprise Workflows

**Reference date:** 2026-08-24  
**Suite:** 1.0.0  
**Canonical workflows:** 300  
**Grounded phases:** 1665  

## Architecture

The 300 workflows are an **internal orchestration catalog**, not 300 new public MCP tools. The public entry point is `prstudio_workflow`, which supports `search`, `describe`, `catalog`, `validate`, and `run`. Known procedures are orchestrated in code; planner-assisted workflows stop at an evidence decision gate when multiple site-specific mutations are plausible.

Each phase is grounded either in an existing capability from `capability-registry.json` or in an existing typed MCP tool. Mutation safety stays under the suite anti-crash/auth/schema/idempotency contracts. Every workflow carries bounded retries, phase receipts, evidence requirements, state continuity metadata and no-false-completion semantics.

## Wave structure

| Wave | Workflows | Phases | Focus |
|---|---:|---:|---|
| 1 | 150 | 765 | Horizontal operational workflows across browser, SEO, commerce, orders, media, UX, extensions, ops, data, security |
| 2 | 150 | 900 | Cross-session continuity, state-machine recovery, drift detection, reconciliation, governance, lineage, rollback evidence |
| **Total** | **300** | **1665** | |

## Incident-specific enterprise workflow

`seo_autopilot_state_convergence_enterprise` is dedicated to the persistent SEO rotation failure discovered on the live suite. It treats SEO Autopilot campaign state as the source of truth and the interventions ledger as historical evidence. It performs state read → reconciliation/convergence → state read → eligible claim, and explicitly forbids direct SQL completion of campaign rows.

The server-side Autopilot implementation now understands both `seo_autopilot_pass` and historical `seo_rotation_cooldown`. Historical work can be backfilled only when the product has not changed since the intervention and current acceptance requirements are provable from server-side evidence. Requirements needing live Rank Math/editor/report evidence are never fabricated. Historical cooldowns default to 120 days and reopen after expiry; proper Autopilot completions remain fingerprint-driven.

## 2026 enterprise design basis

- **OpenAI Agents SDK:** code orchestration for known flows, model/planner reasoning only for ambiguous decisions; tracing spans and tool-level guardrails shape receipts and phase checks.
- **Chrome Extensions / CDP:** explicit tab identity, MV3 service-worker state persistence, owned-session recovery and evidence-bound browser operations.
- **Google Search Console:** bounded/paginated Search Analytics semantics; preserve freshness/data-state semantics rather than inventing completeness.
- **WooCommerce HPOS:** orders and commerce workflows use WooCommerce CRUD/API authority rather than assuming `posts/postmeta` is authoritative.
- **Action Scheduler:** queue work is treated as claimed, traceable, bounded work; no uncontrolled concurrency escalation.
- **WordPress Security:** nonces are not authorization; server capability checks remain authoritative.
- **WCAG 2.2:** UX/accessibility workflows include current focus, target-size and accessible interaction expectations.
- **OWASP ASVS 5.0.0:** security/identity workflows use verifiable control, evidence and least-privilege patterns.

Official references:

- https://openai.github.io/openai-agents-python/multi_agent/
- https://openai.github.io/openai-agents-python/tracing/
- https://openai.github.io/openai-agents-python/guardrails/
- https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle
- https://developer.chrome.com/docs/extensions/reference/api/debugger
- https://developer.chrome.com/docs/extensions/reference/api/tabs
- https://developers.google.com/webmaster-tools/v1/searchanalytics/query
- https://developer.woocommerce.com/docs/features/orders/high-performance-order-storage/recipe-book/
- https://actionscheduler.org/
- https://developer.wordpress.org/apis/security/nonces/
- https://www.w3.org/TR/WCAG22/
- https://owasp.org/www-project-application-security-verification-standard/

## Wave 2 — 150 new workflows

### `browser`

- `browser_stateful_property_handoff` — Handoff proprietà/browser autenticata (durable, 6 phases)
- `browser_spa_state_drift` — Diagnosi drift stato SPA (durable, 6 phases)
- `browser_consent_state_validation` — Validazione consent/cookie state (durable, 6 phases)
- `browser_service_worker_recovery` — Recovery service worker/cache (durable, 6 phases)
- `browser_authenticated_export` — Export autenticato verificato (durable, 6 phases)
- `browser_upload_transaction` — Upload browser verificato (durable, 6 phases)
- `browser_multitab_consistency` — Consistenza multi-tab (durable, 6 phases)
- `browser_redirect_chain_verify` — Verifica catena redirect browser (durable, 6 phases)
- `browser_js_hydration_drift` — Hydration drift JS (durable, 6 phases)
- `browser_checkout_payment_ui_probe` — Probe UI pagamento checkout (durable, 6 phases)
- `browser_print_pdf_evidence` — Evidenza print/PDF (durable, 6 phases)
- `browser_crash_replay` — Replay dopo crash browser (durable, 6 phases)
- `browser_live_url_acceptance` — Acceptance URL live (durable, 6 phases)
- `browser_dom_network_parity` — Parità DOM/rete (durable, 6 phases)
- `browser_evidence_chain` — Catena evidenze browser (durable, 6 phases)

### `catalog_commerce`

- `commerce_catalog_delta_governance` — Governance delta catalogo (durable, 6 phases)
- `commerce_sku_gtin_integrity` — Integrità SKU/GTIN (durable, 6 phases)
- `commerce_supplier_data_reconcile` — Riconcilia dati fornitore (durable, 6 phases)
- `commerce_price_anomaly_triage` — Triage anomalie prezzo (durable, 6 phases)
- `commerce_stock_drift_detection` — Rileva drift stock (durable, 6 phases)
- `commerce_variation_orphan_recovery` — Recovery variazioni orfane (durable, 6 phases)
- `commerce_discontinued_product_migration` — Migrazione prodotto dismesso (planner_assisted, 6 phases)
- `commerce_brand_entity_reconcile` — Riconcilia entità brand (durable, 6 phases)
- `commerce_media_coverage_gap` — Gap copertura media catalogo (durable, 6 phases)
- `commerce_duplicate_product_resolution` — Risoluzione prodotti duplicati (durable, 6 phases)
- `commerce_feed_rejection_recovery` — Recovery rifiuti feed (durable, 6 phases)
- `commerce_merchant_listing_readiness` — Readiness merchant listing (durable, 6 phases)
- `commerce_shipping_tax_consistency` — Consistenza shipping/tax (durable, 6 phases)
- `commerce_bundle_integrity` — Integrità bundle/kit (durable, 6 phases)
- `commerce_catalog_rollback_proof` — Prova rollback catalogo (planner_assisted, 6 phases)

### `content_seo`

- `seo_autopilot_state_convergence_enterprise` — SEO Autopilot state convergence enterprise (durable, 6 phases)
- `seo_campaign_historical_backfill` — Backfill storico campagna SEO (durable, 6 phases)
- `seo_campaign_stale_claim_recovery` — Recovery claim SEO scaduti (durable, 6 phases)
- `seo_fingerprint_drift_reconcile` — Riconcilia fingerprint SEO (durable, 6 phases)
- `seo_rotation_governance` — Governance rotazione prodotti SEO (durable, 6 phases)
- `seo_query_url_ownership` — Ownership query→URL (durable, 6 phases)
- `seo_refresh_measurement_loop` — Loop misurazione post-refresh (durable, 6 phases)
- `seo_redirect_canonical_convergence` — Convergenza redirect/canonical (durable, 6 phases)
- `seo_gsc_blindspot_recovery` — Recovery blind spot GSC (durable, 6 phases)
- `seo_sitemap_delta_governance` — Governance delta sitemap (durable, 6 phases)
- `seo_schema_drift_monitor` — Monitor drift schema (durable, 6 phases)
- `seo_media_entity_alignment` — Allineamento media-entità SEO (durable, 6 phases)
- `seo_cannibalization_decision_ledger` — Ledger decisioni cannibalizzazione (durable, 6 phases)
- `seo_release_no_regression` — SEO release no-regression (durable, 6 phases)
- `seo_catalog_coverage_rotation` — Copertura rotativa catalogo SEO (durable, 6 phases)

### `data_storage`

- `data_serialized_migration_safety` — Safety migrazione serialized (planner_assisted, 6 phases)
- `data_orphan_row_cleanup` — Pulizia righe orfane (planner_assisted, 6 phases)
- `data_postmeta_bloat` — Bloat postmeta (durable, 6 phases)
- `data_transient_hygiene` — Igiene transient (durable, 6 phases)
- `data_action_scheduler_storage` — Storage Action Scheduler (durable, 6 phases)
- `data_schema_drift_detection` — Rileva schema drift (durable, 6 phases)
- `data_restore_diff_acceptance` — Acceptance diff restore (durable, 6 phases)
- `data_file_manifest_drift` — Drift manifest file (durable, 6 phases)
- `data_upload_db_parity` — Parità upload DB/files (durable, 6 phases)
- `data_autoload_budget` — Budget autoload options (durable, 6 phases)
- `data_index_efficiency` — Efficienza indici DB (durable, 6 phases)
- `data_backup_chain_integrity` — Integrità catena backup (durable, 6 phases)
- `data_migration_rollback_proof` — Prova rollback migration (planner_assisted, 6 phases)
- `data_table_engine_consistency` — Consistenza engine tabelle (durable, 6 phases)
- `data_storage_capacity_forecast` — Forecast capacità storage (durable, 6 phases)

### `experience_ui`

- `ux_search_zero_results` — UX zero-results ricerca (planner_assisted, 6 phases)
- `ux_filter_state_persistence` — Persistenza filtri UX (planner_assisted, 6 phases)
- `ux_pagination_infinite_scroll` — Pagination/infinite scroll QA (planner_assisted, 6 phases)
- `ux_focus_order_keyboard` — Focus order tastiera (planner_assisted, 6 phases)
- `ux_modal_focus_trap` — Focus trap modali (planner_assisted, 6 phases)
- `ux_color_contrast_regression` — Regressione contrasto (planner_assisted, 6 phases)
- `ux_sticky_header_collision` — Collisione sticky header (planner_assisted, 6 phases)
- `ux_variant_selection_flow` — Flusso selezione variazioni (planner_assisted, 6 phases)
- `ux_price_stock_clarity` — Chiarezza prezzo/stock (planner_assisted, 6 phases)
- `ux_cookie_banner_interference` — Interferenza cookie banner (planner_assisted, 6 phases)
- `ux_localization_layout` — Layout localizzazione (planner_assisted, 6 phases)
- `ux_empty_state_quality` — Qualità empty state (planner_assisted, 6 phases)
- `ux_design_token_regression` — Regressione design token (planner_assisted, 6 phases)
- `ux_checkout_error_recovery` — Recovery errori checkout (planner_assisted, 6 phases)
- `ux_cross_browser_acceptance` — Acceptance cross-browser (planner_assisted, 6 phases)

### `extensions_themes`

- `extensions_dependency_graph_upgrade` — Upgrade dependency graph (durable, 6 phases)
- `extensions_fatal_error_recovery` — Recovery fatal error estensione (durable, 6 phases)
- `extensions_hook_conflict_analysis` — Analisi conflitti hook (durable, 6 phases)
- `extensions_rest_schema_drift` — REST schema drift (durable, 6 phases)
- `extensions_block_editor_compatibility` — Compatibilità block editor (durable, 6 phases)
- `extensions_woocommerce_template_override` — Audit override WooCommerce (durable, 6 phases)
- `extensions_action_scheduler_health` — Health Action Scheduler (durable, 6 phases)
- `extensions_db_migration_acceptance` — Acceptance migration DB plugin (planner_assisted, 6 phases)
- `extensions_deprecation_audit` — Audit deprecazioni (durable, 6 phases)
- `extensions_asset_collision` — Collisione asset JS/CSS (durable, 6 phases)
- `extensions_php_version_readiness` — Readiness versione PHP (durable, 6 phases)
- `extensions_wp_core_readiness` — Readiness WordPress core (durable, 6 phases)
- `extensions_staging_production_parity` — Parità staging/production (durable, 6 phases)
- `extensions_configuration_drift` — Drift configurazione estensioni (durable, 6 phases)
- `extensions_rollback_rehearsal` — Rehearsal rollback estensione (planner_assisted, 6 phases)

### `media_stories`

- `media_srcset_integrity` — Integrità srcset (durable, 6 phases)
- `media_avif_fallback_qa` — QA fallback AVIF (durable, 6 phases)
- `media_attachment_seo` — SEO attachment media (durable, 6 phases)
- `media_filename_normalization` — Normalizza filename media (durable, 6 phases)
- `media_exif_privacy_cleanup` — Pulizia EXIF/privacy (planner_assisted, 6 phases)
- `media_semantic_duplicate_resolution` — Risolvi duplicati semantici (durable, 6 phases)
- `media_replacement_rollback` — Rollback sostituzione media (planner_assisted, 6 phases)
- `media_story_performance` — Performance asset story (durable, 6 phases)
- `media_video_poster_quality` — Qualità poster video (durable, 6 phases)
- `media_dimensions_cls` — Dimensioni media/CLS (durable, 6 phases)
- `media_cdn_origin_parity` — Parità CDN/origin media (durable, 6 phases)
- `media_gallery_alt_uniqueness` — Unicità ALT gallery (durable, 6 phases)
- `media_orphan_attachment_recovery` — Recovery attachment orfani (durable, 6 phases)
- `media_color_space_consistency` — Consistenza color space (durable, 6 phases)
- `media_asset_lineage_manifest` — Manifest lineage asset (durable, 6 phases)

### `operations`

- `ops_mission_state_recovery` — Recovery stato missione (durable, 6 phases)
- `ops_job_state_integrity` — Integrità stato job (durable, 6 phases)
- `ops_dead_letter_recovery` — Recovery dead-letter (durable, 6 phases)
- `ops_queue_saturation` — Saturazione code (durable, 6 phases)
- `ops_schedule_drift` — Drift schedulazioni (durable, 6 phases)
- `ops_idempotency_collision` — Collisione idempotenza (durable, 6 phases)
- `ops_execution_lane_leak` — Leak execution lane (durable, 6 phases)
- `ops_anti_crash_attestation_refresh` — Refresh anti-crash attestation (durable, 6 phases)
- `ops_audit_chain_integrity` — Integrità audit chain (durable, 6 phases)
- `ops_observability_anomaly` — Anomalia observability (durable, 6 phases)
- `ops_memory_state_consistency` — Consistenza memory state (durable, 6 phases)
- `ops_performance_budget_enforcement` — Enforcement performance budget (durable, 6 phases)
- `ops_artifact_retention` — Retention artifact (durable, 6 phases)
- `ops_browser_worker_recovery` — Recovery browser worker (durable, 6 phases)
- `ops_external_provider_degradation` — Degrado provider esterno (durable, 6 phases)

### `orders_customers`

- `commerceops_payment_status_reconcile` — Riconcilia pagamento/stato (durable, 6 phases)
- `commerceops_stuck_fulfillment_recovery` — Recovery fulfillment bloccato (durable, 6 phases)
- `commerceops_duplicate_detection` — Rilevazione ordini duplicati (durable, 6 phases)
- `commerceops_refund_ledger_reconcile` — Riconcilia refund ledger (durable, 6 phases)
- `commerceops_address_quality` — Qualità indirizzi ordine (durable, 6 phases)
- `commerceops_webhook_delivery_recovery` — Recovery webhook ordini (durable, 6 phases)
- `commerceops_sla_breach_triage` — Triage SLA ordini (durable, 6 phases)
- `commerceops_note_integrity` — Integrità note ordine (durable, 6 phases)
- `commerceops_tax_invoice_consistency` — Consistenza fiscale ordine (durable, 6 phases)
- `commerceops_shipping_exception_recovery` — Recovery eccezioni spedizione (durable, 6 phases)
- `commerceops_identity_resolution` — Risoluzione identità cliente (durable, 6 phases)
- `commerceops_account_state_recovery` — Recovery stato account cliente (durable, 6 phases)
- `commerceops_data_quality` — Qualità dati cliente (durable, 6 phases)
- `commerceops_post_refund_acceptance` — Acceptance post-rimborso (durable, 6 phases)
- `commerceops_cross_system_reconcile` — Riconcilia ordine cross-system (durable, 6 phases)

### `security_identity`

- `security_mcp_token_lifecycle` — Lifecycle token MCP (durable, 6 phases)
- `security_pairing_code_abuse` — Abuso pairing code (durable, 6 phases)
- `security_admin_role_drift` — Drift ruoli admin (planner_assisted, 6 phases)
- `security_session_anomaly` — Anomalia sessioni (durable, 6 phases)
- `security_secret_leak_scan` — Scan secret leakage (durable, 6 phases)
- `security_csp_drift` — CSP drift (durable, 6 phases)
- `security_rest_auth_boundary` — Boundary auth REST (durable, 6 phases)
- `security_supply_chain_integrity` — Integrità supply chain (durable, 6 phases)
- `security_plugin_hash_drift` — Drift hash plugin (durable, 6 phases)
- `security_backup_access` — Accesso backup (durable, 6 phases)
- `security_cookie_flags` — Cookie security flags (durable, 6 phases)
- `security_application_password_audit` — Audit application password (durable, 6 phases)
- `security_least_privilege_roles` — Least privilege ruoli (planner_assisted, 6 phases)
- `security_incident_evidence_chain` — Catena evidenze incidente (durable, 6 phases)
- `security_hardening_drift` — Drift hardening (planner_assisted, 6 phases)

## Runtime contract

A typical call is:

```json
{"action":"search","query":"autopilot rotation product repeats"}
```

then:

```json
{"action":"run","workflow_id":"seo_autopilot_state_convergence_enterprise"}
```

For workflows whose mutation cannot be chosen deterministically, the first run stops at `decision_required=true`; the next call supplies the chosen per-phase arguments and `continue_after_decision=true`. This is a decision boundary, not a blanket operator-approval gate.

## Release validation

The release gate validates: 300 unique IDs; 1665 grounded phases; every capability ID exists; every direct tool exists; zero Wave 1/Wave 2 ID collisions; dedicated Autopilot workflow contains no direct database completion; and Wave 2 workflows carry enterprise continuity, trace and lineage controls.

