# Code and Artifact Cleanup — 2026-08-25

## Removed

- `.github/scripts/generate-enterprise-workflows-wave1.py` — superseded by the unified 2026-08-25 generator; no runtime/test references.
- `.github/scripts/generate-enterprise-workflows-wave2.py` — superseded by the unified generator and depended on an external pasted file that is not part of the release.
- `prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-24.json` — stale generated index; runtime loads only the dated 2026-08-25 manifests.

## Retained intentionally

- `enterprise-workflows-wave1-2026-08-24.json` and `enterprise-workflows-wave2-2026-08-24.json` are migration fixtures. The unified generator and regression suite use them to prove preservation of the original 300 workflow IDs in Wave 2.
- `docs/ENTERPRISE-WORKFLOWS-300-2026-08-24.md` is the baseline migration record and is retained for audit lineage.
- `infection.json5` is the PHP mutation-testing configuration, not dead production code.

## Duplicate policy

Exact duplicate generated/reference documents were split by scope instead of retaining byte-identical copies. Workflow IDs are globally unique; aliases, redirects and generated helpers are not counted as canonical workflows.
