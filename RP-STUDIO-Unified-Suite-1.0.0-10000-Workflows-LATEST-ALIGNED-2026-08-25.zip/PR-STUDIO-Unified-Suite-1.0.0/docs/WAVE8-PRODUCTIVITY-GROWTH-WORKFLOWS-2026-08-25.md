# Wave 8 — Productivity / Social / Local / Content / Keyword / Ads

Reference date: 2026-08-25. Canonical workflows: **299**.

| ID | Domain | Mode | Browser | Risk | Purpose |
|---|---|---|---|---|---|
| `daily_morning_briefing` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: daily morning briefing. |
| `today_calendar_summary` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: today calendar summary. |
| `weekly_calendar_summary` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: weekly calendar summary. |
| `find_free_slots` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: find free slots. |
| `schedule_meeting` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: schedule meeting. |
| `reschedule_meeting` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: reschedule meeting. |
| `cancel_meeting` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: cancel meeting. |
| `email_unread_digest` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: email unread digest. |
| `email_priority_triage` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: email priority triage. |
| `email_reply_draft` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: email reply draft. |
| `email_followup_needed` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: email followup needed. |
| `email_to_task` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: email to task. |
| `slack_channel_digest` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: slack channel digest. |
| `slack_urgent_mentions` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: slack urgent mentions. |
| `slack_thread_summary` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: slack thread summary. |
| `slack_message_to_task` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: slack message to task. |
| `task_capture` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: task capture. |
| `task_prioritize` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: task prioritize. |
| `task_daily_plan` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: task daily plan. |
| `task_weekly_review` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: task weekly review. |
| `reminder_set` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: reminder set. |
| `reminder_snooze` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: reminder snooze. |
| `reminder_complete` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: reminder complete. |
| `notes_quick_capture` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: notes quick capture. |
| `notes_meeting_minutes` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: notes meeting minutes. |
| `notes_action_items` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: notes action items. |
| `personal_finance_overview` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: personal finance overview. |
| `personal_finance_spend_anomalies` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: personal finance spend anomalies. |
| `files_recent_summary` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: files recent summary. |
| `decision_log` | `personal_assistant` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: decision log. |
| `social_create_content_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social create content plan. |
| `social_build_content_calendar` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social build content calendar. |
| `social_idea_generator` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social idea generator. |
| `social_caption_writer` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social caption writer. |
| `social_hashtag_research` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social hashtag research. |
| `social_keyword_research` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social keyword research. |
| `social_trend_watchlist` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social trend watchlist. |
| `social_competitor_digest` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social competitor digest. |
| `social_analytics_snapshot` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social analytics snapshot. |
| `social_weekly_performance_report` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social weekly performance report. |
| `social_monthly_performance_report` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social monthly performance report. |
| `social_audience_insights` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social audience insights. |
| `social_content_gap_analysis` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social content gap analysis. |
| `social_best_time_to_post` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social best time to post. |
| `social_engagement_triage` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social engagement triage. |
| `social_comment_sentiment_summary` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social comment sentiment summary. |
| `social_inbox_digest` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social inbox digest. |
| `social_ugc_watchlist` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social ugc watchlist. |
| `social_campaign_brief` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social campaign brief. |
| `social_campaign_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social campaign plan. |
| `social_campaign_report` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social campaign report. |
| `social_campaign_anomaly_alert` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social campaign anomaly alert. |
| `social_post_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post draft. |
| `social_post_batch_drafts` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post batch drafts. |
| `social_post_approval_pack` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post approval pack. |
| `social_post_schedule` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post schedule. |
| `social_post_reschedule` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post reschedule. |
| `social_post_cancel` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post cancel. |
| `social_post_publish` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post publish. |
| `social_post_verify_published` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post verify published. |
| `social_crosspost_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social crosspost plan. |
| `social_crosspost_publish` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social crosspost publish. |
| `social_content_repurpose` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social content repurpose. |
| `social_blog_to_posts` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social blog to posts. |
| `social_product_to_posts` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social product to posts. |
| `social_video_idea_pack` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social video idea pack. |
| `social_reel_script_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social reel script draft. |
| `social_tiktok_script_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social tiktok script draft. |
| `social_youtube_shorts_script` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social youtube shorts script. |
| `social_linkedin_post_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social linkedin post draft. |
| `social_x_post_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social x post draft. |
| `social_instagram_caption_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social instagram caption draft. |
| `social_facebook_post_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social facebook post draft. |
| `social_pinterest_pin_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social pinterest pin draft. |
| `social_thread_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social thread draft. |
| `social_live_event_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social live event plan. |
| `social_event_promo_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social event promo plan. |
| `social_launch_sequence` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social launch sequence. |
| `social_offer_promo_sequence` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social offer promo sequence. |
| `social_evergreen_queue_build` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social evergreen queue build. |
| `social_evergreen_queue_refresh` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social evergreen queue refresh. |
| `social_content_recycle_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social content recycle plan. |
| `social_brand_voice_check` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social brand voice check. |
| `social_claims_compliance_check` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social claims compliance check. |
| `social_link_check` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social link check. |
| `social_asset_check` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social asset check. |
| `social_pre_publish_check` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social pre publish check. |
| `social_post_publish_monitor` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social post publish monitor. |
| `social_comment_reply_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social comment reply draft. |
| `social_dm_reply_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social dm reply draft. |
| `social_crisis_signal_watch` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social crisis signal watch. |
| `social_crisis_brief` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social crisis brief. |
| `social_paid_organic_sync` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social paid organic sync. |
| `social_influencer_shortlist` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social influencer shortlist. |
| `social_influencer_outreach_draft` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social influencer outreach draft. |
| `social_collab_brief` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social collab brief. |
| `social_content_experiment` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social content experiment. |
| `social_ab_test_plan` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social ab test plan. |
| `social_ab_test_result` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social ab test result. |
| `social_kpi_dashboard_refresh` | `social_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: social kpi dashboard refresh. |
| `local_find_business_profile` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local find business profile. |
| `local_profile_health_check` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local profile health check. |
| `local_name_address_phone_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local name address phone audit. |
| `local_hours_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local hours audit. |
| `local_special_hours_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local special hours update. |
| `local_category_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local category audit. |
| `local_category_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local category update. |
| `local_description_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local description audit. |
| `local_description_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local description update. |
| `local_services_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local services audit. |
| `local_services_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local services update. |
| `local_products_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local products audit. |
| `local_products_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local products update. |
| `local_attributes_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local attributes audit. |
| `local_attributes_update` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local attributes update. |
| `local_photo_inventory` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local photo inventory. |
| `local_photo_plan` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local photo plan. |
| `local_photo_publish` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local photo publish. |
| `local_cover_logo_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local cover logo audit. |
| `local_posts_plan` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local posts plan. |
| `local_post_draft` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local post draft. |
| `local_post_publish` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local post publish. |
| `local_qa_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local qa audit. |
| `local_qa_answer_draft` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local qa answer draft. |
| `local_reviews_digest` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local reviews digest. |
| `local_reviews_sentiment` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local reviews sentiment. |
| `local_review_reply_draft` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local review reply draft. |
| `local_negative_review_alert` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local negative review alert. |
| `local_spam_review_flag` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local spam review flag. |
| `local_duplicates_check` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local duplicates check. |
| `local_duplicate_suppression_plan` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local duplicate suppression plan. |
| `local_citation_audit` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local citation audit. |
| `local_citation_opportunities` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local citation opportunities. |
| `local_local_rank_snapshot` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local local rank snapshot. |
| `local_profile_change_log` | `local_listings_seo` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: local profile change log. |
| `generate_image` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: generate image. |
| `create_blog_graphic` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create blog graphic. |
| `remove_background` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: remove background. |
| `replace_background` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: replace background. |
| `extend_image` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: extend image. |
| `enhance_image` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: enhance image. |
| `create_icon_set` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create icon set. |
| `create_product_mockup` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create product mockup. |
| `create_ad_creative` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create ad creative. |
| `generate_storyboard` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: generate storyboard. |
| `generate_infographic` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: generate infographic. |
| `create_thumbnail_set` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create thumbnail set. |
| `visual_style_transfer` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: visual style transfer. |
| `asset_variant_generator` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: asset variant generator. |
| `image_text_overlay` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: image text overlay. |
| `batch_resize_images` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: batch resize images. |
| `topic_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: topic research. |
| `keyword_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword research. |
| `competitor_content_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: competitor content research. |
| `serp_intent_analysis` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: serp intent analysis. |
| `content_gap_analysis` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: content gap analysis. |
| `trend_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: trend research. |
| `product_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: product research. |
| `audience_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: audience research. |
| `source_pack_build` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: source pack build. |
| `faq_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: faq research. |
| `internal_link_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: internal link research. |
| `entity_research` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: entity research. |
| `create_blog_post` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create blog post. |
| `create_article` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create article. |
| `create_landing_page_copy` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create landing page copy. |
| `create_category_copy` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create category copy. |
| `create_product_description` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create product description. |
| `create_product_comparison` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create product comparison. |
| `create_buying_guide` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create buying guide. |
| `create_howto` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create howto. |
| `create_faq` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create faq. |
| `create_email_newsletter` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create email newsletter. |
| `create_email_sequence` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create email sequence. |
| `create_press_release` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create press release. |
| `create_case_study` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create case study. |
| `create_whitepaper` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create whitepaper. |
| `create_ebook_outline` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create ebook outline. |
| `create_video_script` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create video script. |
| `create_podcast_outline` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create podcast outline. |
| `create_social_post` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create social post. |
| `create_social_thread` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create social thread. |
| `create_ad_copy` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create ad copy. |
| `create_meta_title` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create meta title. |
| `create_meta_description` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create meta description. |
| `create_schema_faq_draft` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create schema faq draft. |
| `create_schema_howto_draft` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create schema howto draft. |
| `create_content_brief` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create content brief. |
| `create_editorial_calendar` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create editorial calendar. |
| `create_content_cluster_plan` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create content cluster plan. |
| `create_link_bait_asset` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: create link bait asset. |
| `rewrite_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: rewrite content. |
| `simplify_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: simplify content. |
| `expand_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: expand content. |
| `shorten_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: shorten content. |
| `tone_shift` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: tone shift. |
| `brand_voice_rewrite` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: brand voice rewrite. |
| `grammar_style_polish` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: grammar style polish. |
| `fact_check_draft` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: fact check draft. |
| `citations_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: citations check. |
| `plagiarism_risk_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: plagiarism risk check. |
| `readability_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: readability check. |
| `seo_onpage_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: seo onpage check. |
| `internal_link_suggestions` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: internal link suggestions. |
| `cannibalization_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: cannibalization check. |
| `content_freshness_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: content freshness check. |
| `claims_compliance_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: claims compliance check. |
| `legal_disclaimer_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: legal disclaimer check. |
| `publish_readiness_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: publish readiness check. |
| `qa_content_checklist` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: qa content checklist. |
| `localization_adapt` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: localization adapt. |
| `translation_review` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: translation review. |
| `terminology_consistency_check` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: terminology consistency check. |
| `update_outdated_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: update outdated content. |
| `merge_duplicate_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: merge duplicate content. |
| `extract_key_points` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: extract key points. |
| `repurpose_content` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: repurpose content. |
| `summarize_longform` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: summarize longform. |
| `generate_content_variants` | `creative_content` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: generate content variants. |
| `keyword_volume_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword volume check. |
| `keyword_batch_volume_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword batch volume check. |
| `keyword_difficulty_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword difficulty check. |
| `keyword_search_intent_classify` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword search intent classify. |
| `keyword_trend_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword trend check. |
| `keyword_seasonality_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword seasonality check. |
| `keyword_serp_features_check` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword serp features check. |
| `keyword_serp_snapshot` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword serp snapshot. |
| `keyword_related_queries` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword related queries. |
| `keyword_people_also_ask` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword people also ask. |
| `keyword_autocomplete_expand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword autocomplete expand. |
| `keyword_question_expand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword question expand. |
| `keyword_entity_expand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword entity expand. |
| `keyword_cluster` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword cluster. |
| `keyword_topic_map` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword topic map. |
| `keyword_content_map` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword content map. |
| `keyword_url_map` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword url map. |
| `keyword_gap_vs_competitor` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword gap vs competitor. |
| `keyword_opportunity_score` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword opportunity score. |
| `keyword_priority_queue` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword priority queue. |
| `keyword_local_variants` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword local variants. |
| `keyword_language_variants` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword language variants. |
| `keyword_synonym_expand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword synonym expand. |
| `keyword_longtail_expand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword longtail expand. |
| `keyword_brand_vs_nonbrand` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword brand vs nonbrand. |
| `keyword_commercial_terms` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword commercial terms. |
| `keyword_informational_terms` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword informational terms. |
| `keyword_transactional_terms` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword transactional terms. |
| `keyword_navigational_terms` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword navigational terms. |
| `keyword_position_tracking_snapshot` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword position tracking snapshot. |
| `keyword_rank_change_alert` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword rank change alert. |
| `keyword_cannibalization_serp` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword cannibalization serp. |
| `keyword_serp_competitor_extract` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword serp competitor extract. |
| `keyword_top_pages_extract` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword top pages extract. |
| `keyword_domain_overlap` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword domain overlap. |
| `keyword_competitor_new_keywords` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword competitor new keywords. |
| `keyword_competitor_lost_keywords` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword competitor lost keywords. |
| `keyword_export_csv` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword export csv. |
| `keyword_report_build` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword report build. |
| `keyword_research_full` | `keyword_competitive` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: keyword research full. |
| `ads_create_campaign` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads create campaign. |
| `ads_create_adset` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads create adset. |
| `ads_create_ad` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads create ad. |
| `ads_update_campaign` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads update campaign. |
| `ads_update_adset` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads update adset. |
| `ads_update_ad` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads update ad. |
| `ads_pause_campaign` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads pause campaign. |
| `ads_resume_campaign` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads resume campaign. |
| `ads_pause_adset` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads pause adset. |
| `ads_resume_adset` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads resume adset. |
| `ads_pause_ad` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads pause ad. |
| `ads_resume_ad` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads resume ad. |
| `ads_duplicate_campaign` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads duplicate campaign. |
| `ads_duplicate_adset` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads duplicate adset. |
| `ads_duplicate_ad` | `ads_operations` | `durable` | `optional` | `high` | Exact cumulative workflow from the later 299-workflow specification: ads duplicate ad. |
| `ads_campaign_summary` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads campaign summary. |
| `ads_performance_report` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads performance report. |
| `ads_spend_summary` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads spend summary. |
| `ads_budget_pacing` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads budget pacing. |
| `ads_budget_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads budget alert. |
| `ads_cpa_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads cpa alert. |
| `ads_roas_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads roas alert. |
| `ads_ctr_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads ctr alert. |
| `ads_cvr_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads cvr alert. |
| `ads_frequency_alert` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads frequency alert. |
| `ads_anomaly_detect` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads anomaly detect. |
| `ads_top_performers` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads top performers. |
| `ads_bottom_performers` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads bottom performers. |
| `ads_creative_fatigue_check` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads creative fatigue check. |
| `ads_audience_overlap_check` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads audience overlap check. |
| `ads_search_terms_review` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads search terms review. |
| `ads_negative_keyword_suggestions` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads negative keyword suggestions. |
| `ads_keyword_bid_review` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads keyword bid review. |
| `ads_placement_review` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads placement review. |
| `ads_device_breakdown` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads device breakdown. |
| `ads_geo_breakdown` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads geo breakdown. |
| `ads_dayparting_analysis` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads dayparting analysis. |
| `ads_attribution_compare` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads attribution compare. |
| `ads_tracking_health_check` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads tracking health check. |
| `ads_conversion_gap_check` | `ads_operations` | `durable` | `optional` | `medium` | Exact cumulative workflow from the later 299-workflow specification: ads conversion gap check. |
