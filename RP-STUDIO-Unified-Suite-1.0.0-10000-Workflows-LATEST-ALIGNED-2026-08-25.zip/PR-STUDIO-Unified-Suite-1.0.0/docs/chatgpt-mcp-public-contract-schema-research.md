# ChatGPT / MCP public tool contract schema research

Date: 2026-08-24

This note records the design basis for the public RP Studio Connector contract refinements in `class-prstudio-uc-public-tool-contracts.php`.

## Sources

- OpenAI, *Latest model / tool-use guidance*: https://developers.openai.com/api/docs/guides/latest-model
- OpenAI, *Build an MCP server*: https://developers.openai.com/plugins/build/mcp-server
- OpenAI, *Plugins reference*: https://developers.openai.com/plugins/reference
- Model Context Protocol, *2026-07-28 release candidate*: https://blog.modelcontextprotocol.io/posts/2026-07-28-release-candidate/
- Model Context Protocol, *Tool annotations*: https://blog.modelcontextprotocol.io/posts/2026-03-16-tool-annotations/
- Playwright, *Locators*: https://playwright.dev/docs/locators

## Contract rules applied

1. Public descriptions lead with the action and the decision boundary: what the tool does and when it is the right tool. Long operating guidance remains available through `prstudio_tool_manual` instead of bloating `tools/list`.
2. Stable vocabularies use enums. Stable identifiers and bounded text use realistic length/pattern constraints. URLs and UUID-shaped values advertise formats when the runtime semantics support them.
3. Conditional contracts use JSON Schema composition where the runtime has conditional requirements, for example `prstudio_observe`, `prstudio_flow`, and `wordpress_content_transaction`.
4. Dynamic objects stay dynamic only when the schema is genuinely selected at runtime. In particular, `prstudio_execute.arguments` is defined by `prstudio_capability_describe`, and `prstudio_do.params` is defined by the resolved intent.
5. `social_metrics_ingest` is no longer an unbounded free-form object: its public schema mirrors the provider-neutral normalization already implemented by the backend, including account/source/platform vocabularies and metric/content bounds.
6. Browser target discovery prefers reusable target references and semantic role/label/text locators before CSS/XPath fallback. This follows the Browser Agent's own snapshot model and Playwright's resilience guidance.
7. MCP annotations reflect the worst operation a tool can perform. `prstudio_flow`, for example, cannot truthfully advertise `readOnlyHint=true` because a flow may contain mutations or destructive operations.
8. Compatibility is preserved where the runtime intentionally infers values. `prstudio_observe.target` remains optional because the handler infers `url` from `url` and `post` from `id`; conditional requirements apply only once an explicit target is selected.

## Output schemas and bounded discovery

Every direct tool always exposes an `outputSchema`, OAuth security schemes and all four safety annotations. Successful and error `structuredContent` use the same advertised envelope. The complete descriptor is budgeted as emitted — including title, input/output schemas, security, annotations and `_meta` — and `tools/list` uses deterministic cursor pagination so all tools remain reachable without any page exceeding the context ceiling. The lossless `prstudio_capability_catalog` independently exposes every runtime capability with its input/output schemas and annotations.
