# RP STUDIO — Cumulative 10,000 Workflow Architecture

Cutoff: 2026-08-25. Canonical executable workflows: **10,000**. Grounded executable phases: **40,715**. Domains: **178**.

| Wave | Count | Role |
|---:|---:|---|
| 1 | 300 | General BrowserKing/browser automation, tab ownership and recovery. |
| 2 | 300 | Original 300 workflow IDs preserved for backward compatibility. |
| 3 | 300 | Engineering, logs, bugs, refactor, repo/file analysis and defensive security. |
| 4 | 380 | Global agency expansion and specialist centres of excellence. |
| 5 | 600 | Agency operating-system strategic/compositional workflows. |
| 6 | 299 | First exact consulting/production 299-workflow prompt. |
| 7 | 200 | Gutenberg, HTML, JavaScript, Java and CSS engineering. |
| 8 | 299 | Second distinct productivity/social/local/content/keyword/ads 299-workflow prompt. |
| 9 | 7,322 | Enterprise Atlas: 73 domains × 100 lifecycle procedures + 22 cross-domain controls. |
| **Total** | **10,000** | **Canonical executable registry** |

The registry preserves every previously loaded workflow ID. Wave 8 preserves the second distinct 299-workflow specification; Wave 9 contributes 7,322 enterprise procedures. Wave 9 is not an alias pack: it is a lifecycle matrix over 73 operating domains, 10 domain concerns and 10 distinct lifecycle objectives (observe, diagnose, map, plan, execute, verify, measure, optimize, recover, govern), plus 22 cross-domain controls.

## How ChatGPT sees the suite

ChatGPT sees a compact MCP surface of **123 public tools**, backed by **1,364 canonical capabilities** and **1,076 legacy actions**. It does **not** receive 10,000 top-level workflow tools. The public `prstudio_workflow` gateway exposes all 10,000 canonical workflows through paginated `search`/`catalog`, then `describe`/`validate` and server-side `run`. The gateway accepts Waves 1–9 and a catalog/search limit up to 100 with offset pagination.

This separation keeps tool selection bounded while preserving lossless workflow reachability. Direct primitive requests can still use typed tools; multi-step objectives should prefer the canonical workflow gateway.

## Authoritative count sources

- `prstudio-unified-control/workflows/enterprise-workflows-index-2026-08-25.json` — workflow, phase, wave and domain registry.
- `prstudio-unified-control/BUILD-INFO.json` — MCP tool, capability and action counts.
- `RP-STUDIO-CHATGPT-PLUGIN-1.0.0.json` — ChatGPT/MCP exposure contract.
- `prstudio-unified-control/workflows/README.md` — human-readable registry map.
