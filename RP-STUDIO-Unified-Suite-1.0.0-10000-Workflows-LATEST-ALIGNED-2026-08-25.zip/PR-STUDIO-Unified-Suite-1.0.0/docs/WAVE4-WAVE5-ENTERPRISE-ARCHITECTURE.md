# Wave 4–5 Enterprise Architecture

The suite remains a three-component system: principal orchestration/workflow registry, BrowserKing-derived browser executor, and WordPress control plane. New workflows are internal canonical procedures routed through the existing compact workflow surface; they do not become thousands of top-level MCP tools.

Execution success, verification success and business outcome remain separate states. All retries are bounded, mutations require authorization/idempotency, and high-consequence legal/security decisions require human review.
