# OpenAI MCP first-call reliability runbook — 2026-08-24

## Problema che questo runbook risolve

Avere centinaia o migliaia di controlli **dopo** la selezione del tool non garantisce che il primo tool scelto sia quello corretto. RP STUDIO deve quindi rendere corretta la strada iniziale tramite metadata brevi, invarianti lato server, progressive disclosure e regressioni sul primo tool.

## Evidenza ufficiale OpenAI verificata il 24/08/2026

1. **Snapshot MCP** — la documentazione ChatGPT Developer mode richiede `Scan Tools` durante la configurazione e specifica che un'app MCP approvata usa uno snapshot congelato di tool/input; le modifiche successive non entrano in uso finché l'aggiornamento non viene riesaminato/pubblicato. Un server live con schema diverso dallo snapshot può produrre errori.
   - https://help.openai.com/en/articles/12584461-developer-mode-and-full-mcp-connectors-in-chatgpt
2. **Prompt/tool set più snelli** — la guida modelli OpenAI raccomanda di esporre solo i tool rilevanti, mantenere descrizioni concise e precise, dichiarare ogni istruzione una volta e validare su eval rappresentative.
   - https://developers.openai.com/api/docs/guides/latest-model
3. **Tool-specific guidance nei metadata** — la stessa guida raccomanda che la descrizione del tool dica cosa fa, quando usarlo, input richiesti, effetti collaterali, retry safety ed errori comuni.
4. **Allowed tools / tool_choice** — quando il client/API lo consente, `allowed_tools` limita il sottoinsieme invocabile e `tool_choice` può richiedere/restringere una scelta senza affidarsi a un fragile ordine scritto nel prompt.
   - https://developers.openai.com/api/docs/guides/latest-model?model=gpt-5.2
   - https://developers.openai.com/api/reference/resources/responses/methods/create
5. **Workflow bounded** — per sequenze deterministiche, la guida GPT-5.6 raccomanda Programmatic Tool Calling o un equivalente server-side quando non serve nuovo giudizio del modello tra i passaggi. RP STUDIO implementa lo stesso principio con tool compositi (`browser_batch`, `prstudio_flow`, transazioni contenuto).

## Correzioni applicate in questa suite

### 1. Lane non più prerequisito del modello

`browser_*`, GSC e Local Studio usano `PRSTUDIO_UC_Execution_Lanes::ensure_runtime_lane()`. `prstudio_context_open` resta disponibile soltanto per isolamento esplicito/recovery. I metadata non dicono più di anteporlo a ogni mutazione.

### 2. Error contract univoco

Un task Browser eseguito con evidenza applicativa incompleta è `degraded`, non `technical_error`. Il risultato conserva `executed=true`, `effect_verified=false` e `next_action` strutturata quando serve una verifica sulla stessa tab.

### 3. Tool surface progressiva

Il catalogo completo resta raggiungibile ma la prima superficie privilegia router/fast path. Le operazioni note vanno chiamate direttamente; search/describe è solo per capacità non note.

### 4. Workflow frequenti composti

Responsive capture è un tool diretto (`browser_responsive_matrix`), le micro-azioni browser già determinate sono `browser_batch`, i workflow multi-dominio sono `prstudio_flow`.

### 5. BrowserKing loop separato dai tool deterministici

`browser_agent_prompt` preserva un prompt/tool agent-loop BrowserKing-compatible residente nel Browser Agent. Non è il default: se ChatGPT conosce l'azione deterministica, deve usare il tool tipizzato. In questo modo il doppio modello è una capacità esplicita, non un costo/ambiguità nascosta.

### 6. Golden eval sul primo tool

`quality/first-tool-routing-cases.json` misura almeno:

- `first_correct_tool_rate`;
- `calls_to_success`;
- assenza di `prstudio_health`/`prstudio_context_open` preventivi quando l'intento è già concreto;
- selezione del workflow composito per responsive e sequenze deterministiche;
- separazione browser/database/WordPress.

## Procedura dopo ogni modifica MCP

`deploy -> Inspector initialize/tools/list -> Scan Tools o Refresh/Publish -> nuova chat -> golden eval`

Il criterio di accettazione non è soltanto “alla fine riesce”: la regressione deve fallire se il primo tool è sbagliato o se vengono introdotti round-trip infrastrutturali non richiesti.
