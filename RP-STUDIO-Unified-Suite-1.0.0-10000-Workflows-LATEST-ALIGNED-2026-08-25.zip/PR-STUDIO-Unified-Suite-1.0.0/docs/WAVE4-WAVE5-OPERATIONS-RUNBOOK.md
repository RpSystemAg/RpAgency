# Wave 4–5 Operations Runbook

1. Inventory registry and verify manifest counts. 2. Search/describe before execution. 3. Confirm permissions and high-risk gates. 4. Execute bounded phases with request/correlation IDs. 5. Preserve the root technical error and nested cause. 6. Verify objective-specific postconditions. 7. Record execution/verification/business-outcome separately. 8. For browser failures, retain the owned lane, inspect tab registry/affinity, and never use an arbitrary user tab as fallback.
