# SEO report-scope + Rank Math acceptance hotfix — 2026-08-24

## Failure pattern fixed

A product-level audit could return `issue_count=0` and the model could incorrectly announce that an entire supplied report was complete. Separately, the Browser Agent could lose ownership of an already-open Search Console/Trends/WordPress tab and encourage a context rebind instead of recovering the same lane.

This hotfix makes both conditions structural rather than prompt-only advice.

## Binding report denominator

For a report/CSV/URL list, initialize `prstudio_seo_autopilot_control` with `action=init`, `scope_mode=explicit`, and every report product ID/URL. The complete target set remains server-side and the MCP response exposes only a bounded summary. `campaign_complete=true` requires the full denominator to be completed, with no unresolved report URLs and no open/blocked/review rows.

A one-product `commerce_product_audit` result is explicitly product-scoped and can never mean the report campaign is complete.

## Per-product acceptance

A campaign can bind:

- a Rank Math score target;
- a minimum relevant focus-keyword count;
- strict remaining-issue closure;
- live Rank Math editor score observation;
- verified outcome;
- per-product media review/search evidence.

`complete` is rejected until the bound requirements are satisfied. The system never writes `rank_math_seo_score` to fake a score. The score must be produced by Rank Math's own analysis and, when requested, observed in the editor.

Rank Math's official product-page documentation confirms that its product analysis checks the focus keyword in the SEO title, meta description, URL, beginning/body content and image ALT, and that product media/readability tests are part of the analysis. Rank Math also supports multiple focus keywords, with the first one treated as primary, while warning against keyword stuffing.

Official references:

- https://rankmath.com/kb/content-analysis-tests-for-product-pages/
- https://rankmath.com/kb/what-is-a-focus-keyword/
- https://rankmath.com/kb/seo-score-not-available/

## Media gate

With `media_policy=review_if_available`, each product completion must record that media candidates were actually searched/reviewed and one of:

- `updated` with change evidence;
- `kept_relevant` when existing media is already appropriate (and the main image ALT is not empty);
- `none_available` only when no current/gallery/researched candidate is available.

This prevents silently skipping image work on a report-wide SEO task.

## Browser lane recovery

The resident BrowserKing-compatible loop now exposes `browser_adopt_tabs`. In addition, an explicit HTTP(S) `tab_id` that is not currently owned is automatically adopted into the existing lane when safe. Cross-lane conflicts and restricted URLs remain rejected.

The required recovery is therefore:

`same lane -> adopt/recover exact tab -> continue`

not:

`rebind context -> lose tab affinity -> retry from scratch`.
