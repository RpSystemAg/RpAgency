# Wave 4–5 Enterprise Research (extended register compatibility) — 2026-08-25

## Cutoff and technical baseline

Research is frozen at **25 August 2026**. No platform behavior published after that date is treated as a requirement.

### Gutenberg / WordPress

WordPress 7.1 is the production baseline (released 19 August 2026). Wave 7 explicitly covers block metadata and validation, responsive block styles, iframed-editor compatibility, Interactivity API directives/store/SSR, Script Modules, block bindings, DataViews/Abilities integration, accessibility, migration and editor/frontend parity. Experimental or preview editor APIs must be recorded as such rather than silently treated as stable.

### HTML

The WHATWG HTML Living Standard was last updated 11 August 2026 at the cutoff. Workflows verify semantics, parsing/conformance, forms, navigation, custom elements, declarative shadow DOM, embedded-content security, accessibility and progressive enhancement against rendered browser evidence.

### JavaScript

ECMAScript/TC39 is the language-standard baseline. The suite does not invent a JS runtime or compiler: repository/static analysis is combined with the existing Browser Agent for console, page-error, network and runtime evidence.

### Java

Java SE 26 is final as of March 2026. For enterprise longevity the workflows separately audit a JDK 25 baseline and Java 26 compatibility. Preview-sensitive features such as Structured Concurrency are never assumed enabled; selected JDK release and preview opt-in must be explicit. Because the suite has no arbitrary-shell Maven/Gradle executor, Java workflows perform repository/build-configuration/security analysis and must never fabricate compilation or test success.

### CSS

The suite follows individual W3C CSS module specifications, using CSS Snapshot 2025 only as a non-normative module-status overview. Workflows cover cascade/layers, nesting, containment, container/style queries, layout, modern color, reduced motion/forced colors, coverage and render-performance, with Browser Agent visual verification.

### ChatGPT Plugin / MCP exposure

Current OpenAI documentation describes Plugins as an MCP-server-based extension surface. The MCP server defines tools available to ChatGPT and Codex; each tool should represent a coherent user goal with explicit schemas, authorization, side effects, failure behavior and safety annotations. RP STUDIO therefore keeps its existing typed MCP surface and exposes every canonical workflow through the paginated `prstudio_workflow` catalog/search/describe/run gateway. This provides complete workflow reachability without flattening thousands of internal procedures into overlapping top-level tools.
