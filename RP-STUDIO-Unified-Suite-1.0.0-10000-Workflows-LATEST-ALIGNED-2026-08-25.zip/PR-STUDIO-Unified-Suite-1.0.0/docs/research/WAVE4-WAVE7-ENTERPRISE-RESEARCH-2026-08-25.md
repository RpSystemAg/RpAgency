# Wave 4–7 Enterprise Research Register — 2026-08-25

This is the cross-wave research entry point. Wave 4–5 use the global agency/platform/regulatory sources in `WAVE4-WAVE5-SOURCE-REGISTER-2026-08-25.json`; Wave 7 adds the web-engineering sources documented in `../WAVE7-ENTERPRISE-RESEARCH-2026-08-25.md`. The combined machine-readable register is `WAVE4-WAVE7-SOURCE-REGISTER-2026-08-25.json`.

Research cutoff is **2026-08-25**. Sources published after that date are excluded. Normative specifications/regulators take precedence over first-party operating-model references; preview/experimental APIs require explicit workflow metadata and cannot be silently treated as stable.

## Additional cumulative security sources — 2026-08-25

- OWASP ASVS 5.0.0 — stable application-security verification standard, released 2025-05-30.
- OWASP Top 10:2025 — current awareness baseline; not treated as exhaustive verification coverage.
