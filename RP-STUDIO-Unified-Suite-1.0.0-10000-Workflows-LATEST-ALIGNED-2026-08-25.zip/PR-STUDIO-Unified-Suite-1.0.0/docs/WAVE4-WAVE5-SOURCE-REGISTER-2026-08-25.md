# Wave 4–7 Source Register — 2026-08-25

Research cutoff: **2026-08-25**. Official/normative sources are preferred; non-normative first-party operating-model references are marked.

| ID | Provider | Source | Normative | Preview | URL |
|---|---|---|---:|---:|---|
| `openai_plugins_mcp` | OpenAI | Build an MCP server — Plugins | yes | no | https://developers.openai.com/plugins/build/mcp-server |
| `openai_plugins_tools` | OpenAI | Define tools — Plugins | yes | no | https://developers.openai.com/plugins/plan/tools |
| `openai_agents` | OpenAI | Agents SDK — Orchestration and guardrails | yes | no | https://openai.github.io/openai-agents-python/ |
| `openai_deep_research` | OpenAI | Deep research | yes | no | https://developers.openai.com/api/docs/guides/deep-research |
| `github_code_security` | GitHub | GitHub Code Security documentation | yes | no | https://docs.github.com/en/code-security |
| `github_actions` | GitHub | GitHub Actions documentation | yes | no | https://docs.github.com/en/actions |
| `github_attestations` | GitHub | Artifact attestations | yes | no | https://docs.github.com/en/actions/security-for-github-actions/using-artifact-attestations |
| `wordpress_developer` | WordPress | WordPress Developer Resources | yes | no | https://developer.wordpress.org/ |
| `wp71_field_guide` | WordPress | WordPress 7.1 Field Guide / developer changes | yes | no | https://make.wordpress.org/core/2026/08/05/wordpress-7-1-field-guide/ |
| `wp_interactivity_api` | WordPress | Interactivity API Reference | yes | no | https://developer.wordpress.org/block-editor/reference-guides/interactivity-api/ |
| `wp_block_editor` | WordPress | Block Editor Handbook | yes | no | https://developer.wordpress.org/block-editor/ |
| `wordpress_vip` | WordPress VIP | WordPress VIP Documentation | yes | no | https://docs.wpvip.com/ |
| `figma_developers` | Figma | Figma Developer Documentation | yes | no | https://developers.figma.com/ |
| `shopify_dev` | Shopify | Shopify Developer Documentation | yes | no | https://shopify.dev/docs |
| `canva_connect` | Canva | Canva Connect APIs | yes | no | https://www.canva.dev/docs/connect/ |
| `motion_docs` | Motion | Motion documentation | yes | no | https://motion.dev/docs |
| `google_search_console` | Google | Search Console documentation | yes | no | https://developers.google.com/search/docs/monitor-debug/search-console-start |
| `bing_webmaster` | Microsoft | Bing Webmaster API / Webmaster Tools | yes | no | https://learn.microsoft.com/en-us/bingwebmaster/ |
| `indexnow` | IndexNow | IndexNow protocol | yes | no | https://www.indexnow.org/documentation |
| `mobbin_official` | Mobbin | Mobbin API / MCP documentation | no | no | https://mobbin.com/ |
| `higgsfield_official` | Higgsfield | Higgsfield product documentation | no | no | https://higgsfield.ai/ |
| `eurlex_ai_act` | European Union | Regulation (EU) 2024/1689 — Artificial Intelligence Act | yes | no | https://eur-lex.europa.eu/eli/reg/2024/1689/oj |
| `eurlex_gpsr` | European Union | Regulation (EU) 2023/988 — General Product Safety Regulation | yes | no | https://eur-lex.europa.eu/eli/reg/2023/988/oj |
| `eu_accessibility` | European Union | European Accessibility Act — Directive (EU) 2019/882 | yes | no | https://eur-lex.europa.eu/eli/dir/2019/882/oj |
| `eu_gdpr` | European Union | Regulation (EU) 2016/679 — GDPR | yes | no | https://eur-lex.europa.eu/eli/reg/2016/679/oj |
| `eu_dsa` | European Union | Regulation (EU) 2022/2065 — Digital Services Act | yes | no | https://eur-lex.europa.eu/eli/reg/2022/2065/oj |
| `garante_cookie` | Garante Privacy | Linee guida cookie e altri strumenti di tracciamento | yes | no | https://www.garanteprivacy.it/home/docweb/-/docweb-display/docweb/9677876 |
| `agcm_official` | AGCM | Autorità Garante della Concorrenza e del Mercato | yes | no | https://www.agcm.it/ |
| `agenzia_entrate` | Agenzia delle Entrate | Agenzia delle Entrate | yes | no | https://www.agenziaentrate.gov.it/ |
| `adm_official` | Agenzia Dogane e Monopoli | ADM | yes | no | https://www.adm.gov.it/ |
| `mimit_official` | MIMIT | Ministero delle Imprese e del Made in Italy | yes | no | https://www.mimit.gov.it/ |
| `whatwg_html` | WHATWG | HTML Living Standard | yes | no | https://html.spec.whatwg.org/ |
| `tc39_ecma262` | Ecma/TC39 | ECMAScript Language Specification | yes | no | https://tc39.es/ecma262/ |
| `oracle_java_se26` | Oracle / JCP | Java Language Specification, Java SE 26 / JSR 401 | yes | no | https://docs.oracle.com/javase/specs/jls/se26/html/index.html |
| `openjdk_jdk25` | OpenJDK | JDK 25 project and integrated JEPs | yes | no | https://openjdk.org/projects/jdk/25/ |
| `w3c_css_snapshot_2025` | W3C | CSS Snapshot 2025 | no | no | https://www.w3.org/TR/css-2025/ |
| `w3c_css_nesting` | W3C | CSS Nesting Module Level 1 | yes | no | https://www.w3.org/TR/css-nesting-1/ |
| `w3c_css_containment` | W3C | CSS Containment Module Level 3 | yes | no | https://www.w3.org/TR/css-contain-3/ |
| `w3c_css_cascade` | W3C | CSS Cascading and Inheritance | yes | no | https://www.w3.org/TR/css-cascade-6/ |
| `chrome_tabs` | Google Chrome | chrome.tabs API | yes | no | https://developer.chrome.com/docs/extensions/reference/api/tabs |
| `chrome_tabgroups` | Google Chrome | chrome.tabGroups API | yes | no | https://developer.chrome.com/docs/extensions/reference/api/tabGroups |
| `chrome_cdp` | Chrome DevTools Protocol | Chrome DevTools Protocol | yes | no | https://chromedevtools.github.io/devtools-protocol/ |
| `chrome_lighthouse` | Google Chrome | Lighthouse documentation | yes | no | https://developer.chrome.com/docs/lighthouse/ |
| `playwright_pages` | Microsoft Playwright | Pages / multi-page documentation | yes | no | https://playwright.dev/docs/pages |
| `playwright_tracing` | Microsoft Playwright | Trace Viewer / tracing | yes | no | https://playwright.dev/docs/trace-viewer |
| `wpp_open` | WPP | WPP Open | no | no | https://www.wpp.com/en/wpp-open |
| `accenture_song` | Accenture Song | Accenture Song | no | no | https://www.accenture.com/us-en/about/accenture-song-index |
| `dept_agency` | DEPT | DEPT agency operating references | no | no | https://www.deptagency.com/ |

## Additional cumulative security sources — 2026-08-25

- OWASP ASVS 5.0.0 — stable application-security verification standard, released 2025-05-30.
- OWASP Top 10:2025 — current awareness baseline; not treated as exhaustive verification coverage.
