# Wave Migration

On 2026-08-25 the former Wave 1 and Wave 2 corpus (300 IDs total) is consolidated into continuity Wave 2 without renaming workflow IDs or changing their execution semantics. The new Wave 1 is a 300-workflow browser-control foundation. Wave 3 is engineering/reliability/security. Wave 4 and Wave 5 retain the exact 380/600 counts required by the master prompt. The separate 299-workflow consultant prompt is Wave 6. Wave 7 adds exactly 200 Gutenberg/HTML/JavaScript/Java/CSS enterprise workflows grounded to the 2026-08-25 research cutoff.
